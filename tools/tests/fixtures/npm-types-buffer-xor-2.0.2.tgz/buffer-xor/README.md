# Installation
> `npm install --save @types/buffer-xor`

# Summary
This package contains type definitions for buffer-xor (https://github.com/crypto-browserify/buffer-xor).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/buffer-xor.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/buffer-xor/index.d.ts)
````ts
/// <reference types = "node" />

declare function xor(a: Buffer, b: Buffer): Buffer;

export = xor;

````

### Additional Details
 * Last updated: Mon, 06 Nov 2023 22:41:05 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [Daniel Byrne](https://github.com/danwbyrne).
