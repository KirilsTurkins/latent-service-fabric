"""Recover the original v46 evidence without starting or modifying a workload."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

COORD = Path(__file__).resolve().parent
OWNER = "latent-p4-root-native-20261004-v1"
BASE = "/var/lib/docker/volumes/" + OWNER + "/_data"
JOB = "portable-v2-installed394-native-20261007-v46"
HEAD = "b62fec1f0a3f9f8d4505f2b56ccded4e93eeba64"
OUT = COORD / JOB / "recovered-host-custody-20261007-v2"
OUT.mkdir()
recipe = json.loads((COORD / "entity-contract-v33-installed394-native-steps-20261007.json").read_bytes())
assert len(recipe) == 8
body = r'''
import hashlib, json, os, stat, subprocess
from pathlib import Path
base = Path(BASE_PLACEHOLDER)
out = base / 'jobs' / JOB_PLACEHOLDER
names = ['receipt.json', 'progress.json'] + ['step-' + str(i) + '.log' for i in range(1,9)]
files = []
total = 0
for name in names:
    path = out / name
    if not path.exists():
        continue
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_size <= 16*1024**2
    total += info.st_size
    assert total <= 32*1024**2
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(65536):
            digest.update(chunk)
    files.append(dict(name=name, bytes=info.st_size, sha256=digest.hexdigest()))
lock = base / 'jobs' / 'root-native-active-v2.lock'
owners = []
if lock.exists():
    info = lock.stat()
    identity = f'{os.major(info.st_dev):02x}:{os.minor(info.st_dev):02x}:{info.st_ino}'
    for line in Path('/proc/locks').read_text().splitlines():
        fields = line.split()
        if identity in fields:
            owners.append(line)
processes = []
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit() or int(entry.name) == os.getpid():
        continue
    try:
        comm = (entry/'comm').read_text().strip()
        if comm in {'cargo','rustc','clippy-driver','latentd','latent'} or comm.startswith('latent_node-'):
            processes.append(dict(pid=int(entry.name), name=comm, cwd=os.readlink(entry/'cwd')))
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        pass
source = base / 'native-active-portable-v3'
env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_CONFIG_GLOBAL=str(base/'jobs/gitconfig'))
git = {}
for key,args in [('head',['rev-parse','HEAD']),('tree',['rev-parse','HEAD^{tree}']),('status',['status','--porcelain'])]:
    result = subprocess.run(['git','--no-optional-locks',*args],cwd=source,env=env,capture_output=True,text=True,timeout=15)
    assert len(result.stdout.encode()) <= 16*1024**2
    git[key] = dict(exitCode=result.returncode, stdout=result.stdout, stderr=result.stderr)
print(json.dumps(dict(files=files, totalBytes=total, nativeLockOwners=owners, nativeProcesses=processes, source=git)))
'''.replace("BASE_PLACEHOLDER", repr(BASE)).replace("JOB_PLACEHOLDER", repr(JOB))
probe = subprocess.run(["docker", "exec", "-i", "--user", "10001:10001", OWNER, "python3"],
                       input=body.encode(), capture_output=True, timeout=60)
(OUT / "probe.stdout").write_bytes(probe.stdout)
(OUT / "probe.stderr").write_bytes(probe.stderr)
assert probe.returncode == 0, "read-only Native evidence probe failed"
observed = json.loads(probe.stdout)
assert not observed["nativeLockOwners"], "original Native controller still owns its lock; observe only"
assert not observed["nativeProcesses"], "Native children remain; no new workload allowed"
copied = []
for row in observed["files"]:
    destination = OUT / row["name"]
    result = subprocess.run(["docker", "cp", OWNER + ":" + BASE + "/jobs/" + JOB + "/" + row["name"], str(destination)],
                            capture_output=True, timeout=30)
    (OUT / (row["name"] + ".copy.stderr")).write_bytes(result.stderr)
    assert result.returncode == 0
    data = destination.read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
    copied.append(row)
final = OUT / "receipt.json"
record = dict(at=datetime.now(timezone.utc).isoformat(), job=JOB, head=HEAD,
              originalHostObserverFailure="C: full while writing docker-output.log; original host process exited1",
              readOnlyRecovery=True, copied=copied, nativeProcessesAbsent=True, nativeLockAbsent=True,
              completeCI=False, finalReceiptPresent=final.exists(), exactAttemptVerified=False)
if final.exists():
    receipt = json.loads(final.read_bytes())
    tree = subprocess.check_output(["git", "-C", r"C:\Users\turkins\Desktop\lf-p4-entity394-installed-v28", "rev-parse", HEAD + "^{tree}"], timeout=15, text=True).strip()
    assert receipt["head"] == HEAD and receipt["tree"] == tree
    assert receipt["deadlineSeconds"] == 1800 and receipt["maximumTargetGrowthBytes"] == 16*1024**3
    assert len(receipt["steps"]) == len(recipe)
    for index,row in enumerate(receipt["steps"]):
        assert row["argv"] == recipe[index] and row["originalProcessReaped"]
        raw = (OUT / row["log"]).read_bytes()
        assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
    assert receipt["sourceClean"] and receipt["sourceHeadUnchanged"] and receipt["originalProcessReaped"]
    assert observed["source"]["head"]["stdout"].strip() == HEAD
    assert observed["source"]["tree"]["stdout"].strip() == tree
    assert observed["source"]["status"]["exitCode"] == 0 and not observed["source"]["status"]["stdout"]
    record.update(exactAttemptVerified=True, originalPassed=receipt["passed"],
                  originalReceiptSha256=hashlib.sha256(final.read_bytes()).hexdigest(),
                  stepExitCodes=[row["exitCode"] for row in receipt["steps"]],
                  elapsedSeconds=receipt["elapsedSeconds"])
(OUT / "host-custody.json").write_text(json.dumps(record, indent=2)+"\n",encoding="utf8")
print(json.dumps(record))
