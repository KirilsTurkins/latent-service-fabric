Add transaction, fresh-query and deferred-intent facades to the six maintained guest SDKs. Each actual compiler owner builds an independently authored aggregate template and forbidden immediate-HTTP component with captured WIT, profile, state schema, bounded ownership and deployment/binding companions. Supported stateless defaults remain available.

Tracks #389 and Java slice #718. Actual signed-node transaction/query/intent execution, complete-envelope recovery/cancellation, immediate-effect rejection and physical cleanup remain required before issue closure.

Current clean head `f81d0d94c3e62854aad6ddea3e633528d9e0a3f4` is a two-parent merge of the original `438c08e6` authoring head and development `db532ce3`. It retains the current shell-quote 1.12.0 repair, authorized 64 MiB source / 72 MiB archive defaults, phase3-v5 stateless host identity and explicit phase4-v1 guest identity. Canonical State/Intent installation remains before Java's current activation checkpoint/class-origin analysis. Every parent language build step, failure-artifact path, trigger, permission, matrix, condition, historical command mapping and deadline remains required.

The exact-head bounded Linux Source campaign passes all five steps: 319 discovered cases, 318 pass and one existing platform skip, including all 68 Java compiler/capture source tests. CI coverage retains 88 historical obligations, 268 current run blocks and 141 delegated owners. Repository and documentation checks pass; all validation processes are reaped and the source checkout stays clean. The SDK-only tree contains none of the 20 application paths authored for #402.

Current-head hosted CI and actual guest/Native execution remain pending. Earlier failed guest/native/currentness attempts retain their original source identities; this merge and its Source checks do not establish that those runtime failures are repaired.

The previously failed website job emitted successful build/examples/theme/version receipts but no discovery receipt. Its bounded diagnostic wrapper retains the original 180/300/600-second budgets and every browser assertion. Fresh browser execution remains required.
