from pathlib import Path
import json
import sys

root=Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
sys.path.insert(0,str(root))
from tools import ci_contracts as c
module='tools/tests/test_stateful_reference_conductor.py'
expected={
    'StatefulReferenceConductor.test_browser_matrix_requires_six_guest_languages_and_two_distinct_entity_plans',
    'StatefulReferenceConductor.test_byte_identity_refuses_relabelled_compiler_component_and_unassembled_artifact',
    'StatefulReferenceConductor.test_closed_json_and_byte_bounds_refuse_before_any_operator_request',
    'StatefulReferenceConductor.test_original_attestation_refuses_cross_publication_and_requires_explicit_entity',
    'StatefulReferenceConductor.test_unknown_deployment_result_stops_without_trigger_or_mutation_retry',
}
observed=c.python_expectations(root)[module]
assert set(observed['cases'])==expected
for guard in observed['guards'].values():
    assert guard['bases']==['unittest.TestCase']
    assert guard['classDecorators']==guard['decorators']==guard['skipSites']==[]
value=c.record('python','Reviewed Source-only conductor input and refusal checks: genuine ordinary creator captures feed synthetic byte-identity fixtures, never node/compiler qualification. Require exact language/world/component/source/assembled identities; refuse changed bytes, invalid JSON and byte overrun; uncertain deployment stops without retries or trigger writes; current original lookup retains entity and refuses a foreign publication; six-backend scope requires every guest and both entity plans. No skip/decorator or deadline relaxation.',module=module,**observed)
path=root/'tools/ci/contracts/python/test_stateful_reference_conductor.py.json'
assert not path.exists()
path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'registeredExplicitSourceCases':len(expected),'liveNodeQualified':False}))
