from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
PARENT='9a8fcb8a960a1ddf7261266202dea76eeff54d51'
DONOR='a3fb527eb067259865e22777e743614967695551'
PATH='crates/latent-core/src/budget/host_memory.rs'
TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr825-core-owner-v244')
def git(*args,cwd=REPO):return subprocess.check_output(['git','-C',str(cwd),*args])
assert not TREE.exists()
old=git('show',PARENT+':'+PATH)
donor=git('show',DONOR+':'+PATH)
duplicate=b'''        if transaction {
            state.host_observed_memory += bytes;
            let observed =
                state.own_memory_peak + state.host_observed_memory + state.child_observed_memory;
            state.consumption.peak_memory_bytes = state.consumption.peak_memory_bytes.max(observed);
        }

'''
assert old.count(duplicate)==1
expected=old.replace(duplicate,b'',1)
assert expected.count(b'assert_eq!(budget.outstanding_reservations(), 0);')==1
expected=expected.replace(b'assert_eq!(budget.outstanding_reservations(), 0);',b'assert_eq!(budget.outstanding_reservations(), 1);',1)
assert expected.count(b'        drop(owner);\n        assert_eq!(budget.host_memory_bytes(), 0);')==1
expected=expected.replace(b'        drop(owner);\n        assert_eq!(budget.host_memory_bytes(), 0);',b'        drop(owner);\n        assert_eq!(budget.outstanding_reservations(), 0);\n        assert_eq!(budget.host_memory_bytes(), 0);',1)
assert expected==donor
git('worktree','add','--no-checkout','-b','fix/phase4-pr825-core-owner-v244',str(TREE),PARENT)
git('sparse-checkout','set','--no-cone',PATH,cwd=TREE)
git('checkout','fix/phase4-pr825-core-owner-v244',cwd=TREE)
(TREE/PATH).write_bytes(donor)
git('diff','--check',cwd=TREE)
git('add',PATH,cwd=TREE)
git('commit','-m','fix(core): charge native host memory once through physical cleanup',cwd=TREE)
head=git('rev-parse','HEAD',cwd=TREE).decode().strip()
proof=dict(at=datetime.now(timezone.utc).isoformat(),parent=PARENT,head=head,donor=DONOR,tree=str(TREE),onlyPath=PATH,
           donorQualifiedCore131AtOriginalHead=True,onlyDuplicatedChargeRemoved=True,liveOwnerRemainsChargedUntilDrop=True,
           originalPeakAndCleanupAssertionsPreserved=True,allOtherSourcesCaseFloorsAndLimitsUnchanged=True,
           beforeSha256=hashlib.sha256(old).hexdigest(),afterSha256=hashlib.sha256(donor).hexdigest(),
           freshCurrentSourceAndFullCoreNativePending=True,noPublication=True)
(COORD/'portable-v2-pr825-core-owner-repair-prepared-v244.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
