import json
from pathlib import Path
import subprocess

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
heads={'790':'63ca20b1d2d1faf93030283d86272cfcb6d51994','800':'0055f9778e0d4ee2ace92dfdafabfd3e8ad57b7c',
       '791':'af40f10cf214742cc519bb1a8d41fc190f3c56e6','787':'45a6cbcf9e9c52dacb95225c1e75f0e5d0f980ea',
       '796':'c4c5403ed4d2f1d64a07465eca1c669f6db4ab07','784':'c628f225442717668c80f97b919b5fa5d0432d37',
       '825':'17c20ed1a381dc670132d9fc8411fa0ff4fbed07'}
proof=[]
for number,head in heads.items():
    source=json.loads(subprocess.check_output(['git','-C',str(REPO),'show',head+':tools/ci/suites.json']))
    mismatch=[]
    key_rows=[]
    new_required={
        'latent-node.lib.latent-node':'journal::tests::tree::target_service_projection_preserves_identity_and_original_identifier_and_page_limits',
        'latent-node.test.activation-lifecycle':'identity::assigns_absent_identity_and_rejects_untrusted_ancestry',
    }
    for row in source['suites']:
        if 'expectedCases' in row and len(row['expectedCases'])!=row['minimumCases']:
            mismatch.append(dict(id=row['id'],actualExpectedCount=len(row['expectedCases']),minimumCases=row['minimumCases']))
        if row['id'] in ('latent-node.lib.latent-node','latent-node.test.activation-lifecycle','latent-control-store.lib.latent-control-store'):
            key_rows.append(dict(id=row['id'],minimumCases=row['minimumCases'],expectedCaseCount=len(row['expectedCases'])))
            if row['id'] in new_required:assert new_required[row['id']] in row['expectedCases'],(number,row['id'])
    assert not mismatch,(number,mismatch)
    proof.append(dict(pr=int(number),head=head,allDeclaredExpectedCountsMatchFloor=True,keyRows=key_rows))
(COORD/'portable-v2-owned-main-inventory-audit-v219.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
