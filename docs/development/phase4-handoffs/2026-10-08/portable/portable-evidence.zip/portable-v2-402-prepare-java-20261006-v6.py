from pathlib import Path
import json
import subprocess
import sys

root=Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
output=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-java-compile-20261006-v6')
assert not output.exists()
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
output.mkdir()
sys.path.insert(0,str(root))
from tools.stateful_reference_project import create
from tools.rust_capsule_project import snapshot,inventory,digest
project=create(output/'project','java',draft_id='alice')
before=inventory(snapshot(project))
(output/'source-inputs.json').write_bytes(before)
(output/'preparation.json').write_text(json.dumps({'sourceBase':head,'language':'java','draftId':'alice','application':'order-draft-v1','sourceInventoryDigest':digest(before),'authoredSourceUncommitted':False,'compiled':False,'signed':False,'nodeQualified':False,'compilerVolumesReadOnly':True,'compilerCacheSource':'latent-sdk-java-public-cache-af6d-20261006-r4','compilerToolsSource':'latent-sdk-java-public-tools-af6d-20261006-r4'},indent=2)+'\n')
runner=output.parent/'portable-v2-402-java-compile-run-20261006-v6.py'
assert not runner.exists()
runner.write_bytes((output.parent/'portable-v2-402-java-compile-run-20261006-v4.py').read_bytes())
(output/'results').mkdir()
print(json.dumps({'prepared':str(output),'sourceBase':head,'sourceInventoryDigest':digest(before)}))
