import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

COORD = Path(__file__).resolve().parent
REPO = "KirilsTurkins/latent-service-fabric"
DEV = "21cfd22148f849604cb6fc60247924de0012093c"
ENV = dict(os.environ, GODEBUG="http2client=0")
ROWS = [
    (791, "f69c330cd0f77a4c5ddf68d26250b01dcc2ed64f", "a129773f52c4fc15c59b4ce62b52744a233cd4cd", 278, 8,
     "5cd4491844daf073235d05f042c034260c80376642656ccf206ff9e8cfe890d5"),
    (784, "bd2176b8a0ec608b3c407dd5855538044f18ddaa", "b43ab914f9ffbdd4fa26c26b66c913daf3342aef", 226, 7,
     "7c3edcc0ed369df086fd3dadfdffc27f7344b4a09b2f094f8ff18fc7be53ef99"),
]


def run(argv, tree):
    return subprocess.check_output(argv, cwd=tree, env=ENV, timeout=90).decode("utf-8").strip()


for number, old, head, actual_count, gates, expected_receipt in ROWS:
    tree = Path(fr"C:\Users\turkins\Desktop\lf-p4-pr{number}-21c-main-v272")
    job = COORD / f"portable-v2-pr{number}-final-main-source-20261008-v277"
    out = COORD / f"portable-v2-pr{number}-current-source-publication-v314.json"
    assert not out.exists(), "publication already recorded"
    raw = (job / "receipt.json").read_bytes()
    receipt = json.loads(raw)
    assert hashlib.sha256(raw).hexdigest() == expected_receipt
    assert receipt["head"] == head and receipt["passed"] and len(receipt["steps"]) == gates
    assert receipt["sourceClean"] and receipt["sourceHeadUnchanged"] and receipt["originalProcessReaped"]
    assert receipt["infrastructureError"] is None
    for row in receipt["steps"]:
        data = (job / row["log"]).read_bytes()
        assert row["exitCode"] == 0 and row["stopReason"] is None and row["originalProcessReaped"]
        assert hashlib.sha256(data).hexdigest() == row["sha256"] and len(data) == row["bytes"]
    counts = [int(n) for n in re.findall(r"Ran (\d+) tests?", (job / "step-1.log").read_text(encoding="utf-8"))]
    assert sum(counts) == actual_count
    assert run(["git", "rev-parse", "HEAD"], tree) == head and not run(["git", "status", "--porcelain"], tree)
    for ancestor in (old, DEV):
        subprocess.run(["git", "merge-base", "--is-ancestor", ancestor, head], cwd=tree, check=True)
    assert run(["git", "ls-remote", "origin", "refs/heads/development"], tree).split()[0] == DEV
    suites = json.loads(run(["git", "show", f"{head}:tools/ci/suites.json"], tree))
    assert any(r["target"] == "aot_sandbox" and r["minimumCases"] >= 1 for r in suites["suites"])
    for row in suites["suites"]:
        if row["mode"] == "libtest":
            assert len(row["expectedCases"]) == row["minimumCases"]
            assert set(row["expectedIgnored"]) <= set(row["expectedCases"])
    pr = json.loads(run(["gh", "api", f"repos/{REPO}/pulls/{number}"], tree))
    assert pr["state"] == "open" and pr["head"]["sha"] == old and pr["base"]["ref"] == "development"
    branch = pr["head"]["ref"]
    assert run(["git", "ls-remote", "origin", f"refs/heads/{branch}"], tree).split()[0] == old
    if number == 791:
        body = """Node-owned transaction control retains the original caller, selected source, command/effect scope and execution budget through admission, cancellation and durable result lookup. The current source restores the original host-memory transaction charge once and keeps its live owner charged until physical retirement; client, parser and inherited transaction cases remain.

Development21cfd221 is normally integrated, including the reviewed Signing concurrent-currentness and Node identity cases. All original case names, ignored fixtures, resource limits and the historical AOT custom-harness floor remain. The maintained public-guard serialization repair preserves parsed guard definitions and hashes; the exact pinned Linux scanner passes without exceptions.

This exact current head passes all eight Linux Source gates and278 Python cases without skips, full locked offline metadata and maintained generators. Current Core127,Signing58,Node114/activation and AOT native qualification remain pending; historical Native and hosted receipts retain their original heads. The previous Go dependency case's queued ResourceExhausted result is a separate unresolved qualification boundary. Full current hosted CI, installed signed workflows and complete #388 acceptance remain pending; this current-source publication resolves the development conflict and enables fresh CI, with no merge or issue-closure claim.
"""
    else:
        body = """Transactional guest bindings preserve original state-view and key-version tokens, typed result ownership and rollback/refusal behavior. Recovery of an unknown trigger operation accepts the original empty-journal retained floor while preserving identity, exact u64 bounds and currentness checks; the original RPC refusal and overflow schedules remain.

Development21cfd221 is normally integrated, including the reviewed Signing concurrent-currentness and Node identity cases. All inherited cases, ignored fixtures, resource limits and the historical AOT custom-harness floor remain. Both bounded route observers are preserved on the original single request with no raw credential or argument disclosure.

This exact current head passes all seven Linux Source gates and226 Python cases without skips, full locked offline metadata and maintained generators. The prior bd217 head completed all50 hosted checks and its focused RPC/full156 CLI/strict proof remains source-paired to that head. Current Signing58,Node91/activation and AOT native qualification and fresh hosted CI remain pending; historical green CI is not current-source qualification. Complete six-language signed stateful guest workflows and #389 acceptance remain pending. This current-source publication resolves the development conflict and enables fresh CI, with no admin merge or issue closure.
"""
    body_path = COORD / f"portable-v2-pr{number}-current-source-body-v314.md"
    body_path.write_text(body, encoding="utf-8")
    subprocess.run(["git", "-c", "http.version=HTTP/1.1", "push", "origin", f"{head}:refs/heads/{branch}"], cwd=tree, env=ENV, timeout=180, check=True)
    assert run(["git", "ls-remote", "origin", f"refs/heads/{branch}"], tree).split()[0] == head
    subprocess.run(["gh", "pr", "edit", str(number), "--repo", REPO, "--body-file", str(body_path)], env=ENV, timeout=90, check=True)
    final = json.loads(run(["gh", "api", f"repos/{REPO}/pulls/{number}"], tree))
    assert final["head"]["sha"] == head and final["body"].replace("\r\n", "\n").strip() == body.strip()
    result = {
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "pr": number,
        "oldHead": old, "head": head, "development": DEV,
        "normalPush": True, "forcePush": False, "remoteGitAndApiVerified": True,
        "sourceReceiptSha256": expected_receipt, "actualPythonTests": actual_count,
        "sourcePassedGates": gates, "sourceProcessesReaped": True,
        "currentNativeQualificationPending": True, "historicalGreenNotTransferred": True,
        "adminMerged": False, "issueClosed": False, "completeCI": False,
    }
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result), flush=True)
