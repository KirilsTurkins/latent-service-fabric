from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

COORD=Path(__file__).resolve().parent
ENV=dict(os.environ,GODEBUG='http2client=0')
REPO='KirilsTurkins/latent-service-fabric'
number=sys.argv[1];assert number in {'800','825'}
plans={'800':('592db6f7b7a677a0a5a502e82d4333776ca71d6e','5d41e9b481e78818db4ac2a8ff30095301e61f94','feat/phase4-clients-401','portable-v2-pr800-derived-lock-body-v266.md'),
       '825':('03466b9062da20222e6fcdd8b0c6a2ed6dec5fbd','601038c2b908144dadd11bcb48ddbab51606b5d4','feat/phase4-391-dispatch-capacity','portable-v2-pr825-current-fd-body-v255.md')}
old,head,branch,body=plans[number]
TREE=Path(r'C:\Users\turkins\Desktop')/('lf-p4-pr'+number+'-21c-main-v272')
def call(argv):return subprocess.check_output(argv,env=ENV,timeout=120)
out=COORD/('portable-v2-pr'+number+'-final-main-source-20261008-v277');raw=(out/'receipt.json').read_bytes();r=json.loads(raw)
assert r['head']==head and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped']
for row in r['steps']:
    data=(out/Path(row['log']).name).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped']
assert call(['git','-C',str(TREE),'diff','--name-only',old,head]).decode().splitlines()==['tools/java_server_node.py']
assert not call(['git','-C',str(TREE),'status','--porcelain'])
pr=json.loads(call(['gh','pr','view',number,'--repo',REPO,'--json','headRefOid,headRefName,state']))
assert pr==dict(headRefOid=old,headRefName=branch,state='OPEN'),pr
call(['git','-C',str(TREE),'merge-base','--is-ancestor',old,head])
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=int(number),oldHead=old,head=head,sourceReceiptSha256=hashlib.sha256(raw).hexdigest(),
           onlyBoundedJavaDiagnosticSourceChanged=True,allNativeSdkApiWitCargoTestsAndControlsUnchanged=True,
           previousQualifiedNativeAndSDKReceiptsRemainAtTheirActualHeads=True,normalPush=True,published=False,completeCI=False,noIssueClosure=True)
path=COORD/('portable-v2-pr'+number+'-delivered-tool-main-publication-v282.json');path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
push=subprocess.run(['git','-C',str(TREE),'push','origin','HEAD:refs/heads/'+branch],env=ENV,capture_output=True,timeout=120)
(COORD/('portable-v2-pr'+number+'-delivered-tool-main-push-v282.log')).write_bytes(push.stdout+push.stderr)
assert push.returncode==0
remote=call(['git','-C',str(TREE),'ls-remote','origin','refs/heads/'+branch]).decode().split()[0];assert remote==head
call(['gh','pr','edit',number,'--repo',REPO,'--body-file',str(COORD/body)])
proof.update(published=True,verifiedRemoteHead=remote,bodyUpdated=True)
path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
