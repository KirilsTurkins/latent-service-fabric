import json
from pathlib import Path
import subprocess
ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
def read(rev):
    return json.loads(subprocess.check_output(["git", "show", rev + ":tools/ci/suites.json"], cwd=ROOT, timeout=60))
a = {row["id"]: row for row in read("0a460cbaa9dcea330b00978b7b3557ab75e58b23")["suites"]}
b = {row["id"]: row for row in read("318eaa9aea5e0962515c7161d441ee270bcdeae4")["suites"]}
rows = {}
for key in a:
    if a[key] == b[key]:
        continue
    value = {"oursMinimum": a[key]["minimumCases"], "incomingMinimum": b[key]["minimumCases"],
             "oursOnlyCases": sorted(set(a[key].get("expectedCases", [])) - set(b[key].get("expectedCases", []))),
             "incomingOnlyCases": sorted(set(b[key].get("expectedCases", [])) - set(a[key].get("expectedCases", [])))}
    for field in ("expectedIgnored", "ignoredLeaves"):
        if a[key].get(field) != b[key].get(field):
            value[field] = {"ours": a[key].get(field), "incoming": b[key].get(field)}
    rows[key] = value
print(json.dumps(rows), flush=True)
