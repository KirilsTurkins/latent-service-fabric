Adds six external transaction client models, bounded codecs and recovery surfaces for #401. Integrates development, fixes packed scalar accounting, and synchronizes the host staging witness across protobuf, SDK vectors, Node descriptors, Rust conversions and native projection.

Regenerates the Java transport bridge from the unchanged authoritative profile, adding TransactionStagingWitness and the optional ActivationTreeNode staging field while preserving every existing mapping. This repairs the completed Java provider CI failure.

Current-head Linux source and maintained generator checks pass. Pinned Java 25/Gradle 9.1 clean check executes the real semantic and transport suites and bytecode verification. Prior TypeScript network, Rust SDK, native CLI/packaging, and shared HTTP qualification remain recorded on their source-paired receipts. Full CI and six separate-node transaction transport qualification remain pending.
