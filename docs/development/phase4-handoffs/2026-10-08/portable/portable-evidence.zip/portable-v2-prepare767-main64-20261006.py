"""Preserve the unpushed obsolete graph, then merge current main into owned storage."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
OUT = Path(__file__).resolve().parent / "portable-v2-pr767-main64-20261006-v1"
OLD = "a2cb83ec13dbe9b60e477f3c4e69e53625981848"
BASE = "0a460cbaa9dcea330b00978b7b3557ab75e58b23"
INCOMING = "318eaa9aea5e0962515c7161d441ee270bcdeae4"
REMOTE = "f0d1d011961b91f1822ad5936fccf86f4aa2c337"
BRANCH = "custody/root-pr767-a2-before-main64-20261006"
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=60).decode().strip()
assert ROOT.resolve() == Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
assert git("rev-parse", "HEAD") == OLD and not git("status", "--porcelain")
assert subprocess.run(["git", "merge-base", "--is-ancestor", REMOTE, BASE], cwd=ROOT).returncode == 0
pr = json.loads(subprocess.check_output(["gh", "pr", "view", "767", "--repo", "KirilsTurkins/latent-service-fabric",
                                      "--json", "headRefName,headRefOid,state"], timeout=60))
assert pr["state"] == "OPEN" and pr["headRefOid"] == REMOTE and pr["headRefName"] == "feat/phase4-storage-381"
assert not git("branch", "--list", BRANCH)
OUT.mkdir()
subprocess.run(["git", "branch", BRANCH, OLD], cwd=ROOT, check=True)
patch = subprocess.check_output(["git", "diff", "--binary", "--full-index", BASE, OLD], cwd=ROOT, timeout=60)
(OUT / "obsolete-npm-v3.patch").write_bytes(patch)
custody = {"at": datetime.now(timezone.utc).isoformat(), "root": str(ROOT), "oldHead": OLD, "oldTree": git("show", "-s", "--format=%T", OLD),
           "custodyBranch": BRANCH, "preobsoleteBase": BASE, "incoming": INCOMING, "remote": pr,
           "obsoletePatchSha256": hashlib.sha256(patch).hexdigest(), "sourceWasClean": True,
           "otherSessionStorageWorktreeTouched": False, "qualification": False}
(OUT / "custody.json").write_text(json.dumps(custody, indent=2) + "\n", encoding="utf8")
subprocess.run(["git", "checkout", "--detach", BASE], cwd=ROOT, check=True, capture_output=True)
merge = subprocess.run(["git", "merge", "--no-commit", "--no-ff", INCOMING], cwd=ROOT, capture_output=True, text=True, timeout=180)
(OUT / "merge-output.log").write_text(merge.stdout + merge.stderr, encoding="utf8")
unmerged = git("diff", "--name-only", "--diff-filter=U").splitlines()
receipt = {**custody, "mergeExitCode": merge.returncode, "conflicts": unmerged, "status": git("status", "--porcelain").splitlines(),
           "mergeOutputSha256": hashlib.sha256((merge.stdout + merge.stderr).encode()).hexdigest(), "committed": False}
(OUT / "prepared.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps({key: value for key, value in receipt.items() if key not in {"status"}}), flush=True)
