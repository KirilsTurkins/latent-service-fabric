﻿from pathlib import Path
import hashlib,json,subprocess,zipfile
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');repo=Path(r'C:\Users\turkins\Desktop\latent-fabric')
head='8785fadf4d630cce34fbcbfebf65d0fbb0851d1c';root=coord/'portable-v2-pr825-retained-go-inputs-20261007-v89/fixtures'
archive=coord/'portable-v2-pr825-completed-ci-custody-20261007-v82/go-upstream-11472236932.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='b748deafcad3f5ca4b723fe740ecfa0f3b195dc3169e8241740fff8789cbb719'
rows=[];checks=[];missing=[]
def verify(data,size,digest):
 assert len(data)==size and 'sha256:'+hashlib.sha256(data).hexdigest()==digest
with zipfile.ZipFile(archive) as z:
 for i in z.infolist():
  prefix='go-capsule-authoring/sdk-guests/'
  if i.filename.startswith(prefix) and not i.is_dir():
   relative=i.filename[len(prefix):];data=(root/relative).read_bytes()
   assert data==z.read(i)
   rows.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
for role in ['blob','callee','events','http','metrics','random','secrets','service','streaming']:
 r=root/('go-'+role);ob=json.loads((r/'build-observation.json').read_bytes());marker=json.loads((r/'BUILD-COMPLETE.json').read_bytes())
 raw=(r/'build-observation.json').read_bytes();assert marker['observationDigest']=='sha256:'+hashlib.sha256(raw).hexdigest()
 raw=(r/'source-inputs.json').read_bytes();assert ob['source']['snapshotDigest']=='sha256:'+hashlib.sha256(raw).hexdigest()
 component=(r/'component.wasm').read_bytes();verify(component,ob['componentSize'],ob['componentDigest'])
 assert (r/'package/layers/component.wasm').read_bytes()==component
 count=0
 for rel,identity in json.loads(raw).items():
  captured=root/'projects'/role/rel
  if not captured.exists():
   assert rel=='.gitignore';missing.append(dict(role=role,path=rel,identity=identity,reason='GitHub artifact excludes hidden file; capture entry unchanged'));continue
  data=captured.read_bytes();verify(data,identity['size'],identity['digest']);count+=1
  if rel.startswith('vendor/lsf/'):
   path=rel[len('vendor/lsf/'):];assert subprocess.check_output(['git','show',head+':'+path],cwd=repo)==data,(role,path)
 manifest=json.loads((r/'package/manifest.json').read_bytes())
 config=(r/'package/config.json').read_bytes();verify(config,manifest['config']['size'],manifest['config']['digest'])
 for layer in manifest['layers']:
  path=layer['annotations']['org.opencontainers.image.title'];verify((r/'package/layers'/path).read_bytes(),layer['size'],layer['digest'])
 inputs=json.loads((r/'package/layers/package/build-inputs.json').read_bytes())['inputs']
 source_by_path={layer['path']:layer['source'] for layer in json.loads((r/'package-source.json').read_bytes())['layers']}
 for item in inputs:
  verify((r/source_by_path[item['path']]).read_bytes(),item['inputSize'],item['inputDigest'])
  verify((r/'package/layers'/item['path']).read_bytes(),item['outputSize'],item['outputDigest'])
 checks.append(dict(role=role,componentBytes=len(component),componentSha256=hashlib.sha256(component).hexdigest(),capturedSourceFilesVerified=count,observationDigest=marker['observationDigest'],packageLayersVerified=len(manifest['layers'])))
result=dict(head=head,artifactId=11472236932,runId=37587811873,archiveSha256='b748deafcad3f5ca4b723fe740ecfa0f3b195dc3169e8241740fff8789cbb719',memberCount=len(rows),logicalBytes=sum(row['bytes'] for row in rows),checks=checks,members=rows,missingCapturedFiles=missing,retainedCompilerDiagnosticOnly=True,nativeExecution=False,freshCompilerQualification=False)
out=coord/'portable-v2-go825-retained-fixture-proof-20261007-v90.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='members'}))
