from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD = Path(__file__).resolve().parent

def git(*args, cwd=REPO):
    return subprocess.check_output(['git','-C',str(cwd),*args])

def sparse(head, name, branch, paths):
    tree = Path(r'C:\Users\turkins\Desktop') / name
    assert not tree.exists()
    git('worktree','add','--no-checkout','-b',branch,str(tree),head)
    git('sparse-checkout','set','--no-cone',*paths,cwd=tree)
    git('checkout',branch,cwd=tree)
    assert not git('status','--porcelain',cwd=tree)
    return tree

head800 = '017385709f321b43f28a5851aca29eb2a37617d7'
path800 = 'sdk/dotnet/Latent.Sdk.Transport.Tests/Vectors.cs'
tree800 = sparse(head800,'lf-p4-pr800-dotnet-vectors-v209','fix/phase4-pr800-dotnet-vectors-v209',[path800])
original = (tree800/path800).read_bytes()
assert original.count(b'Check(count == 61,') == 1
corrected = original.replace(b'Check(count == 61,',b'Check(count == 62,')
(tree800/path800).write_bytes(corrected)
git('diff','--check',cwd=tree800)
git('add',path800,cwd=tree800)
git('commit','-m','test(dotnet): retain all current shared protobuf vectors',cwd=tree800)
new800 = git('rev-parse','HEAD',cwd=tree800).decode().strip()

head791 = '866416fb57f2a11211fc6ecdf8896c2e5343a36a'
path791 = 'tools/ci/contracts/python/test_dev_node_policies.py.json'
tree791 = sparse(head791,'lf-p4-pr791-guard-layout-v209','fix/phase4-pr791-guard-layout-v209',[path791])
original = (tree791/path791).read_bytes()
qualified = git('show',f'6ab38845e5a266f38229416dc63fe57df471a40f:{path791}')
assert json.loads(original) == json.loads(qualified)
assert original == git('show',f'a3fb527eb067259865e22777e743614967695551:{path791}')
(tree791/path791).write_bytes(qualified)
git('diff','--check',cwd=tree791)
git('add',path791,cwd=tree791)
git('commit','-m','ci: use maintained layout for public guard reference metadata',cwd=tree791)
new791 = git('rev-parse','HEAD',cwd=tree791).decode().strip()
proof = dict(at=datetime.now(timezone.utc).isoformat(),
    dotnet=dict(oldHead=head800,head=new800,tree=str(tree800),onlyPath=path800,expectedCasesBefore=61,expectedCasesAfter=62,
                sameAll78FixtureBodies=True,same62SelectedProtoCases=True,noCaseSkippedOrRemoved=True,actualNativePending=True),
    scanner=dict(oldHead=head791,head=new791,tree=str(tree791),onlyPath=path791,sameParsedJsonAndGuards=True,
                 byteExactAlreadyQualifiedMaintainedSerializer=True,noScanPolicyOrExceptionChanged=True,actualCurrentPinnedScanPending=True),
    sourceQualificationPending=True,noPublication=True)
(COORD/'portable-v2-800-791-isolated-prepared-v209.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
