from pathlib import Path
import json

coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination')
old=json.loads((coord/'portable-v2-402-source-linux-20261006-v1/invocation.json').read_bytes())
steps=old['steps']
steps[0].extend(['tools.tests.test_rust_capsule_authoring','tools.tests.test_wit_contracts','tools.tests.test_phase1_contracts','tools.tests.test_capability_policy_schema','tools.tests.test_ci_suite_inventory','tools.tests.test_ci_profile'])
extra=['campaign','diagnostics','fault_campaign','provision','qualification','recipient','recovery','schema','staging']
steps.insert(1,['python3','-X','utf8','-B','-m','unittest',*('tools.tests.test_java_transaction_'+name for name in extra),'tools.tests.test_browser_response_ownership','tools.tests.test_capsule_provider_diagnostics'])
path=coord/'portable-v2-402-integrated-source-steps-20261006-v2.json'
assert not path.exists()
path.write_text(json.dumps(steps,indent=2)+'\n')
print(str(path))
