from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
OUT=COORD/'portable-v2-dotnet-lock-native-reproduction-20261008-v259'
receipt=json.loads((OUT/'receipt.json').read_bytes())
new=(OUT/'protobuf.lock.json').read_bytes()
assert hashlib.sha256(new).hexdigest()==receipt['newLockSha256'] and receipt['reproductionsIdentical'] and receipt['generatedSources']==16
def git(*args,cwd=REPO):return subprocess.check_output(['git','-C',str(cwd),*args])
results=[]
for number,parent in [(800,'f6f4a95b2dfe5f38295a70ea485f9d797d8786d8'),(811,'3a991d9922390edb3251c84aa8f926a717687d0b')]:
    expected=json.loads(new)
    for path,digest in expected['inputs'].items():
        assert hashlib.sha256(git('show',parent+':api/proto/'+path).replace(b'\r\n',b'\n')).hexdigest()==digest
    assert git('show',parent+':sdk/dotnet/Latent.Sdk.Transport/Latent.Sdk.Transport.csproj')==git('show',receipt['sourceHead']+':sdk/dotnet/Latent.Sdk.Transport/Latent.Sdk.Transport.csproj')
    old=json.loads(git('show',parent+':sdk/dotnet/protobuf.lock.json'))
    assert {k:v for k,v in old.items() if k not in ('inputs','outputs')}=={k:v for k,v in expected.items() if k not in ('inputs','outputs')}
    tree=Path(r'C:\Users\turkins\Desktop')/('lf-p4-pr'+str(number)+'-dotnet-lock-v260')
    assert not tree.exists()
    branch='fix/phase4-pr'+str(number)+'-dotnet-lock-v260'
    git('worktree','add','--no-checkout','-b',branch,str(tree),parent)
    git('sparse-checkout','set','--no-cone','sdk/dotnet/protobuf.lock.json',cwd=tree)
    git('checkout',branch,cwd=tree)
    (tree/'sdk/dotnet/protobuf.lock.json').write_bytes(new)
    git('diff','--check',cwd=tree)
    git('add','sdk/dotnet/protobuf.lock.json',cwd=tree)
    git('commit','-m','fix(dotnet): derive protocol lock from current pinned Linux generation',cwd=tree)
    results.append(dict(pr=number,parent=parent,head=git('rev-parse','HEAD',cwd=tree).decode().strip(),tree=str(tree),
                        onlyPath='sdk/dotnet/protobuf.lock.json',actualLinuxProtoc29TwoReproductions=True,
                        changedInput='latent/control/v1/node.proto',changedOutput='latent/control/v1/Node.cs',
                        SDKRuntimePackageVersionsAndOtherOutputsUnchanged=True,freshSourceAndLinuxFullSDKPending=True,noPublication=True))
proof=dict(at=datetime.now(timezone.utc).isoformat(),generatorReceiptSha256=hashlib.sha256((OUT/'receipt.json').read_bytes()).hexdigest(),records=results,
           initialRootOwnedCpSetupFailureRetained=True,recoveredOnlyExactNewJobOwnership=True)
(COORD/'portable-v2-dotnet-derived-lock-children-v260.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
