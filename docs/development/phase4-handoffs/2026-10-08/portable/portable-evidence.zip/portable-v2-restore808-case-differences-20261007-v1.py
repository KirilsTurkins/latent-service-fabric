import difflib
import importlib.util
import json
import pathlib

COORD = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('audit', COORD / 'portable-v2-restore808-parent-audit-20261007-v1.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
receipt = json.loads((audit.OUT / 'parent-case-audit.json').read_bytes())
records = []
for problem in receipt['problems']:
    original = audit.git('show', f"{audit.PARENTS[problem['parent']]}:{problem['path']}").decode()
    if problem['parent'] == 'peer' and problem['path'] in audit.MAP:
        original = audit.remap_source(original)
    expected = audit.cases(original)[problem['case']]
    actual = audit.cases((audit.ROOT / problem['target']).read_bytes().decode())[problem['case']]
    fragments = []
    for field in ('attributes', 'body'):
        for tag, i, j, k, n in difflib.SequenceMatcher(a=expected[field], b=actual[field], autojunk=False).get_opcodes():
            if tag != 'equal':
                fragments.append({'field': field, 'tag': tag, 'beforeContext': ' '.join(expected[field][max(0, i-6):i]), 'original': ' '.join(expected[field][i:j]), 'resolved': ' '.join(actual[field][k:n]), 'afterContext': ' '.join(expected[field][j:j+6])})
    records.append({'parent': problem['parent'], 'path': problem['path'], 'case': problem['case'], 'differences': fragments})
(audit.OUT / 'case-differences.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
print(json.dumps(records, indent=2))
