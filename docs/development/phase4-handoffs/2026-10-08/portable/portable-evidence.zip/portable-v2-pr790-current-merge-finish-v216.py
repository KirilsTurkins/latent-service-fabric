from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess

TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr790-current-binding-v216')
COORD=Path(__file__).resolve().parent
def git(*args):
    return subprocess.check_output(['git','-C',str(TREE),*args])
assert not git('ls-files','-u')
result=json.loads(git('show',':tools/ci/suites.json'))
rows={r['id']:r for r in result['suites']}
parents=['221645876350b9790d5255df588f0ce2ca728871','0cd6c2e8649e8181366e0adbfe03da1bf2a3c7a3']
for head in parents:
    original=json.loads(git('show',head+':tools/ci/suites.json'))
    for old in original['suites']:
        new=rows[old['id']]
        assert new['minimumCases']>=old['minimumCases']
        for field in ['expectedCases','expectedIgnored','ignoredLeaves','expectedCustomCases','prerequisites']:
            assert set(old.get(field,[]))<=set(new.get(field,[]))
fixture='tools/tests/test_java_server_source.py'
assert git('show',':'+fixture)==git('show',parents[0]+':'+fixture)
git('diff','--check','--cached')
git('commit','-m','merge development into transaction binding repair')
head=git('rev-parse','HEAD').decode().strip()
proof=dict(at=datetime.now(timezone.utc).isoformat(),head=head,parents=parents,allParentCaseFloorsIgnoresPrerequisitesPreserved=True,
           suiteCount=len(rows),qualifiedFixtureByteIdentical=True,productionBindingFixByteIdentical=True,
           currentSourceAndNativePending=True,noPublication=True)
(COORD/'portable-v2-pr790-current-merge-review-v216.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
