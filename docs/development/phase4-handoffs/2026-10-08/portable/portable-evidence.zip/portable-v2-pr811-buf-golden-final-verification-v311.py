import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

COORD = Path(__file__).resolve().parent
TREE = Path(r"C:\Users\turkins\Desktop\lf-p4-pr811-buf-golden-v307")
OUT = COORD / "portable-v2-pr811-buf-golden-producer-v309"
HEAD = "335dca010d299e554a4ab351e9fb525ae15e8d5c"
DONOR = "1e129ef0ed6682c998f81a498e76bd4de61c6fec"
GOLDEN = "api/proto/phase1-descriptor-contract.json"
validator = TREE / "tools/validate_phase1_descriptor.py"
before = (OUT / "original-golden.json").read_bytes()
actual = OUT / "actual-file-descriptor-set.json"
normalized_raw = (TREE / GOLDEN).read_bytes()
assert hashlib.sha256(before).hexdigest() == "11e0edb0dd9d981bebe4d31ceb308b93346d7ae43de62ada561f02fcc5c6099c"
assert hashlib.sha256(actual.read_bytes()).hexdigest() == "539496c72df533c343b0904b1b4aad0546cf33adbeb110322cd911d9726fd3fd"
previous_actual = COORD / "portable-v2-pr811-buf-golden-producer-v308/actual-file-descriptor-set.json"
assert actual.read_bytes() == previous_actual.read_bytes()
assert hashlib.sha256(normalized_raw).hexdigest() == "183faccb2a59d3bdfb368d4ee09dee4ed894d415aee0ca522e872f70657b4e29"
peer_crlf = normalized_raw.removesuffix(b"\n") + b"\r\n"
assert hashlib.sha256(peer_crlf).hexdigest() == "66c924d37e01d2d17dcb517040a6c16564a7e07be7d32f6940c6f6fd77bbcf51"
reviewed_peer = COORD / "entity-contract-v80-actual-buf-descriptor-20261008-v1/verified-normalized-descriptor.pretty.json"
assert json.loads(normalized_raw) == json.loads(reviewed_peer.read_bytes())
# Reexecute only the exact semantic review from the producer, without its
# generation, file write or refused hash assumption. Both original attempts stay.
producer = COORD / "portable-v2-pr811-buf-golden-producer-v309.py"
text = producer.read_text(encoding="utf-8")
review = text[text.index('spec = importlib.util.spec_from_file_location'):text.index('assert len(before.splitlines())')]
namespace = dict(importlib=importlib, json=json, copy=__import__("copy"), validator=validator,
                 before=before, normalized_raw=normalized_raw)
exec(compile(review, str(producer) + ":semantic-review-only", "exec"), namespace)
module = namespace["module"]
module.validate_descriptor(json.loads(actual.read_bytes()), json.loads(normalized_raw))
check = subprocess.run([sys.executable, "-X", "utf8", "-B", str(validator), str(actual)], cwd=TREE, capture_output=True, timeout=60, check=True)
(OUT / "final-maintained-validator.log").write_bytes(check.stdout + check.stderr)
names = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", HEAD, "api/proto"], cwd=TREE, text=True).splitlines()
inputs = [p for p in names if p.endswith((".proto", "buf.yaml", "buf.lock"))]
inputs.append("tools/validate_phase1_descriptor.py")
identity = []
for path in inputs:
    current = subprocess.check_output(["git", "show", f"{HEAD}:{path}"], cwd=TREE)
    donor = subprocess.check_output(["git", "show", f"{DONOR}:{path}"], cwd=TREE)
    assert current == donor, path
    assert (TREE / path).read_bytes().replace(b"\r\n", b"\n") == current.replace(b"\r\n", b"\n"), path
    identity.append({"path": path, "bytes": len(current), "sha256": hashlib.sha256(current).hexdigest()})
assert subprocess.check_output(["git", "diff", "--name-only"], cwd=TREE, text=True).strip() == GOLDEN
buf = Path(shutil.which("buf"))
assert subprocess.check_output([str(buf), "--version"], text=True).strip() == "1.72.0"
result = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "sourceHead": HEAD,
    "bufPath": str(buf), "bufVersion": "1.72.0", "bufSha256": hashlib.sha256(buf.read_bytes()).hexdigest(),
    "actualInvocation": [str(buf), "build", "api/proto", "--as-file-descriptor-set", "-o", str(actual)],
    "actualDescriptorBytes": actual.stat().st_size, "actualDescriptorSha256": hashlib.sha256(actual.read_bytes()).hexdigest(),
    "actualIndependentProductionsIdentical": True,
    "oldGoldenSha256": hashlib.sha256(before).hexdigest(), "newTrackedLfGoldenSha256": hashlib.sha256(normalized_raw).hexdigest(),
    "peerPhysicalCrLfGoldenSha256": hashlib.sha256(peer_crlf).hexdigest(),
    "onlySerializationDifferenceIsOneCrBeforeFinalNewline": True,
    "maintainedCompactOutputAndOriginalTrackedLfPreserved": True,
    "allInputsEqualActual808Producer": identity,
    "reviewedAddedMessage": "TransactionStagingWitness fields1-10",
    "reviewedAddedFields": namespace["field_additions"],
    "allExistingDescriptorSemanticsPreserved": True,
    "actualBufBuildPassedTwice": True, "maintainedValidatorPassed": True,
    "preservedGuardRefusals": ["v308: two changed descriptor files exceeded the initial one-file assumption", "v309: peer physical CRLF hash differed from deliberately tracked LF output"],
    "goldenCopiedFromPeer": False, "sourceQualificationPending": True, "completeCI": False,
}
(OUT / "receipt.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
(COORD / "portable-v2-pr811-buf-golden-final-verification-v311.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in result.items() if k not in ("allInputsEqualActual808Producer", "actualInvocation")}))
