"""Use canonical SDK generator owners for actual application binding/source checks."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
COORD = Path(__file__).resolve().parent
PROJECTS = COORD / "portable-v2-402-created-projects-20261006-v1"
OUT = COORD / "portable-v2-402-owned-bindings-20261006-v1"
sys.path.insert(0, str(ROOT))
from tools.c_guest.bindings import generate as c_generate
from tools.java_guest.bindings import generate as java_generate
from tools.stateful_reference_project import WORLD
OUT.mkdir()
steps = []
counter = 0
def execute(argv):
    global counter
    counter += 1
    log = OUT / ("step-" + str(counter) + ".log")
    start = time.monotonic()
    with log.open("xb") as output:
        process = subprocess.run(list(map(str, argv)), cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, timeout=180)
    raw = log.read_bytes()
    record = {"argv": list(map(str, argv)), "exitCode": process.returncode, "bytes": len(raw),
              "sha256": hashlib.sha256(raw).hexdigest(), "elapsedSeconds": time.monotonic() - start,
              "log": str(log), "originalProcessReaped": True}
    steps.append(record)
    (OUT / "progress.json").write_text(json.dumps(steps, indent=2) + "\n", encoding="utf8")
    if process.returncode:
        raise RuntimeError("application source or binding command failed: " + str(counter))
    return raw
def c_run(*argv):
    return execute(argv).decode("utf8")
def java_run(label, *argv):
    return execute(argv)
generated_c, c_lock = c_generate(c_run, PROJECTS / "c/wit", WORLD, OUT / "c", platform=None)
java_lock = java_generate(java_run, PROJECTS / "java/wit", WORLD, OUT / "java")
sources = [str(path) for path in sorted((PROJECTS / "java/vendor/lsf/sdk/java-guest/runtime").rglob("*.java"))]
sources.extend([str(OUT / "java/Bindings.java"), str(PROJECTS / "java/src/dev/latent/app/Capsule.java")])
classes = OUT / "java/classes"
classes.mkdir()
execute(["javac", "-encoding", "UTF-8", "-d", classes, *sources])
receipt = {"at": datetime.now(timezone.utc).isoformat(), "world": WORLD, "canonicalCBindings": c_lock,
           "canonicalJavaBindings": java_lock, "javaJvmSourceCompilationPassed": True, "steps": steps,
           "wasmComponentsCompiled": False, "signingOrRuntimeQualificationClaimed": False,
           "heavyCargoStarted": False, "peerTreesModified": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps({key: value for key, value in receipt.items() if key not in {"steps", "canonicalCBindings", "canonicalJavaBindings"}}), flush=True)
