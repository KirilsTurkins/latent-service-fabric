import copy
import json
import pathlib
import re

ROOT = pathlib.Path(r'C:\Users\turkins\Desktop\lf-p4-restore808-review-entity-v9-20261006')
OUT = pathlib.Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-restore808-review-20261007-v1')
REL = 'tools/ci/suites.json'

def load(stage):
    return json.loads((OUT / f'stage-{stage}' / REL).read_bytes())

def remap(value):
    if isinstance(value, str):
        if value == 'protected_store::tests::lifecycle::detached_view_response_witness_waits_for_actual_native_retirement_after_close':
            return value + '_retaining_owner'
        return re.sub(r'\brecovery::(?=(?:migration|restore|resume|snapshot|offline)::)', 'recovery::v1::', value)
    if isinstance(value, list):
        return [remap(item) for item in value]
    if isinstance(value, dict):
        return {key: remap(item) for key, item in value.items()}
    return value

MISSING = object()
differences = []

def merge(base, peer, qualified, location):
    if peer == qualified:
        return copy.deepcopy(peer)
    if peer == base:
        return copy.deepcopy(qualified)
    if qualified == base:
        return copy.deepcopy(peer)
    if isinstance(peer, dict) and isinstance(qualified, dict):
        result = {}
        for key in sorted(peer.keys() | qualified.keys()):
            p, q = peer.get(key, MISSING), qualified.get(key, MISSING)
            if p is MISSING:
                result[key] = copy.deepcopy(q)
            elif q is MISSING:
                result[key] = copy.deepcopy(p)
            else:
                result[key] = merge(base.get(key, MISSING) if isinstance(base, dict) else MISSING, p, q, location + [key])
        return result
    if isinstance(peer, list) and isinstance(qualified, list):
        if all(isinstance(item, dict) and isinstance(item.get('id'), str) for item in peer + qualified):
            b = {v['id']: v for v in base} if isinstance(base, list) else {}
            p, q = {v['id']: v for v in peer}, {v['id']: v for v in qualified}
            order = list(p) + [key for key in q if key not in p]
            return [merge(b.get(key, MISSING), p[key], q[key], location + [key]) if key in p and key in q else copy.deepcopy(p.get(key, q.get(key))) for key in order]
        if all(isinstance(item, str) for item in peer + qualified):
            return list(peer) + [item for item in qualified if item not in peer]
    differences.append({'path': location, 'base': None if base is MISSING else base, 'peer': peer, 'qualified': qualified})
    return copy.deepcopy(qualified)

def main():
    base, peer, qualified = load(1), load(2), load(3)
    # Only names of the peer's version-specific Rust test modules move. Every
    # filter/ignore/timeout/prerequisite and both original obligation sets stay.
    peer = remap(peer)
    base = remap(base)
    result = merge(base, peer, qualified, [])
    minimum_reviews = []
    for item in differences:
        assert item['path'][0] == 'suites' and item['path'][-1] == 'minimumCases', item
        sid = item['path'][1]
        suite = next(value for value in result['suites'] if value['id'] == sid)
        print(json.dumps({'suite': sid, 'keys': list(suite), 'arrays': {key: len(value) for key, value in suite.items() if isinstance(value, list)}}))
        # The merged literal case inventory is authoritative; never retain the
        # smaller historical parent's floor after adding its peer's cases.
        names = suite.get('expectedCases')
        assert isinstance(names, list) and all(isinstance(v, str) for v in names), (sid, type(names))
        floor = max(len(names), item['peer'], item['qualified'])
        suite['minimumCases'] = floor
        minimum_reviews.append({'suite': sid, 'baseFloor': item['base'], 'peerFloor': item['peer'], 'qualifiedFloor': item['qualified'], 'unionFloor': floor, 'literalCases': len(names)})
    state = next(value for value in result['suites'] if value['id'] == 'latent-state.lib.latent-state')
    new_cases = [
        'recovery::v1::tests::legacy_selection_refuses_protected_accounting_and_progress_without_rewriting_rows',
        'recovery::v1::snapshot::tests::protected_snapshot_decoder_refuses_original_v1_archive_before_any_row_callback',
        'recovery::snapshot::tests::legacy_snapshot_decoder_refuses_original_v2_archive_before_any_row_callback',
    ]
    assert not set(new_cases) & set(state['expectedCases'])
    state['expectedCases'] = sorted(state['expectedCases'] + new_cases)
    state['minimumCases'] += len(new_cases)
    (OUT / 'ci-union-candidate.json').write_text(json.dumps(result, separators=(',', ':')) + '\n', encoding='utf-8')
    (OUT / 'ci-union-conflicts.json').write_text(json.dumps(differences, indent=2) + '\n', encoding='utf-8')
    (OUT / 'ci-union-floor-review.json').write_text(json.dumps(minimum_reviews, indent=2) + '\n', encoding='utf-8')
    (ROOT / REL).write_bytes((json.dumps(result, separators=(',', ':')) + '\n').encode())
    print(json.dumps({'remainingSemanticConflicts': differences, 'suiteCounts': [len(value.get('suites', [])) for value in (base, peer, qualified, result)]}, indent=2))

if __name__ == '__main__':
    main()
