"""Resolve reviewed additive-only hunks; leave overlapping changes for review."""
from pathlib import Path
import json
import re

root=Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
out=Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1")
names=["crates/latent-component-bindings/build.rs","crates/latent-core/src/budget/descendants/mod.rs",
       "tools/java_capsule_project.py","tools/java_guest/compiler.py","tools/rust_capsule_build.py"]
pattern=re.compile(r"^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]+\n",re.M|re.S)
records=[]
for name in names:
    path=root/name
    text=path.read_text(encoding="utf8")
    changes=[]
    def replace(match):
        ours,incoming=match[1],match[2]
        if not ours.strip() or not incoming.strip():
            changes.append({"oursEmpty":not ours.strip(),"incomingEmpty":not incoming.strip(),
                            "retainedBothNonemptyParentAdditions":True})
            return ours if not incoming.strip() else incoming
        return match[0]
    result=pattern.sub(replace,text)
    if result!=text:
        path.write_text(result,encoding="utf8",newline="\n")
    records.append({"path":name,"additiveHunksResolved":changes,"overlappingHunksRemain":bool(pattern.search(result))})
(out/"additive-source-review.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf8")
print(json.dumps([{ "path":row["path"],"resolved":len(row["additiveHunksResolved"]),
                   "overlapRemains":row["overlappingHunksRemain"]} for row in records]))
