from pathlib import Path
import json

coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination')
old=json.loads((coord/'portable-v2-784-sdk-linux-20261006-v1/invocation.json').read_bytes())
steps=old['steps']
steps[0].extend(['tools.tests.test_rust_capsule_authoring','tools.tests.test_wit_contracts'])
path=coord/'portable-v2-784-profile-source-steps-20261006-v2.json'
assert not path.exists()
path.write_text(json.dumps(steps,indent=2)+'\n')
print(str(path))
