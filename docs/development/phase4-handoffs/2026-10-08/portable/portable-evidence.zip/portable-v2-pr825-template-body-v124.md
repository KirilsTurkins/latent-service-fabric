Adds finite dispatcher capacity and retained transaction admission for #391. Reconciles development and current management APIs while preserving native-owner identity, operator/physical acceptance fences, and all existing tests and bounds.

Repairs the maintained C, Go, TypeScript, and .NET aggregate templates to return the real admission view and optional original key version from the current WIT. C retains and frees its owned version tokens through canonical return and cancellation.

Current-head Linux source checks pass. The same four template bytes compiled both aggregate and forbidden-HTTP variants with the pinned maintained compilers on source-paired 8850/0a4 candidates. Exact-head compiler/runtime qualification, full CI, and installed dispatcher startup/ordering/recovery remain pending. No prior compiler receipt is relabeled as this head.
