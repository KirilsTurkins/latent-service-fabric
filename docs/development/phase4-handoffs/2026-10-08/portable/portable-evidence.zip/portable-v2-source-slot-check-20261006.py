"""Report only the count and commit-prefix of active owned Source processes."""
import json
import subprocess
body = r'''
import json, os
from pathlib import Path
groups = {}
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        if proc.stat().st_uid != 10001:
            continue
        cwd = Path(os.readlink(proc / 'cwd'))
        if not cwd.name.startswith('source-'):
            continue
        if (proc / 'stat').read_text().rpartition(') ')[2].split()[0] == 'Z':
            continue
        groups.setdefault(cwd.name, 0)
        groups[cwd.name] += 1
    except (FileNotFoundError, PermissionError, OSError):
        continue
print(json.dumps({'activeSourceCheckouts': groups, 'count': len(groups)}))
'''
result = subprocess.run(['docker', 'exec', '-i', '--user', '10001:10001', 'latent-p4-root-native-20261004-v1', 'python3'],
                        input=body.encode(), capture_output=True, timeout=30, check=True)
report = json.loads(result.stdout)
print(json.dumps(report), flush=True)
assert report['count'] < 2, 'both-source-slots-occupied'
