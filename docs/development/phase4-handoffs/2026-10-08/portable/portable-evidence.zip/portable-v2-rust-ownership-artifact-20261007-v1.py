from pathlib import Path, PurePosixPath
import hashlib
import json
import subprocess
import zipfile

out=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-rust-ownership-artifact-20261007-v1')
assert not out.exists()
out.mkdir()
repo='repos/KirilsTurkins/latent-service-fabric'
artifact=11446465717
metadata=json.loads(subprocess.check_output(['gh','api',f'{repo}/actions/artifacts/{artifact}']))
assert metadata['workflow_run']['id']==37528001683
assert metadata['workflow_run']['head_sha']=='50869ccea15fa6b38d1091e2e7fa997c99caecb1'
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
archive=out/'artifact.zip'
with archive.open('wb') as target:
    subprocess.run(['gh','api',f'{repo}/actions/artifacts/{artifact}/zip'],stdout=target,check=True,timeout=120)
actual='sha256:'+hashlib.sha256(archive.read_bytes()).hexdigest()
assert actual==metadata['digest'],(actual,metadata['digest'])
selected=[]
with zipfile.ZipFile(archive) as bundle:
    assert len(bundle.infolist())<=2048
    for entry in bundle.infolist():
        name=PurePosixPath(entry.filename)
        assert not name.is_absolute() and '..' not in name.parts
        if name.name not in ('valid-ownership.jsonl','valid-ownership.stderr.txt'):
            continue
        assert entry.file_size<=4*1024*1024
        raw=bundle.read(entry)
        (out/name.name).write_bytes(raw)
        selected.append({'archivePath':entry.filename,'file':name.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
assert {row['file'] for row in selected}=={'valid-ownership.jsonl','valid-ownership.stderr.txt'},selected
diagnostics=[]
for line in (out/'valid-ownership.jsonl').read_bytes().splitlines():
    value=json.loads(line)
    if value.get('reason')=='compiler-message' and value['message'].get('level')=='error':
        message=value['message']
        diagnostics.append({'code':(message.get('code') or {}).get('code'),'message':message['message'],
                            'rendered':message.get('rendered')})
(out/'diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n')
(out/'receipt.json').write_text(json.dumps({'artifactId':artifact,'runId':37528001683,'source':metadata['workflow_run']['head_sha'],'archiveSha256':actual,'selected':selected,'authenticatedArchiveDigestVerified':True},indent=2)+'\n')
print(json.dumps({'artifact':artifact,'source':metadata['workflow_run']['head_sha'],'digestVerified':True,'diagnostics':diagnostics},indent=2))
