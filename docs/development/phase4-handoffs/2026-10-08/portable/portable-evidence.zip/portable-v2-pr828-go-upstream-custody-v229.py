from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-pr828-go-upstream-custody-v229'
OUT.mkdir(exist_ok=True)
ENV=dict(os.environ,GODEBUG='http2client=0')
REPO='KirilsTurkins/latent-service-fabric'
ID=11525626412
def api(endpoint):return subprocess.check_output(['gh','api',endpoint],env=ENV,timeout=180)
raw_meta=api(f'repos/{REPO}/actions/artifacts/{ID}')
metadata=json.loads(raw_meta)
assert metadata['id']==ID and not metadata['expired'] and metadata['size_in_bytes']==25994104
raw=api(f'repos/{REPO}/actions/artifacts/{ID}/zip')
assert len(raw)==metadata['size_in_bytes'] and hashlib.sha256(raw).hexdigest()==metadata['digest'].split(':')[1]
(OUT/'artifact.json').write_bytes(raw_meta)
archive=OUT/'artifact.zip'
archive.write_bytes(raw)
logs=[]
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        if 'sdk-runtime-tests' in info.filename and info.filename.endswith(('.stdout.txt','.stderr.txt','.log')):
            assert info.file_size<=4*1024**2
            data=z.read(info)
            name=info.filename.replace('/','__')
            (OUT/name).write_bytes(data)
            text=data.decode('utf8',errors='replace')
            useful=[line[:800] for line in text.splitlines() if any(s in line for s in (
                'test result:', 'panicked at', 'left:', 'right:', 'GuestTrap', 'ResourceExhausted', 'diagnostic', 'terminal', 'error[E','sdk-service-','failure-reason'))][-26:]
            logs.append(dict(path=info.filename,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),closedDiagnostics=useful))
    manifest=[dict(path=i.filename,bytes=i.file_size) for i in z.infolist() if not i.is_dir()]
proof=dict(at=datetime.now(timezone.utc).isoformat(),artifact=ID,archiveSha256=hashlib.sha256(raw).hexdigest(),archiveBytes=len(raw),
           exactCompletedRun=37717107093,originalHead='6f0a8e82299aa0a1224dee293aaa8a4db7f3a7d9',logs=logs,readOnly=True)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
(OUT/'members.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
