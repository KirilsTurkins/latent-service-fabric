﻿from pathlib import Path
import hashlib,json,shutil,subprocess,sys
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');released=json.loads((coord/'root-client800-current-native-build-20261007-v1/receipt.json').read_bytes());assert released['passed'] and released['originalProcessReaped'] and released['sourceClean'] and released['sourceHeadUnchanged']
stage=coord/'portable-v2-go825-retained-fixture-stage-receipt-20261007-v110.json';receipt=json.loads(stage.read_bytes());assert receipt['head']=='8785fadf4d630cce34fbcbfebf65d0fbb0851d1c' and receipt['allOriginalFileHashesVerified'] and receipt['files']==1111 and not receipt['compilerExecuted']
controller=coord/'portable-v2-go825-retained-sdk-native-controller-20261007-v104.py';steps=coord/'portable-v2-go825-retained-sdk-native-steps-20261007-v104.json';proof=json.loads((coord/'portable-v2-go825-retained-sdk-controller-custody-20261007-v104.json').read_bytes())
assert hashlib.sha256(controller.read_bytes()).hexdigest()==proof['controllerSha256'] and hashlib.sha256(steps.read_bytes()).hexdigest()==proof['stepSha256']
assert shutil.disk_usage(coord).free>2*1024**3
print(json.dumps(dict(head=receipt['head'],originalSourceAndRetainedFixtures=True,fixtureStageSha256=hashlib.sha256(stage.read_bytes()).hexdigest(),current800FullyReaped=True,freeHostBytes=shutil.disk_usage(coord).free,originalGo120sWallGrantPreserved=True,retainedCompilerDiagnosticOnly=True)),flush=True)
raise SystemExit(subprocess.call([sys.executable,'-X','utf8','-B',str(controller),'portable-v2-go825-retained-sdk-native-20261007-v111',receipt['head'],str(steps),'native']))
