import json
import pathlib
import subprocess

COORD = pathlib.Path(__file__).resolve().parent
OUT = COORD / 'portable-v2-pr-historical-green-audit-20261007-v1'
OUT.mkdir(exist_ok=True)
NUMBERS = (767, 780, 784, 787, 790, 791, 796, 800, 802, 803, 808, 811, 821, 823, 825, 828)
parts = [f'p{n}:pullRequest(number:{n}){{headRefOid commits(last:25){{nodes{{commit{{oid statusCheckRollup{{state}}}}}}}}}}' for n in NUMBERS]
query = 'query{repository(owner:"KirilsTurkins",name:"latent-service-fabric"){' + ''.join(parts) + '}}'
result = subprocess.run(['gh', 'api', 'graphql', '-f', 'query=' + query], cwd=COORD, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
(OUT / 'graphql.json').write_bytes(result.stdout)
(OUT / 'graphql.stderr').write_bytes(result.stderr)
assert result.returncode == 0, result.stderr.decode(errors='replace')
raw = json.loads(result.stdout)
assert 'errors' not in raw, raw.get('errors')
records = []
for number in NUMBERS:
    pr = raw['data']['repository'][f'p{number}']
    successes = [node['commit']['oid'] for node in pr['commits']['nodes'] if (node['commit']['statusCheckRollup'] or {}).get('state') == 'SUCCESS']
    records.append({'number': number, 'currentHead': pr['headRefOid'], 'commitsObserved': len(pr['commits']['nodes']), 'historicalSuccessfulAggregateHeads': successes,
                    'wholeCiQualified': False, 'shortcutEligible': False,
                    'note': 'Aggregate success alone is not full required CI. Any candidates still need complete original check contexts and a reviewed simple conflict-only byte delta.'})
(OUT / 'receipt.json').write_text(json.dumps({'records': records, 'readOnly': True}, indent=2) + '\n', encoding='utf-8')
print(json.dumps(records, indent=2))
