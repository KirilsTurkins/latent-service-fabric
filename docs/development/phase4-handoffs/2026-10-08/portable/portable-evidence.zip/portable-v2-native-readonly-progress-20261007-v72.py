import json,subprocess,sys,shutil
from pathlib import Path
owner="latent-p4-root-native-20261004-v1"
base="/var/lib/docker/volumes/"+owner+"/_data"
job=sys.argv[1]
assert job.isascii() and all(c.isalnum() or c=="-" for c in job)
body=r"""import json,pathlib,re,hashlib
p=pathlib.Path(JOB_PATH)
r=p/'progress.json'
if r.exists():
 d=json.loads(r.read_bytes())
 print(json.dumps(dict(head=d['head'],tree=d['tree'],steps=[dict(index=i+1,exit=row['exitCode'],seconds=row['elapsedSeconds'],reaped=row['originalProcessReaped'],stop=row['stopReason']) for i,row in enumerate(d['steps'])])))
else: print('progress:not-yet-written')
logs=sorted(p.glob('step-*.log'),key=lambda f:int(f.stem.split('-')[1]))
if logs:
 f=logs[-1]; raw=f.read_bytes(); text=raw.decode(errors='replace')
 print(json.dumps(dict(log=f.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),testResults=re.findall(r'test result:[^\n]+',text),tail=text[-3200:])))
f=p/'receipt.json'
if f.exists(): print('final:'+f.read_text())
""".replace('JOB_PATH',repr(base+'/jobs/'+job))
r=subprocess.run(['docker','exec','-i','--user','10001:10001',owner,'python3'],input=body.encode(),capture_output=True,timeout=30)
print(r.stdout.decode(errors='replace'))
print(r.stderr.decode(errors='replace'))
print('freeHostBytes',shutil.disk_usage(Path(__file__).parent).free)
raise SystemExit(r.returncode)
