from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path

COORD=Path(__file__).resolve().parent
HEAD='7bc1ca796e5b1a2125a0fb6be905484fec6e8b63'
invocation=json.loads((COORD/'integration-v12-pr823-current-main-source-v16/invocation.json').read_bytes())
assert invocation['head']=='3b7af5096198ae9453b5616bc124def18798911c'
steps=invocation['steps']
assert steps[0][:5]==['python3','-X','utf8','-B','-c']
existing=steps[0][-1]
needle="],check=True)"
assert existing.count(needle)==1
new="'tools.tests.test_stateful_reference_project', 'tools.tests.test_stateful_reference_deployment', 'tools.tests.test_stateful_reference_conductor'"
steps[0][-1]=existing.replace(needle,', '+new+'],check=True)',1)
steps[3][-1]='target/ci/observed-reference402-current-v293.json'
path=COORD/'portable-v2-reference402-current-source-steps-v293.json'
path.write_text(json.dumps(steps,indent=2)+'\n',encoding='utf8')
previous='portable-v2-pr784-final-main-source-20261008-v277'
r=json.loads((COORD/previous/'receipt.json').read_bytes())
assert r['head']=='b43ab914f9ffbdd4fa26c26b66c913daf3342aef' and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped']
proof=dict(at=datetime.now(timezone.utc).isoformat(),head=HEAD,previous=previous,source='source-6ab38845e5a266f3',
           steps=str(path),stepsSha256=hashlib.sha256(path.read_bytes()).hexdigest(),currentFoundationAllModulesAndGatesPreserved=True,
           threeActualAppModulesAdded=True,noNewClone=True,sourcePending=True,noCompilerNodeBrowserClaim=True)
(COORD/'portable-v2-reference402-current-source-prepared-v293.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
