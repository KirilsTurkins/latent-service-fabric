from pathlib import Path

COORD=Path(__file__).resolve().parent
source=(COORD/'portable-v2-owned-signing-source-sequence-v239.py').read_text(encoding='utf8')
source=source.replace('v239','v245')
source=source.replace("previous='portable-v2-pr796-final-main-source-20261008-v234'","previous='portable-v2-pr784-final-main-source-20261008-v239'")
source=source.replace('for number in (790,800,791,787,796,784,825,811):','for number in (825,811,791):')
needle="    record=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-union-v238/receipt.json')).read_bytes())"
replacement="""    if number==825:
        record=json.loads((COORD/'portable-v2-pr825-core-owner-repair-prepared-v244.json').read_bytes())
    elif number==811:
        record=json.loads((COORD/'portable-v2-pr811-current-main-union-v243/receipt.json').read_bytes())
    else:
        record=json.loads((COORD/'portable-v2-pr791-core-owner-repair-prepared-v247.json').read_bytes())"""
assert source.count(needle)==1
source=source.replace(needle,replacement)
path=COORD/'portable-v2-completed-repair-source-sequence-v245.py'
compile(source,str(path),'exec')
assert not path.exists()
path.write_text(source,encoding='utf8')
print(str(path))
