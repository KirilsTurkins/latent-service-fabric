from datetime import datetime, timezone
import copy
import hashlib
import json
from pathlib import Path
import subprocess

TREE = Path(r'C:\Users\turkins\Desktop\lf-p4-pr790-current-binding-v216')
COORD = Path(__file__).resolve().parent
def git(*args):
    return subprocess.check_output(['git','-C',str(TREE),*args])
def stage(number,path):
    return git('show',f':{number}:{path}')
path = 'tools/ci/suites.json'
base, ours, theirs = [json.loads(stage(n,path)) for n in (1,2,3)]
assert isinstance(base,dict) and all('suites' in value for value in (base,ours,theirs))
result = copy.deepcopy(ours)
union_fields = {'expectedCases','expectedIgnored','ignoredLeaves','expectedCustomCases','prerequisites'}
def merge_scalar(b,o,t,label):
    if o == t: return o
    if o == b: return t
    if t == b: return o
    raise AssertionError(('unreviewed-conflict',label,b,o,t))
for key in (set(base)|set(ours)|set(theirs)) - {'suites'}:
    result[key] = merge_scalar(base.get(key),ours.get(key),theirs.get(key),'root.'+key)
maps = [{row['id']:row for row in value['suites']} for value in (base,ours,theirs)]
rows = []
changed = []
for identity in sorted(set(maps[1])|set(maps[2])):
    b,o,t = [m.get(identity) for m in maps]
    if o is None: row=copy.deepcopy(t)
    elif t is None: row=copy.deepcopy(o)
    else:
        row = {}
        for key in sorted(set(o)|set(t)):
            if key in union_fields:
                row[key] = sorted(set(o.get(key,[]))|set(t.get(key,[])))
            elif key == 'minimumCases':
                row[key] = max(o[key],t[key],len(set(o.get('expectedCases',[]))|set(t.get('expectedCases',[]))))
            else:
                row[key] = merge_scalar((b or {}).get(key),o.get(key),t.get(key),identity+'.'+key)
        for parent in (o,t):
            assert parent['minimumCases'] <= row['minimumCases']
            for key in union_fields:
                assert set(parent.get(key,[])) <= set(row.get(key,[]))
        if row != o: changed.append(dict(id=identity,minimumCases=row['minimumCases'],caseCount=len(row.get('expectedCases',[]))))
    rows.append(row)
result['suites'] = rows
(TREE/path).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf8')
test_path='tools/tests/test_java_server_source.py'
old_test=stage(2,test_path)
other_test=stage(3,test_path)
assert old_test.replace(b'/* controlled empty-world canonical bridge: no transaction imports */',b'/* controlled import probe */') == other_test
(TREE/test_path).parent.mkdir(parents=True,exist_ok=True)
(TREE/test_path).write_bytes(old_test)
git('add',path,test_path)
assert not git('ls-files','-u')
git('diff','--check','--cached')
proof = dict(at=datetime.now(timezone.utc).isoformat(),ours='221645876350b9790d5255df588f0ce2ca728871',development='0cd6c2e8649e8181366e0adbfe03da1bf2a3c7a3',
             allParentSuiteCasesFloorsIgnoresPrerequisitesPreserved=True,suiteCount=len(rows),changedRows=changed,
             originalQualifiedEmptyWorldFixturePreserved=True,sourceAndNativeCurrentMergePending=True,noPublication=True)
(COORD/'portable-v2-pr790-current-merge-review-v216.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
git('commit','-m','merge development into transaction binding repair')
proof['head']=git('rev-parse','HEAD').decode().strip()
(COORD/'portable-v2-pr790-current-merge-review-v216.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
