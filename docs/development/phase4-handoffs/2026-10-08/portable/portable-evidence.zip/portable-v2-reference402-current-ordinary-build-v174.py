"""Invoke each maintained ordinary captured app build; no simulated package/node proof."""
from pathlib import Path
import argparse,hashlib,importlib,json,subprocess,sys
sys.path.insert(0,str(Path.cwd()))
from tools import stateful_reference_project as app
from tools.rust_capsule_project import snapshot
parser=argparse.ArgumentParser();parser.add_argument("--language",choices=app.LANGUAGES,required=True);parser.add_argument("--output",type=Path,required=True);parser.add_argument("--contracts-tool",type=Path,required=True);parser.add_argument("--tools",type=Path);parser.add_argument("--wasi-sdk",type=Path);parser.add_argument("--gradle",default="gradle");args=parser.parse_args()
root=Path.cwd();head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip();assert head=="0429371476cca028c2884fd5d0db26d17af5f410" and not subprocess.check_output(["git","status","--porcelain"])
assert not args.output.exists();args.output.mkdir(mode=0o700);project=app.create(args.output/"project",args.language,draft_id="alice");captured=snapshot(project)
modules={"rust":"tools.rust_capsule_build","c":"tools.c_capsule_build","typescript":"tools.typescript_guest.build","go":"tools.go_capsule_build","java":"tools.java_capsule_build","dotnet":"tools.dotnet_guest.build"};owner=importlib.import_module(modules[args.language]);kw={}
if args.language in ("typescript","dotnet"):
 if args.tools is None:raise ValueError("explicit authenticated compiler tools are required")
 kw["tools"]=args.tools
if args.language=="rust":kw["offline"]=True
if args.language=="java":
 if args.wasi_sdk is None:raise ValueError("explicit authenticated WASI SDK is required")
 kw.update(wasi_sdk=args.wasi_sdk,gradle=args.gradle,timeout=900)
output=args.output/"build"
try:
 owner.build(project,output,args.contracts_tool,None,"https://github.com/KirilsTurkins/latent-service-fabric",**kw)
 assert snapshot(project)==captured,"captured application source changed"
 complete=json.loads((output/"BUILD-COMPLETE.json").read_bytes());observation=json.loads((output/"build-observation.json").read_bytes());component=(output/"component.wasm").read_bytes();assert complete["packageAssembled"] is False and observation["componentDigest"]=="sha256:"+hashlib.sha256(component).hexdigest()
 (args.output/"actual-app-compiler-receipt.json").write_text(json.dumps({"sourceHead":head,"language":args.language,"world":app.WORLD,"ordinaryBuildComplete":True,"componentDigest":observation["componentDigest"],"componentBytes":len(component),"sourceDigest":complete["sourceDigest"],"allCapturedProjectBytesUnchanged":True,"packageAssembled":False,"signedNodeQualified":False,"browserQualified":False},indent=2)+"\n")
finally:
 assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==head
 assert not subprocess.check_output(["git","status","--porcelain"])
