from pathlib import Path
import ast
import copy
import hashlib
import json
import subprocess
import sys

root=Path(r'C:\Users\turkins\Desktop\lf-p4-rust-ownership-profile-20261007-v1')
out=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-rust-ownership-review-20261007-v1')
out.mkdir(exist_ok=True)
source='tools/check_rust_capsule_ownership.py'
base='50869ccea15fa6b38d1091e2e7fa997c99caecb1'
before=ast.parse(subprocess.check_output(['git','show',base+':'+source],cwd=root))
after=ast.parse((root/source).read_bytes())
def constants(tree):
    return {node.targets[0].id:ast.literal_eval(node.value) for node in tree.body
            if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name)
            and node.targets[0].id in ('PRELUDE','POSITIVE','CASES')}
assert constants(before)==constants(after)
assert len(constants(before)['CASES'])==19
old=next(node for node in before.body if isinstance(node,ast.FunctionDef) and node.name=='check')
new=copy.deepcopy(next(node for node in after.body if isinstance(node,ast.FunctionDef) and node.name=='check'))
added=[node for node in new.body if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call)
       and getattr(node.value.func,'id','')=='select_transaction_types']
assert len(added)==1 and ast.unparse(added[0])=='select_transaction_types(project)'
new.body.remove(added[0])
assert ast.dump(old)==ast.dump(new),'original-ownership-body-or-deadline-changed'
sys.path.insert(0,str(root))
from tools import ci_contracts as c
owner=root/'tools/ci/contracts/owners/tools/check_rust_capsule_ownership.py.json'
assert not owner.exists(),'unexpected-new-delegated-owner; review separately'
module='tools/tests/test_rust_ownership_profile.py'
observed=c.python_expectations(root)[module]
assert observed['cases']==['RustOwnershipProfile.test_feature_selection_preserves_every_other_captured_byte_and_project_limit',
                           'RustOwnershipProfile.test_manifest_drift_and_second_selection_refuse_without_rewriting_source']
assert all(guard['bases']==['unittest.TestCase'] and guard['classDecorators']==guard['decorators']==guard['skipSites']==[] for guard in observed['guards'].values())
record=c.record('python','Reviewed actual greeting creator/capture checks: select only the exact transaction Cargo feature while every other captured SDK/lock/project/runtime byte remains identical; wrong SDK mapping and repeated selection refuse without rewriting. These two Source cases do not replace the20actual wasm32 positive/negative ownership compiles.',module=module,**observed)
path=root/'tools/ci/contracts/python/test_rust_ownership_profile.py.json'
assert not path.exists()
path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8',newline='\n')
receipt={'base':base,'originalPositiveAnd19NegativeBodiesExact':True,'checkBodyOnlyAddsManifestSelection':True,
         'delegatedOwnerContractRequired':False,
         'overallSeconds':360,'perCheckMaximumSeconds':180,'maximumOutputBytes':4*1024*1024,
         'rootActualWasmCampaignPending':True}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
