from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

COORD=Path(__file__).resolve().parent
TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr811-21c-main-v272')
HEAD='335dca010d299e554a4ab351e9fb525ae15e8d5c'
OLD='74368f3f9ff40d0457316d75b8606c60d77744e5'
BRANCH='feat/phase4-command-completion-388'
REPO='KirilsTurkins/latent-service-fabric'
ENV=dict(os.environ,GODEBUG='http2client=0')
def call(argv):return subprocess.check_output(argv,env=ENV,timeout=120)
def auth(job,head):
    out=COORD/job;raw=(out/'receipt.json').read_bytes();r=json.loads(raw)
    assert r['head']==head and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped']
    logs=[]
    for row in r['steps']:
        data=(out/Path(row['log']).name).read_bytes()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped']
        logs.append(data.decode())
    return hashlib.sha256(raw).hexdigest(),logs
source_sha,_=auth('portable-v2-pr811-final-main-source-20261008-v277',HEAD)
native_sha,logs=auth('portable-v2-pr811-current-main-native-20261008-v283',HEAD)
metadata=json.loads(call(['git','-C',str(TREE),'show',HEAD+':tools/ci/suites.json']));rows={r['id']:r for r in metadata['suites']}
for index,key,count in [(0,'latent-signing.lib.latent-signing',58),(3,'latent-node.lib.latent-node',108)]:
    listed=set(re.findall(r'^([\w:]+): test$',logs[index],re.M))
    assert listed==set(rows[key]['expectedCases']) and len(listed)==count
for index,count in [(1,58),(4,108),(5,66)]:assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in logs[index]
assert 'AOT sandbox: 12 unprivileged real-entry probes and exact-policy syscall probe passed' in logs[6]
host_dir=COORD/'portable-v2-pr811-current-sdk-host-v267'
host_raw=(host_dir/'host-native-receipt.json').read_bytes();host=json.loads(host_raw)
assert host['head']=='f8253b33ce6987663ff423bafce1946f901ba66f' and host['passed'] and host['allProcessesReaped'] and host['allSourceHashesUnchanged']
for row in host['steps']:
    data=(host_dir/row['log']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['returncode']==0
assert call(['git','-C',str(TREE),'diff','--name-only',host['head'],HEAD]).decode().splitlines()==['tools/java_server_node.py']
assert not call(['git','-C',str(TREE),'status','--porcelain'])
pr=json.loads(call(['gh','pr','view','811','--repo',REPO,'--json','headRefOid,headRefName,state']))
assert pr==dict(headRefOid=OLD,headRefName=BRANCH,state='OPEN'),pr
call(['git','-C',str(TREE),'merge-base','--is-ancestor',OLD,HEAD])
body='''Retains command completion, physical native-owner shutdown and the typed staging witness for #388. Normally merges current peer and development history while preserving every original model, field allocation, operation, test, bound and ignore control.

Repairs the completed cross-language SDK failures by regenerating the Node descriptors with the maintained locked protoc31.1 producer and retaining all62 .NET protobuf fixtures among78 shared records. The six-input .NET generation lock comes from two actual pinned Linuxprotoc29 reproductions of all10 sources; only the node.proto input and Node.cs output change. All13 client facades, Java bridge and Rust network conversions remain source-matched.

Current Linux source checks pass238 cases with zero skips, including actual Node descriptor verification. Exact Signing58, Node108 and activation66 cases, twelve real AOT probes, the syscall check and original ordinary/selected strict Clippy pass. Pinned Windows SDK tests pass all11 commands: TypeScript27 network cases with one original Windows skip, semantic checks, .NET62 protobuf cases,13 transport scenarios/571 checks and78 semantic records. Those SDK receipts remain at their exact source head; the later Java diagnostic-only delta leaves all SDK/native bytes unchanged. Full current Linux SDK qualification, hosted CI and the complete separate-node delivery gates remain pending.
'''
body_path=COORD/'portable-v2-pr811-current-qualified-body-v285.md';body_path.write_text(body,encoding='utf8')
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=811,head=HEAD,oldHead=OLD,sourceReceiptSha256=source_sha,
           nativeReceiptSha256=native_sha,hostSDKReceiptSha256=hashlib.sha256(host_raw).hexdigest(),
           exactSigning58Node108Activation66AndCustomAOTPass=True,actualSDKOriginalGuardsAndSourceHashesPass=True,
           peerCurrentSigningSemanticsAndAOT1Preserved=True,normalPush=True,published=False,fullLinuxSDKAndCIPending=True,noIssueClosure=True)
path=COORD/'portable-v2-pr811-current-qualified-publication-v285.json';path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
push=subprocess.run(['git','-C',str(TREE),'push','origin','HEAD:refs/heads/'+BRANCH],env=ENV,capture_output=True,timeout=120)
(COORD/'portable-v2-pr811-current-qualified-push-v285.log').write_bytes(push.stdout+push.stderr)
assert push.returncode==0
remote=call(['git','-C',str(TREE),'ls-remote','origin','refs/heads/'+BRANCH]).decode().split()[0];assert remote==HEAD
call(['gh','pr','edit','811','--repo',REPO,'--body-file',str(body_path)])
proof.update(published=True,verifiedRemoteHead=remote,bodyUpdated=True)
path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
