Preserves conservative retention, clock and native-owner accounting for #397. Normally integrates current development while keeping all prior retention, payload, quota, recovery, maintenance and cleanup cases, bounds and ignore controls.

Repairs the completed source/lint seams and retains the complete generated Java fixture. Current route evidence combines the existing bounded recorder with the new rejected-delete summary through one actual call; original error identity, privacy and size limits remain intact.

The original feature head completed all48 checks. Its current development merge also contained source conflicts, so the reconciled candidate received fresh Linux qualification:227 source cases pass with zero skips; exactSigning58, Node91 and activation66 cases, twelve real AOT probes, the syscall check, ordinary Clippy and original selected strict checks pass. All earlier failures and source-paired proofs remain retained.

Full current CI and the complete twelve acceptance criteria still need review, including logical and physical engine high-water, atomic quota, shared paged maintenance, linked command/effect/payload and inbox retention, conservative restore clocks, and actual reserved recovery under store pressure. This PR does not close #397 from these scoped checks alone.
