from pathlib import Path
import json

COORD=Path(__file__).resolve().parent
source=(COORD/'portable-v2-owned-corrected-source-sequence-v234.py').read_text(encoding='utf8')
source=source.replace('v234','v239')
source=source.replace("previous='portable-v2-pr796-final-main-source-20261008-v225'","previous='portable-v2-pr796-final-main-source-20261008-v234'")
needle="    record=next(row for row in json.loads((COORD/'portable-v2-owned-aot-floor-restored-v233.json').read_bytes())['records'] if row['pr']==number)"
replacement="    record=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-union-v238/receipt.json')).read_bytes())"
assert source.count(needle)==1
source=source.replace(needle,replacement)
source=source.replace("if number==811:\n        steps=", "if number==811:\n        steps=",1)
target=COORD/'portable-v2-owned-signing-source-sequence-v239.py'
compile(source,str(target),'exec')
assert not target.exists()
target.write_text(source,encoding='utf8')
print(str(target))
