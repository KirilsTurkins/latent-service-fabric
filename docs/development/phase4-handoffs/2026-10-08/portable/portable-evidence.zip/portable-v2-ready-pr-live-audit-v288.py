from datetime import datetime,timezone
import json
import os
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
ENV=dict(os.environ,GODEBUG='http2client=0')
out=COORD/'portable-v2-ready-pr-live-audit-v288';out.mkdir(exist_ok=True)
records=[]
for number in (784,796,787,790,800,825,811):
    raw=subprocess.check_output(['gh','pr','view',str(number),'--repo','KirilsTurkins/latent-service-fabric','--json','headRefOid,headRefName,state,mergeable,statusCheckRollup'],env=ENV,timeout=60)
    (out/(str(number)+'.json')).write_bytes(raw)
    r=json.loads(raw);checks=r['statusCheckRollup']
    pending=[dict(name=x['name'],status=x.get('status'),url=x.get('detailsUrl')) for x in checks if x.get('status')!='COMPLETED']
    failures=[dict(name=x['name'],url=x.get('detailsUrl')) for x in checks if x.get('conclusion')=='FAILURE']
    records.append(dict(pr=number,head=r['headRefOid'],mergeable=r['mergeable'],state=r['state'],checks=len(checks),pending=pending,failures=failures,
                        fullyGreen=bool(checks) and not pending and all(x.get('conclusion') in {'SUCCESS','SKIPPED','NEUTRAL'} for x in checks)))
proof=dict(at=datetime.now(timezone.utc).isoformat(),readOnly=True,records=records)
(out/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(at=proof['at'],records=[dict(pr=r['pr'],head=r['head'],mergeable=r['mergeable'],checks=r['checks'],pending=len(r['pending']),failures=r['failures'],fullyGreen=r['fullyGreen']) for r in records]),indent=2))
