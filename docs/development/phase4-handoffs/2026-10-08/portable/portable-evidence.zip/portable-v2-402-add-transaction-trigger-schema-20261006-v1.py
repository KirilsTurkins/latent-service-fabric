"""Add the exact closed shared HTTP transaction profile without changing old profiles."""
from pathlib import Path
import copy
import json

root = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
path = root / "schemas/trigger.schema.json"
raw = path.read_bytes()
value = json.loads(raw)
original = copy.deepcopy(value)
defs = value["$defs"]
assert "transactionHttpTrigger" not in defs
maximum = str((1 << 64) - 1)
parts = [r"[1-9][0-9]{0,18}"]
for index, digit in enumerate(maximum):
    low, high = (1 if index == 0 else 0), int(digit) - 1
    if high < low:
        continue
    selected = str(low) if low == high else "[" + str(low) + "-" + str(high) + "]"
    remaining = len(maximum) - index - 1
    parts.append(maximum[:index] + selected + ("[0-9]{" + str(remaining) + "}" if remaining else ""))
parts.append(maximum)
incarnation = "^(?:" + "|".join(parts) + ")$"
identity = {"type":"string","minLength":1,"maxLength":256,"pattern":r"^[^\u0000-\u001f\u007f-\u009f]+$"}
sha = {"type":"string","minLength":71,"maxLength":71,"pattern":r"^sha256:[0-9a-f]{64}$"}
properties = {
    "profile":{"const":"transaction-http-v1"}, "scheme":{"enum":["http","https"]},
    "host":{"type":"string","minLength":1,"maxLength":255},
    "path":{"type":"string","minLength":1,"maxLength":8192,"pattern":r"^/"},
    "pathMatch":{"enum":["exact","prefix"]}, "method":{"enum":["GET","HEAD","POST","PUT","PATCH","DELETE"]},
    "transactionMode":{"enum":["command","query","result"]}, "namespace":copy.deepcopy(identity),
    "incarnation":{"type":"string","minLength":1,"maxLength":20,"pattern":incarnation},
    "stateSchema":copy.deepcopy(sha), "companionDigest":copy.deepcopy(sha),
    "stateBinding":copy.deepcopy(identity), "resultPolicy":copy.deepcopy(identity), "entity":copy.deepcopy(identity),
    "preconditionKey":{"type":"string","minLength":4,"maxLength":1368,
      "pattern":r"^(?:(?:[A-Za-z0-9+/]{4}){0,340}(?:[A-Za-z0-9+/]{4}|[A-Za-z0-9+/][AQgw]==|[A-Za-z0-9+/]{2}[AEIMQUYcgkosw048]=)|(?:[A-Za-z0-9+/]{4}){341}[A-Za-z0-9+/][AQgw]==)$"},
}
configuration = {"type":"object","additionalProperties":False,"maxProperties":15,
    "required":[key for key in properties if key not in {"entity","preconditionKey"}],"properties":properties,
    "allOf":[
      {"if":{"properties":{"transactionMode":{"const":"command"}}},
       "then":{"properties":{"method":{"enum":["POST","PUT","PATCH","DELETE"]}}}},
      {"if":{"properties":{"transactionMode":{"const":"query"}}},
       "then":{"properties":{"method":{"enum":["GET","HEAD"]}}}},
      {"if":{"properties":{"transactionMode":{"const":"result"}}},
       "then":{"properties":{"method":{"const":"GET"}}}},
      {"if":{"required":["preconditionKey"]},"then":{"properties":{"transactionMode":{"const":"command"}}}},
    ]}
profile = copy.deepcopy(defs["bufferedHttpTrigger"])
target = profile["properties"]["spec"]["properties"]["target"]
target["properties"]["contract"] = {"type":"string","minLength":1,"maxLength":128}
target["properties"]["function"] = {"type":"string","minLength":1,"maxLength":128}
profile["properties"]["spec"]["properties"]["configuration"] = configuration
defs["transactionHttpTrigger"] = profile
defs["httpTrigger"]["oneOf"].append({"$ref":"#/$defs/transactionHttpTrigger"})
value["description"] = ("Generic trigger envelope. HttpTrigger configuration selects exactly one closed target/profile pair: "
    "buffered-v1 application execution, static-site-v1 browser publication routing, or transaction-http-v1 "
    "signed command/query/original-result routes. Configuration and signed links are constraints, not grants.")
check = copy.deepcopy(value)
del check["$defs"]["transactionHttpTrigger"]
check["$defs"]["httpTrigger"]["oneOf"].pop()
check["description"] = original["description"]
assert check == original
path.write_text(json.dumps(value,separators=(",",":"),ensure_ascii=False)+"\n",encoding="utf8",newline="\n")
print("Closed transaction profile added; every previous schema field preserved")
