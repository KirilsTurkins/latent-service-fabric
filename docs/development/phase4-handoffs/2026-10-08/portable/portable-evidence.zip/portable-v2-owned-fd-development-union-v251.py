from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import sys

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
MAIN='fd4623acdc8f94e72291b85716c16d10dcd118cd'
number,parent=sys.argv[1:]
assert number in {'790','800','791','787','796','784','825','811'} and len(parent)==40
TREE=Path(r'C:\Users\turkins\Desktop')/('lf-p4-pr'+number+'-fd-main-v251')
assert not TREE.exists()
def git(*args,cwd=REPO):return subprocess.check_output(['git','-C',str(cwd),*args])
git('worktree','add','--no-checkout','-b','fix/phase4-pr'+number+'-fd-main-v251',str(TREE),parent)
git('sparse-checkout','set','--no-cone','tools/java_http_composition/qualify.py',cwd=TREE)
git('checkout','fix/phase4-pr'+number+'-fd-main-v251',cwd=TREE)
git('merge','--no-ff','-m','merge verified Java composition evidence from development',MAIN,cwd=TREE)
head=git('rev-parse','HEAD',cwd=TREE).decode().strip()
assert not git('status','--porcelain',cwd=TREE)
paths=git('diff','--name-only',parent,head,cwd=TREE).decode().splitlines()
assert set(paths)==set(git('diff','--name-only','c84473ec9868fc496486f864afe52f1b7105329f',MAIN,cwd=TREE).decode().splitlines())
assert all(p.startswith('docs/evidence/java-http-current-fd') or p.startswith('docs/evidence/') or p=='tools/java_http_composition/qualify.py' for p in paths)
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=int(number),head=head,parent=parent,development=MAIN,tree=str(TREE),
           changedPaths=paths,allRustApiSdkWitSchemasCargoAndSigningBodiesUnchanged=True,allCaseFloorAndIgnoreMetadataUnchanged=True,
           priorNativeReceiptsRemainAtActualOriginalHeads=True,currentSourceValidationPending=True,noPublication=True)
(COORD/('portable-v2-pr'+number+'-fd-main-union-v251.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k!='changedPaths'},indent=2))
