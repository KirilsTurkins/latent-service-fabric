import hashlib
import json
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
PATH='crates/latent-core/src/budget/host_memory.rs'
old='d790df6cea7115f21e3f7281a77227403fe7769777933e5b18bcd928f0e3a1c3'
good='1b57f7000372cc0ad7e77a4c559c9a6e0f6c75963c4d1315163f214146e68790'
rows=[]
for number in (790,800,791,787,796,784,825,811):
    record=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-union-v238/receipt.json')).read_bytes())
    data=subprocess.check_output(['git','-C',str(REPO),'show',record['head']+':'+PATH])
    sha=hashlib.sha256(data).hexdigest()
    rows.append(dict(pr=number,head=record['head'],sha256=sha,exactKnownFailedBlob=sha==old,exactQualifiedRepairBlob=sha==good))
(COORD/'portable-v2-shared-core-owner-source-audit-v246.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
print(json.dumps(rows,indent=2))
