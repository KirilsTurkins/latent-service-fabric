from pathlib import Path, PurePosixPath
import hashlib
import json
import posixpath
import re
import subprocess

repo=Path(r'C:\Users\turkins\Desktop\latent-fabric')
source=Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination')
audit=json.loads((coord/'portable-v2-395-shared-closure-audit-20261006-v1.json').read_bytes())
head=audit['source']; base=audit['base']
trees={}
for revision in (head,base):
    entries={}
    for line in subprocess.check_output(['git','ls-tree','-r',revision],cwd=repo,text=True).splitlines():
        meta,name=line.split('\t',1)
        mode,kind,oid=meta.split()
        entries[name]={'mode':mode,'kind':kind,'oid':oid}
    trees[revision]=entries
selected={row['path'] for row in audit['runtimePaths']}
references=[]
missing=[]
for name in sorted(selected):
    if not name.endswith('.rs') or name not in trees[head]:
        continue
    path=source/name
    raw=path.read_bytes()
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==trees[head][name]['oid'],name
    text=raw.decode()
    matches=re.findall(r'include_(?:bytes|str)!\(\s*"([^"]+)"',text)
    matches+=re.findall(r'#\[path\s*=\s*"([^"]+)"\]',text)
    for reference in matches:
        target=posixpath.normpath(str(PurePosixPath(name).parent/reference))
        if target not in trees[head]:
            missing.append({'from':name,'reference':reference,'resolved':target})
            continue
        if target not in selected and trees[base].get(target)!=trees[head][target]:
            references.append({'from':name,'path':target,'sourceOid':trees[head][target]['oid']})
record={'source':head,'base':base,'additionalChangedLiteralReferences':references,
        'nonliteralOrModuleResolutionReview':missing}
(coord/'portable-v2-395-shared-reference-audit-20261006-v1.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
