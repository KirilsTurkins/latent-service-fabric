from pathlib import Path
import hashlib,json,os,stat,subprocess,tarfile,time
src=Path('/root-checks/portable-v2-aggregate-version-compiler-preparation-20261008-v113/c-zig.tar.xz');raw=src.read_bytes();assert hashlib.sha256(raw).hexdigest()=='70e49664a74374b48b51e6f3fdfbf437f6395d42509050588bd49abe52ba3d00'
root=Path('/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data/jobs/portable-v2-c-zig-tools-20261008-v120');assert os.getuid()==10001 and not root.exists();root.mkdir(mode=0o700)
with tarfile.open(src,'r:xz') as z:
 members=z.getmembers();assert len(members)<32768 and sum(m.size for m in members)<1024**3
 for m in members:
  p=Path(m.name);assert not p.is_absolute() and '..' not in p.parts and (m.isdir() or m.isfile()),m.name
 z.extractall(root,filter='data')
paths=list(root.glob('*/zig'));assert len(paths)==1;p=paths[0];version=subprocess.check_output([str(p),'version'],timeout=30).decode().strip();assert version=='0.16.0'
receipt=dict(archiveSha256=hashlib.sha256(raw).hexdigest(),binarySha256=hashlib.sha256(p.read_bytes()).hexdigest(),version=version,logicalBytes=sum(m.size for m in members),members=len(members),path=str(p),notCurrentCompilationQualification=True)
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
