﻿from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');out=coord/'portable-v2-aggregate-version-compiler-preparation-20261008-v113';env=dict(os.environ,GODEBUG='http2client=0')
current=json.loads((coord/'integration-v12-union-review/pr823-f898-go-artifacts.json').read_bytes());old=json.loads((out/'retained-developer774-artifacts.raw.json').read_bytes())
selected=[next(a for a in current['artifacts'] if a['id']==11514296888)]+[next(a for a in old['artifacts'] if a['id']==i) for i in [11416504183,11416253331]]
for a in selected:
 path=out/('artifact-'+str(a['id'])+'.zip');assert not path.exists() and not a['expired'] and a['size_in_bytes']<1024**3
 with path.open('xb') as stream:
  process=subprocess.Popen(['gh','api',f"repos/KirilsTurkins/latent-service-fabric/actions/artifacts/{a['id']}/zip"],env=env,stdout=stream,stderr=subprocess.PIPE)
  deadline=time.monotonic()+600
  while process.poll() is None:
   if path.stat().st_size>a['size_in_bytes'] or time.monotonic()>=deadline:
    process.terminate();process.wait(timeout=10);raise RuntimeError('bounded-authenticated-artifact-download-refused')
   time.sleep(1)
  error=process.stderr.read();assert process.returncode==0,error.decode()[-300:]
 assert path.stat().st_size==a['size_in_bytes'] and 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()==a['digest']
 receipt=dict(at=datetime.now(timezone.utc).isoformat(),artifact=a,path=path.name,archiveSHA=a['digest'],byteMatched=True,notCurrent8850Qualification=True)
 (out/(path.stem+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(id=a['id'],bytes=a['size_in_bytes'],sha256=a['digest'],retainedToolsOnly=True)),flush=True)
