﻿from pathlib import Path
import json,subprocess,sys,hashlib
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');repo=Path(r'C:\Users\turkins\Desktop\lf-p4-http-deferred-admission-v96');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,timeout=30).decode().strip();assert head.startswith('c32c8ad9') and not subprocess.check_output(['git','status','--porcelain'],cwd=repo,timeout=30)
old='7a6b163e0b45b820efe3150215ef26b6672bf76e';moved_old='crates/latent-capabilities/src/broker/pools/tests/deferred/admission.rs';moved_new='crates/latent-capabilities/src/broker/pools/client/admission/deferred_tests.rs'
a=subprocess.check_output(['git','show',old+':'+moved_old],cwd=repo).decode();b=(repo/moved_new).read_text()
start=a.index('#[tokio::test]');assert a[start:]==b[b.index('#[tokio::test]'):], 'all seven case bodies must remain exact'
for path in ['crates/latent-capabilities/src/broker/pools/deferred.rs','crates/latent-http/src/network.rs']:
 assert subprocess.check_output(['git','show',old+':'+path],cwd=repo)==(repo/path).read_bytes()
oldcase='broker::pools::tests::deferred::admission::';newcase='broker::pools::client::admission::deferred_tests::'
cases=json.loads((repo/'tools/ci/suites.json').read_bytes());suite=next(row for row in cases['suites'] if row['id']=='latent-capabilities.lib.latent-capabilities');added=[n for n in suite['expectedCases'] if n.startswith(newcase)];assert len(added)==7 and suite['minimumCases']==167
proof=dict(head=head,parent=old,allSevenCaseBodiesByteIdentical=True,productionDeferredAndHttpPathsByteIdentical=True,onlyExistingRestrictDeadlineApiUsed=True,noPrivacyWidening=True,casePathMapping={n.replace(newcase,oldcase,1):n for n in added},expectedFullCaps167=True)
(coord/'portable-v2-http-fixture-scope-preservation-20261007-v105.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
steps=coord/'portable-v2-http-deferred-admission-source-steps-20261007-v102.json';raise SystemExit(subprocess.call([sys.executable,'-X','utf8','-B',str(coord/'portable-v2-reconstructed-native-controller-20261007-v93.py'),'portable-v2-http-fixture-scope-source-20261007-v105',head,str(steps),'source']))
