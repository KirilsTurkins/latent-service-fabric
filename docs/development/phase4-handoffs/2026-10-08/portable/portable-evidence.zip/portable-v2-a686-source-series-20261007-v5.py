import json
import pathlib
import subprocess
import sys

COORD = pathlib.Path(__file__).resolve().parent
STEP_FILE = COORD / 'portable-v2-a686-source-steps-20261007-v5.json'
steps = json.loads(STEP_FILE.read_bytes())
numbers = tuple(map(int, sys.argv[1:])) or (767, 780, 821, 796)
for number in numbers:
    record = json.loads((COORD / f'portable-v2-pr{number}-a686-reconcile-20261007-v4' / 'receipt.json').read_bytes())
    root = pathlib.Path(record['root'])
    for module in steps[0][6:]:
        assert (root / (module.replace('.', '/') + '.py')).is_file(), (number, module)
for number in numbers:
    record = json.loads((COORD / f'portable-v2-pr{number}-a686-reconcile-20261007-v4' / 'receipt.json').read_bytes())
    job = f'portable-v2-pr{number}-a686-source-linux-20261007-v5'
    print(json.dumps({'number': number, 'head': record['head'], 'job': job, 'status': 'starting'}), flush=True)
    result = subprocess.run([sys.executable, '-X', 'utf8', str(COORD / 'root-candidate-run-20261005-v2.py'), job, record['head'], str(STEP_FILE), 'source'], cwd=COORD)
    print(json.dumps({'number': number, 'exitCode': result.returncode, 'status': 'reaped'}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
