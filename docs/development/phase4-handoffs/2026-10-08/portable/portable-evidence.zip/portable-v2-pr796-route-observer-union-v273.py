from datetime import datetime,timezone
import ast
import hashlib
import json
from pathlib import Path
import subprocess

TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr796-21c-main-v272')
COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-pr796-route-observer-union-v273';OUT.mkdir()
PATH='tools/java_server_node.py'
MAIN='21cfd22148f849604cb6fc60247924de0012093c'
PARENT='cdb25931de74109140b5a4dd5597e8b138f56f2d'
def git(*args):return subprocess.check_output(['git','-C',str(TREE),*args])
stages={n:git('show',f':{n}:{PATH}') for n in (1,2,3)}
for n,raw in stages.items():(OUT/f'stage{n}.py').write_bytes(raw)
ours=stages[2].decode();theirs=stages[3].decode()
def node_source(text,name):
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name==name)
    return ast.get_source_segment(text,node)
recorded=node_source(ours,'RecordedRouteClient')
observed=node_source(theirs,'ObservedRouteClient')
assert recorded.count('super().call(')==1 and observed.count('super().call(')==1
combined=observed.replace('class ObservedRouteClient(RouteClient):','class ObservedRouteClient(RecordedRouteClient):',1)
combined=combined.replace('        super().__init__(*args, **kwargs)\n        self.evidence = evidence',
                          '        super().__init__(*args, evidence=evidence / "route-control", **kwargs)\n        self.rejection_evidence = evidence',1)
combined=combined.replace('write_json(self.evidence / "route-delete-rejection.json", summary)',
                          'write_json(self.rejection_evidence / "route-delete-rejection.json", summary)',1)
merged=ours.replace(recorded,recorded+'\n\n\n'+combined,1)
merged=merged.replace('route_cli = RecordedRouteClient(binary, client.config, root / "routes",\n                evidence=evidence / "route-control", deadline=client.deadline)',
                      'route_cli = ObservedRouteClient(binary, client.config, root / "routes",\n                evidence=evidence, deadline=client.deadline)',1)
assert ast.dump(next(n for n in ast.parse(merged).body if isinstance(n,ast.ClassDef) and n.name=='RecordedRouteClient'),include_attributes=False)==ast.dump(next(n for n in ast.parse(ours).body if isinstance(n,ast.ClassDef) and n.name=='RecordedRouteClient'),include_attributes=False)
compile(merged,PATH,'exec')
(TREE/PATH).write_text(merged,encoding='utf8')
git('add',PATH);assert not git('ls-files','-u');git('diff','--cached','--check')
git('commit','-m','merge bounded route evidence and rejected-delete diagnostics without repeating calls')
head=git('rev-parse','HEAD').decode().strip()
assert git('diff','--name-only',PARENT,head).decode().splitlines()==[PATH]
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=796,head=head,parent=PARENT,development=MAIN,tree=str(TREE),
           originalGenericRecorderBodyByteEquivalent=True,newRejectedDeleteSummaryBodyPreserved=True,
           oneActualUnderlyingCall=True,original1MiBResponse16MiBTotal512RecordAnd8KiBSummaryLimitsPreserved=True,
           noRawArgumentsOrMutationRetry=True,allRustApiSdkWitCargoMetadataAndTestsUnchanged=True,
           currentSourceAndObserverBehaviorTestsPending=True,noPublication=True)
(COORD/'portable-v2-pr796-21c-main-union-v272.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
