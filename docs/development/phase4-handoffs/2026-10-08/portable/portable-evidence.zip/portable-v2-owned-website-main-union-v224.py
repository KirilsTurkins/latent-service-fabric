from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import sys

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
MAIN='9f7aab58400d446f451964dc492b34dc46d09f14'
number,parent=sys.argv[1:]
assert number in {'790','800','791','787','796','784','825','811'} and len(parent)==40
TREE=Path(r'C:\Users\turkins\Desktop')/('lf-p4-pr'+number+'-website-main-v224')
assert not TREE.exists()
def git(*args,cwd=REPO):return subprocess.check_output(['git','-C',str(cwd),*args])
git('worktree','add','--no-checkout','-b','fix/phase4-pr'+number+'-website-main-v224',str(TREE),parent)
git('sparse-checkout','set','--no-cone','website/scripts/test-discovery.mjs',cwd=TREE)
git('checkout','fix/phase4-pr'+number+'-website-main-v224',cwd=TREE)
git('merge','--no-ff','-m','merge website discovery correction from development',MAIN,cwd=TREE)
head=git('rev-parse','HEAD',cwd=TREE).decode().strip()
assert not git('status','--porcelain',cwd=TREE)
paths=git('diff','--name-only',parent,head,cwd=TREE).decode().splitlines()
assert paths==['website/scripts/test-discovery.mjs']
assert git('show',head+':website/scripts/test-discovery.mjs',cwd=TREE)==git('show',MAIN+':website/scripts/test-discovery.mjs',cwd=TREE)
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=int(number),head=head,parent=parent,development=MAIN,tree=str(TREE),
           onlyChangedPath=paths[0],allOtherTrackedBytesIdentical=True,originalNativeReceiptHeadUnchanged=True,
           realBrowserDiscoveryStillPending=True,currentSourceQualificationPending=True,noPublication=True)
(COORD/('portable-v2-pr'+number+'-website-main-union-v224.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
