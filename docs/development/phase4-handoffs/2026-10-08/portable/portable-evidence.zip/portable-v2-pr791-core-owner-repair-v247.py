from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
PARENT='c2bac5e3015c2166c70825c91ece7833f701742b'
DONOR='8e0125db0bb21b3e456f5450fd64a24b0caee3d5'
PATH='crates/latent-core/src/budget/host_memory.rs'
TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr791-core-owner-v247')
def git(*args,cwd=REPO):return subprocess.check_output(['git','-C',str(cwd),*args])
old=git('show',PARENT+':'+PATH)
assert hashlib.sha256(old).hexdigest()=='d790df6cea7115f21e3f7281a77227403fe7769777933e5b18bcd928f0e3a1c3'
good=git('show',DONOR+':'+PATH)
assert hashlib.sha256(good).hexdigest()=='1b57f7000372cc0ad7e77a4c559c9a6e0f6c75963c4d1315163f214146e68790'
assert not TREE.exists()
git('worktree','add','--no-checkout','-b','fix/phase4-pr791-core-owner-v247',str(TREE),PARENT)
git('sparse-checkout','set','--no-cone',PATH,cwd=TREE)
git('checkout','fix/phase4-pr791-core-owner-v247',cwd=TREE)
(TREE/PATH).write_bytes(good)
git('add',PATH,cwd=TREE)
git('diff','--cached','--check',cwd=TREE)
git('commit','-m','fix(core): preserve physical host owner without double charging',cwd=TREE)
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=791,parent=PARENT,head=git('rev-parse','HEAD',cwd=TREE).decode().strip(),tree=str(TREE),
           onlyPath=PATH,oldByteExactActual825Failure=True,fixByteExactQualified790And825Candidate=True,
           noOtherSourceCasesLimitsOrIgnoresChanged=True,queuedGoPreparationFailureStillDistinctAndUnresolved=True,
           freshSourceAndCoreNativePending=True,noPublication=True)
(COORD/'portable-v2-pr791-core-owner-repair-prepared-v247.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
