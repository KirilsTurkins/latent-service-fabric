from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path,PurePosixPath
import tarfile

COORD=Path(__file__).resolve().parent
ARCHIVE=COORD/'root-private-npm-v4-preparation-20261007-v1/source/target/website-package-manager/npm-11.19.1-lsf-bundle-v4.tar'
EXPECTED='f05c6309efcb0713b56a9a31236547ecbb164195b43978c4db38488ccd743d6f'
assert ARCHIVE.stat().st_size==14315520 and hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()==EXPECTED
OUT=COORD/'portable-v2-private-npm-host-v241'
assert not OUT.exists()
OUT.mkdir()
files=[]
with tarfile.open(ARCHIVE) as tar:
    members=tar.getmembers()
    assert len(members)<=2500 and sum(m.size for m in members)<=32*1024**2
    for member in members:
        path=PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.name
        assert member.isfile() or member.isdir()
        target=OUT.joinpath(*path.parts)
        assert target.resolve().is_relative_to(OUT.resolve())
        if member.isdir():target.mkdir(parents=True,exist_ok=True)
        else:
            assert member.size<=4*1024**2
            data=tar.extractfile(member).read()
            assert len(data)==member.size
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data)
            files.append(dict(path=member.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert (OUT/'package/bin/npm-cli.js').is_file()
proof=dict(at=datetime.now(timezone.utc).isoformat(),archiveSha256=EXPECTED,currentMaintainedProfile='npm-11.19.1-lsf-bundle-v4',
           sourceReceipt=str(COORD/'root-private-npm-v4-preparation-20261007-v1/receipt.json'),
           files=files,fileCount=len(files),expandedBytes=sum(r['bytes'] for r in files),privateOnly=True,noGlobalPathOrInstallMutation=True,
           npmCli=str(OUT/'package/bin/npm-cli.js'),executionPending=True)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k!='files'},indent=2))
