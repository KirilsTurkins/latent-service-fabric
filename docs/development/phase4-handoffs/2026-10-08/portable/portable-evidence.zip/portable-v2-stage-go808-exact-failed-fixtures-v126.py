from pathlib import Path
import hashlib,json,os,stat,time,zipfile
coord=Path('/root-checks');manifest=json.loads((coord/'portable-v2-go808-exact-failed-fixture-manifest-v126.json').read_bytes());archive=coord/'portable-v2-completed-ci-refresh-20261008-v123/artifact-11516155976.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archiveSha256']
root=Path('/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data/jobs/portable-v2-go808-exact-failed-sdk-inputs-20261008-v126');assert os.getuid()==10001 and not root.exists();root.mkdir(mode=0o700);deadline=time.monotonic()+120
with zipfile.ZipFile(archive) as z:
 for row in manifest['rows']:
  assert time.monotonic()<deadline;p=Path(row['path']);assert not p.is_absolute() and '..' not in p.parts;info=z.getinfo(row['archivePath']);assert stat.S_IFMT(info.external_attr>>16)!=stat.S_IFLNK;raw=z.read(info);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];dest=root/p;dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700);dest.write_bytes(raw);dest.chmod(0o600)
receipt=dict(artifactId=manifest['artifactId'],archiveSha256=manifest['archiveSha256'],failedHostHead=manifest['failedHostHead'],uid=os.getuid(),privateDirectory=str(root),files=len(manifest['rows']),bytes=sum(r['bytes'] for r in manifest['rows']),allAuthenticatedBytesMatched=True,noCompilerExecution=True,qualification=False);(root/'stage-custody.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
