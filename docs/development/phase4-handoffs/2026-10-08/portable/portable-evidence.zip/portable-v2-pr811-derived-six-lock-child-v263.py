from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
OUT=COORD/'portable-v2-dotnet-lock-native-reproduction-20261008-v262'
receipt=json.loads((OUT/'receipt.json').read_bytes())
lock=(OUT/'protobuf.lock.json').read_bytes()
assert hashlib.sha256(lock).hexdigest()==receipt['newLockSha256'] and receipt['reproductionsIdentical'] and receipt['generatedSources']==10
PARENT='3a991d9922390edb3251c84aa8f926a717687d0b'
TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr811-dotnet-lock-v263')
def git(*args,cwd=REPO):return subprocess.check_output(['git','-C',str(cwd),*args])
assert not TREE.exists()
for path,digest in json.loads(lock)['inputs'].items():
    assert hashlib.sha256(git('show',PARENT+':api/proto/'+path).replace(b'\r\n',b'\n')).hexdigest()==digest
git('worktree','add','--no-checkout','-b','fix/phase4-pr811-dotnet-lock-v263',str(TREE),PARENT)
git('sparse-checkout','set','--no-cone','sdk/dotnet/protobuf.lock.json',cwd=TREE)
git('checkout','fix/phase4-pr811-dotnet-lock-v263',cwd=TREE)
(TREE/'sdk/dotnet/protobuf.lock.json').write_bytes(lock)
git('diff','--check',cwd=TREE)
git('add','sdk/dotnet/protobuf.lock.json',cwd=TREE)
git('commit','-m','fix(dotnet): retain source-matched six-protocol generation lock',cwd=TREE)
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=811,parent=PARENT,head=git('rev-parse','HEAD',cwd=TREE).decode().strip(),tree=str(TREE),
           onlyPath='sdk/dotnet/protobuf.lock.json',actualPinnedLinuxProtoc29TwoReproductions=True,
           sixSelectedInputsTenGeneratedSourcesPreserved=True,onlyNodeProtoAndNodeCsHashChanged=True,
           generatorReceiptSha256=hashlib.sha256((OUT/'receipt.json').read_bytes()).hexdigest(),fullLinuxSDKPending=True,freshSourcePending=True,noPublication=True)
(COORD/'portable-v2-pr811-derived-six-lock-child-v263.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
