"""Describe semantic parent differences without printing source commands or payloads."""
import json
from pathlib import Path
import subprocess
ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
OURS = "0a460cbaa9dcea330b00978b7b3557ab75e58b23"
THEIRS = "318eaa9aea5e0962515c7161d441ee270bcdeae4"
def read(revision, path):
    return json.loads(subprocess.check_output(["git", "show", revision + ":" + path], cwd=ROOT, timeout=60))
rows = {}
path = ".github/security/inventory.json"
a, b = read(OURS, path), read(THEIRS, path)
aa, bb = {row["path"]: row for row in a["manifests"]}, {row["path"]: row for row in b["manifests"]}
rows[path] = {"onlyOurs": sorted(set(aa) - set(bb)), "onlyIncoming": sorted(set(bb) - set(aa)),
              "differentRows": {key: {"oursFields": sorted(aa[key]), "incomingFields": sorted(bb[key])} for key in aa.keys() & bb.keys() if aa[key] != bb[key]},
              "topDifferences": [key for key in set(a) | set(b) if key != "manifests" and a.get(key) != b.get(key)]}
path = "tools/ci/suites.json"
a, b = read(OURS, path), read(THEIRS, path)
aa, bb = {row["id"]: row for row in a["suites"]}, {row["id"]: row for row in b["suites"]}
rows[path] = {"onlyOurs": sorted(set(aa) - set(bb)), "onlyIncoming": sorted(set(bb) - set(aa)),
              "differentRows": {key: [field for field in set(aa[key]) | set(bb[key]) if aa[key].get(field) != bb[key].get(field)] for key in aa.keys() & bb.keys() if aa[key] != bb[key]},
              "topDifferences": {key: ({"onlyOursKeys": sorted(set(a[key]) - set(b[key])), "onlyIncomingKeys": sorted(set(b[key]) - set(a[key])),
                                        "differentKeys": sorted(name for name in set(a[key]) & set(b[key]) if a[key][name] != b[key][name])} if isinstance(a.get(key), dict) and isinstance(b.get(key), dict) else "changed")
                                 for key in set(a) | set(b) if key != "suites" and a.get(key) != b.get(key)}}
print(json.dumps(rows), flush=True)
