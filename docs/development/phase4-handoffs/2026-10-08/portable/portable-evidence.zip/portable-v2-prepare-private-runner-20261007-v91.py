﻿from pathlib import Path
import hashlib,json,subprocess
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');repo=Path(r'C:\Users\turkins\Desktop\latent-fabric')
out=coord/'portable-v2-private-runner-reconstruction-20261007-v91';assert not out.exists();out.mkdir()
original=coord/'root-native-rebuild-20261005-v1/Dockerfile';docker=original.read_bytes();(out/'Dockerfile').write_bytes(docker)
heads=['139e4a3aa4a9f2f749f7c2e33e055810cada6f10','8785fadf4d630cce34fbcbfebf65d0fbb0851d1c','76d8a7a7852c7ebcd646c7ca787412df4c495d4d',subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,timeout=30).decode().strip()]
objects=set(heads)
for head in heads:
 inventory=subprocess.check_output(['git','ls-tree','-r','-t',head],cwd=repo,timeout=120);(out/(head+'.inventory')).write_bytes(inventory)
 for row in inventory.splitlines():
  metadata,path=row.split(b'\t',1);mode,kind,oid=metadata.split();assert kind in [b'tree',b'blob'];objects.add(oid.decode())
contents=('\n'.join(sorted(objects))+'\n').encode();(out/'objects.txt').write_bytes(contents)
pack=out/'source-trees.pack'
with pack.open('xb') as stream:
 process=subprocess.run(['git','pack-objects','--stdout'],cwd=repo,input=contents,stdout=stream,stderr=subprocess.PIPE,timeout=900)
(out/'pack.stderr.log').write_bytes(process.stderr);assert process.returncode==0
assert pack.stat().st_size<512*1024**2
registry=Path(r'C:\Users\turkins\.cargo\registry');inputs=[]
for selected in ['cache','index']:
 for file in sorted((registry/selected).rglob('*')):
  if not file.is_file():continue
  assert not file.is_symlink();data=file.read_bytes();inputs.append(dict(path=file.relative_to(registry).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert len(inputs)<4096 and sum(item['bytes'] for item in inputs)<1024**3
result=dict(preparedOnly=True,dockerLaunched=False,oldVolumeGone=True,oldReceiptsRetained=True,owner='/root',container='latent-p4-root-native-20261007-v6',volume='latent-p4-root-native-20261007-v6',base='/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data',head=heads[0],heads=heads,objectCount=len(objects),packBytes=pack.stat().st_size,packSha256=hashlib.sha256(pack.read_bytes()).hexdigest(),dockerfileSha256=hashlib.sha256(docker).hexdigest(),originalDockerfileByteIdentical=True,registryFiles=len(inputs),registryBytes=sum(item['bytes'] for item in inputs),registryInputs=inputs,caps=dict(uid=10001,gid=10001,cpu=2,memoryBytes=8*1024**3,pids=512),qualification=False)
(out/'plan.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='registryInputs'}))
