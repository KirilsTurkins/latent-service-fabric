"""Reuse Root's bounded controller for three separate, source-paired guest phases."""
import json, subprocess, sys
from pathlib import Path

coord = Path(__file__).resolve().parent
head = 'bef72bfe145c03bf3bdd9c2cd2578ee55dd7f1a3'
phase = sys.argv[1]
assert phase in {'compile', 'build', 'execute'}
owner = 'latent-p4-root-native-20261004-v1'
base = '/var/lib/docker/volumes/' + owner + '/_data'
compiler_job = 'portable-v2-pr790-completion-denial-rust-compiler-20261007-v48'
guest_root = base + '/jobs/' + compiler_job + '/transaction-guests-rust'
tools = json.loads((coord / 'root-private-guest-tools-20261006-v12/receipt.json').read_bytes())
assert tools['authenticated'] and all(row['version'].split()[:2] in [['wasm-tools','1.254.0'], ['wit-bindgen-cli','0.62.0']] for row in tools['tools'])
if phase == 'compile':
    job, seconds = compiler_job, 1900
    steps = [['python3', 'tools/compile_transaction_guests.py', '--language', 'rust', '--output', guest_root]]
else:
    compiler_receipt = json.loads((coord / compiler_job / 'receipt.json').read_bytes())
    assert compiler_receipt['passed'] and compiler_receipt['head'] == head and compiler_receipt['sourceClean'] and compiler_receipt['originalProcessReaped']
    if phase == 'execute':
        build_receipt = json.loads((coord / 'portable-v2-pr790-completion-denial-guest-build-20261007-v48/receipt.json').read_bytes())
        assert build_receipt['passed'] and build_receipt['head'] == head and build_receipt['sourceClean'] and build_receipt['originalProcessReaped']
    job = 'portable-v2-pr790-completion-denial-guest-' + phase + '-20261007-v48'
    seconds = 1800 if phase == 'build' else 900
    steps = [['cargo', '+1.97.1', '--config', '.cargo/managed-guest.toml', 'test', '--locked', '-p', 'latent-wire', '--lib', 'phase4::local_transaction::tests::']]
    steps[0] += ['--no-run'] if phase == 'build' else ['--','--ignored','--test-threads=1','--nocapture']
step_file = coord / (job + '-steps.json')
assert not step_file.exists()
step_file.write_text(json.dumps(steps, indent=2) + '\n', encoding='utf8')
template = (coord / 'portable-v2-isolated-native-controller-20261007-v33.py').read_text(encoding='utf8')
old_check = '''assert all(row[:2] == ["cargo", "+1.97.1"] for row in steps) if mode == "native" else all(row[0] == "python3" for row in steps)'''
assert template.count(old_check) == 1
template = template.replace(old_check, 'assert steps == ' + repr(steps))
assert template.count('deadlineSeconds=1800') == 1
template = template.replace('deadlineSeconds=1800', 'deadlineSeconds=' + str(seconds))
inject = '''
env['PATH'] = ''' + repr(tools['privatePath']) + ''' + os.pathsep + env['PATH']
env['LSF_TRANSACTION_GUEST_ROOT'] = ''' + repr(guest_root) + '''
env['LATENT_STATE_TEST_ROOT'] = ''' + repr(base + '/jobs/' + job + '/physical-store-evidence') + '''
Path(env['LATENT_STATE_TEST_ROOT']).mkdir(mode=0o700,exist_ok=True)
tool_materials = ''' + repr(tools['tools']) + '''
for material in tool_materials:
    assert hashlib.sha256(Path(material['path']).read_bytes()).hexdigest() == material['binarySha256']
'''
marker = "env.pop('RUSTUP_TOOLCHAIN', None)"
assert template.count(marker) == 1
template = template.replace(marker, marker + '\n' + inject)
if phase == 'compile':
    marker = "['du', '-sk', str(target)]"
    assert template.count(marker) == 1
    template = template.replace(marker, "['du', '-sk', str(out)]")
else:
    marker = "receipt = dict(at=datetime.now(timezone.utc).isoformat(), head=head, tree=tree,"
    check = "\nfor material in tool_materials:\n    assert hashlib.sha256(Path(material['path']).read_bytes()).hexdigest() == material['binarySha256']\n"
    assert template.count(marker) == 1
    template = template.replace(marker, check + marker)
sys.argv = ['portable-v2-isolated-native-controller-20261007-v33.py', job, head, str(step_file), 'native']
exec(compile(template, '<root-transaction387-' + phase + '>', 'exec'), {'__file__': str(coord / 'portable-v2-isolated-native-controller-20261007-v33.py'), '__name__': '__main__'})
