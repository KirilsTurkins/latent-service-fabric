import concurrent.futures
import json
import pathlib
import subprocess
import sys

COORD = pathlib.Path(__file__).resolve().parent

def check(number):
    directory = COORD / f'portable-v2-pr{number}-a686-reconcile-20261007-v4'
    record = json.loads((directory / 'receipt.json').read_bytes())
    root = pathlib.Path(record['root'])
    with (directory / 'fmt.log').open('wb') as log:
        fmt = subprocess.run(['cargo', '+1.97.1', 'fmt', '--all', '--', '--check'], cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    metadata = subprocess.run(['cargo', '+1.97.1', 'metadata', '--locked', '--offline', '--no-deps', '--format-version', '1'], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    (directory / 'metadata.json').write_bytes(metadata.stdout)
    (directory / 'metadata.stderr').write_bytes(metadata.stderr)
    assert fmt.returncode == metadata.returncode == 0, number
    parsed = json.loads(metadata.stdout)
    result = {'number': number, 'head': record['head'], 'fmtPassed': True, 'lockedOfflineMetadataPassed': True, 'workspacePackages': len(parsed['packages']), 'nativeExecuted': False}
    (directory / 'host-gates.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result

if __name__ == '__main__':
    numbers = tuple(map(int, sys.argv[1:])) or (767, 780, 821, 796)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for result in pool.map(check, numbers):
            print(json.dumps(result), flush=True)
