import json
from pathlib import Path
import re

COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-pr828-go-upstream-custody-v229'
raw=(OUT/'go-capsule-authoring__logs__04-sdk-runtime-tests.stdout.txt').read_text(encoding='utf8')
outcomes=re.findall(r'outcome:\s*(Success|GuestTrap|PlatformFailure|Cancelled|DeadlineExceeded|TimedOut|Unavailable)',raw)
codes=re.findall(r'code:\s*(ResourceExhausted|PermissionDenied|InvalidArgument|Unavailable|DeadlineExceeded|Internal)',raw)
consumptions=re.findall(r'Consumption\s*\{([^}]+)\}',raw)
clean=[]
for text in consumptions:
    allowed=dict(re.findall(r'\b(cpu_fuel|memory_bytes|child_calls|wall_time_micros|host_calls|fuel|memory_peak_bytes):\s*(\d+)',text))
    clean.append({key:int(value) for key,value in allowed.items()})
failure_record=re.findall(r'(StageChildFailure|StartChildFailure|ChildFailure|Unclassified|Queued|Materializing|Running)',raw)
result=dict(originalHead='6f0a8e82299aa0a1224dee293aaa8a4db7f3a7d9',language='go',lane='authoring',case=0,
            serviceElapsedMs=7.455464,expectedResult='42',observedResult='14',suitePassed=9,suiteFailed=1,
            outcomes=outcomes,codes=codes,closedConsumptions=clean,closedFailurePhases=sorted(set(failure_record)),
            noCauseInferred=True,retainedFullLogs=True)
(OUT/'closed-outcome.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
