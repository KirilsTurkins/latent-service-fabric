from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
proof=[]
for number in (790,800,791,787,796,784,825,811):
    source=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-union-v238/receipt.json')).read_bytes())
    head=source['head']
    metadata=json.loads(subprocess.check_output(['git','-C',str(REPO),'show',head+':tools/ci/suites.json']))
    rows={row['id']:row for row in metadata['suites']}
    assert rows['latent-wasmtime.test.aot-sandbox']['minimumCases']==1
    for row in rows.values():
        if 'expectedCases' in row and row['mode']=='libtest':assert len(row['expectedCases'])==row['minimumCases'],row['id']
    cargo=['cargo','+1.97.1'];flags=['--all-features','--locked','--offline']
    steps=[
        cargo+['test','-p','latent-signing','--lib',*flags,'--','--list'],
        cargo+['test','-p','latent-signing','--lib',*flags,'--','--nocapture'],
        cargo+['check','-p','latent-node','--all-targets',*flags],
        cargo+['test','-p','latent-node','--lib',*flags,'--','--list'],
        cargo+['test','-p','latent-node','--lib',*flags,'--','--nocapture'],
        cargo+['test','-p','latent-node','--test','activation_lifecycle',*flags,'--','--nocapture'],
        cargo+['test','-p','latent-wasmtime','--test','aot_sandbox',*flags],
        cargo+['clippy','-p','latent-signing','-p','latent-node','--all-targets',*flags],
    ]
    if number==790:
        steps.extend(json.loads((COORD/'portable-v2-pr790-binding-native-steps-v212.json').read_bytes()))
    steps.append(cargo+['clippy','-p','latent','-p','latentd','-p','latent-testkit','-p','latent-admission','--all-targets',*flags,'--no-deps','--','-D','warnings'])
    path=COORD/('portable-v2-pr'+str(number)+'-signing-main-native-steps-v240.json')
    path.write_text(json.dumps(steps,indent=2)+'\n',encoding='utf8')
    result=dict(pr=number,head=head,steps=str(path),stepsSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                signingExpectedCases=rows['latent-signing.lib.latent-signing']['expectedCases'],
                signingFloor=rows['latent-signing.lib.latent-signing']['minimumCases'],nodeFloor=rows['latent-node.lib.latent-node']['minimumCases'],
                activationFloor=rows['latent-node.test.activation-lifecycle']['minimumCases'],allHistoricalAOTControlsPreserved=True,
                actualAOTCustom12ProbeMarkerRequired=True,completeCIPending=True,nativePending=True)
    proof.append(result)
(COORD/'portable-v2-signing-main-native-recipes-v240.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps([{k:r[k] for k in ('pr','head','signingFloor','nodeFloor','activationFloor')} for r in proof],indent=2))
