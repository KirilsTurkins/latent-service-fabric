from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-current828-control-failure-artifact-v295';OUT.mkdir(exist_ok=True)
ENV=dict(os.environ,GODEBUG='http2client=0')
REPO='KirilsTurkins/latent-service-fabric';ID=11529647896
def api(path):return subprocess.check_output(['gh','api',path],env=ENV,timeout=180)
metadata_raw=api(f'repos/{REPO}/actions/artifacts/{ID}');metadata=json.loads(metadata_raw)
assert metadata['id']==ID and metadata['size_in_bytes']==61123837 and not metadata['expired']
raw=api(f'repos/{REPO}/actions/artifacts/{ID}/zip')
assert len(raw)==metadata['size_in_bytes'] and hashlib.sha256(raw).hexdigest()==metadata['digest'].split(':')[1]
(OUT/'artifact.json').write_bytes(metadata_raw);archive=OUT/'artifact.zip';archive.write_bytes(raw)
selected=[];manifest=[];closed=[]
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        if info.is_dir():continue
        manifest.append(dict(path=info.filename,bytes=info.file_size))
        wanted=('authoring-control-29' in info.filename or 'sdk-runtime-tests' in info.filename or
                info.filename.endswith(('report.json','node.stderr.txt','node.stdout.txt','control-journal.json','journal.json')))
        if wanted and info.file_size<=4*1024**2:
            data=z.read(info);name=info.filename.replace('/','__');(OUT/name).write_bytes(data)
            item=dict(path=info.filename,bytes=len(data),sha256=hashlib.sha256(data).hexdigest());selected.append(item)
            if 'sdk-runtime-tests' in info.filename and info.filename.endswith('.stdout.txt'):
                text=data.decode('utf8',errors='replace')
                closed.append(dict(path=info.filename,results=[s[:300] for s in text.splitlines() if s.startswith('test result:')]))
            if 'authoring-control-29' in info.filename:
                try:value=json.loads(data)
                except (ValueError,UnicodeError):continue
                safe={k:value.get(k) for k in ('category','outcomeKnown','requestDispatched')}
                error=value.get('error')
                if isinstance(error,dict):safe['errorCode']=error.get('code')
                payload=value.get('data')
                if isinstance(payload,dict):
                    safe['dataKeys']=list(payload)
                    if isinstance(payload.get('declaredError'),dict):safe['declaredErrorCode']=payload['declaredError'].get('code')
                    if isinstance(payload.get('platformFailure'),dict):safe['platformFailureCode']=payload['platformFailure'].get('code')
                closed.append(dict(path=info.filename,closedResult=safe))
    assert sum(row['bytes'] for row in selected)<=16*1024**2
proof=dict(at=datetime.now(timezone.utc).isoformat(),head='912701092b03c97d6ce92e5bbac8a9f9a2f5fc68',artifact=ID,
           archiveBytes=len(raw),archiveSha256=hashlib.sha256(raw).hexdigest(),selected=selected,closed=closed,
           boundedOnlyRelevantControlSdkNodeLogsExtracted=True,noProductCauseInferred=True)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
(OUT/'members.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k!='selected'},indent=2))
