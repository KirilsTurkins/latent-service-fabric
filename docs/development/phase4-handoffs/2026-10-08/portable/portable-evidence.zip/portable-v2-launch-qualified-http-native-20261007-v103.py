﻿from pathlib import Path
import hashlib,json,subprocess,sys,shutil
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');repo=Path(r'C:\Users\turkins\Desktop\lf-p4-http-deferred-admission-v96');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,timeout=30).decode().strip()
p=coord/'portable-v2-http-deferred-admission-source-20261007-v102/receipt.json';r=json.loads(p.read_bytes())
assert r['head']==head and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped'] and len(r['steps'])==7
for row in r['steps']:
 data=(p.parent/row['log']).read_bytes();assert row['exitCode']==0 and row['originalProcessReaped'] and len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print((p.parent/'step-1.log').read_text(),flush=True)
stepfile=coord/'portable-v2-http-deferred-admission-native-steps-20261007-v100.json';assert hashlib.sha256(stepfile.read_bytes()).hexdigest()=='9ac4aad68c0a29fed541a9498c8e6a1e02964e9d1f9c0881f1f2620fbc08b3b7'
assert shutil.disk_usage(coord).free>24*1024**3
preflight=dict(head=head,sourceReceiptSha256=hashlib.sha256(p.read_bytes()).hexdigest(),allSevenLogHashesVerified=True,freeHostBytes=shutil.disk_usage(coord).free,sourceCases=187,fullCapsExpected167=True,fullHttpExpected59=True,fullControlStoreExpected251=True)
(coord/'portable-v2-http-admission-native-preflight-20261007-v103.json').write_text(json.dumps(preflight,indent=2)+'\n');print(json.dumps(preflight),flush=True)
raise SystemExit(subprocess.call([sys.executable,'-X','utf8','-B',str(coord/'portable-v2-reconstructed-native-controller-20261007-v93.py'),'portable-v2-http-deferred-admission-native-20261007-v103',head,str(stepfile),'native']))
