from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

root = Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out = Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
sys.path.insert(0, str(root))
from tools import ci_contracts as c
models = c.observed_workflows(root)
expectations = c.python_expectations(root)
names = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=root, text=True).splitlines()
assert all(name.startswith('tools/ci/contracts/') for name in names), names
records = []
for name in names:
    physical = [json.loads((out / label / name).read_bytes()) for label in ('ours', 'incoming')]
    ours, incoming = [c.semantic_record(value) for value in physical]
    assert ours['kind'] == incoming['kind']
    chosen = copy.deepcopy(ours)
    review = {'path': name, 'kind': ours['kind']}
    if ours['kind'] == 'owner':
        assert {k:v for k,v in ours.items() if k not in ('sha256', 'reviewReason')} == {k:v for k,v in incoming.items() if k not in ('sha256', 'reviewReason')}
        digest = hashlib.sha256((root / ours['path']).read_bytes()).hexdigest()
        matches = [value for value in (ours, incoming) if value['sha256'] == digest]
        assert matches, (name, 'unreviewed-source-digest')
        chosen['sha256'] = matches[0]['sha256']
        review['sourceMatchesExistingParent'] = 'ours' if ours['sha256'] == digest else 'incoming'
    elif ours['kind'] == 'python':
        assert ours['module'] == incoming['module']
        actual = expectations[ours['module']]
        union = sorted(set(ours['cases']) | set(incoming['cases']))
        assert actual['cases'] == union, (name, 'case-union')
        for parent in (ours, incoming):
            for case, guard in parent['guards'].items():
                if guard == actual['guards'][case]:
                    continue
                assert name.endswith('/test_node_security_profile_schema.py.json'), (name, case)
                for field in c.GUARD_FIELDS - {'fixtureGuards'}:
                    assert guard[field] == actual['guards'][case][field], (name, case, field)
                old = [value for value in guard['fixtureGuards'] if ':setup-sha256:' not in value]
                new = [value for value in actual['guards'][case]['fixtureGuards'] if ':setup-sha256:' not in value]
                assert old == new
                assert actual['guards'][case] == ours['guards'][case]
        chosen.update(actual)
        review['allParentCaseAndSkipDecoratorGuardsRetained'] = True
    elif ours['kind'] == 'job':
        assert ours['workflow'] == incoming['workflow'] and ours['jobId'] == incoming['jobId']
        for field in ('baselineRevision', 'before', 'coverage'):
            assert ours[field] == incoming[field]
        actual = models[ours['workflow']]['jobs'][ours['jobId']]
        for parent in (ours, incoming):
            assert {k:v for k,v in parent['definition'].items() if k != 'steps'} == {k:v for k,v in actual.items() if k != 'steps'}, (name, 'job-policy')
            for step in parent['definition']['steps']:
                if step in actual['steps']:
                    continue
                candidates = [value for value in actual['steps'] if value.get('name') == step.get('name')]
                assert len(candidates) == 1, (name, step.get('name'))
                new = candidates[0]
                if step.get('uses') == 'actions/upload-artifact':
                    assert {k:v for k,v in step.items() if k != 'with'} == {k:v for k,v in new.items() if k != 'with'}
                    assert {k:v for k,v in step['with'].items() if k != 'path'} == {k:v for k,v in new['with'].items() if k != 'path'}
                    assert set(step['with']['path'].splitlines()) <= set(new['with']['path'].splitlines())
                else:
                    assert name.endswith('/ci.yml/jobs/fast.json') and step.get('name') == 'Qualify the genuinely narrow reverse-dependent fixture'
                    assert {k:v for k,v in step.items() if k != 'run'} == {k:v for k,v in new.items() if k != 'run'}
                    for required in ("state.profile == 'full'", "selection.profile == 'full'", 'assert selection.fast_packages', "set(selection.fast_packages) < set(registry.load()['fastPackages'])", 'tools/ci_fast.py --packages-json', "classify_paths(['crates/latent-workflows/src/lib.rs'])"):
                        assert required in new['run']
                    assert new == next(value for value in incoming['definition']['steps'] if value.get('name') == step['name'])
        chosen['definition'] = actual
        review['allParentCommandsArtifactsConditionsDeadlinesRetained'] = True
    elif ours['kind'] == 'workflow':
        assert ours['workflow'] == incoming['workflow']
        actual = models[ours['workflow']]
        policy = {k:v for k,v in actual.items() if k != 'jobs'}
        for parent in (ours, incoming):
            assert set(parent['requiredJobs']) <= set(actual['jobs'])
            assert {k:v for k,v in parent['policy'].items() if k != 'on'} == {k:v for k,v in policy.items() if k != 'on'}
            assert set(parent['policy']['on']) == set(policy['on'])
            for event, old in parent['policy']['on'].items():
                new = policy['on'][event]
                if isinstance(old, dict) and 'paths' in old:
                    assert {k:v for k,v in old.items() if k != 'paths'} == {k:v for k,v in new.items() if k != 'paths'}
                    assert set(old['paths']) <= set(new['paths'])
                else:
                    assert old == new
        chosen.update(policy=policy, requiredJobs=sorted(actual['jobs']))
        review['additivePathTriggersAndUnchangedPermissionsConcurrency'] = True
    else:
        raise AssertionError(name)
    chosen['reviewReason'] = (ours['reviewReason'] + ' Retain integrated HTTP parent obligation: ' + incoming['reviewReason']
        + ' Reviewed #402 union with immutable #828: preserve activation-v5 and stream resources, explicit transaction recovery/dispatch host operations, both clock/dependency test sets, exact typed denial after staging, all existing cases, skip/decorator guards, historical command mappings and unchanged deadline bounds. The installed state runtime makes the workflow dependency closure full; its selected fast subset remains nonempty and strictly narrower than the host-only registry.')
    if physical[0]['schemaVersion'] == c.PYTHON_STORAGE_SCHEMA:
        chosen = c.shared_python_record(chosen)
    raw = (out / 'ours' / name).read_bytes()
    compact = b'\n' not in raw.rstrip()
    encoded = json.dumps(chosen, ensure_ascii=False, separators=(',', ':') if compact else None, indent=None if compact else 2) + '\n'
    assert c.semantic_record(json.loads(encoded)) == c.semantic_record(chosen)
    (root / name).write_bytes(encoded.encode())
    records.append(review)
subprocess.run(['git', 'add', '--', *names], cwd=root, check=True)
assert not subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=root).strip()
(out / 'contract-resolution-v2.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'resolvedContracts': len(records), 'allParentCases': True, 'noDeadlineOrSkipRelaxation': True}))
