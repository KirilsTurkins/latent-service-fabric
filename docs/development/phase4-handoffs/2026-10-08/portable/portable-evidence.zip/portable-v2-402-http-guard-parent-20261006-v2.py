from pathlib import Path
import json
import subprocess
import sys

root=Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
sys.path.insert(0,str(root))
from tools import ci_contracts as c
actual=c.python_expectations(root)
for module in ('test_build_angular_package.py', 'test_guest_resources.py'):
    source='tools/tests/'+module
    name='tools/ci/contracts/python/'+module+'.json'
    for parent in ('HEAD','ad537698c0178ab4325ebe4f32857d4f94d00dca'):
        record=c.semantic_record(json.loads(subprocess.check_output(['git','show',parent+':'+name],cwd=root)))
        print(json.dumps({'module':module,'parent':parent,'sourceMatches':subprocess.check_output(['git','show',parent+':'+source],cwd=root)==(root/source).read_bytes(),'recordMatches':record['guards']==actual[source]['guards'],'guard':next(iter(record['guards'].values()))['fixtureGuards']}))
