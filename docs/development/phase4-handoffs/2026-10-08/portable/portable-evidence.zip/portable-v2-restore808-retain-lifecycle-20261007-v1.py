import importlib.util
import pathlib

COORD = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('audit', COORD / 'portable-v2-restore808-parent-audit-20261007-v1.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
rel = 'crates/latent-state/src/protected_store/tests/lifecycle.rs'
name = 'detached_view_response_witness_waits_for_actual_native_retirement_after_close'
new_name = name + '_retaining_owner'
original = audit.git('show', f"{audit.PARENTS['qualified']}:{rel}").decode()
ts = audit.tokens(original)
for i in range(len(ts)-5):
    if [v[0] for v in ts[i:i+4]] != ['#', '[', 'test', ']']:
        continue
    j = i + 4
    while ts[j][0] != 'fn':
        j += 1
    if ts[j+1][0] != name:
        continue
    while ts[j][0] != '{':
        j += 1
    depth = 1
    j += 1
    while depth:
        depth += (ts[j][0] == '{') - (ts[j][0] == '}')
        j += 1
    case = original[ts[i][1]:ts[j-1][2]]
    break
else:
    raise AssertionError(name)
path = audit.ROOT / rel
text = path.read_bytes().decode().replace('\r\n', '\n')
assert text.count('fn ' + name + '(') == 1 and new_name not in text
text = text.replace('fn ' + name + '(', 'fn ' + new_name + '(', 1)
path.write_bytes((text.rstrip() + '\n\n' + case + '\n').encode())
print('Retained both late opened-view witness and early retaining-owner schedules separately.')
