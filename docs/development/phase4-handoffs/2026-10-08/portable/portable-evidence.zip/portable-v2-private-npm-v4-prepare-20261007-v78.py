from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,shutil,subprocess
COORD=Path(__file__).resolve().parent
OWNER="latent-p4-root-native-20261004-v1"
BASE="/var/lib/docker/volumes/"+OWNER+"/_data"
JOB="portable-v2-private-npm-v4-20261007-v78"
EXPECTED="f05c6309efcb0713b56a9a31236547ecbb164195b43978c4db38488ccd743d6f"
REL="root-private-npm-v4-preparation-20261007-v1/source/target/website-package-manager/npm-11.19.1-lsf-bundle-v4.tar"
source=COORD/REL
assert source.stat().st_size==14315520 and hashlib.sha256(source.read_bytes()).hexdigest()==EXPECTED
assert shutil.disk_usage(COORD).free>2*1024**3+64*1024**2
body=r"""from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
import hashlib,json,os,subprocess,tarfile
base=Path(BASE_VALUE);out=base/'jobs'/JOB_VALUE
archive=Path('/root-checks')/REL_VALUE
assert os.getuid()==10001 and os.getgid()==10001 and not out.exists()
assert archive.stat().st_size==14315520 and hashlib.sha256(archive.read_bytes()).hexdigest()==EXPECTED_VALUE
node=base/'jobs/portable-v2-private-ci-tools-node-20261007-v58/node/node-v24.19.0-linux-x64/bin/node'
assert hashlib.sha256(node.read_bytes()).hexdigest()=='bc17c508ffeed0ec622934f9b7fa72f8e78da65350e63c3eceb56fa688aa5e12'
with tarfile.open(archive,'r:') as tar:
 members=tar.getmembers()
 assert len(members)==2015 and all(m.isfile() for m in members)
 assert sum(m.size for m in members)==12723814 and sum(m.size for m in members)<32*1024**2
 for m in members:
  name=PurePosixPath(m.name)
  assert not name.is_absolute() and '..' not in name.parts and name.parts[0]=='package'
 out.mkdir(mode=0o700)
 extracted=out/'npm';extracted.mkdir(mode=0o700)
 tar.extractall(extracted,filter='data')
files=[]
for file in sorted(extracted.rglob('*')):
 if file.is_file():
  assert not file.is_symlink()
  raw=file.read_bytes();files.append(dict(path=file.relative_to(extracted).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
assert len(files)==2015 and sum(r['bytes'] for r in files)==12723814
cli=extracted/'package/bin/npm-cli.js'
cli_before=hashlib.sha256(cli.read_bytes()).hexdigest()
r=subprocess.run([str(node),str(cli),'--version'],cwd=out,capture_output=True,text=True,timeout=30)
assert r.returncode==0 and r.stdout.strip()=='11.19.1',(r.returncode,r.stdout,r.stderr)
assert hashlib.sha256(cli.read_bytes()).hexdigest()==cli_before
receipt=dict(at=datetime.now(timezone.utc).isoformat(),profile='npm-11.19.1-lsf-bundle-v4',sourceArchiveSha256=EXPECTED_VALUE,nodeSha256='bc17c508ffeed0ec622934f9b7fa72f8e78da65350e63c3eceb56fa688aa5e12',node=str(node),cli=str(cli),cliSha256=cli_before,actualVersion=r.stdout.strip(),files=files,bytes=12723814,readOnlySourceInput=True,sourceTreeModified=False,completeCI=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(profile=receipt['profile'],version=receipt['actualVersion'],cli=str(cli),files=len(files),bytes=receipt['bytes'],receipt=str(out/'receipt.json'))))
""".replace('BASE_VALUE',repr(BASE)).replace('JOB_VALUE',repr(JOB)).replace('REL_VALUE',repr(REL)).replace('EXPECTED_VALUE',repr(EXPECTED))
container=json.loads(subprocess.check_output(['docker','inspect',OWNER],timeout=30))[0]
assert container['State']['Running'] and container['Config']['Labels']['latent.owner']=='/root'
out=COORD/JOB;assert not out.exists();out.mkdir()
(out/'input.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),archive=REL,sha256=EXPECTED,maximumExtractedBytes=32*1024**2,maximumEntries=2015,freeHostBytes=shutil.disk_usage(COORD).free,completeCI=False),indent=2)+'\n')
(out/'runner.py').write_text(body)
r=subprocess.run(['docker','exec','-i','--user','10001:10001',OWNER,'python3'],input=body.encode(),capture_output=True,timeout=180)
(out/'output.log').write_bytes(r.stdout+r.stderr)
assert r.returncode==0,r.stderr.decode(errors='replace')
subprocess.run(['docker','cp',OWNER+':'+BASE+'/jobs/'+JOB+'/receipt.json',str(out/'receipt.json')],timeout=30,check=True,capture_output=True)
raw=(out/'receipt.json').read_bytes();receipt=json.loads(raw)
assert receipt['profile']=='npm-11.19.1-lsf-bundle-v4' and receipt['actualVersion']=='11.19.1' and len(receipt['files'])==2015
(out/'host-custody.json').write_text(json.dumps(dict(receiptSHA=hashlib.sha256(raw).hexdigest(),actualVersion=receipt['actualVersion'],files=len(receipt['files']),freeHostBytes=shutil.disk_usage(COORD).free,completeCI=False),indent=2)+'\n')
print(r.stdout.decode())
