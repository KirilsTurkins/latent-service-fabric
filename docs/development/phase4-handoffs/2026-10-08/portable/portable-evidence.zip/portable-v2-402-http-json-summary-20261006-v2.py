from pathlib import Path
import json
import subprocess
import sys

root = Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out = Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
sys.path.insert(0, str(root))
from tools import ci_contracts as c
def diffs(a, b, path=''):
    if a == b:
        return []
    if isinstance(a, dict) and isinstance(b, dict):
        result = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                result.append({'key': path + '/' + key, 'only': 'incoming' if key not in a else 'ours'})
            else:
                result.extend(diffs(a[key], b[key], path + '/' + key))
        return result
    if isinstance(a, list) and isinstance(b, list):
        return [{'key': path, 'oursLength': len(a), 'incomingLength': len(b), 'onlyOurs': [x for x in a if x not in b][:5], 'onlyIncoming': [x for x in b if x not in a][:5]}]
    return [{'key': path, 'ours': a, 'incoming': b}]

names = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=root, text=True).splitlines()
for name in names:
    parents = [json.loads((out / label / name).read_bytes()) for label in ('ours', 'incoming')]
    if name.startswith('tools/ci/contracts/'):
        parents = [c.semantic_record(value) for value in parents]
        changes = sorted(key for key in set(parents[0]) | set(parents[1]) if parents[0].get(key) != parents[1].get(key))
        record = {'path': name, 'different': changes}
        if parents[0].get('kind') == 'python' or '/python/' in name:
            cases = [value['cases'] for value in parents]
            record['caseCounts'] = [len(value) for value in cases]
            record['caseNamesOnly'] = [sorted(set(values) - set(cases[1-index])) for index, values in enumerate(cases)]
            record['commonCaseDiffs'] = [diffs(parents[0]['guards'][case], parents[1]['guards'][case], case) for case in sorted(set(cases[0]) & set(cases[1])) if parents[0]['guards'][case] != parents[1]['guards'][case]]
        print(json.dumps(record))
    elif name in ('.github/security/inventory.json', 'tools/ci/suites.json', 'api/proto/phase1-descriptor-contract.json'):
        key = {'tools/ci/suites.json': 'suites', '.github/security/inventory.json': 'manifests', 'api/proto/phase1-descriptor-contract.json': 'file'}[name]
        if key not in parents[0]:
            print(json.dumps({'path': name, 'keys': list(parents[0])}))
            continue
        identity = {'manifests': 'path', 'file': 'name', 'suites': 'id'}[key]
        a, b = [{value[identity]: value for value in parent[key]} for parent in parents]
        print(json.dumps({'path': name, 'onlyOurs': sorted(set(a) - set(b)), 'onlyIncoming': sorted(set(b) - set(a)), 'changedCommon': [name for name in a.keys() & b.keys() if a[name] != b[name]]}))
    else:
        print(json.dumps({'path': name, 'diffs': diffs(*parents)}))
