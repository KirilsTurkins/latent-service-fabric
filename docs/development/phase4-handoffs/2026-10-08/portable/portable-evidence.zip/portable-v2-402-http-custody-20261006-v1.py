from pathlib import Path
import hashlib
import json
import subprocess

root=Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
out=Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1")
assert not out.exists()
out.mkdir()
def git(*args):
    return subprocess.check_output(["git",*args],cwd=root,timeout=90)
ours=git("rev-parse","HEAD").decode().strip()
incoming=git("rev-parse","MERGE_HEAD").decode().strip()
assert ours=="abbeeceb7fa85534476d8b66cb8ab567f9263493"
assert incoming=="ad537698c0178ab4325ebe4f32857d4f94d00dca"
paths=git("diff","--name-only","--diff-filter=U").decode().splitlines()
records=[]
for name in paths:
    row={"path":name}
    for stage,label in ((2,"ours"),(3,"incoming")):
        raw=git("show",":"+str(stage)+":"+name)
        target=out/label/name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)
        row[label]={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
    records.append(row)
(out/"custody.json").write_text(json.dumps({"ours":ours,"incoming":incoming,"conflicts":records,
    "peerRefsUntouched":True,"peerWorktreeUntouched":True},indent=2)+"\n",encoding="utf8")
print(json.dumps({"savedConflicts":len(records),"out":str(out)}))
