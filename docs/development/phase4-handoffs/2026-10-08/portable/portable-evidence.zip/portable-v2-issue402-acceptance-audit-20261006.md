# Issue #402 current acceptance and reuse audit

Read-only audit on 2026-10-06. Current main is `3d77ab9e`; inspected storage source is clean `259f5fd9`. Issue #402 remains open. No dedicated current #402 application PR was found; GitHub's broad `402 in:body` match returned an unrelated historical Wasmtime PR, so it is not treated as application coverage.

The milestone currently lists 29 open and three closed issues (#380, #382, #384). All application runtime dependencies #388/#389/#392/#393/#394/#395/#398/#400/#401/#408/#409/#718 remain open. #403/#404/#405/#406/#407 are downstream consumers/gates and do not block beginning implementation.

| Acceptance | Existing reusable source/evidence | Remaining application work |
| --- | --- | --- |
| One common contract and six real guests | PR #784 `438c08e6`: six maintained transactional aggregate templates, typed transaction/query/intents, common namespace/key observations; PR #802 retains actual Java compiler captures | One bounded business contract, related state keys plus event intent in the actual atomic envelope, fresh projection, declared rejection, stale edit and original command recovery across all six signed publications |
| JetStream, qualified HTTP and separate incoming inbox | Merged JetStream qualification source; PR #821/#797 HTTP adapter/reconciliation; atomic envelope processed-input representation | Distinct bounded input/output subjects, actual outgoing effects and separate transactional input processing, no feedback loop; post-commit acknowledgement and duplicate input schedule |
| Purpose-specific authenticated HTTP and Angular | Existing supported `examples/angular-reference-application` and `tools/run_angular_reference_workflow.py`; PR #828/#823 compose installed query/HTTP transaction owners | Protected explicit commands and read-only rendering queries through shared ingress, with configuration matching the actual installed signed binding/profile |
| Origin/CSRF/cookie/CSP/assets/current authority/cache | Maintained Angular/static/browser and shared HTTP policies, signed immutable assets, actual reference scenarios | Apply existing controls to personalized state; fresh queries and tenant isolation; no shared immutable cache for state-dependent output |
| Real SSR, DOM reuse, pending/commit/effect display, lost response | Existing Angular `provideClientHydration`, `TransferState`, reference browser/node conductor | Actual stateful command submit/query/recovery browser flow against real node; retain original mutation identity; no Playwright manufactured HTTP responses |
| Same browser flow for each guest | Six guest source/compiler owners in #784, Java source stack #802 | Exact compiler/component/ABI/publication maps and one frontend/scenario set for Rust/C/TypeScript/Go/Java/.NET; external-client language does not count as guest language |
| Restart/redelivery/policy/uncertainty/schema | Store/envelope/dispatcher owners; peer #808 migration/history, #823/#828 installed recovery | Integrated restart after commit before dispatch, duplicate inbox, explicit blocked/uncertain reconciliation, compatible rollout and incompatible rollback refusal |
| Finite dormant and physical ownership | Shared state/runtime/node/effect accounting and physical-retirement controls; fixed native store workers | Measured actual owners after success/failure/stop and pending intents; no per-aggregate guest or process retention and no constant-RSS claim |
| Outside-checkout workflow and source/evidence | Packaged developer workflow, six client source #800, source-bound Angular build/sign/admission tools | Actual create/build/package/sign/admit/run/failure/cleanup recipe, source regions and exact node/compiler/component/browser/provider evidence; no required 36-way matrix |

| Required scenario | Application-specific gap |
| --- | --- |
| #408 ordinary read and #409 shared command/query/recovery | Connect actual shared read path; no durable command row for a view, private database gateway or app-only HTTP transaction protocol |
| Two stale editors | Preserve an explicit business expected revision from the original screen; technical activation OCC alone is insufficient |
| Lost rejection and approved retry | Retain and recover original declared rejection after business data changes; explicit technical-abort retry proof, concurrent attempts, no hidden retries |
| Two users in one tenant | Separate entity/result authorization; ID knowledge does not grant lookup/cancel; stable-subject token rotation keeps identity and replay does not reissue credentials/cookies |
| Old pending work and expiry | Compatible update and ordinary result-body expiry preserve pending work; revocation/unknown remote completion stay explicit |
| Finite effect status and state update | Finite status queries plus explicit authorized commands or separate incoming events; no automatic callback prerequisite |
| Composed Java | Reuse #718/#708/#709/#710 actual preparation/currentness/diagnostic interfaces without global runtime-limit inflation or synchronous child transaction assumptions |

Concrete reuse findings: the current Angular reference `shared/app.ts` has a browser-local `count` signal and Home/About navigation. `server/main.ts` renders authenticated display text and a bounded optional HTTP message, not durable application state; `client/main.ts` performs actual Angular hydration. These are the maintained frontend/renderer baseline to extend, not stateful application evidence. Current `tools/transaction_contracts.py` owns bounded generic framing and is expressly not a state engine. The contract-feasibility compiler source under `sdk/transaction-contract` is likewise not the six application implementation.

Protected peer trees/PRs #808/#811/#802/#823/#828 were only read. Their signed composition, migration and Java implementation remain owned elsewhere. The independent application worktree is based on #784's immutable guest-authoring head so the real guest SDK templates can be reused without editing those peer trees.

Implementation order: one closed business WIT/data/schema contract and equivalent guest source over the existing SDK facades; one shared Angular command/query/recovery client and UI; actual signed configuration using the installed host owner fields; one bounded node/browser/provider conductor with distinct inbox/outbox paths and all required recovery schedules. Qualification receipts must be produced by executed exact-source components and the real node, with pending stages kept explicit until executed.
