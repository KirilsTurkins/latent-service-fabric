import importlib.util
from pathlib import Path

path = Path(__file__).resolve().parent / 'portable-v2-current-development-continuations-20261007-v4.py'
spec = importlib.util.spec_from_file_location('continuations', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.HEADS = {
    787: 'f058c3aba9959508aacfb573533ff6b7a8f02b65',
    800: 'af1134cb1a61ed091234a9cc42a59512b66e619f',
}
module.main()
