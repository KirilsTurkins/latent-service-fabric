"""Parse all six actual captured worlds and generate pinned C/Java/Rust bindings."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
COORD = Path(__file__).resolve().parent
PROJECTS = COORD / "portable-v2-402-created-projects-20261006-v1"
OUT = COORD / "portable-v2-402-bindings-20261006-v1"
sys.path.insert(0, str(ROOT))
from tools.java_guest.surface import surface
from tools.stateful_reference_project import LANGUAGES, WORLD
OUT.mkdir()
def call(label, argv, timeout=120):
    log = OUT / (label + ".log")
    start = time.monotonic()
    with log.open("xb") as output:
        result = subprocess.run(argv, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, timeout=timeout)
    raw = log.read_bytes()
    row = {"label": label, "argv": list(map(str, argv)), "exitCode": result.returncode,
           "elapsedSeconds": time.monotonic() - start, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
           "originalProcessReaped": True}
    assert result.returncode == 0, (label, result.returncode)
    return raw, row
rows = []
wasm, row = call("wasm-version", ["wasm-tools", "--version"]); rows.append(row)
bindgen, row = call("bindgen-version", ["wit-bindgen", "--version"]); rows.append(row)
assert wasm.strip() == b"wasm-tools 1.254.0" and bindgen.strip() == b"wit-bindgen-cli 0.62.0"
surfaces = {}
for language in LANGUAGES:
    raw, row = call(language + "-world", ["wasm-tools", "component", "wit", str(PROJECTS / language / "wit"), "--json"])
    rows.append(row)
    model = surface(json.loads(raw), WORLD)
    assert {"latent:state/key-value@0.2.0", "latent:intents/staging@0.1.0"} <= model["imports"].keys()
    assert not any(name.startswith(("latent:http/", "latent:services/")) for name in model["imports"])
    surfaces[language] = model["exports"]
assert all(value == surfaces["rust"] for value in surfaces.values())
for language, generator, extra in [("c", "c", ["--rename-world", "probe", "--no-sig-flattening", "--async=all"]),
                                    ("java", "c", ["--rename-world", "probe", "--no-sig-flattening", "--async=-all"]),
                                    ("rust", "rust", ["--generate-all"])]:
    target = OUT / (language + "-bindings")
    _, row = call(language + "-bindings", ["wit-bindgen", generator, str(PROJECTS / language / "wit"),
                                           "--world", WORLD, *extra, "--out-dir", str(target)])
    rows.append(row)
receipt = {"at": datetime.now(timezone.utc).isoformat(), "world": WORLD, "steps": rows,
           "sixExportSurfacesEqual": True, "strictStateAndIntentImportsPreserved": True,
           "immediateHttpOrChildImports": False, "componentsCompiled": False, "runtimeQualified": False,
           "heavyCargoStarted": False, "peerTreesModified": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps({key: value for key, value in receipt.items() if key != "steps"}), flush=True)
