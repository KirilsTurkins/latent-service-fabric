import hashlib
import json
import pathlib
import re
import subprocess
import sys
import time

COORD = pathlib.Path(__file__).resolve().parent
number = int(sys.argv[1])
assert number in {767, 780, 821, 796, 787, 800}
out = COORD / f'portable-v2-pr{number}-a686-reconcile-20261007-v4'
record = json.loads((out / 'receipt.json').read_bytes())
root = pathlib.Path(record['root'])
source_dir = COORD / f'portable-v2-pr{number}-a686-source-linux-20261007-v5'
proof = json.loads((source_dir / 'receipt.json').read_bytes())
host = json.loads((out / 'host-gates.json').read_bytes())
assert proof['head'] == record['head'] and proof['passed'] and proof['sourceClean'] and proof['sourceHeadUnchanged'] and proof['originalProcessReaped']
assert host['head'] == record['head'] and host['fmtPassed'] and host['lockedOfflineMetadataPassed']

def command(args):
    result = subprocess.run(args, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace')[-3000:])
    return result.stdout

assert command(['git', 'rev-parse', 'HEAD']).decode().strip() == record['head']
assert not command(['git', 'status', '--porcelain'])
before_raw = command(['gh', 'pr', 'view', str(number), '--json', 'state,headRefOid,headRefName,baseRefName,body,isDraft'])
before = json.loads(before_raw)
(out / 'prepublication-pr.json').write_bytes(before_raw)
assert before['state'] == 'OPEN' and before['baseRefName'] == 'development'
assert before['headRefOid'] == record['parent'], (number, before['headRefOid'], record['parent'])
expected = {767: 'feat/phase4-storage-381', 780: 'feat/phase4-391-dispatcher', 821: 'feat/phase4-393-http-deferred', 796: 'feat/phase4-retention-397', 787: 'feat/phase4-atomic-envelope-386', 800: 'feat/phase4-clients-401'}
assert before['headRefName'] == expected[number]
remote_branch = 'refs/heads/' + before['headRefName']
push = subprocess.run(['git', 'push', 'origin', record['head'] + ':' + remote_branch], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
(out / 'push.log').write_bytes(push.stdout)
assert push.returncode == 0, push.stdout.decode(errors='replace')
assert command(['git', 'ls-remote', '--heads', 'origin', remote_branch]).decode().split()[0] == record['head']
for attempt in range(5):
    after_raw = command(['gh', 'pr', 'view', str(number), '--json', 'state,headRefOid,headRefName,baseRefName,mergeable,isDraft'])
    after = json.loads(after_raw)
    if after['headRefOid'] == record['head']:
        break
    time.sleep(2)
else:
    raise RuntimeError('Push verified by ls-remote but PR API still lags; preserve receipt and refresh before body mutation')
assert after['state'] == 'OPEN'
(out / 'postpublication-pr.json').write_bytes(after_raw)
log = (source_dir / 'step-1.log').read_text(encoding='utf-8')
cases = int(re.search(r'Ran (\d+) tests', log)[1])
skipped = int(match[1]) if (match := re.search(r'OK \(skipped=(\d+)\)', log)) else 0
body = before['body'].rstrip()
body = body.replace('Current head `' + record['parent'] + '`', 'Prior head `' + record['parent'] + '`')
body += ('\n\nCurrent published head `' + record['head'] + '` merges development `a686ed45` with exactly eight reviewed Go generator/support paths. '
         'Rust runtime, SDK, WIT, schema, protocol and dependency-lock bytes are identical to the prior head; its existing Native receipts keep their original source/scope. '
         f'Fresh exact-head Linux Source passes all five checks: {cases} discovered, {cases-skipped} pass and {skipped} original platform skip(s), including mandatory symlink refusal. '
         'Generator, CI coverage, repository, documentation, full formatting and locked/offline metadata checks pass; source is clean and all processes reaped under original limits. '
         'All existing test guards, budgets, conditions and remaining issue acceptance requirements stay required. Hosted CI is pending; this update establishes no CI bypass or issue closure.\n')
body_path = out / 'body.md'
body_path.write_text(body, encoding='utf-8')
command(['gh', 'pr', 'edit', str(number), '--body-file', str(body_path)])
publication = {'number': number, 'parent': record['parent'], 'head': record['head'], 'branch': remote_branch,
               'sourceReceiptSha256': hashlib.sha256((source_dir / 'receipt.json').read_bytes()).hexdigest(),
               'sourceCases': cases, 'originalSkips': skipped, 'runtimeBytesUnchanged': True,
               'normalPushPassed': True, 'lsRemoteVerified': True, 'postpublicationPr': after,
               'bodySha256': hashlib.sha256(body_path.read_bytes()).hexdigest(), 'merged': False, 'completeCI': False}
(out / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
print(json.dumps(publication))
