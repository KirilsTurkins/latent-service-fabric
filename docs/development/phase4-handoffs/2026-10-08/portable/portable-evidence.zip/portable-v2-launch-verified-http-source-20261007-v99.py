﻿from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');repo=Path(r'C:\Users\turkins\Desktop\lf-p4-http-deferred-admission-v96');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,timeout=30).decode().strip()
assert head=='7a6b163e0b45b820efe3150215ef26b6672bf76e' and not subprocess.check_output(['git','status','--porcelain'],cwd=repo,timeout=30)
previous=coord/'portable-v2-http-deferred-admission-source-20261007-v98';log=(previous/'docker-output.log').read_bytes()
assert b'checkout' in log and not (previous/'receipt.json').exists()
(previous/'setup-refusal.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),outcome='incorrect-invocation-head-refused-before-tests',incorrectInvocationHead=json.loads((previous/'invocation.json').read_bytes())['head'],correctHead=head,rawSha256=hashlib.sha256(log).hexdigest(),testsExecuted=False,qualification=False),indent=2)+'\n')
argv=[sys.executable,'-X','utf8','-B',str(coord/'portable-v2-reconstructed-native-controller-20261007-v93.py'),'portable-v2-http-deferred-admission-source-20261007-v99',head,str(coord/'portable-v2-http-deferred-admission-source-steps-20261007-v98.json'),'source']
print(json.dumps(dict(head=head,argv=argv,sourceSlotsOwnedByMe=1)),flush=True)
raise SystemExit(subprocess.call(argv))
