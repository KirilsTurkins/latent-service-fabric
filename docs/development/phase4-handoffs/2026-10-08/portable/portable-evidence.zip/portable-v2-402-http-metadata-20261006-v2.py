from pathlib import Path
import hashlib
import json
import subprocess

root=Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
before=hashlib.sha256((root/'Cargo.lock').read_bytes()).hexdigest()
result=subprocess.run(['cargo','metadata','--locked','--offline','--no-deps','--format-version','1'],cwd=root,capture_output=True,timeout=120)
(out/'metadata-v2.json').write_bytes(result.stdout)
(out/'metadata-v2.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode(errors='replace')
data=json.loads(result.stdout)
assert before==hashlib.sha256((root/'Cargo.lock').read_bytes()).hexdigest()
receipt={'exitCode':0,'workspacePackages':len(data['workspace_members']),'cargoLockUnchanged':True,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'mergeHead':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()}
(out/'metadata-v2-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
