﻿from pathlib import Path
import hashlib,json,re,subprocess
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');repo=Path(r'C:\Users\turkins\Desktop\lf-p4-http-deferred-admission-v96');out=coord/'portable-v2-http-corrected-native-20261007-v107';p=out/'receipt.json';r=json.loads(p.read_bytes());head='c7663996caa7722cd2a9ccc298f656e6c27a01e5'
assert r['head']==head and r['passed'] and r['originalProcessReaped'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['infrastructureError'] is None and len(r['steps'])==7
inventory=json.loads((repo/'tools/ci/suites.json').read_bytes());expected={row['id']:row for row in inventory['suites']};rows=[]
for i,row in enumerate(r['steps']):
 raw=(out/row['log']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped'] and row['stopReason'] is None
 s=raw.decode(errors='replace');counts=[dict(passed=int(a),failed=int(b),ignored=int(c)) for a,b,c in re.findall(r'test result:.*? (\d+) passed; (\d+) failed; (\d+) ignored;',s)]
 rows.append(dict(step=i+1,sha256=row['sha256'],bytes=len(raw),counts=counts))
 if i==1:
  names=re.findall(r'^([A-Za-z0-9_:]+): test$',s,re.M);assert len(names)==167 and set(names)==set(expected['latent-capabilities.lib.latent-capabilities']['expectedCases']);rows[-1]['compiledExact167CaseNames']=names
 if i in [3,4,5]:
  suite=expected[['latent-capabilities.lib.latent-capabilities','latent-http.lib.latent-http','latent-control-store.lib.latent-control-store'][[3,4,5].index(i)]]
  names=re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\.',s,re.M);assert set(names)==set(suite['expectedCases']),(i,len(set(names)),suite['minimumCases'])
  assert counts[-1]['failed']==0 and counts[-1]['passed']+counts[-1]['ignored']==suite['minimumCases']
proof=dict(head=head,receiptSha256=hashlib.sha256(p.read_bytes()).hexdigest(),allSevenRawLogsVerified=True,allOriginalProcessGroupsReaped=True,sourceCleanAndHeadUnchanged=True,infra=None,elapsedSeconds=r['elapsedSeconds'],targetGrowthBytes=r['targetGrowthBytes'],checkAllTargetsPass=True,newSevenCasesPass=True,fullCapability167Pass=True,allHttp59Pass=True,fullControlStore250PassOneOriginalIgnore=True,compiledNamesExactlyMatchCurrentCaseContract=True,ordinaryClippyPass=True,originalBudgetsAndGuardsUnchanged=True,rows=rows,completeCI=False)
(out/'authenticated-final-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='rows'}))
shared=coord/'portable-v2-http-admission-shared-patch-20261007-v109'
source_patch=subprocess.check_output(['git','diff','--binary','cbef28330f87de778141017cfedf1faa32bb520a',head,'--','.',' :(exclude)tools/ci/suites.json'.strip()],cwd=repo);assert b'diff --git a/tools/ci/suites.json' not in source_patch;(shared/'source-only-final.patch').write_bytes(source_patch)
mail=subprocess.check_output(['git','format-patch','--stdout','cbef28330f87de778141017cfedf1faa32bb520a..'+head,'--','.',' :(exclude)tools/ci/suites.json'.strip()],cwd=repo);assert b'diff --git a/tools/ci/suites.json' not in mail;(shared/'source-only-series.mbox').write_bytes(mail)
identities=json.loads((shared/'path-identities.json').read_bytes());identities.update(nativeFinalPending=False,nativeFinalProofSha256=hashlib.sha256((out/'authenticated-final-proof.json').read_bytes()).hexdigest(),nativeReceiptSha256=proof['receiptSha256'],sourceOnlyPatchSha256=hashlib.sha256(source_patch).hexdigest(),sourceOnlyPatchBytes=len(source_patch),sourceOnlyMailSha256=hashlib.sha256(mail).hexdigest())
for row in identities['paths']:
 path=row['path'];row['baseBlob']=subprocess.check_output(['git','rev-parse','cbef28330f87de778141017cfedf1faa32bb520a:'+path],cwd=repo,stderr=subprocess.DEVNULL).decode().strip() if not row['baseAbsent'] else None;row['currentBlob']=subprocess.check_output(['git','rev-parse',head+':'+path],cwd=repo).decode().strip()
(shared/'qualified-path-identities.json').write_text(json.dumps(identities,indent=2)+'\n');print(json.dumps(dict(sourceOnlyPatchBytes=len(source_patch),sourceOnlyMailBytes=len(mail),nativeFinalReceiptSha256=proof['receiptSha256'])))
