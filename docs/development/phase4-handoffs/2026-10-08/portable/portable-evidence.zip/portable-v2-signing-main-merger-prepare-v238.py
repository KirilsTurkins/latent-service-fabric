from pathlib import Path

COORD=Path(__file__).resolve().parent
source=(COORD/'portable-v2-owned-current-main-union-v217.py').read_text(encoding='utf8')
source=source.replace('v217','v238').replace('0cd6c2e8649e8181366e0adbfe03da1bf2a3c7a3','c84473ec9868fc496486f864afe52f1b7105329f')
source=source.replace("{'791','800','787','796','784','825','811'}","{'790','791','800','787','796','784','825','811'}")
target=COORD/'portable-v2-owned-signing-main-union-v238.py'
compile(source,str(target),'exec')
assert not target.exists()
target.write_text(source,encoding='utf8')
print(str(target))
