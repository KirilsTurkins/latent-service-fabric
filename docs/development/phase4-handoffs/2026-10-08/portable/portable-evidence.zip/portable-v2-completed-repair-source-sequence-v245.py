from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

COORD=Path(__file__).resolve().parent
SOURCE='source-6ab38845e5a266f3'
previous='portable-v2-pr784-final-main-source-20261008-v239'
items=[]
for number in (825,811,791):
    if number==825:
        record=json.loads((COORD/'portable-v2-pr825-core-owner-repair-prepared-v244.json').read_bytes())
    elif number==811:
        record=json.loads((COORD/'portable-v2-pr811-current-main-union-v243/receipt.json').read_bytes())
    else:
        record=json.loads((COORD/'portable-v2-pr791-core-owner-repair-prepared-v247.json').read_bytes())
    if number==811:
        steps=json.loads((COORD/'portable-v2-pr811-network-fields-source-steps-v184.json').read_bytes())
        for module in ['tools.tests.test_java_diagnostic_program','tools.tests.test_java_provider_timeout','tools.tests.test_java_resource_diagnostics']:
            if module not in steps[0]:steps[0].append(module)
        steps.append(['python3','-X','utf8','-B','tools/generate_node_rpc.py','--protoc','/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/protoc-bin-vendored-linux-x86_64-3.2.0/bin/protoc','--check'])
    else:
        steps=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-source-steps-v222.json')).read_bytes())
    job='portable-v2-pr'+str(number)+'-final-main-source-20261008-v245'
    steps[3][-1]='target/ci/observed-pr'+str(number)+'-final-main-v245.json'
    if number in (790,791):
        steps[-1][-1]=steps[-1][-1].replace('portable-v2-pr'+str(number)+'-current-main-source-20261008-v222',job)
    path=COORD/('portable-v2-pr'+str(number)+'-final-main-source-steps-v245.json')
    path.write_text(json.dumps(steps,indent=2)+'\n',encoding='utf8')
    items.append(dict(pr=number,head=record['head'],job=job,steps=str(path)))
(COORD/'portable-v2-owned-final-source-sequence-prepared-v245.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf8')
out=COORD/'portable-v2-owned-final-source-sequence-v245'
assert not out.exists()
out.mkdir()
records=[]
for row in items:
    if (COORD/'portable-v2-corrected-source-sequence-v245.pause').exists():
        print(json.dumps(dict(status='paused-at-reaped-boundary',nextPr=row['pr'])),flush=True)
        break
    previous_receipt=json.loads((COORD/previous/'receipt.json').read_bytes())
    assert previous_receipt['sourceClean'] and previous_receipt['sourceHeadUnchanged'] and previous_receipt['originalProcessReaped']
    script='portable-v2-pr'+str(row['pr'])+'-final-source-reuse-controller-v245.py'
    prep=['python','-X','utf8','-B',str(COORD/'portable-v2-source-reuse-prepare-v211.py'),row['head'],previous,SOURCE,row['job'],row['steps'],script]
    subprocess.run(prep,check=True,timeout=120,stdout=subprocess.DEVNULL)
    print(json.dumps(dict(status='launching-one-source',**row)),flush=True)
    log=out/('pr'+str(row['pr'])+'-observer.log')
    with log.open('xb') as target:
        process=subprocess.Popen(['python','-X','utf8','-B',str(COORD/script),row['job'],row['head'],row['steps'],'source'],stdout=target,stderr=subprocess.STDOUT)
        launched=time.monotonic()
        while process.poll() is None:
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                print(json.dumps(dict(status='source-observer-active',pr=row['pr'],job=row['job'],elapsedSeconds=time.monotonic()-launched)),flush=True)
            if time.monotonic()-launched>2150:
                subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,timeout=20)
                process.wait(timeout=20)
                raise AssertionError(('source-observer-overrun-preserved',row['job']))
    assert process.poll() is not None
    receipt_path=COORD/row['job']/'receipt.json'
    assert receipt_path.exists(),row
    raw=receipt_path.read_bytes()
    receipt=json.loads(raw)
    assert receipt['head']==row['head'] and receipt['sourceClean'] and receipt['sourceHeadUnchanged'] and receipt['originalProcessReaped']
    for item in receipt['steps']:
        data=(receipt_path.parent/Path(item['log']).name).read_bytes()
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
    observed=dict(**row,passed=receipt['passed'],sourceClean=True,sourceHeadUnchanged=True,originalProcessReaped=True,
                  receiptSha256=hashlib.sha256(raw).hexdigest(),hostExit=process.returncode)
    records.append(observed)
    (out/'progress.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8')
    print(json.dumps(dict(status='source-final-reaped',**observed)),flush=True)
    previous=row['job']
result=dict(at=datetime.now(timezone.utc).isoformat(),oneSequentialSourceLane=True,allOriginalSourceLimitsPreserved=True,
            noNativeCheckoutMutation=True,noClone=True,records=records,allPassed=all(row['passed'] for row in records))
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(status='sequence-final',allPassed=result['allPassed'],heads=len(records))),flush=True)
