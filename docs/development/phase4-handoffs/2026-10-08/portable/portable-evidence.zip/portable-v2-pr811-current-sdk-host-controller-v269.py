from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-pr811-current-sdk-host-v267'
SOURCE=OUT/'source'
receipt=json.loads((OUT/'source-receipt.json').read_bytes())
assert receipt['head']=='f8253b33ce6987663ff423bafce1946f901ba66f'
def authenticate():
    for row in receipt['files']:
        data=(SOURCE/row['path']).read_bytes()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
authenticate()
NODE=Path(r'C:\Program Files\nodejs\node.exe')
NPM=COORD/'portable-v2-private-npm-host-v241/package/bin/npm-cli.js'
assert subprocess.check_output([str(NODE),'--version'],text=True,timeout=20).strip()=='v24.19.0'
assert subprocess.check_output([str(NODE),str(NPM),'--version'],text=True,timeout=20).strip()=='11.19.1'
env=dict(os.environ,DOTNET_CLI_TELEMETRY_OPTOUT='1',DOTNET_NOLOGO='1',DOTNET_CLI_USE_MSBUILD_SERVER='0',DOTNET_SKIP_FIRST_TIME_EXPERIENCE='1',NUGET_XMLDOC_MODE='skip')
TS=SOURCE/'sdk/typescript-client'
SDK=SOURCE/'sdk/dotnet'
assert subprocess.check_output(['dotnet','--version'],cwd=SDK,env=env,text=True,timeout=20).strip()=='8.0.425'
runtimes=subprocess.check_output(['dotnet','--list-runtimes'],cwd=SDK,env=env,text=True,timeout=20)
assert all(name+' 8.0.31 ' in runtimes for name in ('Microsoft.NETCore.App','Microsoft.AspNetCore.App'))
tests=sorted(str(path.relative_to(TS)) for path in (TS/'tests/network').glob('*.test.mjs'))
assert tests
commands=[
    (TS,[str(NODE),str(NPM),'ci','--ignore-scripts','--no-audit','--no-fund'],180),
    (TS,[str(NODE),str(TS/'node_modules/typescript/bin/tsc'),'-p','tsconfig.json'],180),
    (TS,[str(NODE),'--test',*tests],180),
    (TS,[str(NODE),str(TS/'node_modules/typescript/bin/tsc'),'-p','tsconfig.tests.json'],180),
    (TS,[str(NODE),str(TS/'dist/semantic-tests/tests/invocation-identity.js')],180),
]
properties=['-p:ImportDirectoryBuildProps=false','-p:ImportDirectoryBuildTargets=false','-p:ImportDirectoryPackagesProps=false','-p:UseSharedCompilation=false','-nodeReuse:false']
artifacts=OUT/'dotnet-build'
for project in ('Latent.Sdk.Transport.Tests','Latent.Sdk.SemanticTests'):
    path=project+'/'+project+'.csproj'
    commands.extend([
        (SDK,['dotnet','restore',path,'--locked-mode','--configfile','nuget.transport.config','-p:ArtifactsPath='+str(artifacts),'-p:NuGetAuditMode=all',*properties],180),
        (SDK,['dotnet','build',path,'--no-restore','--disable-build-servers','--artifacts-path',str(artifacts),'-v:q',*properties],180),
        (SDK,['dotnet',str(artifacts/'bin'/project/'debug'/(project+'.dll'))],180),
    ])
start=time.monotonic();records=[]
assert not (OUT/'host-native-receipt.json').exists()
for index,(cwd,argv,limit) in enumerate(commands,1):
    assert time.monotonic()-start<1800
    log=OUT/f'host-step-{index}.log';assert not log.exists()
    before=time.monotonic();stop=None
    with log.open('xb') as target:
        process=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=target,stderr=subprocess.STDOUT)
        try:process.wait(timeout=min(limit,1800-(time.monotonic()-start)))
        except subprocess.TimeoutExpired:
            stop='original-180-second-command-deadline'
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,timeout=20)
            process.wait(timeout=20)
    data=log.read_bytes();assert len(data)<=4*1024**2
    row=dict(argv=argv,cwd=str(cwd),returncode=process.returncode,stopReason=stop,elapsedSeconds=time.monotonic()-before,
             originalProcessReaped=process.poll() is not None,log=log.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    records.append(row)
    print(json.dumps(dict(step=index,returncode=row['returncode'],elapsedSeconds=row['elapsedSeconds'],reaped=row['originalProcessReaped'])),flush=True)
    if process.returncode or stop:break
authenticate()
result=dict(at=datetime.now(timezone.utc).isoformat(),head=receipt['head'],environment='Windows x64 host, pinnedNode24.19/npm11.19.1 maintainedv4/.NET8.0.425/runtime8.0.31',
            steps=records,passed=len(records)==len(commands) and all(row['returncode']==0 and row['stopReason'] is None for row in records),
            allSourceHashesUnchanged=True,sourceFileCount=len(receipt['files']),allProcessesReaped=all(row['originalProcessReaped'] for row in records),elapsedSeconds=time.monotonic()-start,
            completeCI=False,authoritativeLinuxSDKQualification=False)
(OUT/'host-native-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='steps'},indent=2),flush=True)
