"""Remove only the verified clean merged-PR worktree, preserving proof custody."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

TARGET = Path(r"C:\Users\turkins\Desktop\lf-p4-common-braces-runtime-20261006")
ACTIVE = Path(r"C:\Users\turkins\Desktop\lf-p4-common-ci-history-20261006")
COORD = Path(__file__).resolve().parent
OUT = COORD / "portable-v2-cleanup-merged841-20261006-v1"
EXPECTED = "2298d9dd437b9c54aa9b524ddcd65348dc1428b5"
assert TARGET.resolve() == Path(r"C:\Users\turkins\Desktop\lf-p4-common-braces-runtime-20261006")
assert TARGET.parent.resolve() == Path(r"C:\Users\turkins\Desktop")
assert ACTIVE.is_dir() and ACTIVE.resolve() != TARGET.resolve()
def git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root, timeout=30).decode().strip()
assert git(TARGET, "rev-parse", "HEAD") == EXPECTED and not git(TARGET, "status", "--porcelain")
pr = json.loads(subprocess.check_output(["gh", "pr", "view", "841", "--repo", "KirilsTurkins/latent-service-fabric",
                                     "--json", "number,state,headRefOid,mergedAt,mergeCommit"], timeout=60))
assert pr["state"] == "MERGED" and pr["headRefOid"] == EXPECTED
assert git(ACTIVE, "rev-parse", "HEAD") == pr["mergeCommit"]["oid"]
assert not git(ACTIVE, "status", "--porcelain")
OUT.mkdir()
artifact = TARGET / "target/website-package-manager/npm-11.19.1-lsf-bundle-v4.tar"
destination = OUT / artifact.name
expected_sha = "f05c6309efcb0713b56a9a31236547ecbb164195b43978c4db38488ccd743d6f"
with artifact.open("rb") as source:
    assert hashlib.file_digest(source, "sha256").hexdigest() == expected_sha
shutil.copyfile(artifact, destination)
with destination.open("rb") as source:
    assert hashlib.file_digest(source, "sha256").hexdigest() == expected_sha
result = subprocess.run(["git", "worktree", "remove", str(TARGET)], cwd=ACTIVE, capture_output=True, text=True, timeout=180)
receipt = {"at": datetime.now(timezone.utc).isoformat(), "target": str(TARGET), "pr": pr,
           "headWasExact": True, "sourceWasClean": True, "qualifiedSourceProcessesPreviouslyReaped": True,
           "newOwnedTree": str(ACTIVE), "preservedArtifact": str(destination), "preservedArtifactSha256": expected_sha,
           "command": ["git", "worktree", "remove", str(TARGET)], "forceUsed": False, "globalPruneUsed": False,
           "exitCode": result.returncode, "targetRemoved": not TARGET.exists(), "output": result.stdout + result.stderr}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps(receipt), flush=True)
raise SystemExit(result.returncode or TARGET.exists())
