﻿from pathlib import Path
import json,subprocess,sys,hashlib
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');repo=Path(r'C:\Users\turkins\Desktop\lf-p4-http-deferred-admission-v96')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,timeout=30).decode().strip();assert head=='7a6b163e0b45b820efe3150215ef26b6672bf76e' and not subprocess.check_output(['git','status','--porcelain'],cwd=repo,timeout=30)
old=json.loads((coord/'portable-v2-http-deferred-admission-source-steps-20261007-v98.json').read_bytes());steps=json.loads(json.dumps(old));prefix=steps[0].index('unittest')+1
missing=[];present=[]
for name in steps[0][prefix:]:
 if (repo/Path(*name.split('.')).with_suffix('.py')).is_file():present.append(name)
 else:missing.append(name)
assert len(present)==17 and len(missing)==10
for name in ['tools.tests.test_ci_contracts','tools.tests.test_ci_suite_inventory','tools.tests.test_ci_suite_discovery','tools.tests.test_ci_suite_fragments','tools.tests.test_manifest_codec_contract','tools.tests.test_manifest_integer_dialect']:assert name in present
steps[0]=steps[0][:prefix]+present;assert steps[1:]==old[1:]
out=coord/'portable-v2-http-deferred-admission-source-steps-20261007-v102.json';assert not out.exists();out.write_text(json.dumps(steps,indent=2)+'\n')
proof=dict(head=head,presentModules=present,foreignUnmergedModulesAbsentFromSource=missing,allCurrentScopeCasesAndGuardsRetained=True,allSixOtherSourceCommandsByteIdentical=True,stepsSha256=hashlib.sha256(out.read_bytes()).hexdigest(),originalFailedRecipePreserved=True)
(coord/'portable-v2-http-deferred-admission-source-recipe-scope-20261007-v102.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
argv=[sys.executable,'-X','utf8','-B',str(coord/'portable-v2-reconstructed-native-controller-20261007-v93.py'),'portable-v2-http-deferred-admission-source-20261007-v102',head,str(out),'source']
raise SystemExit(subprocess.call(argv))
