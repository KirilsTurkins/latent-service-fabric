import concurrent.futures
import hashlib
import json
import pathlib
import re
import subprocess
import sys

COORD = pathlib.Path(__file__).resolve().parent
OUT = COORD / (sys.argv[1] if len(sys.argv) > 1 else 'portable-v2-ready-head-failures-20261007-v1')
assert OUT.parent == COORD and OUT.name.startswith('portable-v2-ready-head-failures-')
OUT.mkdir(exist_ok=True)
NUMBERS = (767, 780, 821, 825, 784, 803, 791)

def capture(number):
    pr_dir = OUT / str(number)
    pr_dir.mkdir(exist_ok=True)
    raw = subprocess.check_output(['gh', 'pr', 'view', str(number), '--repo', 'KirilsTurkins/latent-service-fabric', '--json', 'headRefOid,headRefName,state,statusCheckRollup'], cwd=COORD, timeout=120)
    (pr_dir / 'pr.json').write_bytes(raw)
    pr = json.loads(raw)
    failures = []
    for check in pr['statusCheckRollup']:
        if check.get('status') != 'COMPLETED' or check.get('conclusion') != 'FAILURE':
            continue
        match = re.search(r'/actions/runs/(\d+)/job/(\d+)', check['detailsUrl'])
        if not match:
            failures.append({'name': check['name'], 'url': check['detailsUrl'], 'unparsedUrl': True})
            continue
        run, job = match.groups()
        metadata_raw = subprocess.check_output(['gh', 'api', f'repos/KirilsTurkins/latent-service-fabric/actions/jobs/{job}'], cwd=COORD, timeout=120)
        metadata = json.loads(metadata_raw)
        assert str(metadata['run_id']) == run and metadata['status'] == 'completed' and metadata['conclusion'] == 'failure'
        run_raw = subprocess.check_output(['gh', 'api', f'repos/KirilsTurkins/latent-service-fabric/actions/runs/{run}'], cwd=COORD, timeout=120)
        run_metadata = json.loads(run_raw)
        assert run_metadata['head_sha'] == pr['headRefOid'], (number, run_metadata['head_sha'], pr['headRefOid'])
        logs = subprocess.run(['gh', 'api', f'repos/KirilsTurkins/latent-service-fabric/actions/jobs/{job}/logs'], cwd=COORD, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
        stem = f'{run}-{job}'
        (pr_dir / (stem + '-job.json')).write_bytes(metadata_raw)
        (pr_dir / (stem + '-run.json')).write_bytes(run_raw)
        (pr_dir / (stem + '.log')).write_bytes(logs.stdout)
        (pr_dir / (stem + '.stderr')).write_bytes(logs.stderr)
        failures.append({'name': check['name'], 'head': pr['headRefOid'], 'run': run, 'job': job, 'logReturnCode': logs.returncode,
                         'logBytes': len(logs.stdout), 'logSha256': hashlib.sha256(logs.stdout).hexdigest(), 'log': str(pr_dir / (stem + '.log'))})
    return {'number': number, 'head': pr['headRefOid'], 'state': pr['state'], 'failures': failures, 'readOnly': True}

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    records = list(pool.map(capture, NUMBERS))
(OUT / 'receipt.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
print(json.dumps(records, indent=2))
