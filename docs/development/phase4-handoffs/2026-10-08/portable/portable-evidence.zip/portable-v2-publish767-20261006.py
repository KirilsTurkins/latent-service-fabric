"""Normal-push only the exact clean, Source-qualified descendant to owned PR 767."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
COORD = Path(__file__).resolve().parent
OUT = COORD / "portable-v2-publish767-20261006-v1"
HEAD = "259f5fd96526a2f7a4f7a4dbf55a5658363142c3"
EXPECTED_REMOTE = "f0d1d011961b91f1822ad5936fccf86f4aa2c337"
DEVELOPMENT = "3d77ab9e77849c1061ae9480902f262ac3975857"
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=60).decode().strip()
assert git("rev-parse", "HEAD") == HEAD and not git("status", "--porcelain")
receipt_path = COORD / "portable-v2-pr767-linux-20261006-v1/receipt.json"
source = json.loads(receipt_path.read_bytes())
assert source["head"] == HEAD and source["tree"] == git("show", "-s", "--format=%T", "HEAD")
assert source["passed"] and source["sourceClean"] and source["sourceHeadUnchanged"] and source["originalProcessReaped"]
scan = json.loads((receipt_path.parent / "step-6.log").read_bytes())
assert scan["status"] == "pass" and scan["finding_count"] == 0 and scan["source_revision"] == HEAD
pr = json.loads(subprocess.check_output(["gh", "pr", "view", "767", "--repo", "KirilsTurkins/latent-service-fabric",
                                      "--json", "state,headRefOid,headRefName,baseRefName"], timeout=60))
assert pr["state"] == "OPEN" and pr["headRefOid"] == EXPECTED_REMOTE
assert pr["headRefName"] == "feat/phase4-storage-381" and pr["baseRefName"] == "development"
remote_development = subprocess.check_output(["gh", "api", "repos/KirilsTurkins/latent-service-fabric/git/ref/heads/development",
                                            "--jq", ".object.sha"], timeout=60).decode().strip()
assert remote_development == DEVELOPMENT
for ancestor in [EXPECTED_REMOTE, DEVELOPMENT, "318eaa9aea5e0962515c7161d441ee270bcdeae4"]:
    subprocess.run(["git", "merge-base", "--is-ancestor", ancestor, HEAD], cwd=ROOT, check=True)
assert git("ls-remote", "--heads", "origin", "refs/heads/" + pr["headRefName"]).split()[0] == EXPECTED_REMOTE
OUT.mkdir()
push = subprocess.run(["git", "push", "origin", "HEAD:refs/heads/" + pr["headRefName"]], cwd=ROOT,
                      capture_output=True, text=True, timeout=180)
(OUT / "push.log").write_text(push.stdout + push.stderr, encoding="utf8")
assert push.returncode == 0
subprocess.run(["gh", "pr", "edit", "767", "--repo", "KirilsTurkins/latent-service-fabric", "--body-file",
                str(COORD / "portable-v2-pr767-body-20261006.md")], cwd=ROOT, check=True, capture_output=True, timeout=60)
after = json.loads(subprocess.check_output(["gh", "pr", "view", "767", "--repo", "KirilsTurkins/latent-service-fabric",
                                         "--json", "state,headRefOid,headRefName,baseRefName,isDraft,url"], timeout=60))
assert after["headRefOid"] == HEAD and after["state"] == "OPEN" and not git("status", "--porcelain")
receipt = {"at": datetime.now(timezone.utc).isoformat(), "root": str(ROOT), "oldRemote": EXPECTED_REMOTE, "head": HEAD,
           "tree": source["tree"], "development": DEVELOPMENT, "sourceReceipt": str(receipt_path),
           "sourceReceiptSha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest(), "pr": after,
           "normalPushSucceeded": True, "forceUsed": False, "sourceClean": True, "completeCI": False,
           "heavyCargoStarted": False, "otherSessionStorageWorktreeTouched": False, "merged": False, "issueClosed": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps(receipt), flush=True)
