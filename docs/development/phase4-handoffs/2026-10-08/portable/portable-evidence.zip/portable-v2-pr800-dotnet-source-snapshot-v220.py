from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
HEAD='0055f9778e0d4ee2ace92dfdafabfd3e8ad57b7c'
OUT=COORD/'portable-v2-pr800-dotnet-current-native-v220'
assert not OUT.exists()
SOURCE=OUT/'source'
SOURCE.mkdir(parents=True)
listed=subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r','--name-only',HEAD,'sdk/dotnet','api/proto','sdk/profile']).decode().splitlines()
projects={'Latent.Sdk','Latent.Sdk.SemanticTests','Latent.Sdk.Transport','Latent.Sdk.Transport.Tests','Latent.Sdk.ProviderWorkflow'}
selected=[]
for path in listed:
    parts=Path(path).parts
    if path in ('sdk/dotnet/global.json','sdk/dotnet/nuget.transport.config','sdk/profile/fixtures.json'):
        selected.append(path)
    elif path.startswith('api/proto/') and path.endswith('.proto'):
        selected.append(path)
    elif len(parts)>3 and parts[:2]==('sdk','dotnet') and parts[2] in projects and (Path(path).suffix in ('.cs','.csproj') or parts[-1]=='packages.lock.json'):
        selected.append(path)
assert len(selected)<=128
records=[]
for path in selected:
    data=subprocess.check_output(['git','-C',str(REPO),'show',HEAD+':'+path]).replace(b'\r\n',b'\n')
    assert len(data)<=2*1024**2
    target=SOURCE/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data)
    records.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
proof=dict(at=datetime.now(timezone.utc).isoformat(),head=HEAD,source=str(SOURCE),files=records,fileCount=len(records),
           exactTrackedSourceBytes=True,pinnedSDK='8.0.425',pinnedRuntime='8.0.31',originalLocksAndNoScriptsPreserved=True,
           hostWindowsFocusedExecutionPending=True,linuxAuthoritativeValidationPending=True,noCIClaim=True)
(OUT/'source-receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k!='files'},indent=2))
