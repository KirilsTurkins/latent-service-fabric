from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr800-dotnet-lock-v260')
HEAD='592db6f7b7a677a0a5a502e82d4333776ca71d6e'
OLD='017385709f321b43f28a5851aca29eb2a37617d7'
NATIVE='f6f4a95b2dfe5f38295a70ea485f9d797d8786d8'
BRANCH='feat/phase4-clients-401'
REPO='KirilsTurkins/latent-service-fabric'
ENV=dict(os.environ,GODEBUG='http2client=0')
def call(argv):return subprocess.check_output(argv,env=ENV,timeout=120)
def authenticate(job,head):
    out=COORD/job;raw=(out/'receipt.json').read_bytes();r=json.loads(raw)
    assert r['head']==head and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped']
    for row in r['steps']:
        data=(out/Path(row['log']).name).read_bytes()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped']
    return hashlib.sha256(raw).hexdigest()
source_sha=authenticate('portable-v2-pr800-final-main-source-20261008-v264',HEAD)
native_sha=authenticate('portable-v2-pr800-fd-current-native-20261008-v256',NATIVE)
assert call(['git','-C',str(TREE),'diff','--name-only',NATIVE,HEAD]).decode().splitlines()==['sdk/dotnet/protobuf.lock.json']
generator=COORD/'portable-v2-dotnet-lock-native-reproduction-20261008-v259'
g=json.loads((generator/'receipt.json').read_bytes())
assert g['sourceHead']==NATIVE and g['reproductionsIdentical'] and g['generatedSources']==16
actual=call(['git','-C',str(TREE),'show',HEAD+':sdk/dotnet/protobuf.lock.json'])
assert actual==(generator/'protobuf.lock.json').read_bytes()
assert not call(['git','-C',str(TREE),'status','--porcelain'])
pr=json.loads(call(['gh','pr','view','800','--repo',REPO,'--json','headRefOid,headRefName,state']))
assert pr==dict(headRefOid=OLD,headRefName=BRANCH,state='OPEN')
call(['git','-C',str(TREE),'merge-base','--is-ancestor',OLD,HEAD])
body='''Adds bounded transaction models, codecs and recovery surfaces to all six external clients for #401. Preserves actual owner identity, packed scalar accounting, staging witness fields and every prior vector, operation and refusal.

Normally includes current development and retains all test floors, bounds and ignore controls. Repairs the completed .NET vector-count failure by executing all62 protobuf cases among78 shared records. Its generation lock is derived from two actual pinned Linux protoc29 reproductions of all16 sources, with only the current node.proto input and Node.cs output changing. The TypeScript descriptors, Java bridge, Rust conversions and client profiles remain source-matched.

Current Linux source checks pass226 cases with zero skips. Source-paired native checks pass Signing58, Node91, activation66, twelve real AOT probes, the syscall check and original ordinary/selected strict Clippy. Pinned Windows.NET8.0.425/8.0.31 tests pass21 transport scenarios and656 checks plus78 semantic records; this is host evidence. Earlier Java25/Gradle9.1 and guest/compiler receipts remain at their original source heads. Full current Linux.NET validation, hosted CI and six separate-node transaction transport qualification remain pending.
'''
body_path=COORD/'portable-v2-pr800-derived-lock-body-v266.md';body_path.write_text(body,encoding='utf8')
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=800,head=HEAD,oldHead=OLD,nativeHead=NATIVE,
           sourceReceiptSha256=source_sha,nativeReceiptSha256=native_sha,actualLinuxCodegenTwoReproductions=True,
           onlyDerivedMetadataAfterNative=True,normalPush=True,published=False,completeCI=False,issueNotClosed=True)
path=COORD/'portable-v2-pr800-derived-lock-publication-v266.json';path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
push=subprocess.run(['git','-C',str(TREE),'push','origin',f'HEAD:refs/heads/{BRANCH}'],env=ENV,capture_output=True,timeout=120)
(COORD/'portable-v2-pr800-derived-lock-push-v266.log').write_bytes(push.stdout+push.stderr)
assert push.returncode==0
remote=call(['git','-C',str(TREE),'ls-remote','origin',f'refs/heads/{BRANCH}']).decode().split()[0]
assert remote==HEAD
call(['gh','pr','edit','800','--repo',REPO,'--body-file',str(body_path)])
proof.update(published=True,verifiedRemoteHead=remote,bodyUpdated=True)
path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
