from datetime import datetime,timezone
import copy
import json
from pathlib import Path
import subprocess

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
results=[]
def git(*args,cwd=REPO):return subprocess.check_output(['git','-C',str(cwd),*args])
for number in (790,800,791,787,796,784,825,811):
    source=json.loads((COORD/('portable-v2-pr'+str(number)+'-website-main-union-v224.json')).read_bytes())
    parent=source['head']
    metadata=json.loads(git('show',parent+':tools/ci/suites.json'))
    row=next(r for r in metadata['suites'] if r['id']=='latent-wasmtime.test.aot-sandbox')
    before=copy.deepcopy(row)
    if row['minimumCases']>=1:
        results.append(dict(pr=number,parent=parent,head=parent,floor=row['minimumCases'],changed=False))
        continue
    assert row['minimumCases']==0 and row['mode']=='custom' and row['successMarker']=='AOT sandbox: 12 unprivileged real-entry probes and exact-policy syscall probe passed'
    tree=Path(r'C:\Users\turkins\Desktop')/('lf-p4-pr'+str(number)+'-aot-floor-v233')
    assert not tree.exists()
    branch='fix/phase4-pr'+str(number)+'-aot-floor-v233'
    git('worktree','add','--no-checkout','-b',branch,str(tree),parent)
    git('sparse-checkout','set','--no-cone','tools/ci/suites.json',cwd=tree)
    git('checkout',branch,cwd=tree)
    row['minimumCases']=1
    assert {k:v for k,v in row.items() if k!='minimumCases'}=={k:v for k,v in before.items() if k!='minimumCases'}
    (tree/'tools/ci/suites.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n',encoding='utf8')
    git('diff','--check',cwd=tree)
    git('add','tools/ci/suites.json',cwd=tree)
    git('commit','-m','ci: restore required native AOT sandbox case floor',cwd=tree)
    head=git('rev-parse','HEAD',cwd=tree).decode().strip()
    results.append(dict(pr=number,parent=parent,head=head,floor=1,changed=True,tree=str(tree),
                        onlyAOTMinimumCasesChanged=True,allCaseIgnoreRecipePlatformResourcesPreserved=True,
                        originalNativeBodyAndMarkerUnchanged=True,freshSourceAndActualSandboxRequired=True))
proof=dict(at=datetime.now(timezone.utc).isoformat(),records=results,noPublication=True,priorFailedOrZeroFloorReceiptsPreserved=True)
(COORD/'portable-v2-owned-aot-floor-restored-v233.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
