from datetime import datetime, timezone
import ast
import json
from pathlib import Path
import subprocess

TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr796-current-main-v217')
COORD=Path(__file__).resolve().parent
PARENT='43503d8cfbd9e938aa6d798ccd00059efdae8e9e'
MAIN='0cd6c2e8649e8181366e0adbfe03da1bf2a3c7a3'
def git(*args):return subprocess.check_output(['git','-C',str(TREE),*args])
path='tools/tests/test_java_server_source.py'
text=(TREE/path).read_text(encoding='utf8')
start=text.index('<<<<<<< HEAD\n')
middle=text.index('=======\n',start)
end=text.index('>>>>>>> '+MAIN+'\n',middle)+len('>>>>>>> '+MAIN+'\n')
ours=text[start+len('<<<<<<< HEAD\n'):middle]
theirs=text[middle+len('=======\n'):end-len('>>>>>>> '+MAIN+'\n')]
assert ours.replace('/* controlled empty-world canonical bridge: no transaction imports */','/* controlled import probe */')==theirs
merged=text[:start]+ours+text[end:]
assert '<<<<<<<' not in merged and '>>>>>>>' not in merged
def test_bodies(data):
    root=ast.parse(data)
    return {node.name:ast.dump(node,include_attributes=False) for c in root.body if isinstance(c,ast.ClassDef)
            for node in c.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')}
current=test_bodies(merged)
for head in (PARENT,MAIN):
    old=test_bodies(git('show',head+':'+path).decode())
    assert set(old)<=set(current)
    for name,body in old.items():
        if name!='test_c_compile_uses_actual_generated_bridge_before_wasm_tools':
            # The sole changed literal is a comment in generated empty-world C.
            if body!=current[name]:
                original=git('show',head+':'+path).decode().replace('/* controlled import probe */','/* controlled empty-world canonical bridge: no transaction imports */')
                assert test_bodies(original)[name]==current[name],name
(TREE/path).write_text(merged,encoding='utf8')
git('add','--sparse','tools/ci/suites.json',path)
assert not git('ls-files','-u')
rows={row['id']:row for row in json.loads(git('show',':tools/ci/suites.json'))['suites']}
for head in (PARENT,MAIN):
    for old in json.loads(git('show',head+':tools/ci/suites.json'))['suites']:
        new=rows[old['id']]
        assert old['minimumCases']<=new['minimumCases']
        for field in ['expectedCases','expectedIgnored','ignoredLeaves','expectedCustomCases','prerequisites']:
            assert set(old.get(field,[]))<=set(new.get(field,[]))
git('diff','--cached','--check')
git('commit','-m','merge development into current Phase4 retention repair')
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=796,parent=PARENT,development=MAIN,head=git('rev-parse','HEAD').decode().strip(),
           tree=str(TREE),allParentCasesFloorsIgnoresPrerequisitesPreserved=True,allFixtureTestBodiesPreserved=True,
           emptyWorldGeneratedCCommentConflictOnly=True,currentSourceAndNativePending=True,noPublication=True)
(COORD/'portable-v2-pr796-current-main-union-v217/receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
