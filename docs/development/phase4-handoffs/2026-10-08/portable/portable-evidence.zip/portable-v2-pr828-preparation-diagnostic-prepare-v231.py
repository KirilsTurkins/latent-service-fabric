from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
PARENT='f0322bb74085cc452cc7c9885a08b89ab218d290'
DONOR='cde3ab8ed99aa4cb62c071b66263d83d870a7afa'
TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr828-go-preparation-diag-v231')
paths=['crates/latent-wasmtime/tests/local_service/diagnostics/reason.rs','crates/latent-wasmtime/tests/local_service_diagnostics.rs']
def git(*args,cwd=REPO):return subprocess.check_output(['git','-C',str(cwd),*args])
if not TREE.exists():
    git('worktree','add','--no-checkout','-b','fix/phase4-pr828-go-preparation-diag-v231',str(TREE),PARENT)
    git('sparse-checkout','set','--no-cone',*paths,'tools/ci/suites.json',cwd=TREE)
    git('checkout','fix/phase4-pr828-go-preparation-diag-v231',cwd=TREE)
else:
    assert git('rev-parse','HEAD',cwd=TREE).decode().strip()==PARENT
    assert set(git('diff','--name-only',cwd=TREE).decode().splitlines())<=set(paths)
review=[]
for path in paths:
    old=git('show',PARENT+':'+path)
    donor=git('show',DONOR+':'+path)
    baseline=git('show','866416fb57f2a11211fc6ecdf8896c2e5343a36a:'+path)
    assert old==baseline,('not-byte-exact-current-test-baseline',path)
    (TREE/path).write_bytes(donor)
    review.append(dict(path=path,beforeSha256=hashlib.sha256(old).hexdigest(),afterSha256=hashlib.sha256(donor).hexdigest(),testOnly=True))
metadata=json.loads((TREE/'tools/ci/suites.json').read_bytes())
donor_meta=json.loads(git('show',DONOR+':tools/ci/suites.json'))
current=next(r for r in metadata['suites'] if r['id']=='latent-wasmtime.test.local-service-diagnostics')
added=next(r for r in donor_meta['suites'] if r['id']==current['id'])
assert len(current['expectedCases'])==8 and len(added['expectedCases'])==9
assert set(current['expectedCases'])<set(added['expectedCases'])
for key in current:
    if key not in ('minimumCases','expectedCases'):assert current[key]==added[key],key
current['expectedCases']=added['expectedCases'];current['minimumCases']=9
(TREE/'tools/ci/suites.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n',encoding='utf8')
git('diff','--check',cwd=TREE)
git('add',*paths,'tools/ci/suites.json',cwd=TREE)
git('commit','-m','test(runtime): classify closed Go preparation refusals',cwd=TREE)
head=git('rev-parse','HEAD',cwd=TREE).decode().strip()
proof=dict(at=datetime.now(timezone.utc).isoformat(),parent=PARENT,head=head,tree=str(TREE),testOnlyPaths=review,
           onlyAdditiveDiagnosticCase8to9=True,allOriginalRuntimeGuest10BodiesAndBudgetsUnchanged=True,
           sourceAndNativePending=True,noProductCauseOrRepairClaim=True,noPublication=True)
(COORD/'portable-v2-pr828-preparation-diagnostic-prepared-v231.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
