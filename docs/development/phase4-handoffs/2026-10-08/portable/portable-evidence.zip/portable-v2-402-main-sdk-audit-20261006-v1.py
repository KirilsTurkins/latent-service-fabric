from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys

root = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
out = Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-main-sdk-reconcile-20261006-v1")
out.mkdir(exist_ok=True)
sys.path.insert(0, str(root))
from tools import ci_contracts as contracts

def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, timeout=60)

paths = git("diff", "--name-only", "--diff-filter=U").decode().splitlines()
models = contracts.observed_workflows(root)
report = []
for name in paths:
    raw = []
    for index, label in ((2, "ours"), (3, "incoming")):
        value = git("show", ":" + str(index) + ":" + name)
        target = out / label / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(value)
        raw.append(value)
    row = {"path": name}
    if name.endswith(".json"):
        ours, incoming = [contracts.semantic_record(json.loads(value)) for value in raw]
        row["kind"] = ours["kind"]
        row["sameExceptReason"] = {key: value for key, value in ours.items() if key != "reviewReason"} == {key: value for key, value in incoming.items() if key != "reviewReason"}
        if row["kind"] == "job":
            actual = models[ours["workflow"]]["jobs"][ours["jobId"]]
            row["stepCounts"] = [len(value["definition"]["steps"]) for value in (ours, incoming)] + [len(actual["steps"])]
            old_steps = [value["definition"]["steps"] for value in (ours, incoming)]
            row["missingParentSteps"] = [[step.get("name",step.get("uses","?")) for step in values if step not in actual["steps"]] for values in old_steps]
            row["parentDeadlines"] = [value["definition"].get("timeout-minutes") for value in (ours, incoming)]
            row["actualDeadline"] = actual.get("timeout-minutes")
            row["sameHistoricalBefore"] = ours["before"] == incoming["before"]
            row["sameHistoricalCoverage"] = ours["coverage"] == incoming["coverage"]
        if row["kind"] == "workflow":
            row["parentJobs"] = [value["requiredJobs"] for value in (ours, incoming)]
            row["actualJobs"] = list(models[ours["workflow"]]["jobs"])
        if row["kind"] == "python":
            row["cases"] = [len(value["cases"]) for value in (ours, incoming)]
    else:
        row["kind"] = "source"
    report.append(row)
(out / "audit.json").write_text(json.dumps(report, indent=2)+"\n",encoding="utf8")
for row in report:
    print(json.dumps(row))
