from pathlib import Path
import copy
import hashlib
import json
import sys

root=Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-notification-source-20261006-v3')
out.mkdir(exist_ok=False)
sys.path.insert(0,str(root))
from tools import ci_contracts as c
name='tools/ci/contracts/python/test_stateful_reference_project.py.json'
path=root/name
raw=path.read_bytes()
(out/'contract-before.json').write_bytes(raw)
before=c.semantic_record(json.loads(raw))
actual=c.python_expectations(root)[before['module']]
added={
    'StatefulReferenceProject.test_six_notification_captures_package_exact_profile_bytes_without_grants',
    'StatefulReferenceProject.test_notification_packaging_refuses_payload_scope_media_and_count_drift',
    'StatefulReferenceProject.test_notification_selector_requires_exact_namespace_and_command_query_contract',
}
assert set(actual['cases'])==set(before['cases'])|added
for case,guard in before['guards'].items():
    assert actual['guards'][case]==guard,(case,'old-guard-drift')
expected_guard=next(iter(before['guards'].values()))
for case in added:
    assert actual['guards'][case]==expected_guard,(case,'new-guard')
after=copy.deepcopy(before)
after.update(actual)
after['reviewReason'] += ' Reviewed finite order-draft notification integration: six real creators capture and package the exact per-draft octet-stream requirements; altered payload/media/namespace/companion/count/authority/ceiling values fail before output. The maximum valid draft identity is exercised and wrong namespaces/operation contracts are refused. All prior case bodies and setup/skip/decorator guards remain required; compiler/node/provider qualification stays separate.'
if json.loads(raw)['schemaVersion']==c.PYTHON_STORAGE_SCHEMA:
    after=c.shared_python_record(after)
compact=b'\n' not in raw.rstrip()
text=json.dumps(after,ensure_ascii=False,separators=(',',':') if compact else None,indent=None if compact else 2)+'\n'
path.write_bytes(text.encode())
(out/'contract-review.json').write_text(json.dumps({'path':name,'beforeSha256':hashlib.sha256(raw).hexdigest(),'afterSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'explicitNewCases':sorted(added),'oldGuardsExact':True},indent=2)+'\n')
print(json.dumps({'priorCases':len(before['cases']),'additionalCases':len(added),'allPriorGuardsExact':True}))
