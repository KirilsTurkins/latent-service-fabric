from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out = Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
pattern = re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]+\n', re.M | re.S)
decisions = {
    'docs/development/security-baseline.md': ['ours'],
    'docs/component-development/java-authoring.md': ['both'],
    'docs/component-development/transactional-authoring.md': ['incoming', 'ours'],
    'tools/tests/test_transaction_guest_authoring.py': ['both', 'ours', 'ours', 'ours'],
    'tools/tests/test_transaction_guest_compilers.py': ['incoming', 'incoming'],
    'tools/tests/test_capability_policy_schema.py': ['matrices'],
}
records = []
for name, choices in decisions.items():
    path = root / name
    raw = path.read_bytes()
    source = raw.decode()
    matches = list(pattern.finditer(source))
    assert len(matches) == len(choices), (name, len(matches), len(choices))
    index = 0
    def resolve(match):
        global index
        choice = choices[index]
        index += 1
        if choice == 'both':
            return match[1] + ('\n' if match[1].strip() and match[2].strip() else '') + match[2]
        if choice == 'matrices':
            assert 'for version in (2, 3, 4)' in match[2]
            return match[2].replace('for version in (2, 3, 4)', 'for version in (2, 3, 4, 5)')
        return match[1] if choice == 'ours' else match[2]
    result = pattern.sub(resolve, source)
    assert not pattern.search(result)
    path.write_text(result, encoding='utf8', newline='\n')
    records.append({'path': name, 'before': hashlib.sha256(raw).hexdigest(), 'after': hashlib.sha256(path.read_bytes()).hexdigest(), 'hunks': choices})
# These two files were already individually reconciled with current 64/72 MiB
# bounds and the current controlled-resource probe. Preserve the reviewed bytes.
for name in ('tools/tests/test_build_snapshot.py', 'tools/tests/test_java_resource_runtime.py'):
    assert not pattern.search((root / name).read_text())
    records.append({'path': name, 'existingReviewedResolutionRetained': True})
# Main's negative component deliberately stages before the exact typed denial;
# the incoming pre-stage trap variant cannot qualify rollback.
name = 'tools/transaction_guest_variants.py'
assert (root / name).read_bytes() == subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=root)
records.append({'path': name, 'mainTypedPermissionDeniedAfterStagingRetained': True})
subprocess.run(['git', 'add', '--', *(value['path'] for value in records)], cwd=root, check=True)
(out / 'source-resolution-v2.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'resolvedSourcePaths': len(records), 'historicalAndActiveAbiMatrices': [2, 3, 4, 5], 'noNegativeRollbackWeakening': True}))
