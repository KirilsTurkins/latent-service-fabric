"""Measure storage options without changing source, thresholds or history bytes."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-common-braces-runtime-20261006")
COORD = Path(__file__).resolve().parent
HEAD = "2298d9dd437b9c54aa9b524ddcd65348dc1428b5"
HISTORY = "tools/ci/history/commands-v1.json"
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=30)
assert git("rev-parse", "HEAD").decode().strip() == HEAD and not git("status", "--porcelain").strip()
raw = git("show", HEAD + ":" + HISTORY)
compact = (json.dumps(json.loads(raw), separators=(",", ":"), ensure_ascii=False) + "\n").encode()
packed = gzip.compress(raw, compresslevel=9, mtime=0)
assert gzip.decompress(packed) == raw and gzip.compress(raw, compresslevel=9, mtime=0) == packed
source = json.loads((COORD / "portable-v2-current-main-preparation-20261006-v1/source-inventory.json").read_bytes())
ordinary = []
for row in source:
    path = row["path"]
    if not path.endswith(".json") or "package-lock.json" in path or path.startswith("tools/ci/"):
        continue
    original = git("show", HEAD + ":" + path)
    try:
        value = json.loads(original)
    except ValueError:
        continue
    result = (json.dumps(value, separators=(",", ":"), ensure_ascii=False) + "\n").encode()
    saving = len(original) - len(result)
    if saving > 0:
        ordinary.append({"path": path, "beforeBytes": len(original), "potentialSavedBytes": saving})
receipt = {"at": datetime.now(timezone.utc).isoformat(), "head": HEAD, "historyPath": HISTORY,
           "historyDecodedBytes": len(raw), "historyDecodedSha256": hashlib.sha256(raw).hexdigest(),
           "historyJsonCompactionSavedBytes": len(raw) - len(compact), "historyGzipBytes": len(packed),
           "historyGzipSha256": hashlib.sha256(packed).hexdigest(), "historyGzipSavedBytes": len(raw) - len(packed),
           "historyGzipHeaderHex": packed[:10].hex(), "decodedBytesUnchanged": True,
           "ordinaryJsonPotentialSavedBytes": sum(row["potentialSavedBytes"] for row in ordinary),
           "ordinaryJsonCandidates": sorted(ordinary, key=lambda row: row["potentialSavedBytes"], reverse=True),
           "sourceChanged": False, "qualified": False}
output = COORD / "portable-v2-history-storage-measurement-20261006.json"
assert not output.exists()
output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps({key: value for key, value in receipt.items() if key != "ordinaryJsonCandidates"}), flush=True)
