from datetime import datetime,timezone
import copy
import hashlib
import json
from pathlib import Path
import subprocess

TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr811-peer-signing-v250')
COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-pr811-peer-signing-union-v250'
OUT.mkdir()
OURS='091c4b2f2e323a4d2242246d4d1c362c7aa1248a'
PEER='74368f3f9ff40d0457316d75b8606c60d77744e5'
MAIN='c84473ec9868fc496486f864afe52f1b7105329f'
def git(*args):return subprocess.check_output(['git','-C',str(TREE),*args])
path='tools/ci/suites.json'
raws=[git('show',f':{n}:{path}') for n in (1,2,3)]
for n,raw in enumerate(raws,1):(OUT/f'suites-stage{n}.json').write_bytes(raw)
o,t=[json.loads(raws[n]) for n in (1,2)]
assert {k:v for k,v in o.items() if k!='suites'}=={k:v for k,v in t.items() if k!='suites'}
result=copy.deepcopy(o)
union={'expectedCases','expectedIgnored','ignoredLeaves','expectedCustomCases','prerequisites'}
left,right=[{r['id']:r for r in p['suites']} for p in (o,t)]
rows=[]
for identity in sorted(set(left)|set(right)):
    a,b=left.get(identity),right.get(identity)
    if a is None:row=copy.deepcopy(b)
    elif b is None:row=copy.deepcopy(a)
    else:
        row={}
        for k in set(a)|set(b):
            if k in union:row[k]=sorted(set(a.get(k,[]))|set(b.get(k,[])))
            elif k=='minimumCases':row[k]=max(a[k],b[k],len(set(a.get('expectedCases',[]))|set(b.get('expectedCases',[]))))
            else:assert a.get(k)==b.get(k),(identity,k);row[k]=a.get(k)
    rows.append(row)
result['suites']=rows
(TREE/path).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf8')
signing_paths=git('diff','--name-only','9f7aab58400d446f451964dc492b34dc46d09f14',MAIN,'--','crates/latent-signing').decode().splitlines()
assert len(signing_paths)==6
review=[]
for p in signing_paths:
    original=git('show',OURS+':'+p)
    assert original==git('show',MAIN+':'+p)
    try:auto=git('show',':'+p)
    except subprocess.CalledProcessError:auto=b''
    target=TREE/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original)
    review.append(dict(path=p,mainSha256=hashlib.sha256(original).hexdigest(),autoMergeChanged=original!=auto))
git('add','--sparse',path,*signing_paths)
assert not git('ls-files','-u')
assert next(r for r in rows if r['id']=='latent-signing.lib.latent-signing')['minimumCases']==58
assert next(r for r in rows if r['id']=='latent-wasmtime.test.aot-sandbox')['minimumCases']==1
git('diff','--cached','--check')
git('commit','-m','merge peer completion history while retaining current trust readers and SDK descriptors')
head=git('rev-parse','HEAD').decode().strip()
changed=git('diff','--name-only',OURS,head).decode().splitlines()
assert set(changed)<= {'tools/ci/suites.json'},changed
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=811,head=head,parent=OURS,peer=PEER,tree=str(TREE),
           signingReview=review,actualReviewedC844SigningBodiesRetained=True,allSixSigningCasesAndAOT1Required=True,
           allPeerModelAndOwnedDescriptorFieldsRetained=True,allOtherTrackedBytesFromOwnedParentUnchanged=True,
           freshSourceAndNativePending=True,noPublication=True)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
