import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

COORD = Path(__file__).resolve().parent
TREE = Path(r"C:\Users\turkins\Desktop\lf-p4-control-preparation-stages-v301")
REPO = "KirilsTurkins/latent-service-fabric"
OLD = "756a492b1678dec5e4f69dac11c571acc3836dd1"
NEW = "1b7a8073f9ec7b354a4dd00a365deb1c4094e3aa"
JOB = COORD / "portable-v2-control-preparation-stage-cli-source-20261008-v305"
ENV = dict(os.environ, GODEBUG="http2client=0")
VERIFY_ONLY = sys.argv[1:] == ["--verify-existing-publication"]
assert not sys.argv[1:] or VERIFY_ONLY


def run(argv, cwd=None):
    return subprocess.check_output(argv, cwd=cwd, env=ENV, timeout=90).decode("utf-8").strip()


def api(path):
    return json.loads(run(["gh", "api", f"repos/{REPO}/{path}"]))


receipt_raw = (JOB / "receipt.json").read_bytes()
receipt = json.loads(receipt_raw)
assert receipt["head"] == NEW and receipt["passed"]
assert receipt["sourceClean"] and receipt["sourceHeadUnchanged"] and receipt["originalProcessReaped"]
assert receipt["infrastructureError"] is None and len(receipt["steps"]) == 7
for row in receipt["steps"]:
    raw = (JOB / row["log"]).read_bytes()
    assert row["exitCode"] == 0 and row["stopReason"] is None and row["originalProcessReaped"]
    assert hashlib.sha256(raw).hexdigest() == row["sha256"] and len(raw) == row["bytes"]
assert run(["git", "rev-parse", "HEAD"], TREE) == NEW
assert not run(["git", "status", "--porcelain"], TREE)
subprocess.run(["git", "merge-base", "--is-ancestor", OLD, NEW], cwd=TREE, check=True)
parent_json = json.loads(run(["git", "show", f"{OLD}:tools/ci/suites.json"], TREE))
current_json = json.loads(run(["git", "show", f"{NEW}:tools/ci/suites.json"], TREE))
changes = {"latent-control-store.lib.latent-control-store": 3, "latent.lib.latent": 1}
for before, after in zip(parent_json["suites"], current_json["suites"], strict=True):
    assert before["id"] == after["id"]
    delta = changes.get(before["id"], 0)
    assert set(before.get("expectedCases", [])) <= set(after.get("expectedCases", []))
    assert after["minimumCases"] == before["minimumCases"] + delta
    for key in before:
        if key not in ("expectedCases", "minimumCases"):
            assert after[key] == before[key], (before["id"], key)
for key in parent_json:
    if key != "suites":
        assert current_json[key] == parent_json[key]
pr = api("pulls/828")
assert pr["state"] == "open" and pr["base"]["ref"] == "development"
assert pr["head"]["sha"] == (NEW if VERIFY_ONLY else OLD), "live-head-moved-before-publication"
branch = pr["head"]["ref"]
assert run(["git", "ls-remote", "origin", f"refs/heads/{branch}"], TREE).split()[0] == (NEW if VERIFY_ONLY else OLD)

body = """Shared HTTP ingress routes transactional commands, queries and original-result recovery through the installed transaction owners. Admission retains the original deadline, caller and source policy, charges native request/response ownership and permits bounded recovery while ordinary responses remain retained. The native inspection command observes actual retirement; current Java packaging and typed client models stay synchronized.

Current development 21cfd221 is integrated. All inherited cases, ignores, limits and the original AOT sandbox floor remain. The current renderer repair retains each reviewed typed RPC floor-release case once, and transactional authoring is restored to Learn with all six compiler references. Both bounded route collectors remain on the same single request.

The retained Go workflow passed both ten-case SDK suites, then rejected deployment preparation with the existing clock-lease currentness error. The original audit proves the writer was not entered. A closed diagnostic now identifies the failing preparation stage without changing the original error, authority, renewal calls, deadline, budget or mutation attempt. The CLI accepts only six fixed stage values and omits arbitrary peer data. Three additive ControlStore cases and one CLI wire/privacy case are registered; the branch-specific floors increase252 to255 and161 to162.

This exact head passes all seven Linux Source gates:375 discovered cases,374 passed and one original Windows skip, SDK13, locked libprotoc31.1 Node descriptor verification, formatting and full locked offline metadata. Actual current Rust255/CLI162/RPC27 execution, full website132 and fresh hosted CI remain pending because the local runner is below its disk floor. Historical signing58 and Node116/Wire193/daemon282 with27 original ignores retain their actual c844 parent receipts; the custom AOT harness retains its separate12 real probes and syscall proof. Full signed public HTTP/browser qualification and complete #409 acceptance remain pending.
"""
body_path = COORD / "portable-v2-pr828-current-control-stage-body-v306.md"
body_path.write_text(body, encoding="utf-8")
if not VERIFY_ONLY:
    subprocess.run(["git", "-c", "http.version=HTTP/1.1", "push", "origin", f"{NEW}:refs/heads/{branch}"], cwd=TREE, env=ENV, check=True, timeout=180)
assert run(["git", "ls-remote", "origin", f"refs/heads/{branch}"], TREE).split()[0] == NEW
if not VERIFY_ONLY:
    subprocess.run(["gh", "pr", "edit", "828", "--repo", REPO, "--body-file", str(body_path)], env=ENV, check=True, timeout=90)
final_pr = api("pulls/828")
assert final_pr["head"]["sha"] == NEW
assert final_pr["body"].replace("\r\n", "\n").strip() == body.strip()
failure = {"code": "unavailable", "retryable": True, "details": [{"kind": "admission.currentness", "fields": {"reason": "admission-clock-lease-uncovered"}}]}
shape_example = json.loads(json.dumps(failure))
shape_example["details"].append({"kind": "admission.control-stage", "fields": {"stage": "package-read"}})
result = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "pr": 828,
    "oldHead": OLD, "head": NEW, "branch": branch,
    "normalPush": True, "forcePush": False, "remoteVerified": True,
    "postPublicationVerificationOnly": VERIFY_ONLY,
    "initialVerificationIssue": "GitHub body uses CRLF; first exact LF comparison refused after successful normal push/body edit." if VERIFY_ONLY else None,
    "remoteBodySha256": hashlib.sha256(final_pr["body"].encode("utf-8")).hexdigest(),
    "sourceReceipt": str(JOB / "receipt.json"), "sourceReceiptSha256": hashlib.sha256(receipt_raw).hexdigest(),
    "allSourceLogsAuthenticated": True, "sourceProcessesReaped": True,
    "originalErrorShape": failure, "exampleReportedShape": shape_example,
    "exampleIsContractReviewNotObservedControl29Stage": True,
    "onlyOneFiniteStageAdded": True, "originalErrorFieldsPreserved": True,
    "allOriginalCaseFloorsLimitsAndIgnoresPreserved": True,
    "currentNativeExecuted": False, "completeCI": False, "issueClosed": False,
    "changedPaths": run(["git", "diff", "--name-only", OLD, NEW], TREE).splitlines(),
}
(COORD / "portable-v2-control-stage-source-publication-v306.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in result.items() if k not in ("originalErrorShape", "exampleReportedShape", "changedPaths")}))
