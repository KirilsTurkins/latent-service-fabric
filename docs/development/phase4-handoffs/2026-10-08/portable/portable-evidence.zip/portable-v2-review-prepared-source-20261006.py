"""Review the prepared v4 fixture and lossless lock compaction, without rebuilding."""
from dataclasses import asdict
from datetime import datetime, timezone
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-common-braces-runtime-20261006")
OUT = Path(__file__).resolve().parent / "portable-v2-current-main-preparation-20261006-v1"
BASE = "502389acd45ffd3b611db64168f7651dad8da8b6"
LOCKS = ["website/package-lock.json", "examples/framework-compatibility/package-lock.json", "website/toolchain/package-lock.json"]
sys.path.insert(0, str(ROOT))
from tools.build_snapshot import SOURCE_ALLOWLIST, SnapshotLimits, portable_path

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=60)

assert git("rev-parse", "HEAD").decode().strip() == BASE
assert OUT.is_dir() and not (OUT / "receipt.json").exists()
failure = {"preparationExitCode": 1, "reason": "Four actual changed paths, because the framework lock was already compact.",
           "guardsWeakened": False, "qualified": False, "failedInvocationPreserved": True}
(OUT / "preparation-shape-failure.json").write_text(json.dumps(failure, indent=2) + "\n", encoding="utf8")
records = []
for path in LOCKS:
    previous = (OUT / "before" / path).read_bytes()
    assert previous == git("show", BASE + ":" + path)
    result = (ROOT / path).read_bytes().replace(b"\r\n", b"\n")
    assert json.loads(previous) == json.loads(result)
    records.append({"path": path, "beforeBytes": len(previous), "afterBytes": len(result),
                    "beforeSha256": hashlib.sha256(previous).hexdigest(),
                    "afterSha256": hashlib.sha256(result).hexdigest(), "parsedGraphUnchanged": True})
inventory_path = ".github/security/inventory.json"
prior_inventory = json.loads((OUT / "before" / inventory_path).read_bytes())
inventory = json.loads((ROOT / inventory_path).read_bytes())
reconstructed = json.loads(json.dumps(inventory))
pins = []
for row in reconstructed["manifests"]:
    if row.get("lock") not in LOCKS:
        continue
    record = next(record for record in records if record["path"] == row["lock"])
    profile = next(key for key in ("derived_bundle", "derived_libraries") if key in row)
    assert row[profile]["lock_sha256"] == record["afterSha256"]
    row[profile]["lock_sha256"] = record["beforeSha256"]
    pins.append({"manifest": row["path"], "lock": row["lock"], "profile": profile,
                 "beforeSha256": record["beforeSha256"], "afterSha256": record["afterSha256"]})
assert len(pins) == 3 and reconstructed == prior_inventory
# Keep the existing compact inventory convention, changing only reviewed lock byte pins.
(ROOT / inventory_path).write_text(json.dumps(inventory, separators=(",", ":"), ensure_ascii=False) + "\n", encoding="utf8", newline="\n")

fixture_path = "website/toolchain/tests/test_prepare.py"
old_module, new_module = ast.parse(git("show", BASE + ":" + fixture_path)), ast.parse((ROOT / fixture_path).read_bytes())
def cases(module):
    cls = next(node for node in module.body if isinstance(node, ast.ClassDef) and node.name == "PreparationTests")
    return {node.name: node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}
old_cases, new_cases = cases(old_module), cases(new_module)
assert set(new_cases) - set(old_cases) == {"test_selector_uses_only_the_existing_exact_dependencies", "test_selector_rejects_changed_dependencies_and_shadowed_resolution"}
assert set(old_cases) <= set(new_cases)
for name, previous in old_cases.items():
    result = new_cases[name]
    if name == "test_complete_packages_replaced_without_stale_files":
        loop = result.body[1]
        assert isinstance(loop, ast.With)
        extra = [node for node in loop.body if "postcss-selector-parser/obsolete.js" in ast.dump(node)]
        assert len(extra) == 1
        loop.body.remove(extra[0])
    assert ast.dump(previous, include_attributes=False) == ast.dump(result, include_attributes=False), name

paths = [inventory_path, "website/package-lock.json", "website/toolchain/package-lock.json", fixture_path]
subprocess.run(["git", "add", "--", *paths], cwd=ROOT, check=True)
assert set(git("diff", "--cached", "--name-only").decode().splitlines()) == set(paths)
subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, check=True)
tree = git("write-tree").decode().strip()
limits = SnapshotLimits(max_total_bytes=32 * 1024 * 1024, max_archive_bytes=40 * 1024 * 1024)
limits.validate()
rows, directories, roots = [], set(), set()
for raw in git("ls-tree", "-r", "-z", "--long", tree, "--", *SOURCE_ALLOWLIST).split(b"\0"):
    if not raw:
        continue
    metadata, encoded_path = raw.split(b"\t", 1)
    mode, kind, oid, size = metadata.split()
    assert mode in {b"100644", b"100755"} and kind == b"blob"
    selected = portable_path(encoded_path.decode("ascii"))
    size = int(size)
    assert size <= limits.max_file_bytes
    rows.append({"path": selected, "gitBlob": oid.decode(), "bytes": size})
    directories.update(str(parent) for parent in PurePosixPath(selected).parents if str(parent) != ".")
    roots.update(root for root in SOURCE_ALLOWLIST if selected == root or selected.startswith(root + "/"))
assert len(rows) <= limits.max_entries and len(directories) <= limits.max_directories
total = sum(row["bytes"] for row in rows)
archive = OUT / ("source-" + tree[:16] + ".tar")
subprocess.run(["git", "archive", "--format=tar", "--output=" + str(archive), tree, "--", *sorted(roots)], cwd=ROOT,
               check=True, capture_output=True, timeout=60)
with tarfile.open(archive, "r:") as reader:
    members = reader.getmembers()
    assert all(member.isfile() or member.isdir() for member in members)
    assert {member.name: member.size for member in members if member.isfile()} == {row["path"]: row["bytes"] for row in rows}
with archive.open("rb") as reader:
    archive_sha = hashlib.file_digest(reader, "sha256").hexdigest()
receipt = {"at": datetime.now(timezone.utc).isoformat(), "base": BASE, "tree": tree, "paths": paths,
           "lockCompaction": records, "inventoryPins": pins, "captureLimitsReviewed": asdict(limits),
           "productionCaptureLimitsChanged": False, "dependencyGraphChanged": False,
           "priorFixtureCases": len(old_cases), "newFixtureCases": len(new_cases), "allExistingAssertionsPreserved": True,
           "sourceFiles": len(rows), "sourceDirectories": len(directories), "sourceBytes": total,
           "sourceHeadroomBytesAt32MiB": limits.max_total_bytes - total,
           "archiveBytes": archive.stat().st_size, "archiveSha256": archive_sha,
           "archiveHeadroomBytesAt40MiB": limits.max_archive_bytes - archive.stat().st_size,
           "fits32And40MiB": total <= limits.max_total_bytes and archive.stat().st_size <= limits.max_archive_bytes,
           "completeCI": False, "committed": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
(OUT / "source-inventory.json").write_text(json.dumps(rows, separators=(",", ":")) + "\n", encoding="utf8")
print(json.dumps({key: value for key, value in receipt.items() if key not in {"lockCompaction", "inventoryPins"}}), flush=True)
