import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

COORD = Path(__file__).resolve().parent
REPO = "KirilsTurkins/latent-service-fabric"
ENV = dict(os.environ, GODEBUG="http2client=0")
OUT = COORD / "portable-v2-pr825-infra-rerun-result-v317"
OUT.mkdir(exist_ok=True)


def api(path, name):
    raw = subprocess.check_output(["gh", "api", f"repos/{REPO}/{path}"], env=ENV, timeout=60)
    (OUT / name).write_bytes(raw)
    return json.loads(raw)


run = api("actions/runs/37729173027", "run.json")
jobs = api("actions/runs/37729173027/attempts/2/jobs?per_page=100", "attempt-2-jobs.json")
assert run["head_sha"] == "601038c2b908144dadd11bcb48ddbab51606b5d4"
assert run["run_attempt"] == 2 and run["status"] == "completed" and run["conclusion"] == "success"
assert jobs["jobs"] and all(j["status"] == "completed" and j["conclusion"] in {"success", "skipped"} for j in jobs["jobs"])
result = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "head": run["head_sha"],
    "run": run["id"], "attempt": run["run_attempt"], "status": run["status"], "conclusion": run["conclusion"],
    "requestedOnlyOriginalJob": 113154150383,
    "completedAttemptJobs": [{"id": j["id"], "name": j["name"], "conclusion": j["conclusion"]} for j in jobs["jobs"]],
    "originalFailureRawSha256": "7a4e6aaee9800a91fe4d0348b065a059af8abb2be2267a1b8a18832a0a438359",
    "sourceAndWorkflowUnchanged": True, "otherWorkflowsQualified": False, "completeCI": False,
    "runObservationSha256": hashlib.sha256((OUT / "run.json").read_bytes()).hexdigest(),
}
(OUT / "receipt.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
