"""Create the six real SDK-authored application projects and retain source identities."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
OUT = Path(__file__).resolve().parent / "portable-v2-402-created-projects-20261006-v1"
sys.path.insert(0, str(ROOT))
from tools.stateful_reference_project import LANGUAGES, SOURCES, create
OUT.mkdir()
records = []
for language in LANGUAGES:
    project = create(OUT / language, language)
    descriptor = json.loads((project / "capsule-project.json").read_bytes())
    companion = json.loads((project / "transaction-binding.json").read_bytes())
    source = (project / SOURCES[language][1]).read_bytes()
    records.append({"language": language, "project": str(project), "world": descriptor["world"],
                    "sourceBytes": len(source), "sourceSha256": hashlib.sha256(source).hexdigest(),
                    "companionSha256": hashlib.sha256((project / "transaction-binding.json").read_bytes()).hexdigest(),
                    "stateSchema": companion["stateSchema"], "namespace": companion["namespace"],
                    "operations": companion["operations"], "compiled": False, "signed": False, "executionQualified": False})
receipt = {"at": datetime.now(timezone.utc).isoformat(), "root": str(ROOT), "records": records,
           "allSixProjectsCreated": len(records) == 6, "componentCompilationClaimed": False,
           "qualificationClaimed": False, "peerTreesModified": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps(receipt), flush=True)
