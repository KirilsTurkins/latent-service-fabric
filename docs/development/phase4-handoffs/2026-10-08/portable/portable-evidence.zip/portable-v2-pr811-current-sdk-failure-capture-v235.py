from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-pr811-current-sdk-failure-v235'
OUT.mkdir(exist_ok=True)
ENV=dict(os.environ,GODEBUG='http2client=0')
REPO='KirilsTurkins/latent-service-fabric'
JOB=113123427114;RUN=37714109815
def api(endpoint):return subprocess.check_output(['gh','api',endpoint],env=ENV,timeout=120)
jm=api(f'repos/{REPO}/actions/jobs/{JOB}');rm=api(f'repos/{REPO}/actions/runs/{RUN}');raw=api(f'repos/{REPO}/actions/jobs/{JOB}/logs')
j,r=json.loads(jm),json.loads(rm)
assert j['run_id']==RUN and j['status']=='completed' and j['conclusion']=='failure'
for name,data in [('job.json',jm),('run.json',rm),('raw.log',raw)]: (OUT/name).write_bytes(data)
lines=re.sub(r'\x1b\[[0-9;]*m','',raw.decode('utf8')).splitlines()
diagnostics=[line[:650] for line in lines if any(s in line for s in ('InvalidOperationException','not all shared','Vectors.cs:','SecurityError:','error CS','error NU','FAILED'))][-18:]
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=811,job=JOB,run=RUN,head=r['head_sha'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
           failedSteps=[s['name'] for s in j['steps'] if s.get('conclusion')=='failure'],diagnostics=diagnostics,readOnly=True)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
