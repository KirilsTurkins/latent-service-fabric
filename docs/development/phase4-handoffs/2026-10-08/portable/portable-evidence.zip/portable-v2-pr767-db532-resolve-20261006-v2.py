"""Apply the individually reviewed nine-contract merge without reformatting JSON."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

root = Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
out = Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-pr767-db532-reconcile-20261006-v2")
sys.path.insert(0, str(root))
from tools import ci_contracts as contracts
def git(*argv):
    return subprocess.check_output(["git", *argv], cwd=root, timeout=60).decode().strip()
assert git("rev-parse", "HEAD") == "259f5fd96526a2f7a4f7a4dbf55a5658363142c3"
assert git("rev-parse", "MERGE_HEAD") == "db532ce3f18e867ded98b248c2d1797d678789b8"
observed = contracts.python_expectations(root)
audit = json.loads((out / "conflict-audit.json").read_bytes())
resolved = []
for row in audit:
    name = row["path"]
    raw_ours, raw_incoming = ((out / label / name).read_bytes() for label in ("ours", "incoming"))
    ours, incoming = (contracts.semantic_record(json.loads(raw)) for raw in (raw_ours, raw_incoming))
    if row["kind"] == "python":
        assert not row["lostOurs"] and not row["lostIncoming"] and not row["nonhashGuardChanges"]
        assert observed[incoming["module"]]["guards"] == incoming["guards"]
        raw, chosen = raw_incoming, incoming
    elif row["kind"] == "owner":
        assert hashlib.sha256((root / incoming["path"]).read_bytes()).hexdigest() == incoming["sha256"]
        raw, chosen = raw_incoming, incoming
    else:
        assert row["sameHistoricalBefore"] and row["sameHistoricalCoverage"] and row["sameDeadline"]
        model = contracts.observed_workflows(root)[ours["workflow"]]["jobs"][ours["jobId"]]
        assert model == ours["definition"]
        # All incoming steps remain; Root's five extra state/full-renderer and
        # proper narrow-package assertions stay in the actual workflow above.
        assert len(ours["definition"]["steps"]) == len(incoming["definition"]["steps"])
        raw, chosen = raw_ours, ours
    reason = (chosen["reviewReason"] + " Retain the other parent reviewed obligation: "
              + (ours if chosen is incoming else incoming)["reviewReason"]
              + " Current development db532 merge review: preserve every case, base, decorator, skip and nonhash fixture guard;"
                " inherit the active phase3-v5 runtime identity and immutable historical descriptor versions;"
                " retain the 64/72 MiB one-over source/archive refusals, full storage renderer selection,"
                " proper narrow graph, all deadlines, artifact controls and historical mappings.")
    text = raw.decode("utf8")
    pattern = r'("reviewReason"\s*:\s*)("(?:[^"\\]|\\.)*")'
    updated, count = re.subn(pattern, lambda match: match[1] + json.dumps(reason, ensure_ascii=False), text)
    assert count == 1
    value = contracts.semantic_record(json.loads(updated))
    assert {key: item for key, item in value.items() if key != "reviewReason"} == {
        key: item for key, item in chosen.items() if key != "reviewReason"}
    (root / name).write_bytes(updated.encode("utf8"))
    resolved.append({"path": name, "storageFormattingPreservedFrom": "incoming" if chosen is incoming else "ours",
                     "normalizedChosenObligationsUnchanged": True, "reviewed": row})
subprocess.run(["git", "add", "--", *(row["path"] for row in audit)], cwd=root, check=True)
assert not git("diff", "--name-only", "--diff-filter=U")
assert not git("diff", "--name-only")
(out / "resolution.json").write_text(json.dumps({"ours": git("rev-parse", "HEAD"),
    "incoming": git("rev-parse", "MERGE_HEAD"), "resolvedTree": git("write-tree"),
    "reviewedConflicts": resolved, "newFormattingOrCompaction": False}, indent=2) + "\n", encoding="utf8")
print(json.dumps({"conflictsResolved": len(resolved), "tree": git("write-tree"), "noUnstagedChanges": True}))
