from pathlib import Path
import hashlib,json,stat,subprocess,zipfile
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination')
repo=Path(r'C:\Users\turkins\Desktop\latent-fabric')
custody=coord/'portable-v2-pr825-completed-ci-custody-20261007-v82'
zpath=custody/'go-upstream-11472236932.zip'
head='8785fadf4d630cce34fbcbfebf65d0fbb0851d1c'
metadata=json.loads((custody/'go-artifacts.json').read_bytes())
a=next(a for a in metadata['artifacts'] if a['id']==11472236932)
raw=zpath.read_bytes();digest=hashlib.sha256(raw).hexdigest()
assert len(raw)==a['size_in_bytes']==25986483 and 'sha256:'+digest==a['digest']
assert a['workflow_run']['head_sha']==head and a['workflow_run']['id']==37587811873
out=coord/'portable-v2-pr825-retained-go-inputs-20261007-v89'
assert not out.exists();out.mkdir()
prefix='go-capsule-authoring/sdk-guests/'
roles={'go-'+r for r in ['blob','callee','events','http','metrics','random','secrets','service','streaming']}
rows=[]
with zipfile.ZipFile(zpath) as z:
 members=[i for i in z.infolist() if i.filename.startswith(prefix) and not i.is_dir()]
 assert len(members)<3000 and sum(i.file_size for i in members)<128*1024**2
 names=set()
 for info in members:
  rel=info.filename[len(prefix):]
  p=Path(rel)
  assert p.parts and not p.is_absolute() and all(q not in ('','..','.') for q in p.parts) and ':' not in rel and '\\' not in rel
  assert p.parts[0] in roles or p.parts[0] in {'SDK-BUILD.json','projects'}
  assert rel not in names and stat.S_IFMT(info.external_attr>>16)!=stat.S_IFLNK
  names.add(rel);data=z.read(info);assert len(data)==info.file_size
  target=out/'fixtures'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  rows.append(dict(path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
checks=[]
absent_capture_files=[]
for role in sorted(roles):
 root=out/'fixtures'/role
 marker=json.loads((root/'BUILD-COMPLETE.json').read_bytes())
 observation=json.loads((root/'build-observation.json').read_bytes())
 inputs=json.loads((root/'source-inputs.json').read_bytes())
 assert marker['observationDigest']=='sha256:'+hashlib.sha256((root/'build-observation.json').read_bytes()).hexdigest()
 assert observation['source']['snapshotDigest']=='sha256:'+hashlib.sha256((root/'source-inputs.json').read_bytes()).hexdigest()
 component=(root/'component.wasm').read_bytes()
 assert len(component)==observation['componentSize'] and observation['componentDigest']=='sha256:'+hashlib.sha256(component).hexdigest()
 assert (root/'package/layers/component.wasm').read_bytes()==component
 project=out/'fixtures/projects'/role.removeprefix('go-')
 for relative, identity in inputs.items():
  source_path=project/relative
  if not source_path.exists():
   assert relative=='.gitignore', (role,relative)
   absent_capture_files.append(dict(role=role,path=relative,identity=identity,reason='GitHub artifact excludes hidden project file; unchanged capture retained'))
   continue
  content=source_path.read_bytes()
  assert len(content)==identity['size'] and 'sha256:'+hashlib.sha256(content).hexdigest()==identity['digest'],(role,relative)
  if relative.startswith('vendor/lsf/'):
   repository_path=relative.removeprefix('vendor/lsf/')
   git_content=subprocess.check_output(['git','show',head+':'+repository_path],cwd=repo)
   assert git_content==content,(role,repository_path)
 for layer in json.loads((root/'package-source.json').read_bytes())['layers']:
  assert (root/layer['source']).read_bytes()==(root/'package/layers'/layer['path']).read_bytes(),(role,layer['path'])

 # Keep complete source-capture observations for explicit schema review.
 checks.append(dict(role=role,marker=marker,observation=observation,inputs=inputs))
original= subprocess.check_output(['git','show',head+':tools/qualify_rust_capsules.py'],cwd=repo)
assert b'commands.environment["LSF_GUEST_CAPSULES"] = str(output / "sdk-guests")' in original
assert b'"--", "--ignored", "--test-threads=1", "--show-output"' in original
result=dict(head=head,artifactId=a['id'],runId=a['workflow_run']['id'],archiveSha256=digest,archiveBytes=len(raw),memberCount=len(rows),logicalBytes=sum(r['bytes'] for r in rows),roles=sorted(roles),members=rows,originalQualifierSha256=hashlib.sha256(original).hexdigest(),absentCapturedFiles=absent_capture_files,retainedCompilerDiagnosticOnly=True,freshCompilerQualification=False,nativeExecution=False)
(out/'inventory.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
(out/'observation-review.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='members'}))
print('all9 observations/components and available source captures/vendor WIT/package layers verified; nine omitted .gitignore capture entries preserved explicitly')
