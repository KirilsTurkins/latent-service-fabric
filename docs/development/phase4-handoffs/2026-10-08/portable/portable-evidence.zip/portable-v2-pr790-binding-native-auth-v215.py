from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

COORD = Path(__file__).resolve().parent
DIRECTORY = COORD/'portable-v2-pr790-binding-native-20261008-v212'
raw = (DIRECTORY/'receipt.json').read_bytes()
r = json.loads(raw)
assert r['head'] == '221645876350b9790d5255df588f0ce2ca728871'
assert r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped'] and r['infrastructureError'] is None
logs = []
for row in r['steps']:
    data = (DIRECTORY/Path(row['log']).name).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'] and row['exitCode'] == 0 and row['originalProcessReaped']
    logs.append(data.decode())
prepared = json.loads((COORD/'portable-v2-pr790-binding-native-prepared-v212.json').read_bytes())
listed = set(re.findall(r'^([\w:]+): test$',logs[0],re.M))
expected = set(prepared['expectedCases'])
assert listed == expected and len(listed) == 264
assert '3 passed; 0 failed; 0 ignored' in logs[1]
assert '263 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out' in logs[2]
proof = dict(at=datetime.now(timezone.utc).isoformat(),head=r['head'],sourceReceipt=str(COORD/'portable-v2-pr790-binding-source-20261008-v208/receipt.json'),
             nativeReceiptSha256=hashlib.sha256(raw).hexdigest(),allFourNativeStepsPass=True,exactCompiledCaseSet=264,
             originalFocusedCasesPass=3,fullPass=263,originalIgnored=1,noMissingOrExtraCases=True,
             sourceClean=True,sourceHeadUnchanged=True,allProcessesReaped=True,ordinaryRegisteredPackageClippyPass=True,
             elapsedSeconds=r['elapsedSeconds'],targetGrowthBytes=r['targetGrowthBytes'],currentMainMergePending=True,noPublication=True)
(COORD/'portable-v2-pr790-binding-qualified-v215.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
