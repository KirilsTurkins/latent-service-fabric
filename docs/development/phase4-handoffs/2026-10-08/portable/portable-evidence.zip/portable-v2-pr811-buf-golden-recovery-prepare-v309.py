from pathlib import Path

coord = Path(__file__).resolve().parent
previous = coord / "portable-v2-pr811-buf-golden-producer-v308.py"
source = previous.read_text(encoding="utf-8")
source = source.replace('OUT = COORD / "portable-v2-pr811-buf-golden-producer-v308"',
                        'OUT = COORD / "portable-v2-pr811-buf-golden-producer-v309"')
old = '''assert len(changed) == 1 and changed[0][0]["name"] == "latent/control/v1/node.proto"
old_node, new_node = changed[0]'''
new = '''assert {left["name"] for left, _ in changed} == {"latent/control/v1/node.proto", "latent/control/v1/state.proto"}
old_files = {left["name"]: left for left, _ in changed}
new_files = {right["name"]: right for _, right in changed}
old_node, new_node = old_files["latent/control/v1/node.proto"], new_files["latent/control/v1/node.proto"]'''
assert source.count(old) == 1
source = source.replace(old, new)
source = source.replace('restored = copy.deepcopy(new_node)', 'restored_files = copy.deepcopy(new_files)\nrestored = restored_files["latent/control/v1/node.proto"]')
old = '''for message_name, field_name, number in [
    ("ActivationTreeNode", "transaction_staging", 15),
    ("NamespaceInspection", "policy_digest", 12),
]:
    message = next(m for m in restored["messageType"] if m["name"] == message_name)'''
new = '''for file_name, message_name, field_name, number in [
    ("latent/control/v1/node.proto", "ActivationTreeNode", "transaction_staging", 15),
    ("latent/control/v1/state.proto", "NamespaceInspection", "policy_digest", 12),
]:
    message = next(m for m in restored_files[file_name]["messageType"] if m["name"] == message_name)'''
assert source.count(old) == 1
source = source.replace(old, new)
source = source.replace('assert restored == old_node, "descriptor delta contains unreviewed existing semantics"',
                        'assert restored_files == old_files, "descriptor delta contains unreviewed existing semantics"')
source = source.replace('"sourceQualificationPending": True, "completeCI": False,',
                        '"sourceQualificationPending": True, "completeCI": False,\n    "previousGuardRefusalPreserved": "v308 correctly retained original golden when two changed files exceeded the initial one-file assumption; Node and State additions are now reviewed separately.",')
new_script = coord / "portable-v2-pr811-buf-golden-producer-v309.py"
assert not new_script.exists()
compile(source, str(new_script), "exec")
new_script.write_text(source, encoding="utf-8", newline="\n")
print(new_script)
