import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

COORD = Path(__file__).resolve().parent
HEAD = "b43ab914f9ffbdd4fa26c26b66c913daf3342aef"
REPO = "KirilsTurkins/latent-service-fabric"
ENV = dict(os.environ, GODEBUG="http2client=0")
JOB = COORD / "portable-v2-pr784-current-main-native-20261008-v315"
raw = (JOB / "receipt.json").read_bytes()
receipt = json.loads(raw)
assert receipt["head"] == HEAD and receipt["passed"] and len(receipt["steps"]) == 9
assert receipt["sourceClean"] and receipt["sourceHeadUnchanged"] and receipt["originalProcessReaped"]
for row in receipt["steps"]:
    data = (JOB / row["log"]).read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
    assert row["exitCode"] == 0 and row["originalProcessReaped"] and row["stopReason"] is None


def api():
    return json.loads(subprocess.check_output(["gh", "api", f"repos/{REPO}/pulls/784"], env=ENV, timeout=60))


pr = api()
assert pr["head"]["sha"] == HEAD and pr["state"] == "open"
body = """Transactional guest bindings preserve original state-view and key-version tokens, typed result ownership and rollback/refusal behavior. Recovery of an unknown trigger operation accepts the original empty-journal retained floor while preserving identity, exact u64 bounds and currentness checks; the original RPC refusal and overflow schedules remain.

Development21cfd221 is normally integrated, including the reviewed Signing concurrent-currentness and Node identity cases. All inherited cases, ignored fixtures, resource limits and the historical AOT custom-harness floor remain. Both bounded route observers are preserved on the original single request with no raw credential or argument disclosure.

This exact current head passes all seven Linux Source gates and226 Python cases without skips, plus all nine Native gates: the exact compiled Signing58/Node91 sets and full tests, all66 activation-lifecycle tests, Node all-target/all-feature checks, all12 real unprivileged AOT entry probes and the exact-policy syscall probe, ordinary Clippy and the original selected four-package warnings-as-errors gate. All processes are reaped and the source is clean and unchanged. The prior bd217 focused RPC/full156 CLI proof and historical50 accepted hosted checks retain their original heads; full current hosted CI and complete six-language signed stateful guest/#389 acceptance remain pending. No historical-green transfer, admin merge or issue closure is claimed.
"""
path = COORD / "portable-v2-pr784-current-native-body-v318.md"
path.write_text(body, encoding="utf-8")
subprocess.run(["gh", "pr", "edit", "784", "--repo", REPO, "--body-file", str(path)], env=ENV, timeout=90, check=True)
final = api()
assert final["head"]["sha"] == HEAD and final["body"].replace("\r\n", "\n").strip() == body.strip()
result = {"at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "head": HEAD, "pr": 784,
          "nativeReceiptSha256": hashlib.sha256(raw).hexdigest(), "allNineNativeStepsPassed": True,
          "currentHeadUnchanged": True, "descriptionUpdatedAndVerified": True,
          "completeHostedCiClaimed": False, "adminMerged": False, "issueClosed": False}
(COORD / "portable-v2-pr784-current-native-description-v318.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
