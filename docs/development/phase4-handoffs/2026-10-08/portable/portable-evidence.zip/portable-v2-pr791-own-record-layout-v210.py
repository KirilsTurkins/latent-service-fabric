from datetime import datetime, timezone
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

REPO = Path(r'C:\Users\turkins\Desktop\latent-fabric')
TREE = Path(r'C:\Users\turkins\Desktop\lf-p4-pr791-guard-layout-v209')
COORD = Path(__file__).resolve().parent
OLD = '866416fb57f2a11211fc6ecdf8896c2e5343a36a'
PATH = 'tools/ci/contracts/python/test_dev_node_policies.py.json'

def git(*args):
    return subprocess.check_output(['git','-C',str(TREE),*args])

assert git('rev-parse','HEAD').decode().strip() == OLD and not git('status','--porcelain')
original = (TREE/PATH).read_bytes()
record = json.loads(original)
for identity, definition in record['guardDefinitions'].items():
    canonical = json.dumps(definition,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf8')
    assert hashlib.sha256(canonical).hexdigest() == identity
source = git('show',f'{OLD}:tools/ci_contracts.py').decode()
qualified_source = git('show','6ab38845e5a266f38229416dc63fe57df471a40f:tools/ci_contracts.py').decode()
def serializer(text):
    nodes = [node for node in ast.parse(text).body if isinstance(node,ast.FunctionDef) and node.name == 'shared_python_text']
    assert len(nodes) == 1
    return nodes[0]
assert ast.dump(serializer(source),include_attributes=False) == ast.dump(serializer(qualified_source),include_attributes=False)
sys.path.insert(0,str(REPO))
from tools import ci_contracts
assert ast.dump(serializer((REPO/'tools/ci_contracts.py').read_text(encoding='utf8')),include_attributes=False) == ast.dump(serializer(source),include_attributes=False)
corrected = ci_contracts.shared_python_text(record).encode('utf8')
assert json.loads(corrected) == record
assert list(json.loads(corrected)) == list(record)
(TREE/PATH).write_bytes(corrected)
git('diff','--check')
git('add',PATH)
git('commit','-m','ci: preserve current guard metadata with maintained reference layout')
head = git('rev-parse','HEAD').decode().strip()
proof = dict(at=datetime.now(timezone.utc).isoformat(), oldHead=OLD, head=head, onlyPath=PATH,
             priorDirectCopyRefusedForDifferentReviewReason=True, currentRecordAndAllGuardsPreserved=True,
             exactMaintainedSerializerFunction=True, allGuardDigestsRecomputed=True, noScanExceptionsOrPolicyChange=True,
             actualCurrentPinnedScanAndSourcePending=True, oldSha256=hashlib.sha256(original).hexdigest(),
             newSha256=hashlib.sha256(corrected).hexdigest(), tree=str(TREE))
(COORD/'portable-v2-pr791-own-record-layout-prepared-v210.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
