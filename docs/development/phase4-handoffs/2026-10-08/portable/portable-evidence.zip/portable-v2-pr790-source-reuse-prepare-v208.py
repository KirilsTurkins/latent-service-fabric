from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

COORD = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\turkins\Desktop\latent-fabric')
HEAD = subprocess.check_output(['git','-C',str(REPO),'rev-parse','fix/phase4-pr790-binding-native-v208'],text=True).strip()
OLD = '6ab38845e5a266f38229416dc63fe57df471a40f'
BASE = '/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data'
JOB = 'portable-v2-pr790-binding-source-20261008-v208'
previous = COORD / 'portable-v2-pr790-guard-layout-source-20261008-v205'
receipt_raw = (previous/'receipt.json').read_bytes()
receipt = json.loads(receipt_raw)
assert receipt['head'] == OLD and receipt['passed'] and receipt['sourceClean'] and receipt['sourceHeadUnchanged'] and receipt['originalProcessReaped']
for row in receipt['steps']:
    raw = (previous/Path(row['log']).name).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'] and row['originalProcessReaped']
assert subprocess.check_output(['git','-C',str(REPO),'diff','--name-only',OLD,HEAD],text=True).splitlines() == ['crates/latent-control-store/src/deployments/bindings/compile.rs']
steps = json.loads((COORD/'portable-v2-pr790-guard-layout-source-steps-v205.json').read_bytes())
steps[3][-1] = 'target/ci/observed-pr790-binding-v208.json'
steps[7][-1] = steps[7][-1].replace('portable-v2-pr790-guard-layout-source-20261008-v205', JOB)
step_path = COORD/'portable-v2-pr790-binding-source-steps-v208.json'
step_path.write_text(json.dumps(steps,indent=2)+'\n',encoding='utf8')
source = (COORD/'portable-v2-reconstructed-native-controller-20261007-v93.py').read_text(encoding='utf8')
needle = "else:\n    source = base / ('source-' + head[:16])\n"
replacement = '''else:
    source = base / 'source-6ab38845e5a266f3'
    reuse_lock = (base / 'jobs' / 'portable-v2-pr790-source-reuse-v208.lock').open('a+')
    fcntl.flock(reuse_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert source.is_dir() and not source.is_symlink()
    assert source.resolve().is_relative_to(base.resolve())
    assert cfg['head'] == NEW_HEAD_LITERAL
    assert call(['git', 'rev-parse', 'HEAD'], source) == OLD_HEAD_LITERAL
    assert not call(['git', 'status', '--porcelain'], source)
    prior = base / 'jobs' / 'portable-v2-pr790-guard-layout-source-20261008-v205'
    raw_receipt = (prior / 'receipt.json').read_bytes()
    assert hashlib.sha256(raw_receipt).hexdigest() == OLD_RECEIPT_LITERAL
    old = json.loads(raw_receipt)
    assert old['head'] == OLD_HEAD_LITERAL and old['passed'] and old['sourceClean'] and old['sourceHeadUnchanged'] and old['originalProcessReaped']
    for row in old['steps']:
        raw = (prior / Path(row['log']).name).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == row['sha256'] and len(raw) == row['bytes'] and row['originalProcessReaped']
    custody = dict(oldHead=old['head'], oldTree=old['tree'], newHead=cfg['head'], sourceClean=True,
                   oldReceiptSha256=hashlib.sha256(raw_receipt).hexdigest(), oldProcessesReaped=True,
                   sourceOnly=True, nativeCheckoutMutation=False, noForcedResetOrClean=True)
    (out / 'source-reuse-custody.json').write_text(json.dumps(custody, indent=2) + '\\n')
'''
replacement = replacement.replace('NEW_HEAD_LITERAL',repr(HEAD)).replace('OLD_HEAD_LITERAL',repr(OLD)).replace('OLD_RECEIPT_LITERAL',repr(hashlib.sha256(receipt_raw).hexdigest()))
assert source.count(needle) == 1
source = source.replace(needle,replacement)
source = source.replace('assert mode in {"native", "source"}', 'assert mode == "source", "Exact released Source checkout only"',1)
script = COORD/'portable-v2-pr790-source-reuse-controller-v208.py'
compile(source,str(script),'exec')
script.write_text(source,encoding='utf8')
proof = dict(at=datetime.now(timezone.utc).isoformat(), oldHead=OLD, head=HEAD, priorReceiptSha256=hashlib.sha256(receipt_raw).hexdigest(),
             originalBoundsPreserved=True, noClone=True, sourceOnly=True, originalEightCommandsPreservedExceptOwnedReceiptPaths=True,
             controller=str(script), controllerSha256=hashlib.sha256(script.read_bytes()).hexdigest(),
             steps=str(step_path), stepsSha256=hashlib.sha256(step_path.read_bytes()).hexdigest(), job=JOB)
(COORD/'portable-v2-pr790-source-reuse-prepared-v208.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
