Adds original-command waiting and completion semantics for #387, retaining actual guest execution counting, bounded Rust results and explicit retry/recovery identities. Integrates development while preserving cancellation, native retirement, read-view history and policy fences.

Repairs duplicate descendant and runtime initializer declarations introduced during integration. Removes a duplicate Phase 4 native-memory observation and requires confirmed native capacity to remain charged until its real owner retires. Completes the generated Java source fixture without changing its original assertions.

Current-head Linux source checks pass. Native workspace compilation and all 131 Core cases are qualified before publication. Full CI and installed command recovery qualification remain pending; prior actual guest receipts retain their original source heads.
