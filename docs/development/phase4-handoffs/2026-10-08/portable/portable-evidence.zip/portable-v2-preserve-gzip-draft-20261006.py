"""Preserve the unpublished gzip draft, then restore only its owned source paths."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-common-ci-history-20261006")
OUT = Path(__file__).resolve().parent / "portable-v2-unpublished-gzip-draft-20261006-v1"
BASE = "3d77ab9e77849c1061ae9480902f262ac3975857"
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=60)
assert git("rev-parse", "HEAD").decode().strip() == BASE
assert git("branch", "--show-current").decode().strip() == "fix/phase4-ci-history-storage-20261006"
OUT.mkdir()
patch = git("diff", "--cached", "--binary", "--full-index", "--no-ext-diff")
(OUT / "draft.patch").write_bytes(patch)
paths = git("diff", "--cached", "--name-only").decode().splitlines()
expected = {"docs/testing/ci-command-contracts.md", "docs/testing/ci-suite-inventory.md",
            "tools/ci/contracts/owners/tools/ci_contracts.py.json", "tools/ci/contracts/python/test_build_source_capacity.py.json",
            "tools/ci/contracts/python/test_ci_contracts.py.json", "tools/ci/history/commands-v1.json",
            "tools/ci/history/commands-v1.json.gz", "tools/ci_contracts.py", "tools/tests/test_build_source_capacity.py",
            "tools/tests/test_ci_contracts.py"}
assert set(paths) == expected and not git("diff", "--name-only").strip()
records = []
for path in paths:
    target = ROOT / path
    if target.exists():
        raw = target.read_bytes()
        custody = OUT / "source" / path
        custody.parent.mkdir(parents=True, exist_ok=True)
        custody.write_bytes(raw)
        records.append({"path": path, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
    else:
        records.append({"path": path, "draftDeleted": True})
created = "tools/ci/history/commands-v1.json.gz"
assert (ROOT / created).resolve() == ROOT.resolve() / created
assert hashlib.sha256((ROOT / created).read_bytes()).hexdigest() == "caeecaf8062bb6ed4b9d4a5787945a5beab53c583dbe2998dc419a075f2c492c"
subprocess.run(["git", "restore", "--source=" + BASE, "--staged", "--worktree", "--", *[path for path in paths if path != created]], cwd=ROOT, check=True)
subprocess.run(["git", "rm", "--cached", "--", created], cwd=ROOT, check=True, capture_output=True)
(ROOT / created).unlink()
assert not git("status", "--porcelain").strip()
subprocess.run(["git", "switch", "-c", "fix/phase4-source-capture-64mib-20261006", BASE], cwd=ROOT, check=True, capture_output=True)
receipt = {"at": datetime.now(timezone.utc).isoformat(), "root": str(ROOT), "base": BASE,
           "reason": "User explicitly authorized increasing the source build limit to 64 MB; stop compression work.",
           "patch": str(OUT / "draft.patch"), "patchSha256": hashlib.sha256(patch).hexdigest(), "paths": records,
           "sourceRestoredClean": True, "published": False, "historicalBytesRestored": True,
           "nextBranch": "fix/phase4-source-capture-64mib-20261006", "qualified": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps({key: value for key, value in receipt.items() if key != "paths"}), flush=True)
