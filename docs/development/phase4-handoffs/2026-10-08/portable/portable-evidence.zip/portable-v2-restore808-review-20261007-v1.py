import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path(r'C:\Users\turkins\Desktop\lf-p4-restore808-review-entity-v9-20261006')
OUT = pathlib.Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-restore808-review-20261007-v1')

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        path.write_bytes(data)

def main():
    head = git('rev-parse', 'HEAD').decode().strip()
    merge = git('rev-parse', 'MERGE_HEAD').decode().strip()
    assert head == 'ce764ab44c744b7dad0c9b56bb2ea0451bdf8115'
    assert merge == '0e0162f71127bfbd2a88e848f153f4c64c134e83'
    paths = git('diff', '--name-only', '--diff-filter=U', '-z').decode().strip('\0').split('\0')
    entries = []
    for rel in paths:
        raw = (ROOT / rel).read_bytes()
        save(OUT / 'original' / rel, raw)
        stages = []
        for line in git('ls-files', '-u', '--', rel).decode().splitlines():
            info, actual = line.split('\t')
            mode, sha, stage = info.split()
            blob = git('cat-file', 'blob', sha)
            save(OUT / ('stage-' + stage) / rel, blob)
            stages.append({'stage': int(stage), 'mode': mode, 'blob': sha, 'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest()})
        entries.append({'path': rel, 'workingBytes': len(raw), 'workingSha256': hashlib.sha256(raw).hexdigest(), 'stages': stages})
    index = pathlib.Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index.is_absolute():
        index = ROOT / index
    save(OUT / 'original-index', index.read_bytes())
    save(OUT / 'original-status.txt', git('status', '--porcelain=v1'))
    save(OUT / 'original-diff.patch', git('diff'))
    receipt = {'root': str(ROOT), 'head': head, 'mergeHead': merge, 'conflicts': entries, 'canonicalPeerModified': False, 'published': False, 'sourceQualified': False, 'nativeQualified': False}
    save(OUT / 'custody.json', (json.dumps(receipt, indent=2) + '\n').encode())
    print(json.dumps({'head': head, 'mergeHead': merge, 'conflicts': len(paths), 'paths': [{'path': e['path'], 'stageBytes': [s['bytes'] for s in e['stages']]} for e in entries]}, indent=2))

if __name__ == '__main__':
    main()
