import json
from pathlib import Path
import subprocess
import sys

COORD = Path(__file__).resolve().parent
HEAD = "f149bb009952e823c6d6f3877af80b298c5c7258"
steps = json.loads((COORD / "portable-v2-pr811-final-main-source-steps-v277.json").read_bytes())
assert len(steps) == 8
extra_modules = steps[0][6:]
assert extra_modules == ["tools.tests.test_java_diagnostic_program", "tools.tests.test_java_provider_timeout", "tools.tests.test_java_resource_diagnostics"]
for module in extra_modules:
    subprocess.run(["git", "cat-file", "-e", HEAD + ":" + module.replace(".", "/") + ".py"], check=True)
needle = "'tools.tests.test_java_server_source'],check=True)"
assert steps[0][5].count(needle) == 1
steps[0][5] = steps[0][5].replace(needle, "'tools.tests.test_java_server_source', " + ", ".join(repr(m) for m in extra_modules) + "],check=True)")
steps[0] = steps[0][:6]
changed = 0
for row in steps:
    for index, item in enumerate(row):
        if item == "target/ci/observed-pr811-final-main-v277.json":
            row[index] = "target/ci/observed-pr811-buf-golden-v312.json"
            changed += 1
assert changed == 1
steps.append([
    "python3", "-X", "utf8", "-B", "-c",
    "import hashlib,subprocess; from pathlib import Path; p=Path('/root-checks/portable-v2-pr811-buf-golden-producer-v309/actual-file-descriptor-set.json'); assert p.stat().st_size==594567; assert hashlib.sha256(p.read_bytes()).hexdigest()=='539496c72df533c343b0904b1b4aad0546cf33adbeb110322cd911d9726fd3fd'; subprocess.run(['python3','-X','utf8','-B','tools/validate_phase1_descriptor.py',str(p)],check=True)",
])
step_file = COORD / "portable-v2-pr811-buf-golden-source-steps-v312.json"
step_file.write_text(json.dumps(steps, indent=2) + "\n", encoding="utf-8")
subprocess.run([
    sys.executable, "-X", "utf8", "-B", str(COORD / "portable-v2-source-reuse-prepare-v211.py"),
    HEAD, "portable-v2-control-preparation-stage-cli-source-20261008-v305", "source-6ab38845e5a266f3",
    "portable-v2-pr811-buf-golden-source-20261008-v312", str(step_file), "portable-v2-pr811-buf-golden-source-controller-v312.py",
], check=True)
print(json.dumps({"head": HEAD, "originalEightGatesRetained": True, "formerlyUnusedModuleArgumentsNowActuallyExecuted": extra_modules, "actualCapturedBufValidationAdded": True, "newSourceOnly": True}))
