"""Review both workflow parents and preserve their shared SDK obligations."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

root = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
out = Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-main-sdk-reconcile-20261006-v1")
sys.path.insert(0, str(root))
from tools import ci_contracts as c

models = c.observed_workflows(root)
audit = json.loads((out / "audit.json").read_bytes())
resolved = []
for row in audit:
    name = row["path"]
    if row["kind"] == "source":
        continue
    ours, incoming = [c.semantic_record(json.loads((out / label / name).read_bytes())) for label in ("ours", "incoming")]
    chosen = dict(incoming)
    if row["kind"] == "job":
        actual = models[ours["workflow"]]["jobs"][ours["jobId"]]
        for parent in (ours, incoming):
            assert parent["definition"].get("timeout-minutes") == actual.get("timeout-minutes")
            assert parent["before"] == chosen["before"] and parent["coverage"] == chosen["coverage"]
            for step in parent["definition"]["steps"]:
                if step in actual["steps"]:
                    continue
                matches = [value for value in actual["steps"] if value.get("name") == step.get("name")]
                assert len(matches) == 1 and step.get("uses") == "actions/upload-artifact", (name, step.get("name"))
                actual_step = matches[0]
                assert {key: value for key, value in step.items() if key != "with"} == {key: value for key, value in actual_step.items() if key != "with"}
                assert {key: value for key, value in step["with"].items() if key != "path"} == {key: value for key, value in actual_step["with"].items() if key != "path"}
                assert set(step["with"]["path"].splitlines()) <= set(actual_step["with"]["path"].splitlines())
        chosen["definition"] = actual
    elif row["kind"] == "workflow":
        actual = models[ours["workflow"]]
        for parent in (ours, incoming):
            assert set(parent["requiredJobs"]) <= set(actual["jobs"])
            old_policy = dict(parent["policy"])
            new_policy = {key: value for key, value in actual.items() if key != "jobs"}
            # Changes in these three workflow policies are additive path
            # triggers; permissions, concurrency and dispatch stay exact.
            old_on = old_policy.pop("on")
            new_on = new_policy.pop("on")
            assert old_policy == new_policy
            assert set(old_on) == set(new_on)
            for event, old_trigger in old_on.items():
                new_trigger = new_on[event]
                if isinstance(old_trigger, dict) and "paths" in old_trigger:
                    assert {key: value for key, value in old_trigger.items() if key != "paths"} == {key: value for key, value in new_trigger.items() if key != "paths"}
                    assert set(old_trigger["paths"]) <= set(new_trigger["paths"])
                else:
                    assert old_trigger == new_trigger
        chosen["policy"] = {key: value for key, value in actual.items() if key != "jobs"}
        chosen["requiredJobs"] = sorted(actual["jobs"])
    elif row["kind"] == "owner":
        chosen["sha256"] = hashlib.sha256((root / chosen["path"]).read_bytes()).hexdigest()
    else:
        assert row["sameExceptReason"]
    chosen["reviewReason"] = (incoming["reviewReason"] + " Retain Phase 4 parent obligation: " + ours["reviewReason"]
        + " Reviewed db532 shared SDK union: phase3-v5 and opt-in phase4 host identities coexist;"
          " canonical State/Intent installation precedes preserved activation checkpoint analysis."
          " Both parents' commands, artifact path unions, permissions, conditions, matrices, all deadline bounds,"
          " historical mappings and case/skip/decorator guards remain required.")
    physical = json.loads((out / "incoming" / name).read_bytes())
    if physical["schemaVersion"] == c.PYTHON_STORAGE_SCHEMA:
        chosen = c.shared_python_record(chosen)
    # Existing records whose reviewed content changes retain the incoming
    # storage representation and key order. No unrelated record is rewritten.
    if row["kind"] == "python":
        text = (out / "incoming" / name).read_text()
        text, count = re.subn(r'("reviewReason"\s*:\s*)("(?:[^"\\]|\\.)*")',
            lambda match: match[1] + json.dumps(chosen["reviewReason"], ensure_ascii=False), text)
        assert count == 1
    else:
        compact = b"\n" not in (out / "incoming" / name).read_bytes().rstrip()
        text = json.dumps(chosen, ensure_ascii=False, separators=(",", ":") if compact else None,
                          indent=None if compact else 2) + "\n"
    assert c.semantic_record(json.loads(text)) == c.semantic_record(chosen)
    (root / name).write_bytes(text.encode("utf8"))
    resolved.append({"path": name, "kind": row["kind"], "allParentObligationsReviewed": True})
subprocess.run(["git", "add", "--", *(value["path"] for value in audit)], cwd=root, check=True)
assert not subprocess.check_output(["git", "diff", "--name-only", "--diff-filter=U"], cwd=root).strip()
(out / "resolution.json").write_text(json.dumps({"resolved": resolved,
    "sourceUnions": [value["path"] for value in audit if value["kind"] == "source"],
    "noDeadlineExtensions": True, "noDroppedArtifactInputs": True}, indent=2) + "\n")
print(json.dumps({"resolvedContracts": len(resolved), "sourceUnions": 2}))
