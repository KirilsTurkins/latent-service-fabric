from pathlib import Path
import hashlib
import json
import sys

root = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
output = Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-java-compile-20261006-v2")
if output.exists():
    raise SystemExit("refuse replacing a source attempt")
output.mkdir()
sys.path.insert(0, str(root))
from tools.stateful_reference_project import create
from tools.rust_capsule_project import snapshot, inventory, digest

project = create(output / "project", "java")
before = inventory(snapshot(project))
(output / "source-inputs.json").write_bytes(before)
(output / "preparation.json").write_text(json.dumps({
    "language": "java", "application": "order-draft-v1", "sourceInventoryDigest": digest(before),
    "sourceBase": "438c08e67d404b905d2d9f39fb03f964c7251904", "authoredSourceUncommitted": True,
    "compiled": False, "signed": False, "nodeQualified": False,
    "compilerCacheSource": "latent-sdk-java-public-cache-af6d-20261006-r4",
    "compilerToolsSource": "latent-sdk-java-public-tools-af6d-20261006-r4",
    "compilerVolumesReadOnly": True,
}, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"prepared": str(output), "sourceInventoryDigest": digest(before)}))
