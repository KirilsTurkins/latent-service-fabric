"""Union current dependency/CI controls while preserving the storage feature tree."""
from datetime import datetime, timezone
import ast
import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
OUT = Path(__file__).resolve().parent / "portable-v2-pr767-main64-20261006-v1"
OURS = "0a460cbaa9dcea330b00978b7b3557ab75e58b23"
THEIRS = "318eaa9aea5e0962515c7161d441ee270bcdeae4"
assert OUT.is_dir() and not (OUT / "semantic-resolution.json").exists()
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=60)
def read(revision, path):
    return git("show", revision + ":" + path)
def decoded(revision, path):
    return json.loads(read(revision, path))
assert git("rev-parse", "HEAD").decode().strip() == OURS
assert git("rev-parse", "MERGE_HEAD").decode().strip() == THEIRS
original_conflicts = git("diff", "--name-only", "--diff-filter=U").decode().splitlines()
changes = []
def write(path, raw, reason):
    target = ROOT / path
    before = target.read_bytes() if target.exists() else None
    if before is not None:
        custody = OUT / "before-resolution" / path
        custody.parent.mkdir(parents=True, exist_ok=True)
        assert not custody.exists()
        custody.write_bytes(before)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    changes.append({"path": path, "reason": reason, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
def text_write(path, text, reason):
    write(path, text.encode("utf8"), reason)
def json_write(path, value, reason):
    write(path, (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode(), reason)

# All non-npm inventory metadata agrees except the incoming reviewed .NET project
# digest; select the actual incoming project/locks and maintained source policy.
path = ".github/security/inventory.json"
a, b = decoded(OURS, path), decoded(THEIRS, path)
aa, bb = {row["path"]: row for row in a["manifests"]}, {row["path"]: row for row in b["manifests"]}
assert set(aa) == set(bb)
allowed = {"website/package.json", "website/toolchain/package.json", "examples/framework-compatibility/package.json",
           "sdk/dotnet/Latent.Sdk.Transport/Latent.Sdk.Transport.csproj"}
assert {key for key in aa if aa[key] != bb[key]} <= allowed
assert {key: value for key, value in a.items() if key != "manifests"} == {key: value for key, value in b.items() if key != "manifests"}
direct = [path, "examples/framework-compatibility/package-lock.json", "examples/framework-compatibility/package.json",
          "website/package-lock.json", "website/package.json", "website/tests/toolchain.test.mjs",
          "tools/security_advisories.py", "tools/security_inventory.py"]
for path in direct:
    write(path, read(THEIRS, path), "Use current-main authenticated npm v4 and both maintained library repairs; other inventory rows/metadata remain exact.")
path = "tools/security_scan.py"
source = read(THEIRS, path).decode()
anchor = "    return int(bool(remaining)), report\n"
assert source.count(anchor) == 1
source = source.replace(anchor, '    if mode == "dependencies":\n        report["remediated_count"] = len(observation.get("source_remediated_findings", []))\n' + anchor, 1)
text_write(path, source, "Retain the owned public remediation count using maintained verified-source receipts; use the current dependency scanner interface and retain all other scanner controls.")

# Keep the stronger state renderer/narrow-profile fixture, replacing only the
# obsolete archive preparation with the single maintained v4 builder.
path = ".github/workflows/ci.yml"
source = (ROOT / path).read_text(encoding="utf8")
pattern = r"<<<<<<< HEAD\n          python3 tools/security_derivations.py prepare\n=======\n          python3 website/toolchain/prepare.py\n>>>>>>> " + THEIRS + r"\n"
source, count = re.subn(pattern, "          python3 website/toolchain/prepare.py\n", source)
assert count == 1 and "<<<<<<<" not in source
assert "assert state.profile == 'full' and state.renderer" in source
assert "assert set(selection.fast_packages) < set(registry.load()['fastPackages'])" in source
text_write(path, source, "Preserve Root's state/full-renderer and genuinely narrow assertions; materialize the exact current-main v4 archives before the original install.")
for path in [".github/workflows/docs-pages.yml", ".github/workflows/docs-site.yml"]:
    source = (ROOT / path).read_text(encoding="utf8")
    obsolete = "          python3 tools/security_derivations.py prepare\n"
    assert source.count(obsolete) == 1 and "python3 website/toolchain/prepare.py" in source
    text_write(path, source.replace(obsolete, "", 1), "Maintain every existing job/qualification/install command, using the one current authenticated builder for the two repaired libraries instead of a duplicate obsolete builder.")

path = "tools/tests/test_ci_contracts.py"
source = read(THEIRS, path).decode()
old = read(OURS, path).decode()
start = old.index('            host_fixture = ".github/workflows/ci.yml:fast:Qualify the genuinely narrow reverse-dependent fixture"')
finish = old.index("            elif key in reviewed_browser_derivations:", start)
owned_branch = old[start:finish]
owned_branch = owned_branch.replace('            host_fixture = ".github/workflows/ci.yml:fast:Qualify the genuinely narrow reverse-dependent fixture"\n            if key == host_fixture:', '            if key == reviewed_narrow_fixture:', 1)
start = source.index("            elif key == reviewed_narrow_fixture:")
finish = source.index("            elif key == reviewed_deferred_owners:", start)
source = source[:start] + owned_branch.replace("            if key == reviewed_narrow_fixture:", "            elif key == reviewed_narrow_fixture:", 1) + source[finish:]
assert "reviewed_framework_archives" in source and "reviewed_deferred_owners" in source
assert "security_derivations" not in source
ast.parse(source)
text_write(path, source, "Keep every migration case/assertion; combine current archive/deferred-runner obligations with Root's stronger exact state renderer and narrow-fixture expectations.")

# Retain Root's named exact-advisory case and all its known/unrelated finding
# assertions under the maintained independent source/advisory revision policy.
path = "tools/tests/test_security_baseline.py"
source = (ROOT / path).read_text(encoding="utf8")
start = source.index("    def test_source_repair_classifies_only_the_proved_braces_advisory(self) -> None:\n")
finish = source.index("    def test_new_manifest_missing_lock_or_unresolved_requirement_cannot_pass", start)
old_case = source[start:finish]
assert old_case.count("self.assertEqual(") == 2 and old_case.count("self.assertRaisesRegex(") == 1
replacement = '''    def test_source_repair_classifies_only_the_proved_braces_advisory(self) -> None:
        from tools.security_npm_sources import resolve_findings

        paths = ("website/package-lock.json", "examples/framework-compatibility/package-lock.json")
        revision = "2026-10-02T22:45:04.328737Z"
        advisory = {"id": "GHSA-vfj7-8cjw-p6xm", "modified": revision}
        receipts = [{"name": "braces", "version": "3.0.3", "locks": list(paths), "advisories": [advisory]}]
        observations = [{"advisories": [{"package": {"name": "braces", "version": "3.0.3", "path": path},
                                          **advisory} for path in paths]}]
        known = [finding("osv", "GHSA-vfj7-8cjw-p6xm", path, "npm:braces@3.0.3") for path in paths]
        unrelated = [finding("osv", "GHSA-different", paths[0], "npm:braces@3.0.3"),
                     finding("osv", "GHSA-vfj7-8cjw-p6xm", "sdk/typescript-client/package-lock.json",
                             "npm:braces@3.0.3"),
                     finding("osv", "GHSA-vfj7-8cjw-p6xm", paths[0], "npm:braces@3.0.4")]
        remaining, remediated = resolve_findings(known + unrelated, observations, receipts)
        self.assertEqual(remediated, known)
        self.assertEqual(remaining, unrelated)
        with self.assertRaisesRegex(SecurityError, "npm-repair-advisory-policy"):
            resolve_findings(known, observations, [{**receipts[0], "advisories": [{"id": advisory["id"]}]}])
        # A different upstream advisory revision never inherits the old repair.
        changed = [{"advisories": [{**row, "modified": "2026-10-03T00:00:00Z"}
                                    for row in observations[0]["advisories"]]}]
        self.assertEqual(resolve_findings(known, changed, receipts), (known, []))

'''
source = source[:start] + replacement + source[finish:]
ast.parse(source)
text_write(path, source, "Retain the Root-only advisory case and exact positive/unrelated/failure assertions; additionally refuse another advisory revision under the independently authenticated v4 source policy.")

# Incoming static suite inventory adds cases/floors to every nonempty Root set.
# Preserve explicit nonempty case/ignore obligations and every independent field.
path = "tools/ci/suites.json"
a, b = decoded(OURS, path), decoded(THEIRS, path)
aa, bb = {row["id"]: row for row in a["suites"]}, {row["id"]: row for row in b["suites"]}
assert set(aa) == set(bb)
for key in aa:
    old, actual = aa[key], bb[key]
    assert set(old.get("expectedCases", [])) <= set(actual.get("expectedCases", [])), key
    assert set(old.get("expectedIgnored", [])) <= set(actual.get("expectedIgnored", [])), key
    assert actual["minimumCases"] >= old["minimumCases"], key
    for field in set(old) | set(actual):
        if field not in {"expectedCases", "expectedIgnored", "minimumCases"}:
            assert old.get(field) == actual.get(field), (key, field)
for field in set(a) | set(b):
    if field == "suites":
        continue
    if field == "selections":
        assert set(a[field]) <= set(b[field])
        for key, value in a[field].items():
            assert b[field][key] == value
    else:
        assert a[field] == b[field], field
write(path, read(THEIRS, path), "Current-main suite inventory retains every Root nonempty case/ignore set and increases applicable floors; all prior selections remain exact and the owned deferred selection is added.")

# Retire only superseded unmerged builder/profile material; preserve it in the
# named immutable custody branch and the conflict-resolution custody directory.
retired = ["tools/security_derivations.py", "website/toolchain/braces-source.json", "website/toolchain/braces-depth.js",
           "website/toolchain/braces-proof.cjs", "tools/ci/contracts/owners/tools/security_derivations.py.json"]
for path in retired:
    target = ROOT / path
    assert target.exists() and target.read_bytes().replace(b"\r\n", b"\n") == read(OURS, path)
    custody = OUT / "retired" / path
    custody.parent.mkdir(parents=True, exist_ok=True)
    custody.write_bytes(target.read_bytes())
    target.unlink()
for path in ["docs/how-to/serve-angular-and-docusaurus.md", "docs/development/website-versions.md", "docs/development/website.md"]:
    # All Root-only lines here prepare the obsolete derivative. Current main
    # describes the maintained complete builder and its stronger repaired graph.
    write(path, read(THEIRS, path), "Use current maintained v4 instructions; the sole archive builder materializes both byte-pinned repaired libraries before installation.")

sys.path.insert(0, str(ROOT))
from tools import ci_contracts as contracts, ci_lane_inventory as lanes, ci_coverage as coverage
models = contracts.observed_workflows(ROOT)
job_paths = ["tools/ci/contracts/workflows/ci.yml/jobs/fast.json", "tools/ci/contracts/workflows/ci.yml/jobs/rust.json",
             "tools/ci/contracts/workflows/docs-pages.yml/jobs/browser.json", "tools/ci/contracts/workflows/docs-site.yml/jobs/website.json"]
job_reviews = []
for path in job_paths:
    own, incoming = decoded(OURS, path), decoded(THEIRS, path)
    result = copy.deepcopy(incoming)
    assert own["before"] == incoming["before"] and set(own["coverage"]) == set(incoming["coverage"])
    for key in own["coverage"]:
        assert own["coverage"][key]["after"] == incoming["coverage"][key]["after"]
    result["definition"] = models[result["workflow"]]["jobs"][result["jobId"]]
    actual = lanes.run_commands(result["workflow"], {"jobs": {result["jobId"]: result["definition"]}})
    for key, obligation in result["coverage"].items():
        if obligation["disposition"] == "unchanged" and result["before"][key] != actual[obligation["after"]]:
            obligation["disposition"] = "extended"
            obligation["reason"] = "Retain all original commands and exact metadata; qualify the real state renderer/narrow dependency fixture and materialize current independently authenticated npm v4 archives."
    result["reviewReason"] += " Union Root state-renderer/narrow-fixture assertions and every current-main owner/artifact/qualification obligation; retire only the duplicate obsolete source builder in favor of maintained byte-authenticated npm v4. Root reviewed obligation: " + own["reviewReason"]
    json_write(path, result, "Exact observed semantic union; historical before/coverage identities and both parent metadata obligations are retained.")
    job_reviews.append({"path": path, "historicalCommands": len(result["before"]), "actualCommands": len(actual)})

modules = contracts.python_expectations(ROOT)
module_paths = [path for path in original_conflicts if path.startswith("tools/ci/contracts/python/")]
module_paths.append("tools/ci/contracts/python/test_ci_contracts.py.json")
module_reviews = []
for path in sorted(set(module_paths)):
    own = contracts.semantic_record(decoded(OURS, path))
    incoming = contracts.semantic_record(decoded(THEIRS, path))
    module = incoming["module"]
    actual = modules[module]
    assert set(own["cases"]) | set(incoming["cases"]) <= set(actual["cases"]), module
    for parent in (own, incoming):
        for case in parent["cases"]:
            for key in ("bases", "classDecorators", "decorators", "skipSites"):
                assert parent["guards"][case][key] == actual["guards"][case][key], (module, case, key)
            def nonhash(values):
                return [value for value in values if ":setup-sha256:" not in value]
            assert nonhash(parent["guards"][case]["fixtureGuards"]) == nonhash(actual["guards"][case]["fixtureGuards"]), (module, case)
    result = copy.deepcopy(incoming)
    result.update(actual)
    result["reviewReason"] += " Retain both parent case/decorator/class/skip inventories and every nonhash execution guard; setup AST hashes describe the exact merged fixtures, with only maintained v4 source-policy calls replacing the obsolete builder. Root reviewed obligation: " + own["reviewReason"]
    stored = contracts.shared_python_record(result)
    assert contracts.semantic_record(stored) == result
    text_write(path, contracts.shared_python_text(stored), "Review exact merged-source v2 guards while retaining every parent case and execution decision.")
    module_reviews.append({"module": module, "oursCases": len(own["cases"]), "incomingCases": len(incoming["cases"]),
                           "actualCases": len(actual["cases"]), "caseUnionRetained": True, "skipAndDecoratorControlsRetained": True})

owner_paths = [path for path in original_conflicts if path.startswith("tools/ci/contracts/owners/")]
for path in owner_paths:
    own, incoming = decoded(OURS, path), decoded(THEIRS, path)
    result = copy.deepcopy(incoming)
    assert {key: value for key, value in own.items() if key not in {"sha256", "reviewReason"}} == {key: value for key, value in incoming.items() if key not in {"sha256", "reviewReason"}}
    result["sha256"] = hashlib.sha256((ROOT / result["path"]).read_bytes().replace(b"\r\n", b"\n")).hexdigest()
    assert result["sha256"] in {own["sha256"], incoming["sha256"]}
    result["reviewReason"] += " Retain matching Root reviewed owner obligation: " + own["reviewReason"]
    json_write(path, result, "Authenticate the exact unchanged merged owner; preserve both parent review reasons.")

changed_paths = [row["path"] for row in changes]
subprocess.run(["git", "add", "--", *changed_paths, *retired], cwd=ROOT, check=True)
assert not git("diff", "--name-only", "--diff-filter=U").strip()
subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, check=True)
receipt = {"at": datetime.now(timezone.utc).isoformat(), "root": str(ROOT), "ours": OURS, "incoming": THEIRS,
           "changes": changes, "retiredDuplicateBuilderPaths": retired, "jobReviews": job_reviews, "moduleReviews": module_reviews,
           "everyParentCaseAndHistoricalObligationRetained": True, "currentMainV4SourceGraphUsed": True,
           "obsoleteV3GraphIntroduced": False, "storageRustFeatureFilesExplicitlyOverwritten": False,
           "qualified": False, "committed": False}
(OUT / "semantic-resolution.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps({key: value for key, value in receipt.items() if key != "changes"}), flush=True)
