Delivers six authored transaction guest variants for #389, retaining actual stage-before-HTTP-denial behavior, captured compiler inputs and strict forbidden-operation assertions. Integrates development and canonical Java signing/browser contracts without dropping qualification cases.

Completes the generated empty-world Java server test fixture with the canonical C bridge file required by SDK installation. Every original service-union assertion, test guard and skip remains unchanged.

Fresh Linux source checks pass, including all nine Java server source cases and maintained SDK generation. Full CI and six signed installed guest executions remain pending.

Current recovery correction accepts the retained floor one past the high watermark for an empty/pruned trigger operation journal, preserving unknown outcome and executionPermission=false. A real bounded tonic RPC regression passes all eight response/refusal shapes; all 156 CLI cases and the original selected warnings-as-errors gate pass. Source checks pass 196 cases with zero skips. Every original receipt/scope check remains, with one case added and the original five-second deadline/16 KiB future threshold retained. This fixes the secondary invalid-management-response recovery error; the original Java trigger-apply ResourceExhausted and complete Java composition/full CI qualification remain pending.
