from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import sys

root = Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out = Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
sys.path.insert(0, str(root))
from tools import ci_contracts as c
models = c.observed_workflows(root)
names = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=root, text=True).splitlines()
for name in names:
    if not name.startswith('tools/ci/contracts/'):
        continue
    parents = [c.semantic_record(json.loads((out / label / name).read_bytes())) for label in ('ours', 'incoming')]
    ours, incoming = parents
    if ours['kind'] == 'owner':
        digest = hashlib.sha256((root / ours['path']).read_bytes()).hexdigest()
        print(json.dumps({'path': name, 'kind': 'owner', 'currentMatches': [label for label, parent in zip(('ours', 'incoming'), parents) if parent['sha256'] == digest]}))
    elif ours['kind'] in ('job', 'workflow'):
        key = 'definition' if ours['kind'] == 'job' else 'policy'
        actual = models[ours['workflow']]['jobs'][ours['jobId']] if key == 'definition' else {k: v for k, v in models[ours['workflow']].items() if k != 'jobs'}
        for label, parent in zip(('ours', 'incoming'), parents):
            if parent[key] != actual:
                print(name, label)
                print(''.join(difflib.unified_diff(json.dumps(parent[key], indent=2).splitlines(True), json.dumps(actual, indent=2).splitlines(True), fromfile=label, tofile='merged')))
    elif ours['kind'] == 'python':
        actual = c.python_expectations(root)[ours['module']]
        print(json.dumps({'path': name, 'kind': 'python', 'actualCases': len(actual['cases']), 'parentCasesRetained': [set(value['cases']) <= set(actual['cases']) for value in parents]}))

a, b = [json.loads((out / label / 'tools/ci/suites.json').read_bytes()) for label in ('ours', 'incoming')]
print('Suite non-case changes')
rows = [{row['id']: row for row in parent['suites']} for parent in (a,b)]
for ident in sorted(rows[0].keys() & rows[1].keys()):
    left, right = [{key: value for key, value in rows[index][ident].items() if key not in ('expectedCases', 'expectedIgnored', 'ignoredLeaves', 'minimumCases')} for index in (0,1)]
    if left != right:
        print(ident)
        print(''.join(difflib.unified_diff(json.dumps(left, indent=2).splitlines(True), json.dumps(right, indent=2).splitlines(True))))
print(json.dumps({'topKeys': list(a), 'topDifferent': [key for key in a.keys() | b.keys() if key != 'suites' and a.get(key) != b.get(key)]}))
