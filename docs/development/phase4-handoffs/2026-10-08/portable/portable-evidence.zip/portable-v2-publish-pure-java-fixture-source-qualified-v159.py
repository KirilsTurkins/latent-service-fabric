from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
coord=Path(__file__).resolve().parent
pr,old,head,tree,job,cases=sys.argv[1:];pr=int(pr);root=Path(tree);p=coord/job;cases=int(cases);env=dict(os.environ,GODEBUG='http2client=0');r=json.loads((p/'receipt.json').read_bytes());assert r['head']==head and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
for row in r['steps']:
 raw=(p/row['log']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
assert f'Ran {cases} tests' in (p/'step-1.log').read_text() and 'OK' in (p/'step-1.log').read_text()
paths=subprocess.check_output(['git','diff','--name-only',old,head],cwd=root,text=True).splitlines();assert paths==['tools/tests/test_java_server_source.py']
live=json.loads(subprocess.check_output(['gh','pr','view',str(pr),'--repo','KirilsTurkins/latent-service-fabric','--json','state,headRefOid,headRefName,body'],env=env,timeout=30));assert live['state']=='OPEN' and live['headRefOid']==old
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+live['headRefName']],cwd=root,text=True,env=env,timeout=45).split()[0];assert remote==old
subprocess.run(['git','push','origin',head+':refs/heads/'+live['headRefName']],cwd=root,env=env,check=True,timeout=180);remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+live['headRefName']],cwd=root,text=True,env=env,timeout=45).split()[0];assert remote==head
body=live['body'].rstrip()+f'\n\nCurrent test-only continuation completes the generated empty-world Java fixture. Linux source checks pass {cases} cases with zero skips, including all nine Java server source cases. Every production/compiler input remains byte-identical to {old[:8]}; prior native receipts retain that source head. Full CI remains pending.\n'
b=coord/f'portable-v2-pr{pr}-java-fixture-body-published.md';b.write_text(body,encoding='utf8',newline='\n');subprocess.run(['gh','pr','edit',str(pr),'--repo','KirilsTurkins/latent-service-fabric','--body-file',str(b)],env=env,check=True,timeout=45)
proof=dict(pr=pr,oldHead=old,newHead=head,normalPush=True,remoteVerified=True,onlyGeneratedFixtureProbeLineAdded=True,actualPythonCases=cases,zeroSkips=True,javaSourceCases9Passed=True,sourceReceiptSha256=hashlib.sha256((p/'receipt.json').read_bytes()).hexdigest(),allProductionAndCompilerInputsByteUnchanged=True,oldNativeReceiptsNotRelabeled=True,fullCIPending=True,noMergeOrClosure=True)
(coord/f'portable-v2-pr{pr}-java-fixture-final-publication.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8');print(json.dumps(proof))
