import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

COORD = Path(__file__).resolve().parent
TREE = Path(r"C:\Users\turkins\Desktop\lf-p4-portable-cleanup-handoff-20261008")
DEST = TREE / "docs/development/phase4-handoffs/2026-10-08/portable"
DEST.mkdir(parents=True, exist_ok=True)
inventory_raw = (COORD / "portable-v2-complete-owned-preservation-v323.json").read_bytes()
inventory = json.loads(inventory_raw)
assert inventory["allHeadsRemoteVerified"] and inventory["worktreeCount"] == 89
(DEST / "owned-worktrees.json").write_bytes(inventory_raw)
process = subprocess.run(["docker", "exec", "latent-p4-root-native-20261007-v6", "ps", "-eo", "pid,ppid,pgid,comm"], capture_output=True, text=True, timeout=30, check=True)
lines = process.stdout.splitlines()
assert all(line.split()[-1] in {"COMMAND", "docker-init", "sleep", "ps"} for line in lines)
stop = {"at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "userStopHonored": True,
        "ownedSourceNativeSdkJobsActive": 0, "allLatestObserversReaped": True,
        "containerProcessObservation": lines, "noProcessSignalsNeeded": True,
        "noPeerOrGlobalDockerAction": True, "noNewImplementationTestsOrBuilds": True}
(DEST / "stopped-processes.json").write_text(json.dumps(stop, indent=2) + "\n", encoding="utf-8")

selected = []
for path in COORD.iterdir():
    if path.is_file() and path.name.startswith("portable-v2") and path.suffix in {".py", ".json", ".md", ".patch", ".txt"} and path.stat().st_size <= 512 * 1024:
        selected.append(path)
    elif path.is_dir() and path.name.startswith("portable-v2"):
        receipt_path = path / "receipt.json"
        if not receipt_path.is_file() or receipt_path.stat().st_size > 512 * 1024:
            continue
        try:
            receipt = json.loads(receipt_path.read_bytes())
        except (ValueError, UnicodeError):
            continue
        selected.append(receipt_path)
        if not isinstance(receipt, dict):
            continue
        for name in ("host-custody.json", "actual-case-custody.json", "progress.json", "source-reuse-custody.json"):
            candidate = path / name
            if candidate.is_file() and candidate.stat().st_size <= 512 * 1024:
                selected.append(candidate)
        steps = receipt.get("steps", [])
        if not isinstance(steps, list) or not all(isinstance(row, dict) and isinstance(row.get("argv"), list) and "log" in row and "bytes" in row and "sha256" in row for row in steps):
            continue
        ordinary_cargo = steps and all(row.get("argv", [])[:2] == ["cargo", "+1.97.1"] for row in steps)
        source_job = "source" in path.name and steps and all(row.get("argv", [None])[0] == "python3" for row in steps)
        if ordinary_cargo or source_job:
            for row in steps:
                log = path / Path(row["log"]).name
                if log.is_file() and log.stat().st_size <= 2 * 1024 ** 2:
                    raw = log.read_bytes()
                    assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
                    selected.append(log)
        else:
            for name in ("receipt.json", "actual-validator.log", "final-maintained-validator.log", "buf-build.log"):
                candidate = path / name
                if candidate.is_file() and candidate.stat().st_size <= 128 * 1024:
                    selected.append(candidate)

archive = DEST / "portable-evidence.zip"
manifest = []
omitted = []
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(set(selected)):
        raw = path.read_bytes()
        text = raw.decode("utf-8", errors="replace")
        # This is preservation filtering, not a qualification or a new test.
        if re.search(r"-----BEGIN [A-Z ]*PRIVATE KEY-----|\bBearer [A-Za-z0-9._~+/-]{20,}", text):
            omitted.append({"path": path.relative_to(COORD).as_posix(), "sha256": hashlib.sha256(raw).hexdigest(), "reason": "credential-shaped-content-not-uploaded"})
            continue
        name = path.relative_to(COORD).as_posix()
        output.writestr(name, raw)
        manifest.append({"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
assert archive.stat().st_size < 25 * 1024 ** 2
(DEST / "evidence-manifest.json").write_text(json.dumps({"archive": archive.name, "archiveBytes": archive.stat().st_size,
    "archiveSha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "files": manifest,
    "credentialShapedFilesOmitted": omitted, "largeToolsCompiledGuestsAndCampaignDatabasesNotArchived": True}, indent=2) + "\n", encoding="utf-8")

head_rows = {
    784: "b43ab914f9ffbdd4fa26c26b66c913daf3342aef",
    787: "4ce4eb63a04cded8bbb4b875c1b6863a3cc84678",
    790: "9977333b18c3990e52b5aebb7e0382a26dfa35aa",
    791: "a129773f52c4fc15c59b4ce62b52744a233cd4cd",
    796: "8f85a60021786138a25f75b8fbc22c32f8789844",
    800: "5d41e9b481e78818db4ac2a8ff30095301e61f94",
    811: "f149bb009952e823c6d6f3877af80b298c5c7258",
    825: "601038c2b908144dadd11bcb48ddbab51606b5d4",
    828: "1b7a8073f9ec7b354a4dd00a365deb1c4094e3aa",
}
table = "\n".join(f"| #{number} | `{head}` |" for number, head in head_rows.items())
md = f"""# Portable Phase 4 cleanup handoff

The user stopped implementation and validation. All owned Source, Native and SDK jobs are reaped; the private container observation contains only init/sleep and the read-only process probe. No new tests, builds, Docker cleanup or worktree deletion were performed for this handoff.

The complete inventory records89 clean owned worktrees with verified remote archive refs under `checkpoint/phase4-cleanup-20261008/portable/`. Root's central preservation draft #850 also indexes the wider Phase 4 history. No uncommitted source remains in these89 trees. Peer trees are excluded from the owned list.

## Delivered existing pull-request heads at the stop

| PR | Portable delivered head |
| --- | --- |
{table}

These are preserved source states, not claims of full hosted CI, admin merge or issue completion. Root owns final remote-state refresh and ticket/PR progress comments.

## Exact recent qualification boundaries

- #784 b43: Source226 tests/all7 gates, Native all9 gates at the same head; Signing58/Node91 compiled sets equal their registry and all tests pass, activation66 passes, custom AOT12 real-entry plus exact syscall marker passes, original ordinary and selected strict gates pass. Receipt `portable-v2-pr784-current-main-native-20261008-v315/receipt.json`, SHA `0ba2625d9db20f7d41c6011137baecdbeef4133017f511f28172876f61c37ad9`.
- #811 f149: actual pinned Buf1.72.0 produced the same descriptor twice, SHA `539496c72df533c343b0904b1b4aad0546cf33adbeb110322cd911d9726fd3fd`. The tracked compact LF golden183f differs from peer physical CRLF66c only by a trailing CR; all previous semantics are preserved. Source all9 gates/226 tool tests plus12 profile tests pass. Receipt SHA `b7764c8e2b3788f1a7b4648806d19c15ad5716915279e02f3b1f1e185bd0722c`. Original v277 Source ran208 actual tests; unused arguments are corrected in v312's238 actual count. Parent335d Native9 receipts retain their actual head.
- #828 1b7: Source375 discovered/374 passed/one original Windows skip and all7 gates pass, receipt SHA `70082840aea65dc413d13df8f3430ddbbd10cf62879c91bbb325f3a42f25c317`. Existing control29 SDK suites both pass10; the later audit proves deployment preparation rejected before writer acceptance with `admission-clock-lease-uncovered`, operation lookup remains Unknown. The closed six-stage diagnostic and CLI sanitizer are published; actual new Control255/CLI162/RPC27 tests and the exact original subphase remain unqualified. No lease, grant, budget, deadline or mutation retry was added.
- #825 unchanged6010: the one infrastructure-failed Admitted C job was rerun after completed-attempt/head guards. Attempt2 completed successfully, new job113169978107. Original installer timeout and all receipts remain in the archive; other workflow qualification is separate.
- Current #791 a129 Source278/all8 gates passes, including the pinned scanner. Core127/Signing58/Node114 current Native and the separate queued Go preparation result remain pending.
- Current #796 retains Native9 at8f85 and Source227. Its original installer conflict was classified by the coordinating agent; full #397's twelve acceptance criteria were not closed by focused CI evidence.

## Distinct unpublished feature

Reference app #402 is checkpoint `7bc1ca796e5b1a2125a0fb6be905484fec6e8b63`, pushed branch `feat/phase4-reference402-current-foundation-v292` and Root-created draft #956. Source7 passes389 discovered/388 passing/one original Windows skip, with all27 app files and the finite producer branch preserved. Actual six app compilers, signed node, SSR/hydration, two-user browser, JetStream/inbox/crash redelivery, schema, rollout and dormancy remain pending. No current-foundation proof is transferred to the app.

The historical Go accounting d6 and HTTP c766 work are source-adopted in delivered feature heads. d6 is not a Git ancestor of6010, but both source files compare byte-identical there; archive it for provenance, without a duplicate active implementation PR. Root coordinates draft visibility for distinct work.

## Evidence archive and limitations

`portable-evidence.zip` stores{len(manifest)} small coordination scripts, plans, exact receipts and authenticated Source/ordinary-Cargo logs. The manifest gives every original file hash and the ZIP hash. Both passing and failed attempts retain their actual heads and outcomes. Credential-shaped content is omitted rather than uploaded. Large toolchains, compiled guest payloads and private campaign databases are not copied to this compact Git archive; their absence means historical packaged/signed execution cannot be reconstructed solely from this handoff. Source commits and retained small proofs remain durable.

No issues are closed by this handoff. No global cleanup has been performed. Automatic review previously rejected deletion of three audited SDK derivative folders; no deletion or bypass occurred.
"""
(DEST / "README.md").write_text(md, encoding="utf-8", newline="\n")
result = {"directory": str(DEST), "branch": "docs/phase4-portable-cleanup-handoff-20261008",
          "ownedWorktrees": 89, "archivedEvidenceFiles": len(manifest), "archiveBytes": archive.stat().st_size,
          "omittedCredentialShapedFiles": len(omitted), "allOwnedJobsStopped": True,
          "noImplementationTestsBuildsOrDeletion": True}
(COORD / "portable-v2-preservation-handoff-prepared-v324.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result), flush=True)
