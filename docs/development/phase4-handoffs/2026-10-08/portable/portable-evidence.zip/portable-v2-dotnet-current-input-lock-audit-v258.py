import hashlib
import json
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
rows=[]
for number,head in [(800,'f6f4a95b2dfe5f38295a70ea485f9d797d8786d8'),(811,'3a991d9922390edb3251c84aa8f926a717687d0b')]:
    def blob(path):return subprocess.check_output(['git','-C',str(REPO),'show',head+':'+path])
    lock=json.loads(blob('sdk/dotnet/protobuf.lock.json'))
    failures=[]
    for path,expected in lock['inputs'].items():
        actual=hashlib.sha256(blob('api/proto/'+path).replace(b'\r\n',b'\n')).hexdigest()
        if actual!=expected:failures.append(dict(path=path,expected=expected,actual=actual))
    rows.append(dict(pr=number,head=head,lockSDK=lock['sdkVersion'],lockRuntime=lock['runtimeVersion'],allInputHashesMatch=not failures,mismatches=failures))
(COORD/'portable-v2-dotnet-current-input-lock-audit-v258.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
print(json.dumps(rows,indent=2))
