from collections import Counter
import json
from pathlib import Path
import re
import subprocess

REPO = Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD = Path(__file__).resolve().parent

def blob(head, path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', f'{head}:{path}'])

scan_raw = (COORD / 'portable-v2-new800-791-completed-failures-v207/791/raw.log').read_text(encoding='utf8')
for line in scan_raw.splitlines():
    if '{"control_revision"' in line:
        report = json.loads(line[line.index('{'):])
        safe = {k: report[k] for k in ('source_revision','control_revision','status','finding_count','exception_count')}
        safe['findings'] = [{k:v for k,v in row.items() if k in ('tool','rule','path','line','column','kind','severity')} for row in report['findings']]
        (COORD / 'portable-v2-new800-791-completed-failures-v207/791/closed-scan-report.json').write_text(json.dumps(safe,indent=2)+'\n',encoding='utf8')
        print(json.dumps({'pr791':safe},indent=2))

head = '017385709f321b43f28a5851aca29eb2a37617d7'
fixtures = json.loads(blob(head, 'sdk/profile/fixtures.json'))['cases']
proto_paths = subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r','--name-only',head,'api/proto/latent']).decode().splitlines()
message_source = {}
for path in proto_paths:
    if path.endswith('.proto'):
        for name in re.findall(r'^message\s+(\w+)\s*\{', blob(head,path).decode(), re.M):
            message_source.setdefault(name, []).append(path)
legacy_sources = ('common','policy','capability','node','release','invocation')
legacy = [row for row in fixtures if any(Path(path).stem in legacy_sources for path in message_source.get(row['type'], []))]
all_proto = [row for row in fixtures if row['type'] in message_source]
missing = [dict(name=row['name'], type=row['type'], sources=message_source.get(row['type'],[])) for row in all_proto if row not in legacy]
result = dict(head=head, total=len(fixtures), actualSelectedLegacy=len(legacy), allDeclaredProtoCases=len(all_proto),
              selectedTypes=dict(Counter(row['type'] for row in legacy)), omittedProtoCases=missing)
(COORD / 'portable-v2-new800-791-completed-failures-v207/800/fixture-descriptor-selection.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({'pr800':result},indent=2))
