import datetime
import json
import os
from pathlib import Path
import subprocess

COORD = Path(__file__).resolve().parent
REPO = Path(r"C:\Users\turkins\Desktop\latent-fabric")
ENV = dict(os.environ, GODEBUG="http2client=0")
rows = json.loads((COORD / "portable-v2-confirmed-owned-worktrees-v321.json").read_bytes())
assert len(rows) == 89 and all(not row["statusLines"] for row in rows)


def remote_refs():
    raw = subprocess.check_output(["git", "ls-remote", "--heads", "origin"], cwd=REPO, env=ENV, timeout=90).decode("utf-8")
    return {name: sha for sha, name in (line.split() for line in raw.splitlines())}


before = remote_refs()
pending = []
for row in rows:
    name = row["worktree"].split("/")[-1]
    ref = "refs/heads/checkpoint/phase4-cleanup-20261008/portable/" + name
    if ref in before and before[ref] != row["HEAD"]:
        ref += "/head-" + row["HEAD"][:16]
    assert ref not in before or before[ref] == row["HEAD"]
    row["archiveRef"] = ref
    row["originalBranchRemoteHeadBefore"] = before.get(row.get("branch", ""))
    row["otherRemoteRefsAlreadyCoveringHead"] = [name for name, sha in before.items() if sha == row["HEAD"]]
    if ref not in before:
        pending.append(row["HEAD"] + ":" + ref)
for start in range(0, len(pending), 20):
    process = subprocess.run(["git", "-c", "http.version=HTTP/1.1", "push", "origin", *pending[start:start + 20]], cwd=REPO, env=ENV, capture_output=True, timeout=180)
    (COORD / f"portable-v2-cleanup-archive-push-v323-{start // 20 + 1}.log").write_bytes(process.stdout + process.stderr)
    assert process.returncode == 0, "archive push refused; no force push attempted"
after = remote_refs()
for row in rows:
    assert after[row["archiveRef"]] == row["HEAD"]
    row["remoteArchiveSha"] = after[row["archiveRef"]]
    row["remotePushedAndVerified"] = True
result = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "owner": "/root/portable_dependencies_v2", "worktreeCount": len(rows),
    "allOwnedWorktreesClean": True, "uncommittedSourceFiles": 0,
    "allHeadsRemoteVerified": True, "normalPushOnly": True,
    "worktreesRemoved": False, "implementationTestsOrBuildsLaunched": False,
    "ownedWorktrees": rows,
}
(COORD / "portable-v2-complete-owned-preservation-v323.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in result.items() if k != "ownedWorktrees"}), flush=True)
