from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr825-fd-main-v251')
REPO='KirilsTurkins/latent-service-fabric'
OLD='ab1acbcf8db005af21ecef88e01cccb393d1f7a6'
HEAD='03466b9062da20222e6fcdd8b0c6a2ed6dec5fbd'
NATIVE='8e0125db0bb21b3e456f5450fd64a24b0caee3d5'
BRANCH='feat/phase4-391-dispatch-capacity'
ENV=dict(os.environ,GODEBUG='http2client=0')
def call(argv):return subprocess.check_output(argv,env=ENV,timeout=120)
def receipt(job,head):
    p=COORD/job
    raw=(p/'receipt.json').read_bytes();r=json.loads(raw)
    assert r['head']==head and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped'] and r['infrastructureError'] is None
    for row in r['steps']:
        data=(p/Path(row['log']).name).read_bytes()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped']
    return hashlib.sha256(raw).hexdigest()
source_sha=receipt('portable-v2-pr825-final-main-source-20261008-v252',HEAD)
native_sha=receipt('portable-v2-pr825-core-current-native-20261008-v249',NATIVE)
delta=call(['git','-C',str(TREE),'diff','--name-only',NATIVE,HEAD]).decode().splitlines()
assert all(p.startswith('docs/evidence/') or p=='tools/java_http_composition/qualify.py' for p in delta)
assert not call(['git','-C',str(TREE),'status','--porcelain'])
assert call(['git','-C',str(TREE),'rev-parse','HEAD']).decode().strip()==HEAD
pr=json.loads(call(['gh','pr','view','825','--repo',REPO,'--json','headRefOid,headRefName,state']))
assert pr==dict(headRefOid=OLD,headRefName=BRANCH,state='OPEN')
call(['git','-C',str(TREE),'merge-base','--is-ancestor',OLD,HEAD])
body='''Retains finite dispatcher and native-owner capacity through physical retirement for #391. Child fuel is reconciled at service admission; native host memory is charged once and stays owned until cleanup. The real admission view and optional original key version remain intact across all six authoring templates.

Normally includes current development, all existing cases, bounds and ignore controls, and the required AOT sandbox floor. Linux source checks pass 226 cases with zero skips. On the source-paired runtime parent, exact Core127, Signing58, Node106 and activation66 cases pass, the twelve real AOT probes and syscall check pass, and ordinary plus registered selected strict Clippy pass. The later development delta contains documentation and two Java evidence-recording lines; all Rust, ABI, SDK and test bytes remain identical.

Earlier twelve compiler variants and ten retained-fixture Go SDK cases remain evidence at their original source heads. Full current CI, fresh guest/runtime qualification, and the installed dispatcher startup, ordering and recovery gates remain pending. All failed attempts are retained.
'''
body_path=COORD/'portable-v2-pr825-current-fd-body-v255.md'
body_path.write_text(body,encoding='utf8')
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=825,oldHead=OLD,head=HEAD,nativeHead=NATIVE,branch=BRANCH,
           sourceReceiptSha256=source_sha,nativeReceiptSha256=native_sha,exactRuntimeByteClosure=True,
           normalPush=True,completeCI=False,issueNotClosed=True,published=False)
out=COORD/'portable-v2-pr825-current-fd-publication-v255.json'
out.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
push=subprocess.run(['git','-C',str(TREE),'push','origin',f'HEAD:refs/heads/{BRANCH}'],env=ENV,capture_output=True,timeout=120)
(COORD/'portable-v2-pr825-current-fd-push-v255.log').write_bytes(push.stdout+push.stderr)
assert push.returncode==0
actual=call(['git','-C',str(TREE),'ls-remote','origin',f'refs/heads/{BRANCH}']).decode().split()[0]
assert actual==HEAD
call(['gh','pr','edit','825','--repo',REPO,'--body-file',str(body_path)])
proof.update(published=True,verifiedRemoteHead=actual,bodyUpdated=True)
out.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
