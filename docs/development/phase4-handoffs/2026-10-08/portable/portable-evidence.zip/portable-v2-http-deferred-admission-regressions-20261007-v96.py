﻿from pathlib import Path
import json
repo=Path(r'C:\Users\turkins\Desktop\lf-p4-http-deferred-admission-v96');p=repo/'crates/latent-capabilities/src/broker/pools/tests/deferred/admission.rs'
s=p.read_text();s+='''#[tokio::test]
async fn deferred_registry_inspection_waits_without_false_capacity_or_socket_allocation() {
    for lookup in [false, true] {
        let setup = Setup::new(single());
        let (context, request) = request(&setup, lookup, None);
        let mut waiting = Box::pin(setup.client.reserve_deferred_connection_wait(&request));
        {
            let _inspection = setup.pools.inner.state.lock().unwrap();
            // Demonstrate the original immediate refusal under this exact lock,
            // with available physical capacity and an already accepted request.
            assert_eq!(
                setup.client.reserve_deferred_connection(&request).err().unwrap().code,
                PlatformErrorCode::ResourceExhausted
            );
            pending(waiting.as_mut());
            assert_eq!(setup.pools.inner.quotas.use_of(Kind::Connection), 0);
            assert!(!setup.client.core.backoff.lock().unwrap().dialing);
        }
        let reservation = waiting.await.unwrap();
        assert_eq!(setup.pools.snapshot().unwrap().connecting_connections, 1);
        assert_eq!(setup.pools.inner.quotas.use_of(Kind::Connection), 1);
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let stream = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
        let (mut peer, _) = listener.accept().unwrap();
        peer.set_read_timeout(Some(Duration::from_secs(1))).unwrap();
        let connection = reservation.connected(stream).unwrap();
        drop(request);
        assert_eq!(setup.pools.snapshot().unwrap().connections, 1);
        assert_eq!(setup.pools.snapshot().unwrap().running_requests, u64::from(!lookup) as usize);
        assert_eq!(setup.pools.snapshot().unwrap().cleanup_jobs, usize::from(lookup));
        drop(connection);
        assert_eq!(peer.read(&mut [0]).unwrap(), 0);
        context.retire().unwrap();
        clean(&setup.pools).await;
    }
}

#[tokio::test]
async fn deferred_backoff_inspection_waits_without_starting_or_retrying_a_dial() {
    for lookup in [false, true] {
        let setup = Setup::new(single());
        let (context, request) = request(&setup, lookup, None);
        let mut waiting = Box::pin(setup.client.reserve_deferred_connection_wait(&request));
        {
            let _inspection = setup.client.core.backoff.lock().unwrap();
            pending(waiting.as_mut());
            assert_eq!(setup.pools.inner.quotas.use_of(Kind::Connection), 0);
        }
        let reservation = waiting.await.unwrap();
        assert_eq!(setup.pools.snapshot().unwrap().connecting_connections, 1);
        drop((reservation, request));
        context.retire().unwrap();
        clean(&setup.pools).await;
    }
}

#[tokio::test]
async fn deferred_idle_contention_waits_and_fresh_lookup_never_borrows_a_guest_socket() {
    for lookup in [false, true] {
        let setup = Setup::new(single());
        let (session, _control) = setup.session("original-idle-socket");
        let call = setup.call(&session).await;
        let (mut connection, _peer) = connect(&setup.client, &call);
        let address = connection.resource().local_addr().unwrap();
        connection.park().unwrap();
        drop((call, session));
        let (context, request) = request(&setup, lookup, None);
        let mut waiting = Box::pin(setup.client.checkout_deferred_wait(&request));
        {
            let _inspection = setup.client.idle.lock().unwrap();
            if lookup {
                assert!(ready(waiting.as_mut()).unwrap().is_none());
            } else {
                pending(waiting.as_mut());
            }
            assert_eq!(setup.pools.inner.quotas.use_of(Kind::Connection), 1);
            assert_eq!(setup.pools.inner.quotas.use_of(Kind::Idle), 1);
        }
        if lookup {
            drop(waiting);
        } else {
            let mut reused = waiting.await.unwrap().unwrap();
            assert_eq!(reused.resource().local_addr().unwrap(), address);
            assert_eq!(setup.pools.snapshot().unwrap().idle_connections, 0);
            drop(reused);
        }
        drop(request);
        context.retire().unwrap();
        clean(&setup.pools).await;
    }
}

#[tokio::test]
async fn deferred_actual_capacity_active_dial_and_backoff_keep_immediate_refusals() {
    for lookup in [false, true] {
        let setup = Setup::new(ProviderPoolLimits {
            maximum_connections: 1,
            maximum_connections_per_client: 1,
            maximum_idle_connections: 1,
            ..ProviderPoolLimits::default()
        });
        let (context, request) = request(&setup, lookup, None);
        let charge = setup.pools.inner.quotas.acquire(Kind::Connection, 1).unwrap();
        assert_eq!(
            ready(setup.client.reserve_deferred_connection_wait(&request)).err().unwrap().code,
            PlatformErrorCode::ResourceExhausted
        );
        drop(charge);
        let reservation = ready(setup.client.reserve_deferred_connection_wait(&request)).unwrap();
        assert_eq!(
            ready(setup.client.reserve_deferred_connection_wait(&request)).err().unwrap().code,
            PlatformErrorCode::ResourceExhausted
        );
        drop(reservation);
        let failure = ready(setup.client.reserve_deferred_connection_wait(&request)).err().unwrap();
        assert_eq!(failure.code, PlatformErrorCode::Unavailable);
        assert_eq!(failure.message, "provider-backoff");
        assert_eq!(setup.pools.inner.quotas.use_of(Kind::Connection), 0);
        drop(request);
        context.retire().unwrap();
        clean(&setup.pools).await;
    }
}

#[tokio::test]
async fn deferred_wait_preserves_original_deadline_and_abandonment_retirement() {
    for lookup in [false, true] {
        for action in ["expire", "abandon", "retire"] {
            let setup = Setup::new(single());
            let (context, request) = request(
                &setup,
                lookup,
                Some(Instant::now() + Duration::from_millis(100)),
            );
            let original = request.deadline();
            let mut waiting = Box::pin(setup.client.reserve_deferred_connection_wait(&request));
            {
                let _inspection = setup.pools.inner.state.lock().unwrap();
                pending(waiting.as_mut());
                if action == "expire" {
                    std::thread::sleep(Duration::from_millis(125));
                }
                assert_eq!(setup.pools.inner.quotas.use_of(Kind::Connection), 0);
            }
            if action == "abandon" {
                drop(waiting);
            } else {
                if action == "retire" {
                    setup.pools.retire();
                }
                assert_eq!(
                    waiting.await.err().unwrap().code,
                    if action == "expire" {
                        PlatformErrorCode::DeadlineExceeded
                    } else {
                        PlatformErrorCode::PermissionDenied
                    }
                );
            }
            assert_eq!(request.deadline(), original);
            assert_eq!(setup.pools.inner.quotas.use_of(Kind::Connection), 0);
            drop(request);
            context.retire().unwrap();
            clean(&setup.pools).await;
        }
    }
}

#[tokio::test]
async fn deferred_poisoned_registry_fails_closed_without_waiting_or_reserving() {
    for lookup in [false, true] {
        let setup = Setup::new(single());
        let (context, request) = request(&setup, lookup, None);
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let _inspection = setup.pools.inner.state.lock().unwrap();
            panic!("controlled deferred registry poison");
        })).is_err());
        let failure = ready(setup.client.reserve_deferred_connection_wait(&request)).err().unwrap();
        assert_eq!(failure.code, PlatformErrorCode::Unavailable);
        assert_eq!(failure.message, "provider-client-owner-poisoned");
        assert_eq!(setup.pools.inner.quotas.use_of(Kind::Connection), 0);
        setup.pools.inner.state.clear_poison();
        drop(request);
        context.retire().unwrap();
        clean(&setup.pools).await;
    }
}

#[tokio::test]
async fn deferred_wait_cannot_select_another_client_or_revive_a_retired_epoch() {
    for lookup in [false, true] {
        let setup = Setup::new(single());
        let (context, request) = request(&setup, lookup, None);
        let wrong = setup.pools.client::<TcpStream>(&setup.provider, 1).unwrap();
        assert_eq!(
            ready(wrong.reserve_deferred_connection_wait(&request)).err().unwrap().code,
            PlatformErrorCode::PermissionDenied
        );
        assert_eq!(
            ready(wrong.checkout_deferred_wait(&request)).err().unwrap().code,
            PlatformErrorCode::PermissionDenied
        );
        let replacement = install(&setup.pools, "secrets", 2, 1, b"rotated-deferred-secret");
        assert_eq!(
            ready(setup.client.reserve_deferred_connection_wait(&request)).err().unwrap().code,
            PlatformErrorCode::PermissionDenied
        );
        assert_eq!(
            ready(setup.client.checkout_deferred_wait(&request)).err().unwrap().code,
            PlatformErrorCode::PermissionDenied
        );
        assert_eq!(setup.pools.inner.quotas.use_of(Kind::Connection), 0);
        drop((request, replacement));
        context.retire().unwrap();
        clean(&setup.pools).await;
    }
}
'''
s=s.replace('u64::from(!lookup) as usize','usize::from(!lookup)');p.write_text(s,encoding='utf8',newline='\n')
# Register only the seven additive cases, preserving every original case/ignore and formatter shape.
p=repo/'tools/ci/suites.json';raw=p.read_bytes();x=json.loads(raw);suite=next(s for s in x['suites'] if s['id']=='latent-capabilities.lib.latent-capabilities')
import re
cases=re.findall(r'#\[tokio::test\]\nasync fn ([a-z_]+)\(',s);assert len(cases)==7
new=['broker::pools::tests::deferred::admission::'+name for name in cases]
assert suite['minimumCases']==160 and not (set(new)&set(suite['expectedCases']))
suite['expectedCases']=sorted(suite['expectedCases']+new);suite['minimumCases']+=len(new)
# Original compact encoding uses sorted keys and no separator whitespace.
assert json.dumps(json.loads(raw),sort_keys=True,separators=(',',':')).encode()+b'\n'==raw
p.write_bytes(json.dumps(x,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('Added seven real deferred request admission schedules; all160 parent cases preserved; registered floor167.')
