from pathlib import Path
import copy
import hashlib
import json
import subprocess

root = Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out = Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
records = []
def parents(name):
    return [json.loads((out / label / name).read_bytes()) for label in ('ours', 'incoming')]
def save(name, value):
    original = (out / 'ours' / name).read_bytes()
    compact = b'\n' not in original.rstrip()
    encoded = json.dumps(value, ensure_ascii=False, separators=(',', ':') if compact else None, indent=None if compact else 2) + '\n'
    (root / name).write_bytes(encoded.encode())
    records.append({'path': name, 'sha256': hashlib.sha256(encoded.encode()).hexdigest()})

# The current inventory strictly includes the peer inventory, adding two exact
# compiler helper manifests. Their no-external-package disposition is retained.
name = '.github/security/inventory.json'
ours, incoming = parents(name)
for key in set(ours) | set(incoming):
    if key == 'manifests':
        assert all(row in ours[key] for row in incoming[key])
    else:
        assert ours[key] == incoming[key]
save(name, ours)

# The peer descriptor is additive: existing descriptor fields/types/numbers,
# enum values, RPC definitions and oneof shapes must all remain identical.
def subset(left, right, path=''):
    if isinstance(left, dict):
        assert isinstance(right, dict) and set(left) <= set(right), path
        for key, value in left.items():
            subset(value, right[key], path + '/' + key)
    elif isinstance(left, list):
        assert isinstance(right, list), path
        for index, value in enumerate(left):
            if isinstance(value, dict) and 'name' in value:
                matches = [row for row in right if isinstance(row, dict) and row.get('name') == value['name']]
                assert len(matches) == 1, (path, value['name'])
                subset(value, matches[0], path + '/' + value['name'])
            else:
                assert value in right, (path, index)
    else:
        assert left == right, (path, left, right)
name = 'api/proto/phase1-descriptor-contract.json'
ours, incoming = parents(name)
combined = copy.deepcopy(incoming)
audit = next(value for value in combined['file'] if value['name'] == 'latent/control/v1/audit.proto')
resources = next(value for value in audit['enumType'] if value['name'] == 'AuditCapabilityResourceClass')
stream = {'name': 'AUDIT_CAPABILITY_RESOURCE_CLASS_STREAM', 'number': 12}
assert stream not in resources['value']
assert all(value['number'] != 12 for value in resources['value'])
assert 'AUDIT_CAPABILITY_RESOURCE_CLASS_STREAM = 12;' in (root / 'api/proto/latent/control/v1/audit.proto').read_text()
resources['value'].append(stream)
subset(ours, combined)
subset(incoming, combined)
save(name, combined)

# Keep the current activation and network resources. The state/intents rules
# add only explicit host recovery/dispatch purpose labels, never guest imports.
for name in ('schemas/capability-policy.schema.json', 'schemas/capability-provider-binding.schema.json'):
    ours, incoming = parents(name)
    policy = name.endswith('capability-policy.schema.json')
    left = ours['$defs']['rule']['allOf'] if policy else ours['allOf']
    right = incoming['$defs']['rule']['allOf'] if policy else incoming['allOf']
    identity = lambda value: value['if']['properties']['capability']['const']
    old = {identity(value): value for value in left}
    for item in right:
        cap = identity(item)
        original = old[cap]
        before, after = copy.deepcopy(original), copy.deepcopy(item)
        before_properties = before['then']['properties'] if policy else before['then']['properties']['restriction']['properties']
        after_properties = after['then']['properties'] if policy else after['then']['properties']['restriction']['properties']
        before_ops = before_properties['operations']['items'].pop('enum')
        after_ops = after_properties['operations']['items'].pop('enum')
        assert before == after and set(before_ops) <= set(after_ops), (name, cap)
        if before_ops != after_ops:
            assert cap in ('latent:state/key-value@0.2.0', 'latent:intents/staging@0.1.0')
            left[left.index(original)] = item
    save(name, ours)

# The installed state runtime changes the actual Cargo dependency graph. Retain
# the peer's stronger full-profile selection and current reverse-edge fixtures.
name = 'tools/tests/fixtures/ci-suites/affected.json'
ours, incoming = parents(name)
combined = copy.deepcopy(ours)
for row in combined['cases']:
    if row['name'] == 'narrow-reverse-dependents':
        replacement = next(value for value in incoming['cases'] if value['name'] == row['name'])
        row.update(replacement)
save(name, combined)

# Suite definitions are exact apart from the explicitly enumerated case sets.
# Preserve every parent case, every ignored-control marker and the higher floor.
name = 'tools/ci/suites.json'
ours, incoming = parents(name)
combined = copy.deepcopy(ours)
case_fields = {'expectedCases', 'expectedIgnored', 'ignoredLeaves', 'minimumCases'}
left = {row['id']: row for row in combined['suites']}
for row in incoming['suites']:
    ident = row['id']
    if ident not in left:
        combined['suites'].append(row)
        continue
    original = left[ident]
    assert {k:v for k,v in original.items() if k not in case_fields} == {k:v for k,v in row.items() if k not in case_fields}, ident
    for key in ('expectedCases', 'expectedIgnored', 'ignoredLeaves'):
        if key in original or key in row:
            original[key] = sorted(set(original.get(key, [])) | set(row.get(key, [])))
    if 'minimumCases' in original or 'minimumCases' in row:
        assert 'minimumCases' in original and 'minimumCases' in row, ident
        original['minimumCases'] = max(original['minimumCases'], row['minimumCases'], len(original.get('expectedCases', [])))
combined['suites'].sort(key=lambda value: value['id'])
for key in set(ours) | set(incoming):
    if key in ('suites', 'fastPackages', 'narrowPackages'):
        continue
    assert ours[key] == incoming[key], key
for key in ('fastPackages', 'narrowPackages'):
    # Removing packages which now transitively depend on runtime is necessary
    # for the unchanged forbiddenFastDependencies contract, not reduced tests.
    assert set(incoming[key]) <= set(ours[key]), key
    combined[key] = incoming[key]
save(name, combined)
subprocess.run(['git', 'add', '--', *(row['path'] for row in records)], cwd=root, check=True)
(out / 'model-resolution-v2.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'resolvedModels': len(records), 'descriptorStrictlyAdditive': True, 'allParentSuiteCasesRetained': True, 'noFloorOrDeadlineRelaxation': True}))
