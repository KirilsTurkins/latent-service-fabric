Select exact-pinned redb 4.3.0 for the bounded shared state, command and outbox store. Accepted ADR-0063 compares SQLite and records the locking, flush, backup, recovery, format, worker, queue, handle and snapshot decisions. The existing engine prototype, durability and process-crash qualification sources remain behind the shared store boundaries.

This head integrates development `3d77ab9e` and the authorized 64 MiB source capture budget, with a separate 72 MiB archive/process allowance and unchanged file, directory and per-file bounds. It preserves the stronger state/full-renderer and narrow-profile assertions, every parent testcase/skip/decorator obligation, historical command mapping, and current artifact/qualification requirements. Dependency preparation uses the maintained authenticated npm v4 and its two repaired libraries, with independent source reconstruction and exact advisory-revision matching.

Validation of `259f5fd96526a2f7a4f7a4dbf55a5658363142c3`:

- The bounded Linux source campaign passes all six steps: 288 discovered test cases, 286 pass and two unchanged platform skips, including CI/security/capture/process and changed native-policy fixtures plus all 15 package-manager fixtures.
- CI coverage retains 88 historical obligations, 259 current run blocks and 138 delegated owners. Repository and documentation validation pass. The actual dependency scan reports zero findings and two verified source remediations.
- Rust formatting and locked offline Cargo metadata pass; the 51-member workspace retains exact `redb =4.3.0`. The source checkout is clean, and exact commit/tree/log digests plus process retirement are retained.
- The earlier Windows documentation observer reached its original 180-second bound without output. That failed attempt remains preserved; the authoritative Linux documentation check passes within the original bounded campaign.

Earlier engine/native/crash receipts remain tied to their recorded commits. Current-head hosted CI and final #381 acceptance reconciliation remain required before merge or issue closure.

Refs #381.
