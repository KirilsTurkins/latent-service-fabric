from pathlib import Path

COORD=Path(__file__).resolve().parent
source=(COORD/'portable-v2-dotnet-lock-native-reproduction-v259.py').read_text(encoding='utf8')
source=source.replace('v259','v261').replace('f6f4a95b2dfe5f38295a70ea485f9d797d8786d8','3a991d9922390edb3251c84aa8f926a717687d0b')
path=COORD/'portable-v2-pr811-own-lock-native-reproduction-v261.py'
compile(source,str(path),'exec')
assert not path.exists()
path.write_text(source,encoding='utf8')
