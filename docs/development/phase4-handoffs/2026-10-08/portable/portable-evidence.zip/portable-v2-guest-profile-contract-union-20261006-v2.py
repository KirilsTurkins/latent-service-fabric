from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

root=Path(sys.argv[1]).resolve()
label=sys.argv[2]
assert root.name in ('lf-p4-sdk784-main64-20261006-v1','lf-p4-reference-app-402-20261006')
out=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination')/('portable-v2-'+label+'-profile-union-20261006-v2')
out.mkdir(exist_ok=False)
sys.path.insert(0,str(root))
from tools import ci_contracts as c
name='tools/ci/contracts/python/test_transaction_guest_authoring.py.json'
unmerged=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=root,text=True).splitlines()
assert unmerged==[name],unmerged
raw=[subprocess.check_output(['git','show',f':{stage}:'+name],cwd=root) for stage in (2,3)]
for parent,data in zip(('ours','incoming'),raw):
    (out/(parent+'.json')).write_bytes(data)
parents=[c.semantic_record(json.loads(data)) for data in raw]
ours,incoming=parents
assert ours['kind']==incoming['kind']=='python' and ours['module']==incoming['module']
actual=c.python_expectations(root)[ours['module']]
assert actual['cases']==sorted(set(ours['cases'])|set(incoming['cases']))
for parent in parents:
    for case,guard in parent['guards'].items():
        assert guard==actual['guards'][case],(case,'guard-drift')
chosen=copy.deepcopy(ours)
chosen.update(actual)
chosen['reviewReason']=(ours['reviewReason']+' Retain exact profile-selection repair: '+incoming['reviewReason']+' Both immutable parent case sets, decorators, skip sites and fixture guards remain exact; the additional manifest test proves transaction opt-in, default-off capture and refusal of the wrong binding profile without granting runtime authority.')
if json.loads(raw[0])['schemaVersion']==c.PYTHON_STORAGE_SCHEMA:
    chosen=c.shared_python_record(chosen)
compact=b'\n' not in raw[0].rstrip()
encoded=json.dumps(chosen,ensure_ascii=False,separators=(',',':') if compact else None,indent=None if compact else 2)+'\n'
(root/name).write_bytes(encoded.encode())
subprocess.run(['git','add','--',name],cwd=root,check=True)
subprocess.run(['git','cherry-pick','--continue'],cwd=root,check=True)
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root).strip()
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'clean':True,'authoringCases':len(actual['cases']),'allParentGuardsExact':True,'published':False,'nativeEvidence':'shared 50869 narrow Root eight-step compose only; exact descendant Source pending'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
