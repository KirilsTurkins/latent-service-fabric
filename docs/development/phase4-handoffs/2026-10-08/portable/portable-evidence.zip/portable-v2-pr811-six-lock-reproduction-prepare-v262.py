from pathlib import Path

COORD=Path(__file__).resolve().parent
source=(COORD/'portable-v2-pr811-own-lock-native-reproduction-v261.py').read_text(encoding='utf8')
source=source.replace('v261','v262')
source=source.replace('len(protos)==9','len(protos)==6').replace('len(files)==16','len(files)==10').replace('generatedSources=16','generatedSources=10')
needle="result=subprocess.run(['docker','exec',OWNER,'python3','-X','utf8','-B',guest+'/runner.py'],capture_output=True,timeout=120)"
replacement="""ownership = "from pathlib import Path;import os;p=Path("+repr(guest)+");assert p.is_dir() and not p.is_symlink();xs=[p,*p.rglob('*')];assert len(xs)<64 and all(not x.is_symlink() and x.resolve().is_relative_to(p.resolve()) for x in xs);[os.chown(x,10001,10001) for x in xs]"
subprocess.run(['docker','exec','--user','0',OWNER,'python3','-c',ownership],check=True,timeout=30)
result=subprocess.run(['docker','exec',OWNER,'python3','-X','utf8','-B',guest+'/runner.py'],capture_output=True,timeout=120)"""
assert source.count(needle)==1
source=source.replace(needle,replacement)
target=COORD/'portable-v2-pr811-six-lock-native-reproduction-v262.py'
compile(source,str(target),'exec')
assert not target.exists()
target.write_text(source,encoding='utf8')
