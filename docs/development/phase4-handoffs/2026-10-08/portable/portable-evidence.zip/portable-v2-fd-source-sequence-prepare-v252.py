from pathlib import Path

COORD=Path(__file__).resolve().parent
source=(COORD/'portable-v2-owned-signing-source-sequence-v239.py').read_text(encoding='utf8')
source=source.replace('v239','v252')
source=source.replace("previous='portable-v2-pr796-final-main-source-20261008-v234'","previous='portable-v2-pr791-final-main-source-20261008-v245'")
source=source.replace('for number in (790,800,791,787,796,784,825,811):','for number in (825,800,790,811,791,787,796,784):')
source=source.replace("record=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-union-v238/receipt.json')).read_bytes())", "record=json.loads((COORD/('portable-v2-pr'+str(number)+'-fd-main-union-v251.json')).read_bytes())")
path=COORD/'portable-v2-owned-fd-source-sequence-v252.py'
compile(source,str(path),'exec')
assert not path.exists()
path.write_text(source,encoding='utf8')
print(str(path))
