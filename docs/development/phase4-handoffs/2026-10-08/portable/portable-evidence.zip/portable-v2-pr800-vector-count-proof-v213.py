from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

REPO = Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD = Path(__file__).resolve().parent
OLD = '017385709f321b43f28a5851aca29eb2a37617d7'
HEAD = 'a94e696f13a1d22a37c962d7b577ea7535a54f85'
def blob(head,path):
    return subprocess.check_output(['git','-C',str(REPO),'show',f'{head}:{path}'])
assert subprocess.check_output(['git','-C',str(REPO),'diff','--name-only',OLD,HEAD],text=True).splitlines() == ['sdk/dotnet/Latent.Sdk.Transport.Tests/Vectors.cs']
assert blob(OLD,'sdk/profile/fixtures.json') == blob(HEAD,'sdk/profile/fixtures.json')
profile = json.loads(blob(HEAD,'sdk/profile/client-profile.json'))
fixtures = json.loads(blob(HEAD,'sdk/profile/fixtures.json'))['cases']
vectors = blob(HEAD,'sdk/dotnet/Latent.Sdk.Transport.Tests/Vectors.cs').decode()
descriptors = re.findall(r'Latent\.([\w.]+)Reflection\.Descriptor',vectors)
paths = subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r','--name-only',HEAD,'api/proto/latent']).decode().splitlines()
selected = set()
for path in paths:
    if path.endswith('.proto'):
        text = blob(HEAD,path).decode()
        package = re.search(r'^package\s+([\w.]+);',text,re.M).group(1)
        namespace = '.'.join(p[0].upper()+p[1:] for p in package.split('.')[1:])
        reflected = namespace+'.'+Path(path).stem.replace('_',' ').title().replace(' ','')
        if reflected in descriptors:
            selected.update(re.findall(r'^message\s+(\w+)\s*\{',text,re.M))
proto_cases = [row for row in fixtures if row['type'] in selected]
assert len(proto_cases) == 62 and len(fixtures) == 78
assert len({row['name'] for row in proto_cases}) == 62
assert all(row['type'] not in selected for row in fixtures if row not in proto_cases)
proof = dict(at=datetime.now(timezone.utc).isoformat(),head=HEAD,parent=OLD,fixturesSha256=hashlib.sha256(blob(HEAD,'sdk/profile/fixtures.json')).hexdigest(),
             sameAll78FixtureBodies=True,actualSelectedProtoCases=62,nonProtoCases=16,
             descriptorSetUnchanged=True,noFixtureSkippedOrRemoved=True,selectedCaseNames=[row['name'] for row in proto_cases],
             originalWitnessCases=[row['name'] for row in proto_cases if 'witness' in row['name']], actualTransportTestPending=True)
(COORD/'portable-v2-pr800-vector-count-proof-v213.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k!='selectedCaseNames'},indent=2))
