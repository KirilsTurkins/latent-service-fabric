from pathlib import Path
import hashlib,json,os,sys
source=Path.cwd(); sys.path.insert(0,str(source))
from tools.rust_capsule_project import ROOT,snapshot,inventory
from tools.build_observation import build_environment,file_identity
from tools.rust_capsule_build import Commands
from tools.dotnet_guest.compiler import runtime_inputs
from tools.dotnet_guest.runtime import ADAPTERS
from tools.dotnet_guest import http_errors
base=Path('/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data'); tools=Path('/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data/jobs/portable-v2-aggregate-compiler-tools-20261008-v114/dotnet/tools'); out=Path('/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data/jobs/portable-v2-dotnet-current-runtime-tools-20261008-v118/preparation')
assert str(ROOT)==str(source) and tools.is_dir() and not out.exists()
out.mkdir(mode=0o700); env=build_environment(out);env.update(RUSTUP_TOOLCHAIN='1.97.1',DOTNET_CLI_TELEMETRY_OPTOUT='1',DOTNET_SKIP_FIRST_TIME_EXPERIENCE='1',DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE='true',DOTNET_ROLL_FORWARD='Disable',DOTNET_CLI_HOME=str(out/'cli-home'),MSBUILDDISABLENODEREUSE='1',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0')
command=Commands(source,out,env); dotnet=Path('/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data/jobs/portable-v2-aggregate-compiler-tools-20261008-v114/dotnet/dotnet/dotnet');wasm=Path('/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data/jobs/portable-v2-aggregate-compiler-tools-20261008-v114/bin/wasm-tools');target=base/'target'
assert command.run('dotnet-version',dotnet,'--version').strip()==b'10.0.100'
assert command.run('wasm-version',wasm,'--version').split()[:2]==[b'wasm-tools',b'1.254.0']
original=(tools/'runtime-inputs.json').read_bytes();(out/'original-runtime-inputs.json').write_bytes(original);before=runtime_inputs(ROOT)
originals={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in tools.glob('*.wasm')}
http_errors.install(ROOT/'sdk/dotnet-guest',tools,dotnet,command.run)
command.run('closed-runtime-compile','cargo','build','--quiet','--locked','--manifest-path',ROOT/'tools/toolchain-smoke/Cargo.toml','-p','latent-toolchain-smoke',*(arg for example,_ in ADAPTERS.values() for arg in ('--example',example)),'--target','wasm32-unknown-unknown','--release','--target-dir',target)
for profile,(example,binary) in ADAPTERS.items():
 command.run(profile+'-runtime-component',wasm,'component','new',target/'wasm32-unknown-unknown/release/examples'/(example.replace('-','_')+'.wasm'),'-o',out/binary)
assert runtime_inputs(ROOT)==before
for _,(_,binary) in ADAPTERS.items(): (tools/binary).write_bytes((out/binary).read_bytes())
(tools/'runtime-inputs.json').write_bytes(before)
receipt=dict(sourceRevision=command.run('source-revision','git','rev-parse','HEAD').decode().strip(),runtimeInputDigest='sha256:'+hashlib.sha256(before).hexdigest(),originalRuntimeInputDigest='sha256:'+hashlib.sha256(original).hexdigest(),originalAdapters=originals,newAdapters={binary:file_identity(tools/binary,binary) for _,binary in ADAPTERS.values()},httpErrors=http_errors.verify_installed(ROOT/'sdk/dotnet-guest',tools),commands=command.records,actualRebuild=True,compiledApplication=False)
(out/'report.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
