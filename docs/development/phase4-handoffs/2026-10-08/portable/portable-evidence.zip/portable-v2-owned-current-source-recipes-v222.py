from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
heads={row['pr']:row['head'] for row in json.loads((COORD/'portable-v2-owned-main-inventory-audit-v219.json').read_bytes())}
recipes={790:'portable-v2-pr790-binding-source-steps-v208.json',800:'portable-v2-pr800-dotnet-source-steps-v213.json',
         791:'portable-v2-pr791-guard-layout-source-steps-v211.json',787:'portable-v2-pr787-java-fixture-source-steps-v159.json',
         796:'portable-v2-pr796-completed-ci-source-steps-v164.json',784:'portable-v2-pr784-empty-trigger-box-source-steps-v199.json',
         825:'portable-v2-pr825-service-accounting-source-steps-v192.json'}
added=['tools.tests.test_java_diagnostic_program','tools.tests.test_java_provider_timeout','tools.tests.test_java_resource_diagnostics']
proof=[]
for number,head in heads.items():
    steps=json.loads((COORD/recipes[number]).read_bytes())
    original=list(steps[0])
    for module in added:
        assert subprocess.run(['git','-C',str(REPO),'cat-file','-e',head+':'+module.replace('.','/')+'.py'],capture_output=True).returncode==0
        if module not in steps[0]:steps[0].append(module)
    assert set(original)<=set(steps[0])
    steps[3][-1]='target/ci/observed-pr'+str(number)+'-current-main-v222.json'
    job='portable-v2-pr'+str(number)+'-current-main-source-20261008-v222'
    if number in (790,791):
        old_job='portable-v2-pr790-binding-source-20261008-v208' if number==790 else 'portable-v2-pr791-guard-layout-source-20261008-v211'
        steps[-1][-1]=steps[-1][-1].replace(old_job,job)
    path=COORD/('portable-v2-pr'+str(number)+'-current-main-source-steps-v222.json')
    path.write_text(json.dumps(steps,indent=2)+'\n',encoding='utf8')
    proof.append(dict(pr=number,head=head,job=job,steps=str(path),stepsSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                      originalModulesPreserved=True,threeNewMainModulesPresent=True,sourcePending=True))
(COORD/'portable-v2-owned-current-source-recipes-v222.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps([dict(pr=row['pr'],head=row['head'],job=row['job']) for row in proof],indent=2))
