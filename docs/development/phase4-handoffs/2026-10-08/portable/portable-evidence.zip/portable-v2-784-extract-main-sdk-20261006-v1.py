"""Create a two-parent SDK-only merge using a private index, without tree edits."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
out = Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-784-main-sdk-extract-20261006-v1")
assert not out.exists()
out.mkdir()
application = "bd020400583e13393de029f2420e3cf4a31fcc50"
merged = "ce284d47834b1e38b11cc39bfc99906bbecdcdb3"
original = "438c08e67d404b905d2d9f39fb03f964c7251904"
incoming = "db532ce3f18e867ded98b248c2d1797d678789b8"

def git(*argv, env=None, data=None):
    return subprocess.check_output(["git", *argv], cwd=root, env=env, input=data, timeout=120).decode().strip()

assert git("rev-parse", "HEAD") == merged and not git("status", "--porcelain")
rows = git("diff-tree", "--no-commit-id", "--name-status", "-r", application).splitlines()
assert len(rows) == 20 and all(row.startswith("A\t") for row in rows)
paths = [row.split("\t", 1)[1] for row in rows]
assert all(name.startswith("examples/stateful-reference/") or name in {
    "tools/check_stateful_reference.mjs", "tools/stateful_reference_project.py",
    "tools/tests/test_stateful_reference_project.py", "tools/ci/contracts/python/test_stateful_reference_project.py.json"}
    for name in paths)
assert not git("ls-tree", "-r", "--name-only", incoming, "--", *paths)
task_env = dict(os.environ, GIT_INDEX_FILE=str(out / "sdk-only.index"))
git("read-tree", merged + "^{tree}", env=task_env)
git("update-index", "--force-remove", "--", *paths, env=task_env)
tree = git("write-tree", env=task_env)
head = git("commit-tree", tree, "-p", original, "-p", incoming,
           "-m", "Merge development into Phase 4 guest authoring and retain runtime profiles")
branch = "reconcile/phase4-sdk784-main-20261006-v1"
subprocess.run(["git", "branch", branch, head], cwd=root, check=True)
assert git("rev-parse", "HEAD") == merged and not git("status", "--porcelain")
assert not git("ls-tree", "-r", "--name-only", head, "--", *paths)
record = {"sdkHead": head, "sdkTree": tree, "parents": [original, incoming], "custodyBranch": branch,
    "preservedApplicationHead": merged, "preservedApplicationSourceMilestone": application,
    "excludedExactlyNewApplicationPaths": paths, "excludedCount": len(paths),
    "sourceParentObligationsPreserved": True, "published": False, "qualified": False,
    "noPeerWorktreeMutation": True}
(out / "receipt.json").write_text(json.dumps(record, indent=2)+"\n",encoding="utf8")
print(json.dumps({"sdkHead": head,"sdkTree":tree,"excludedNewApplicationPaths":len(paths),"appPreserved":True}))
