import collections
import json
import pathlib
import subprocess

ROOT = pathlib.Path(r'C:\Users\turkins\Desktop\latent-fabric')
OUT = pathlib.Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-open-pr-readiness-audit-20261007-v1')
OWNED = {767, 774, 778, 779, 780, 784, 787, 788, 790, 791, 796, 800, 802, 803, 808, 811, 821, 823, 825, 828}
OUT.mkdir(exist_ok=True)
raw = subprocess.check_output(['gh', 'pr', 'list', '--state', 'open', '--base', 'development', '--limit', '100', '--json', 'number,title,headRefOid,headRefName,isDraft,mergeable,statusCheckRollup'], cwd=ROOT)
(OUT / 'raw-open-prs.json').write_bytes(raw)
prs = json.loads(raw)
records = []
for pr in prs:
    if pr['number'] not in OWNED:
        continue
    checks = pr.pop('statusCheckRollup')
    conclusions = collections.Counter(check.get('conclusion') if check.get('status') == 'COMPLETED' else check.get('status') for check in checks)
    bad = [check['name'] for check in checks if check.get('status') == 'COMPLETED' and check.get('conclusion') not in {'SUCCESS', 'SKIPPED', 'NEUTRAL'}]
    pending = [check['name'] for check in checks if check.get('status') != 'COMPLETED']
    records.append({**pr, 'checkConclusions': dict(conclusions), 'completedFailures': bad, 'pendingChecks': pending,
                    'currentRollupAllCompletedWithoutFailure': bool(checks) and not bad and not pending,
                    'priorFullyGreenQualificationEstablished': False,
                    'shortcutEligible': False,
                    'note': 'Current rollup only; historical exact-head full qualification and semantic conflict complexity require separate proof before any shortcut.'})
(OUT / 'receipt.json').write_text(json.dumps({'openPrCount': len(prs), 'ownedRecords': records, 'readOnly': True}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'openPrCount': len(prs), 'owned': [{key: row[key] for key in ('number', 'headRefOid', 'isDraft', 'mergeable', 'checkConclusions', 'currentRollupAllCompletedWithoutFailure')} for row in records]}, indent=2))
