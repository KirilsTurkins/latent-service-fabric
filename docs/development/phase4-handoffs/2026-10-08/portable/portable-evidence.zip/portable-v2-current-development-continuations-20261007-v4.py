import hashlib
import json
import pathlib
import subprocess

DESKTOP = pathlib.Path(r'C:\Users\turkins\Desktop').resolve()
REPO = DESKTOP / 'latent-fabric'
COORD = DESKTOP / 'latent-phase4-coordination'
MAIN = 'a686ed45a83d0f9de8158fd5be45f43a756abfb7'
HEADS = {
    767: 'f3a2ace2e063579e8e98a541062fcbb6a89716f7',
    780: '78f08282de92f856ab8095e1f5b436d370cee957',
    821: 'd71c56485cc326ca87b9275f1ac610c9dc731cf0',
    796: '3020cb779a66c9ab039e027160f0e0c9e0f15573',
}
EXPECTED = {
    'docs/component-development/go-authoring.md', 'docs/component-development/go-generators.md',
    'tools/ci/contracts/python/test_go_generator_authoring.py.json', 'tools/go_capsule.py',
    'tools/go_capsule_build.py', 'tools/go_capsule_project.py', 'tools/go_generator_authoring.py',
    'tools/tests/test_go_generator_authoring.py',
}
ROOTS = ['apps', 'crates', 'sdk', 'wit', 'proto', 'contracts', 'Cargo.lock', 'Cargo.toml', 'rust-toolchain.toml']

def git(root, *args, check=True):
    result = subprocess.run(['git', '-C', str(root), *args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
    if check and result.returncode:
        raise RuntimeError(result.stdout.decode(errors='replace')[-4000:])
    return result

def main():
    for number, before in HEADS.items():
        root = DESKTOP / f'lf-p4-pr{number}-a686-portable-v4-20261007'
        assert root.parent.resolve() == DESKTOP and not root.exists(), root
        out = COORD / f'portable-v2-pr{number}-a686-reconcile-20261007-v4'
        out.mkdir()
        branch = f'repair/phase4-pr{number}-a686-20261007-v4'
        created = git(REPO, 'worktree', 'add', '-b', branch, str(root), before)
        (out / 'creation.log').write_bytes(created.stdout)
        assert not git(root, 'status', '--porcelain').stdout
        assert git(root, 'rev-parse', 'HEAD').stdout.decode().strip() == before
        merged = git(root, 'merge', '--no-ff', '--no-commit', MAIN, check=False)
        (out / 'merge.log').write_bytes(merged.stdout)
        (out / 'staged.patch').write_bytes(git(root, 'diff', '--cached', '--binary').stdout)
        if merged.returncode:
            (out / 'unmerged.txt').write_bytes(git(root, 'ls-files', '-u').stdout)
            raise RuntimeError(f'isolated conflict on{number}; raw custody saved, review before continuation')
        actual = set(git(root, 'diff', '--cached', '--name-only').stdout.decode().splitlines())
        assert actual == EXPECTED, (number, actual)
        assert not git(root, 'diff', '--cached', '--name-only', '--', *ROOTS).stdout, 'qualified runtime/SDK/ABI/lock bytes changed'
        git(root, 'diff', '--cached', '--check')
        git(root, 'commit', '-m', f'merge development Go generator support into Phase4 PR{number}')
        after = git(root, 'rev-parse', 'HEAD').stdout.decode().strip()
        assert not git(root, 'status', '--porcelain').stdout
        assert not git(root, 'diff', '--name-only', before, after, '--', *ROOTS).stdout
        body = {'number': number, 'root': str(root), 'branch': branch, 'parent': before, 'development': MAIN, 'head': after,
                'changedPaths': sorted(actual), 'reviewedDevelopmentOnly': True, 'qualifiedRuntimeSdkAbiLocksUnchanged': True,
                'sourcePassed': False, 'published': False, 'completeCI': False,
                'stagedPatchSha256': hashlib.sha256((out / 'staged.patch').read_bytes()).hexdigest()}
        (out / 'receipt.json').write_text(json.dumps(body, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'number': number, 'head': after, 'paths': len(actual), 'runtimeBytesUnchanged': True, 'clean': True}), flush=True)

if __name__ == '__main__':
    main()
