from pathlib import Path
import json

out = Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
name = 'api/proto/phase1-descriptor-contract.json'
a,b = [json.loads((out / label / name).read_bytes()) for label in ('ours', 'incoming')]
def differences(a,b,path=''):
    if a == b:
        return
    if isinstance(a,dict) and isinstance(b,dict):
        for key in sorted(set(a)|set(b)):
            if key in a and key in b:
                differences(a[key],b[key],path+'/'+key)
            else:
                print(json.dumps({'key':path+'/'+key,'only':'ours' if key in a else 'incoming','value':a.get(key,b.get(key))}))
    elif isinstance(a,list) and isinstance(b,list) and all(isinstance(x,dict) and 'name' in x for x in a+b):
        left,right = [{x['name']:x for x in values} for values in (a,b)]
        for key in sorted(set(left)|set(right)):
            if key in left and key in right:
                differences(left[key],right[key],path+'/'+key)
            else:
                value=left.get(key,right.get(key))
                print(json.dumps({'key':path+'/'+key,'only':'ours' if key in left else 'incoming','value':value if len(json.dumps(value))<1500 else {'nestedKeys':list(value)}}))
    else:
        print(json.dumps({'key':path,'ours':a,'incoming':b}))
differences(a,b)
