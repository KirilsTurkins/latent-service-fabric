from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
HEAD='8e0125db0bb21b3e456f5450fd64a24b0caee3d5'
OUT=COORD/'portable-v2-pr825-core-current-native-20261008-v249'
raw=(OUT/'receipt.json').read_bytes()
r=json.loads(raw)
assert r['head']==HEAD and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped'] and r['infrastructureError'] is None
assert len(r['steps'])==11
logs=[]
for row in r['steps']:
    data=(OUT/Path(row['log']).name).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped']
    logs.append(data.decode())
metadata=json.loads(subprocess.check_output(['git','-C',str(REPO),'show',HEAD+':tools/ci/suites.json']))
suites={s['id']:s for s in metadata['suites']}
for index,key,count in [(0,'latent-core.lib.latent-core',127),(2,'latent-signing.lib.latent-signing',58),(5,'latent-node.lib.latent-node',106)]:
    listed=set(re.findall(r'^([\w:]+): test$',logs[index],re.M))
    assert listed==set(suites[key]['expectedCases']) and len(listed)==count
for index,count in [(1,127),(3,58),(6,106),(7,66)]:
    assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in logs[index]
assert 'AOT sandbox: 12 unprivileged real-entry probes and exact-policy syscall probe passed' in logs[8]
proof=dict(at=datetime.now(timezone.utc).isoformat(),head=HEAD,receiptSha256=hashlib.sha256(raw).hexdigest(),
           allElevenStepsPass=True,allLogsAuthenticated=True,allProcessesReaped=True,sourceClean=True,sourceHeadUnchanged=True,
           exactCoreSet127Passed=True,exactSigningSet58Passed=True,exactNodeSet106Passed=True,activation66Passed=True,
           realCustomAOT12AndSyscallPass=True,ordinarySigningNodeClippyPass=True,originalSelectedStrictFourPass=True,
           elapsedSeconds=r['elapsedSeconds'],targetGrowthBytes=r['targetGrowthBytes'],completeCI=False,
           fdDevelopmentSourceOnlyClosurePending=True,noPublication=True)
(COORD/'portable-v2-pr825-core-current-qualified-v253.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
