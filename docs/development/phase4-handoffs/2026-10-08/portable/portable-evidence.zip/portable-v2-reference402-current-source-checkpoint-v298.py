from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-reference402-current-foundation-v292')
HEAD='7bc1ca796e5b1a2125a0fb6be905484fec6e8b63'
BRANCH='feat/phase4-reference402-current-foundation-v292'
out=COORD/'portable-v2-reference402-current-source-20261008-v293'
raw=(out/'receipt.json').read_bytes();r=json.loads(raw)
assert r['head']==HEAD and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped']
for row in r['steps']:
    data=(out/Path(row['log']).name).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped']
assert 'Ran 389 tests' in (out/'step-1.log').read_text() and 'OK (skipped=1)' in (out/'step-1.log').read_text()
assert not subprocess.check_output(['git','-C',str(TREE),'status','--porcelain'])
proof=dict(at=datetime.now(timezone.utc).isoformat(),head=HEAD,branch=BRANCH,sourceReceiptSha256=hashlib.sha256(raw).hexdigest(),
           actualSource389Discovered388Pass1OriginalWindowsSkip=True,allSevenGatesPass=True,all27AppFilesPreserved=True,
           finiteProducerAppBranchPreserved=True,currentFoundationAllRequiredControlsRetained=True,
           sixActualAppCompilersSignedNodeAndBrowserStillPending=True,noCurrentFoundationQualificationTransferToApp=True,
           noPRCreated=True,noIssueClosure=True,publishedCheckpoint=False)
path=COORD/'portable-v2-reference402-current-source-checkpoint-v298.json';path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
result=subprocess.run(['git','-C',str(TREE),'push','-u','origin','HEAD:refs/heads/'+BRANCH],capture_output=True,timeout=120)
(COORD/'portable-v2-reference402-current-source-push-v298.log').write_bytes(result.stdout+result.stderr)
assert result.returncode==0
remote=subprocess.check_output(['git','-C',str(TREE),'ls-remote','origin','refs/heads/'+BRANCH],text=True,timeout=60).split()[0]
assert remote==HEAD
proof.update(publishedCheckpoint=True,verifiedRemoteHead=remote)
path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
