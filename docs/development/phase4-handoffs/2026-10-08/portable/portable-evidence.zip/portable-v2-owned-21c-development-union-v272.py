from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import sys

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
MAIN='21cfd22148f849604cb6fc60247924de0012093c'
number,parent=sys.argv[1:]
assert number in {'790','800','791','787','796','784','825','811'} and len(parent)==40
TREE=Path(r'C:\Users\turkins\Desktop')/('lf-p4-pr'+number+'-21c-main-v272')
assert not TREE.exists()
def git(*args,cwd=REPO):return subprocess.check_output(['git','-C',str(cwd),*args])
git('worktree','add','--no-checkout','-b','fix/phase4-pr'+number+'-21c-main-v272',str(TREE),parent)
git('sparse-checkout','set','--no-cone','tools/java_server_node.py',cwd=TREE)
git('checkout','fix/phase4-pr'+number+'-21c-main-v272',cwd=TREE)
git('merge','--no-ff','-m','merge bounded Java route diagnostics from development',MAIN,cwd=TREE)
head=git('rev-parse','HEAD',cwd=TREE).decode().strip()
assert not git('status','--porcelain',cwd=TREE)
changed=git('diff','--name-only',parent,head,cwd=TREE).decode().splitlines()
assert changed==['tools/java_server_node.py'],changed
assert git('show',head+':tools/java_server_node.py',cwd=TREE)==git('show',MAIN+':tools/java_server_node.py',cwd=TREE)
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=int(number),head=head,parent=parent,development=MAIN,tree=str(TREE),
           onlyChangedPath=changed[0],allRustApiSdkWitCargoMetadataAndTestsByteIdentical=True,
           singleMutationNoRetryDiagnosticsPreserved=True,originalReceiptsRetainedAtTheirActualHeads=True,
           currentSourceValidationPending=True,noPublication=True)
(COORD/('portable-v2-pr'+number+'-21c-main-union-v272.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
