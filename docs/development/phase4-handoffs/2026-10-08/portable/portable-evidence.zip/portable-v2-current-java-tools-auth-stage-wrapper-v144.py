from pathlib import Path
import hashlib,runpy
source=Path('/root-checks/integration-v12-current-java-tools-custody');script=Path('/root-checks/integration-v12-current-java-tools-stage.py')
assert hashlib.sha256(script.read_bytes()).hexdigest()=='9a7e4ea9b5d39af9bd5565a0d1d337d0aa9361660ca78458219804560c366f93'
p=source/'latent-dev-linux-x86_64-java-tools.zip';assert p.stat().st_size==516852549
with p.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()=='41ffa005ed5113991f9c3921f18cfaf2d8c00615ff608174ba11f5e0e4dc653b'
runpy.run_path(str(script),run_name='__main__')
