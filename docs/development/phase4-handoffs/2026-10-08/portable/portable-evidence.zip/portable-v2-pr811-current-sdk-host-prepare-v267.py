from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
HEAD='f8253b33ce6987663ff423bafce1946f901ba66f'
OUT=COORD/'portable-v2-pr811-current-sdk-host-v267'
assert not OUT.exists()
SOURCE=OUT/'source';SOURCE.mkdir(parents=True)
listed=subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r','--name-only',HEAD,'sdk/typescript-client','sdk/profile','api/proto','sdk/dotnet']).decode().splitlines()
records=[]
projects={'Latent.Sdk','Latent.Sdk.SemanticTests','Latent.Sdk.Transport','Latent.Sdk.Transport.Tests','Latent.Sdk.ProviderWorkflow'}
for path in listed:
    p=Path(path);parts=p.parts
    wanted=(path.startswith('sdk/typescript-client/') and not any(x in parts for x in ('node_modules','dist','target')))
    wanted|=path.startswith('api/proto/') and path.endswith('.proto')
    wanted|=path=='sdk/profile/fixtures.json'
    wanted|=path in ('sdk/dotnet/global.json','sdk/dotnet/nuget.transport.config','sdk/dotnet/protobuf.lock.json')
    wanted|=len(parts)>3 and parts[:2]==('sdk','dotnet') and parts[2] in projects and (p.suffix in ('.cs','.csproj') or p.name=='packages.lock.json')
    if wanted:
        data=subprocess.check_output(['git','-C',str(REPO),'show',HEAD+':'+path]).replace(b'\r\n',b'\n')
        assert len(data)<=2*1024**2
        target=SOURCE/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        records.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert len(records)<256 and sum(r['bytes'] for r in records)<16*1024**2
proof=dict(at=datetime.now(timezone.utc).isoformat(),head=HEAD,source=str(SOURCE),files=records,allTrackedSourceBytesCaptured=True,
           preservedOriginalTSAndDotnetLocks=True,sourceFileCount=len(records),sourceBytes=sum(r['bytes'] for r in records),
           nodePin='24.19.0',npmMaintainedPin='11.19.1-lsf-bundle-v4',dotnetPin='8.0.425',runtimePin='8.0.31',
           actualTSAndDotnetExecutionPending=True,noLinuxOrFullCIClaim=True)
(OUT/'source-receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k!='files'},indent=2))
