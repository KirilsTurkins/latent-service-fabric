from pathlib import Path
import json
import re
import subprocess
import sys

root = Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out = Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
sys.path.insert(0, str(root))
from tools import ci_contracts as c

names = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=root, text=True).splitlines()
pattern = re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]+\n', re.M | re.S)
result = []
for name in names:
    path = root / name
    if name.endswith('.json'):
        parents = [json.loads((out / label / name).read_bytes()) for label in ('ours', 'incoming')]
        if name.startswith('tools/ci/contracts/'):
            parents = [c.semantic_record(value) for value in parents]
        keys = sorted(set(parents[0]) | set(parents[1]))
        different = [key for key in keys if parents[0].get(key) != parents[1].get(key)]
        record = {'path': name, 'keys': keys, 'different': different}
        if not name.startswith('tools/ci/contracts/'):
            record['conflicts'] = [{'ours': match[1], 'incoming': match[2]} for match in pattern.finditer(path.read_text())]
        result.append(record)
    else:
        result.append({'path': name, 'conflicts': [{'ours': match[1], 'incoming': match[2]} for match in pattern.finditer(path.read_text())]})
(out / 'inspect-v2.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
