from pathlib import Path
import hashlib,json,subprocess,tarfile
coord=Path(__file__).resolve().parent
job="portable-v2-pr828-c-fields-compiler-20261008-v169";head="ed2254f1c7300ec11cbf827c4e1ed9fe364e8776";p=coord/job
raw=(p/"receipt.json").read_bytes();r=json.loads(raw);assert r["head"]==head and r["passed"] and r["sourceClean"] and r["sourceHeadUnchanged"] and r["originalProcessReaped"] and len(r["steps"])==1
for s in r["steps"]:
 b=(p/s["log"]).read_bytes();assert hashlib.sha256(b).hexdigest()==s["sha256"] and len(b)==s["bytes"] and s["exitCode"]==0
base="/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data/jobs/"+job+"/results"
resultdir=p/"results";resultdir.mkdir(exist_ok=True)
subprocess.run(["docker","cp","latent-p4-root-native-20261007-v6:"+base+"/.",str(resultdir)],capture_output=True,timeout=90,check=True)
rows=[]
for variant in ("aggregate","forbidden-http"):
 v=resultdir/variant;rep=json.loads((v/"report.json").read_bytes());assert rep["sourceRevision"]==head and rep["status"]=="compiled" and rep["compiled"] and not rep["workingTreeChanged"] and not rep["signedNodeExecutionQualified"]
 component=(v/"component.wasm").read_bytes();assert "sha256:"+hashlib.sha256(component).hexdigest()==rep["componentDigest"] and len(component)==rep["componentBytes"]
 for filename,key in (("source-inputs.json","sourceDigest"),("recipe-inputs.json","recipeDigest"),("source.tar.gz","sourceArchiveDigest")):
  b=(v/filename).read_bytes();assert "sha256:"+hashlib.sha256(b).hexdigest()==rep[key]
 source=json.loads((v/"source-inputs.json").read_bytes());project=v/"project"
 for name,m in source.items():
  path=project/name;b=path.read_bytes();assert len(b)==m["size"] and "sha256:"+hashlib.sha256(b).hexdigest()==m["digest"]
 assert all(command["exitCode"]==0 for command in rep["commands"])
 actual=set(rep["actualImports"]);assert {"latent:intents/staging@0.1.0","latent:state/key-value@0.2.0"}<=actual;assert ("latent:http/client@0.2.0" in actual)==(variant=="forbidden-http")
 rows.append({"variant":variant,"componentDigest":rep["componentDigest"],"componentBytes":rep["componentBytes"],"sourceDigest":rep["sourceDigest"],"recipeDigest":rep["recipeDigest"],"sourceFiles":len(source),"reportSha256":hashlib.sha256((v/"report.json").read_bytes()).hexdigest(),"allCompilerCommandsPassed":True,"capturedProjectBytesVerified":True})
proof={"head":head,"actualBothCVariantsCompiled":True,"variants":rows,"nativeReceiptSha256":hashlib.sha256(raw).hexdigest(),"cleanHeadUnchangedAllReaped":True,"originalLimitsUnchanged":True,"compilerOnly":True,"signedNodeQualified":False,"fullCI":False,"heavyReleased":True}
(coord/"portable-v2-pr828-c-fields-actual-compiler-qualified-v169.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8");print(json.dumps(proof,indent=2))
