﻿from pathlib import Path
import json,os,subprocess
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');out=coord/'portable-v2-aggregate-version-compiler-preparation-20261008-v113';out.mkdir(exist_ok=False)
env=dict(os.environ,GODEBUG='http2client=0')
for name,endpoint in [('current-developer-run','repos/KirilsTurkins/latent-service-fabric/actions/runs/37688331647'),('current-developer-artifacts','repos/KirilsTurkins/latent-service-fabric/actions/runs/37688331647/artifacts?per_page=100')]:
 r=subprocess.run(['gh','api',endpoint],env=env,capture_output=True,timeout=60);(out/(name+'.raw.json')).write_bytes(r.stdout);assert r.returncode==0,r.stderr.decode()[-500:];x=json.loads(r.stdout)
 if 'artifacts' in x:print(json.dumps([dict(id=a['id'],name=a['name'],bytes=a['size_in_bytes'],digest=a.get('digest'),expired=a['expired']) for a in x['artifacts']]))
 else:print(json.dumps(dict(run=x['id'],head=x['head_sha'],status=x['status'],conclusion=x['conclusion'])))
