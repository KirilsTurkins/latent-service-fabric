"""Losslessly compact current dependency locks and review their byte pins."""
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-common-braces-runtime-20261006")
OUT = Path(__file__).resolve().parent / "portable-v2-current-main-preparation-20261006-v1"
BASE = "502389acd45ffd3b611db64168f7651dad8da8b6"
LOCKS = ["website/package-lock.json", "examples/framework-compatibility/package-lock.json", "website/toolchain/package-lock.json"]
sys.path.insert(0, str(ROOT))
from tools.build_snapshot import SOURCE_ALLOWLIST, SnapshotLimits, portable_path

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=60)

assert git("rev-parse", "HEAD").decode().strip() == BASE
assert git("status", "--porcelain=v1").decode().splitlines() == [" M website/toolchain/tests/test_prepare.py"]
OUT.mkdir()
records = []
for path in LOCKS:
    target = ROOT / path
    previous = target.read_bytes().replace(b"\r\n", b"\n")
    value = json.loads(previous)
    result = (json.dumps(value, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf8")
    assert json.loads(result) == value
    custody = OUT / "before" / path
    custody.parent.mkdir(parents=True, exist_ok=True)
    custody.write_bytes(previous)
    target.write_bytes(result)
    records.append({"path": path, "beforeBytes": len(previous), "afterBytes": len(result),
                    "beforeSha256": hashlib.sha256(previous).hexdigest(),
                    "afterSha256": hashlib.sha256(result).hexdigest(), "parsedGraphUnchanged": True})

path = ".github/security/inventory.json"
previous = (ROOT / path).read_bytes().replace(b"\r\n", b"\n")
value = json.loads(previous)
original = json.loads(previous)
pins = []
for row in value["manifests"]:
    if row.get("lock") not in LOCKS:
        continue
    record = next(record for record in records if record["path"] == row["lock"])
    profiles = [key for key in ("derived_bundle", "derived_libraries") if key in row]
    assert len(profiles) == 1, (row["path"], profiles)
    profile = row[profiles[0]]
    assert profile["lock_sha256"] == record["beforeSha256"], row["path"]
    profile["lock_sha256"] = record["afterSha256"]
    pins.append({"manifest": row["path"], "lock": row["lock"], "profile": profiles[0],
                 "beforeSha256": record["beforeSha256"], "afterSha256": record["afterSha256"]})
assert len(pins) == 3
check = json.loads(json.dumps(value))
for row in check["manifests"]:
    for pin in pins:
        if row["path"] == pin["manifest"]:
            row[pin["profile"]]["lock_sha256"] = pin["beforeSha256"]
assert check == original
custody = OUT / "before" / path
custody.parent.mkdir(parents=True, exist_ok=True)
custody.write_bytes(previous)
result = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf8")
(ROOT / path).write_bytes(result)

paths = [*LOCKS, path, "website/toolchain/tests/test_prepare.py"]
subprocess.run(["git", "add", "--", *paths], cwd=ROOT, check=True)
assert set(git("diff", "--cached", "--name-only").decode().splitlines()) == set(paths)
subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, check=True)
tree = git("write-tree").decode().strip()
limits = SnapshotLimits(max_total_bytes=32 * 1024 * 1024, max_archive_bytes=40 * 1024 * 1024)
limits.validate()
rows, directories, roots = [], set(), set()
for raw in git("ls-tree", "-r", "-z", "--long", tree, "--", *SOURCE_ALLOWLIST).split(b"\0"):
    if not raw:
        continue
    metadata, encoded_path = raw.split(b"\t", 1)
    mode, kind, oid, size = metadata.split()
    assert mode in {b"100644", b"100755"} and kind == b"blob"
    selected = portable_path(encoded_path.decode("ascii"))
    size = int(size)
    assert size <= limits.max_file_bytes
    rows.append({"path": selected, "gitBlob": oid.decode(), "bytes": size})
    directories.update(str(parent) for parent in PurePosixPath(selected).parents if str(parent) != ".")
    roots.update(root for root in SOURCE_ALLOWLIST if selected == root or selected.startswith(root + "/"))
assert len(rows) <= limits.max_entries and len(directories) <= limits.max_directories
total = sum(row["bytes"] for row in rows)
archive = OUT / ("source-" + tree[:16] + ".tar")
subprocess.run(["git", "archive", "--format=tar", "--output=" + str(archive), tree, "--", *sorted(roots)], cwd=ROOT,
               check=True, capture_output=True, timeout=60)
with tarfile.open(archive, "r:") as reader:
    members = reader.getmembers()
    assert all(member.isfile() or member.isdir() for member in members)
    assert {member.name: member.size for member in members if member.isfile()} == {row["path"]: row["bytes"] for row in rows}
with archive.open("rb") as reader:
    archive_sha = hashlib.file_digest(reader, "sha256").hexdigest()
receipt = {"at": datetime.now(timezone.utc).isoformat(), "base": BASE, "tree": tree, "paths": paths,
           "lockCompaction": records, "inventoryPins": pins, "captureLimitsReviewed": asdict(limits),
           "productionCaptureLimitsChanged": False, "dependencyGraphChanged": False,
           "sourceFiles": len(rows), "sourceDirectories": len(directories), "sourceBytes": total,
           "sourceHeadroomBytesAt32MiB": limits.max_total_bytes - total,
           "archiveBytes": archive.stat().st_size, "archiveSha256": archive_sha,
           "archiveHeadroomBytesAt40MiB": limits.max_archive_bytes - archive.stat().st_size,
           "fits32And40MiB": total <= limits.max_total_bytes and archive.stat().st_size <= limits.max_archive_bytes,
           "completeCI": False, "committed": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
(OUT / "source-inventory.json").write_text(json.dumps(rows, separators=(",", ":")) + "\n", encoding="utf8")
print(json.dumps({key: value for key, value in receipt.items() if key not in {"lockCompaction", "inventoryPins"}}), flush=True)
