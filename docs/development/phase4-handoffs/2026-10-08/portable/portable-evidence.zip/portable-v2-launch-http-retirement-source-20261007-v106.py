﻿from pathlib import Path
import subprocess,sys,json,hashlib
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');repo=Path(r'C:\Users\turkins\Desktop\lf-p4-http-deferred-admission-v96');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,timeout=30).decode().strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,timeout=30)
parent=subprocess.check_output(['git','rev-parse','HEAD^'],cwd=repo).decode().strip();assert parent=='c32c8ad94a4fef338ce223846114f64a1974eb41'
path='crates/latent-http/src/deferred/tests/lookup.rs';old=subprocess.check_output(['git','show',parent+':'+path],cwd=repo);new=(repo/path).read_bytes();added=b'            || fixture.native_capacity.snapshot().unwrap().ordinary.slots != 0\n';assert new.replace(added,b'')==old
proof=dict(head=head,parent=parent,onlyOnePhysicalRetirementObservationAdded=True,originalWatchdogUnchanged=True,originalYieldUnchanged=True,originalFinalAssertByteIdentical=True,noProductionPathChanged=True,newNativeProofRequired=True)
(coord/'portable-v2-http-retirement-fixture-preservation-20261007-v106.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
raise SystemExit(subprocess.call([sys.executable,'-X','utf8','-B',str(coord/'portable-v2-reconstructed-native-controller-20261007-v93.py'),'portable-v2-http-retirement-fixture-source-20261007-v106',head,str(coord/'portable-v2-http-deferred-admission-source-steps-20261007-v102.json'),'source']))
