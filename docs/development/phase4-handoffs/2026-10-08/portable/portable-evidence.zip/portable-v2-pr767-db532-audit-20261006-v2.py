from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys

root = Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
out = Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-pr767-db532-reconcile-20261006-v2")
out.mkdir(exist_ok=True)
sys.path.insert(0, str(root))
from tools import ci_contracts as contracts

def git(*argv):
    return subprocess.check_output(["git", *argv], cwd=root, timeout=60)

def cases(raw):
    parsed = ast.parse(raw)
    return {node.name + "." + method.name: ast.dump(method, include_attributes=False)
            for node in parsed.body if isinstance(node, ast.ClassDef)
            for method in node.body if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith("test_")}

conflicts = git("diff", "--name-only", "--diff-filter=U").decode().splitlines()
actual = contracts.python_expectations(root)
report = []
for name in conflicts:
    parents = []
    for stage, label in ((2, "ours"), (3, "incoming")):
        raw = git("show", ":" + str(stage) + ":" + name)
        path = out / label / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        parents.append(contracts.semantic_record(json.loads(raw)))
    ours, incoming = parents
    row = {"path": name, "kind": ours["kind"], "sameExceptReason":
        {key: value for key, value in ours.items() if key != "reviewReason"} ==
        {key: value for key, value in incoming.items() if key != "reviewReason"}}
    if row["kind"] == "python":
        module = ours["module"]
        observed = actual[module]
        row.update(oursCases=len(ours["cases"]), incomingCases=len(incoming["cases"]), observedCases=len(observed["cases"]),
            lostOurs=sorted(set(ours["cases"]) - set(observed["cases"])),
            lostIncoming=sorted(set(incoming["cases"]) - set(observed["cases"])),
            matchesIncomingGuards=observed["guards"] == incoming["guards"],
            matchesOursGuards=observed["guards"] == ours["guards"])
        bodies = [cases(git("show", revision + ":" + module).decode())
                  for revision in ("HEAD", "MERGE_HEAD")]
        row["changedOverlappingBodies"] = sorted(key for key in set(bodies[0]) & set(bodies[1]) if bodies[0][key] != bodies[1][key])
        row["nonhashGuardChanges"] = []
        for label, parent in (("ours", ours), ("incoming", incoming)):
            for case, guard in parent["guards"].items():
                observed_guard = observed["guards"][case]
                for key in ("bases", "classDecorators", "decorators", "skipSites"):
                    if guard[key] != observed_guard[key]:
                        row["nonhashGuardChanges"].append([label, case, key])
                nonhash = lambda value: [item for item in value if ":setup-sha256:" not in item]
                if nonhash(guard["fixtureGuards"]) != nonhash(observed_guard["fixtureGuards"]):
                    row["nonhashGuardChanges"].append([label, case, "fixtureGuards"])
    elif row["kind"] == "owner":
        row["actualSha256"] = hashlib.sha256((root / ours["path"]).read_bytes()).hexdigest()
        row["oursSha256"], row["incomingSha256"] = ours["sha256"], incoming["sha256"]
    elif row["kind"] == "job":
        row["sameHistoricalBefore"] = ours["before"] == incoming["before"]
        row["sameHistoricalCoverage"] = ours["coverage"] == incoming["coverage"]
        row["sameDeadline"] = ours["definition"]["timeout-minutes"] == incoming["definition"]["timeout-minutes"]
    report.append(row)
(out / "conflict-audit.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf8")
for row in report:
    print(json.dumps(row))
