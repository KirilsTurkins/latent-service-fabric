"""Store frozen CI history as gzip and explicitly review only affected controls."""
from datetime import datetime, timezone
import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-common-ci-history-20261006")
OUT = Path(__file__).resolve().parent / "portable-v2-history-storage-preparation-20261006-v1"
BASE = "3d77ab9e77849c1061ae9480902f262ac3975857"
ORIGINAL = "tools/ci/history/commands-v1.json"
PACKED = ORIGINAL + ".gz"
PIN = "8b9ff81aa133bac2bf5edea722e44ed4aba499eb4bdeb45128f113c64cb31ced"
sys.path.insert(0, str(ROOT))
from tools import ci_contracts as contracts

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=60)

assert git("rev-parse", "HEAD").decode().strip() == BASE
expected_modified = {"tools/ci_contracts.py", "tools/tests/test_ci_contracts.py", "tools/tests/test_build_source_capacity.py"}
resume = OUT.is_dir()
assert set(git("diff", "--name-only").decode().splitlines()) == expected_modified | ({ORIGINAL} if resume else set())
assert not git("diff", "--cached", "--name-only").strip()
if resume:
    assert not (OUT / "receipt.json").exists()
    (OUT / "guard-review-first-attempt.json").write_text(json.dumps({"exitCode": 1,
        "reason": "The new gzip import changes only the module setup AST hash; every existing execution/decorator/skip guard still requires explicit equality.",
        "qualified": False}) + "\n", encoding="utf8")
else:
    OUT.mkdir()
original = git("show", BASE + ":" + ORIGINAL)
assert len(original) == 485465 and hashlib.sha256(original).hexdigest() == PIN
if resume:
    assert not (ROOT / ORIGINAL).exists() and (OUT / "original-commands-v1.json").read_bytes() == original
else:
    assert (ROOT / ORIGINAL).read_bytes().replace(b"\r\n", b"\n") == original
    (OUT / "original-commands-v1.json").write_bytes(original)
packed = gzip.compress(original, compresslevel=9, mtime=0)
assert gzip.decompress(packed) == original and gzip.compress(original, compresslevel=9, mtime=0) == packed
if resume:
    assert (ROOT / PACKED).read_bytes() == packed
else:
    assert not (ROOT / PACKED).exists()
    (ROOT / PACKED).write_bytes(packed)
    (ROOT / ORIGINAL).unlink()
assert contracts.historical_commands_bytes(ROOT) == original
assert contracts.historical_commands(ROOT) == contracts.json_object(original)

before = {}
for path in expected_modified:
    previous = git("show", BASE + ":" + path)
    before[path] = previous
    custody = OUT / "before" / path
    custody.parent.mkdir(parents=True, exist_ok=True)
    if resume:
        assert custody.read_bytes() == previous
    else:
        custody.write_bytes(previous)

def case_map(raw):
    result = {}
    for cls in ast.parse(raw).body:
        if isinstance(cls, ast.ClassDef):
            for node in cls.body:
                if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                    result[cls.name + "." + node.name] = node
    return result

modules = contracts.python_expectations(ROOT)
records = []
for path in ["tools/tests/test_ci_contracts.py", "tools/tests/test_build_source_capacity.py"]:
    previous, current = case_map(before[path]), case_map((ROOT / path).read_bytes())
    assert set(previous) <= set(current)
    changed = []
    for case, old in previous.items():
        new = current[case]
        if case == "RepositoryMigrationTests.test_every_historical_obligation_and_current_expectation_is_accounted_for":
            old.body[0] = ast.parse("legacy = contracts.historical_commands(ROOT)").body[0]
            changed.append(case)
        elif case == "SourceCapacityTests.test_current_committed_repository_fits_capture_and_attribution_limits":
            for node in ast.walk(old):
                if isinstance(node, ast.Constant) and node.value == ORIGINAL:
                    node.value = PACKED
            changed.append(case)
        assert ast.dump(old, include_attributes=False) == ast.dump(new, include_attributes=False), case
    relative = "tools/ci/contracts/python/" + Path(path).name + ".json"
    old_record = contracts.semantic_record(json.loads(git("show", BASE + ":" + relative)))
    observed = modules[path]
    assert set(old_record["cases"]) <= set(observed["cases"])
    for case in old_record["cases"]:
        for key in ("bases", "classDecorators", "decorators", "skipSites", "fixtureGuards"):
            old_guard, new_guard = old_record["guards"][case][key], observed["guards"][case][key]
            if path == "tools/tests/test_ci_contracts.py" and key == "fixtureGuards":
                prefix = "module:setup-sha256:"
                assert len([item for item in old_guard if item.startswith(prefix)]) == 1
                assert len([item for item in new_guard if item.startswith(prefix)]) == 1
                assert [item for item in old_guard if not item.startswith(prefix)] == [item for item in new_guard if not item.startswith(prefix)]
                old_setup = [node for node in ast.parse(before[path]).body if not isinstance(node, ast.ClassDef)]
                new_setup = [node for node in ast.parse((ROOT / path).read_bytes()).body if not isinstance(node, ast.ClassDef)]
                addition = [node for node in new_setup if isinstance(node, ast.Import) and [alias.name for alias in node.names] == ["gzip"]]
                assert len(addition) == 1
                new_setup.remove(addition[0])
                assert ast.dump(ast.Module(body=old_setup, type_ignores=[]), include_attributes=False) == ast.dump(ast.Module(body=new_setup, type_ignores=[]), include_attributes=False)
            else:
                assert old_guard == new_guard, (path, case, key)
    result = copy.deepcopy(old_record)
    result.update(observed)
    result["reviewReason"] += " Retain every existing test, guard, decorator, threshold and skip decision; add frozen-byte bounded single-member history decoding and original 32/40 MiB source capture controls."
    stored = contracts.shared_python_record(result)
    assert contracts.semantic_record(stored) == result
    target = ROOT / relative
    target.write_text(contracts.shared_python_text(stored), encoding="utf8", newline="\n")
    records.append({"module": path, "beforeCases": len(previous), "afterCases": len(current),
                    "reviewedExistingBodyChanges": changed, "newCases": sorted(set(current) - set(previous)),
                    "allExistingAssertionsAndExecutionGuardsRetained": True, "storedRecord": relative})

owner_path = "tools/ci/contracts/owners/tools/ci_contracts.py.json"
owner = json.loads(git("show", BASE + ":" + owner_path))
previous_digest = owner["sha256"]
assert previous_digest == hashlib.sha256(before["tools/ci_contracts.py"]).hexdigest()
owner["sha256"] = hashlib.sha256((ROOT / "tools/ci_contracts.py").read_bytes().replace(b"\r\n", b"\n")).hexdigest()
owner["reviewReason"] += " Add only the fixed-path frozen historical gzip reader with unchanged independent 2 MiB stored/decoded bounds, exact original byte/hash pins and rejection of truncation, trailing data and extra members. Current contracts and migration remain plain JSON."
(ROOT / owner_path).write_text(json.dumps(owner, indent=2, ensure_ascii=False) + "\n", encoding="utf8", newline="\n")
paths = [*sorted(expected_modified), ORIGINAL, PACKED, owner_path, *[row["storedRecord"] for row in records]]
subprocess.run(["git", "add", "--", *paths], cwd=ROOT, check=True)
subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, check=True)
receipt = {"at": datetime.now(timezone.utc).isoformat(), "root": str(ROOT), "base": BASE,
           "originalPath": ORIGINAL, "storedPath": PACKED, "originalBytes": len(original), "storedBytes": len(packed),
           "savedBytes": len(original) - len(packed), "originalSha256": PIN, "storedSha256": hashlib.sha256(packed).hexdigest(),
           "originalDecodedBytesPreserved": True, "historicalRecipesAndMetadataUnchanged": True,
           "productionCaptureLimitsChanged": False, "independentStoredAndDecodedLimitBytes": 2 * 1024 * 1024,
           "readerSupportsArbitraryCompressedPaths": False, "records": records, "paths": paths,
           "currentOwner": {"path": owner_path, "beforeSha256": previous_digest, "afterSha256": owner["sha256"]},
           "completeCI": False, "qualified": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps(receipt), flush=True)
