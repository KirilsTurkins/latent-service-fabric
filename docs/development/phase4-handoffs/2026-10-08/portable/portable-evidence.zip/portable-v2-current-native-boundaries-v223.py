from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
heads={row['pr']:row['head'] for row in json.loads((COORD/'portable-v2-owned-main-inventory-audit-v219.json').read_bytes())}
proof=[]
for number,head in heads.items():
    metadata=json.loads(subprocess.check_output(['git','-C',str(REPO),'show',head+':tools/ci/suites.json']))
    rows={row['id']:row for row in metadata['suites']}
    basic=['cargo','+1.97.1']
    flags=['--all-features','--locked','--offline']
    steps=[
        basic+['check','-p','latent-node','--all-targets',*flags],
        basic+['test','-p','latent-node','--lib',*flags,'journal::tests::tree::target_service_projection_preserves_identity_and_original_identifier_and_page_limits','--','--exact','--nocapture'],
        basic+['test','-p','latent-node','--test','activation_lifecycle',*flags,'identity::assigns_absent_identity_and_rejects_untrusted_ancestry','--','--exact','--nocapture'],
    ]
    if number==790:
        binding=json.loads((COORD/'portable-v2-pr790-binding-native-steps-v212.json').read_bytes())
        steps.extend(binding)
    else:
        steps.extend([
            basic+['test','-p','latent-node','--lib',*flags,'--','--list'],
            basic+['test','-p','latent-node','--lib',*flags,'--','--nocapture'],
            basic+['test','-p','latent-node','--test','activation_lifecycle',*flags,'--','--nocapture'],
            basic+['clippy','-p','latent-node','--all-targets',*flags],
        ])
    path=COORD/('portable-v2-pr'+str(number)+'-current-main-native-steps-v223.json')
    path.write_text(json.dumps(steps,indent=2)+'\n',encoding='utf8')
    proof.append(dict(pr=number,head=head,steps=str(path),stepsSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        actualNodeFloor=rows['latent-node.lib.latent-node']['minimumCases'],
        activationFloor=rows['latent-node.test.activation-lifecycle']['minimumCases'],
        newMainTwoCasesRequired=True,sourcePending=True,nativePending=True,
        authoritativeFullCIStillPending=True,priorQualifiedFeatureReceiptsKeptAtOriginalHeads=True))
(COORD/'portable-v2-current-native-boundaries-v223.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps([dict(pr=row['pr'],head=row['head'],nodeFloor=row['actualNodeFloor'],activationFloor=row['activationFloor']) for row in proof],indent=2))
