from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-828-790-new-completed-failures-v228'
OUT.mkdir(exist_ok=True)
ENV=dict(os.environ,GODEBUG='http2client=0')
REPO='KirilsTurkins/latent-service-fabric'
def api(endpoint):return subprocess.check_output(['gh','api',endpoint],env=ENV,timeout=120)
records=[]
for number,job,run in ((828,113116181654,37717107093),(790,113100882297,37707434428)):
    out=OUT/str(number);out.mkdir(exist_ok=True)
    job_raw=api(f'repos/{REPO}/actions/jobs/{job}')
    metadata=json.loads(job_raw)
    assert metadata['run_id']==run and metadata['status']=='completed' and metadata['conclusion']=='failure'
    run_raw=api(f'repos/{REPO}/actions/runs/{run}')
    run_metadata=json.loads(run_raw)
    raw=api(f'repos/{REPO}/actions/jobs/{job}/logs')
    for name,data in [('job.json',job_raw),('run.json',run_raw),('raw.log',raw)]: (out/name).write_bytes(data)
    clean=re.sub(r'\x1b\[[0-9;]*m','',raw.decode('utf8'))
    lines=clean.splitlines()
    diagnostics=[line[:650] for line in lines if any(token in line for token in
        ('panicked at','AssertionError','expected:','actual:','left:','right:','test result: FAILED','E0560','error[E','GuestTrap','ResourceExhausted','ResourceExhaustedPreparation','["14"]'))][-30:]
    failure_names=[line[:550] for line in lines if re.search(r'^.*test [\w:]+ \.\.\. FAILED',line)]
    artifact_lines=[line[:450] for line in lines if 'Artifact ID ' in line or 'Final size is' in line or 'SHA256 digest of uploaded artifact is' in line]
    record=dict(pr=number,job=job,run=run,head=run_metadata['head_sha'],name=metadata['name'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                failedSteps=[s['name'] for s in metadata['steps'] if s.get('conclusion')=='failure'],diagnostics=diagnostics,failureNames=failure_names,artifactLines=artifact_lines)
    records.append(record)
proof=dict(at=datetime.now(timezone.utc).isoformat(),readOnly=True,records=records)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
