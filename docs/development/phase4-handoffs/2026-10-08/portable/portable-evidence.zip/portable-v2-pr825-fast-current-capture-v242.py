from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-pr825-fast-current-failure-v242'
OUT.mkdir(exist_ok=True)
ENV=dict(os.environ,GODEBUG='http2client=0')
REPO='KirilsTurkins/latent-service-fabric';JOB=113128431293;RUN=37716083644
def api(path):return subprocess.check_output(['gh','api',path],env=ENV,timeout=120)
jm=api(f'repos/{REPO}/actions/jobs/{JOB}');rm=api(f'repos/{REPO}/actions/runs/{RUN}');raw=api(f'repos/{REPO}/actions/jobs/{JOB}/logs')
j,r=json.loads(jm),json.loads(rm)
assert j['run_id']==RUN and j['conclusion']=='failure' and j['status']=='completed'
for name,data in [('job.json',jm),('run.json',rm),('raw.log',raw)]: (OUT/name).write_bytes(data)
clean=re.sub(r'\x1b\[[0-9;]*m','',raw.decode('utf8'))
diag=[s[:700] for s in clean.splitlines() if any(t in s for t in ('error[','error:','Traceback','AssertionError','missing-suite','case-count','renamed-or-missing','FAILED','panicked at'))][-25:]
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=825,job=JOB,run=RUN,head=r['head_sha'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
           failedSteps=[s['name'] for s in j['steps'] if s.get('conclusion')=='failure'],diagnostics=diag,readOnly=True)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
