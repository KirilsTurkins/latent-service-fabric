import hashlib
import json
from pathlib import Path
import re
import subprocess

COORD = Path(__file__).resolve().parent
TREE = Path(r"C:\Users\turkins\Desktop\lf-p4-control-preparation-stages-v301")
PARENT = "756a492b1678dec5e4f69dac11c571acc3836dd1"
SUITES = "tools/ci/suites.json"
data = json.loads((TREE / SUITES).read_bytes())
original = json.loads(subprocess.check_output(["git", "show", f"{PARENT}:{SUITES}"]))
row = next(r for r in data["suites"] if r["id"] == "latent-control-store.lib.latent-control-store")
previous = next(r for r in original["suites"] if r["id"] == row["id"])
new_cases = [
    "deployments::control_admission::tests::closed_stage_preserves_failure_identity_and_never_copies_private_payload",
    "deployments::tests::operations::lease::preparation_lease_diagnostic_preserves_rejection_without_read_or_mutation_retry",
    "deployments::tests::operations::lease::package_lease_diagnostic_preserves_one_read_and_cancels_unpublished_catalog",
]
assert previous["minimumCases"] == len(previous["expectedCases"]) == 252
assert not set(new_cases) & set(previous["expectedCases"])
row["expectedCases"] = sorted(set(previous["expectedCases"]) | set(new_cases))
row["minimumCases"] = previous["minimumCases"] + len(new_cases)
assert row["minimumCases"] == len(row["expectedCases"]) == 255
for key in previous:
    if key not in ("minimumCases", "expectedCases"):
        assert row[key] == previous[key], key
assert [r for r in data["suites"] if r["id"] != row["id"]] == [
    r for r in original["suites"] if r["id"] != row["id"]
]
for key in data:
    if key != "suites":
        assert data[key] == original[key], key
(TREE / SUITES).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def function_body(source, name):
    start = source.index(f"fn {name}(")
    brace = source.index("{", start)
    depth = 0
    for end in range(brace, len(source)):
        if source[end] == "{":
            depth += 1
        elif source[end] == "}":
            depth -= 1
            if not depth:
                return source[start:end + 1]
    raise AssertionError(name)


test_path = "crates/latent-control-store/src/deployments/tests/operations/lease.rs"
old_test = subprocess.check_output(["git", "show", f"{PARENT}:{test_path}"]).decode("utf-8")
new_test = (TREE / test_path).read_text(encoding="utf-8")
retained_tests = re.findall(r"#\[test\]\s*fn\s+(\w+)\(", old_test)
for name in retained_tests:
    assert function_body(old_test, name) == function_body(new_test, name), name
renewal_paths = [
    "crates/latent-control-store/src/deployments/compiler.rs",
    "crates/latent-control-store/src/deployments/operations/prepare.rs",
]
for path in renewal_paths:
    old = subprocess.check_output(["git", "show", f"{PARENT}:{path}"]).decode("utf-8")
    new = (TREE / path).read_text(encoding="utf-8")
    assert old.count(".renew_control_lease()") == new.count(".renew_control_lease()"), path
unchanged_paths = [
    "crates/latent-control-store/src/deployments/operations/commit.rs",
    "crates/latent-artifacts/src/local_repository/publication_preparation.rs",
    "crates/latent-policy/src/supply_chain.rs",
]
untouched = []
for path in unchanged_paths:
    parent_blob = subprocess.check_output(["git", "rev-parse", f"{PARENT}:{path}"], text=True).strip()
    untouched.append({"path": path, "parentBlob": parent_blob})
result = {
    "parent": PARENT, "tree": str(TREE), "newCases": new_cases,
    "branchSpecificControlStoreFloorBefore": 252,
    "branchSpecificControlStoreFloorAfter": 255,
    "allPreviousCasesAndOtherSuiteControlsPreserved": True,
    "originalLeaseTestBodiesByteIdentical": retained_tests,
    "existingRenewalCountsUnchanged": True,
    "diagnosticStages": ["prepare-lease", "package-lease", "package-read", "package-lifecycle", "package-tenant", "inherited-bindings"],
    "originalFailureForwarded": True, "atMostOneClosedStageDetail": True,
    "noCallerOrEngineTextCopiedIntoStage": True,
    "nativeTestsExecuted": False, "actualSourceQualificationPending": True,
    "untouchedCriticalPaths": untouched,
}
(COORD / "portable-v2-control-preparation-stage-review-v302.json").write_text(
    json.dumps(result, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(result))
