from pathlib import Path
from collections import Counter
import json
import subprocess

repo=Path(r'C:\Users\turkins\Desktop\latent-fabric')
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination')
base='db532ce3f18e867ded98b248c2d1797d678789b8'
head='e57cf16eb9bb61885aa37e0c88806cc9c9347e7d'
rows=[]
for line in subprocess.check_output(['git','diff','--name-status',base,head],cwd=repo,text=True).splitlines():
    status,name=line.split('\t')
    rows.append({'status':status,'path':name})
runtime_prefixes=('apps/latentd/','apps/latent/','crates/','api/proto/','wit/','schemas/','contracts/')
runtime=[row for row in rows if row['path'].startswith(runtime_prefixes) or row['path'] in ('Cargo.toml','Cargo.lock','.cargo/managed-guest.toml')]
excluded=[row for row in rows if row not in runtime]
record={'base':base,'source':head,'runtimePaths':runtime,'remainingChangesForReview':excluded}
path=coord/'portable-v2-395-shared-closure-audit-20261006-v1.json'
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'runtimePaths':len(runtime),'runtimePrefixCounts':dict(Counter('/'.join(row['path'].split('/')[:2]) for row in runtime)),
                  'remainingPrefixCounts':dict(Counter('/'.join(row['path'].split('/')[:2]) for row in excluded)),
                  'changedTools':[row['path'] for row in excluded if row['path'].startswith('tools/') and not row['path'].startswith('tools/ci/')],
                  'changedSdkRoots':dict(Counter('/'.join(row['path'].split('/')[:2]) for row in excluded if row['path'].startswith('sdk/')))},indent=2))
