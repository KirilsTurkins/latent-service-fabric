from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

COORD = Path(__file__).resolve().parent
TREE = Path(r'C:\Users\turkins\Desktop\lf-p4-pr791-guard-layout-v209')
REPO = 'KirilsTurkins/latent-service-fabric'
OLD = '866416fb57f2a11211fc6ecdf8896c2e5343a36a'
HEAD = 'f69c330cd0f77a4c5ddf68d26250b01dcc2ed64f'
BRANCH = 'feat/phase4-node-transactions-388'
ENV = dict(os.environ,GODEBUG='http2client=0')
def call(argv, **kwargs):
    return subprocess.check_output(argv,env=ENV,timeout=120,**kwargs)
directory = COORD/'portable-v2-pr791-guard-layout-source-20261008-v211'
raw = (directory/'receipt.json').read_bytes()
r = json.loads(raw)
assert r['head'] == HEAD and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped']
assert len(r['steps']) == 8 and all(row['exitCode'] == 0 and row['originalProcessReaped'] for row in r['steps'])
for row in r['steps']:
    log = (directory/Path(row['log']).name).read_bytes()
    assert len(log) == row['bytes'] and hashlib.sha256(log).hexdigest() == row['sha256']
assert not call(['git','-C',str(TREE),'status','--porcelain'])
assert call(['git','-C',str(TREE),'rev-parse','HEAD']).decode().strip() == HEAD
pr_raw = call(['gh','pr','view','791','--repo',REPO,'--json','headRefOid,headRefName,state'])
pr = json.loads(pr_raw)
assert pr == dict(headRefOid=OLD,headRefName=BRANCH,state='OPEN')
call(['git','-C',str(TREE),'merge-base','--is-ancestor',OLD,HEAD])
proof = dict(at=datetime.now(timezone.utc).isoformat(),pr=791,oldHead=OLD,head=HEAD,branch=BRANCH,
             sourceReceiptSha256=hashlib.sha256(raw).hexdigest(),actualPinnedLinuxScannerPass=True,
             sourceCases=248,allEightSourceStepsPass=True,sameSemanticMetadata=True,noScannerPolicyExceptionsChanged=True,
             goRuntimeFailureStillUnresolved=True,completeCI=False,normalPush=True,published=False)
out = COORD/'portable-v2-pr791-layout-qualified-publication-v214.json'
out.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
push = subprocess.run(['git','-C',str(TREE),'push','origin',f'HEAD:refs/heads/{BRANCH}'],env=ENV,capture_output=True,timeout=120)
(COORD/'portable-v2-pr791-layout-push-v214.log').write_bytes(push.stdout+push.stderr)
assert push.returncode == 0
remote = call(['git','-C',str(TREE),'ls-remote','origin',f'refs/heads/{BRANCH}']).decode().split()[0]
assert remote == HEAD
proof.update(published=True,verifiedRemoteHead=remote)
out.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
