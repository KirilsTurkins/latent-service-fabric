import copy
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

COORD = Path(__file__).resolve().parent
TREE = Path(r"C:\Users\turkins\Desktop\lf-p4-pr811-buf-golden-v307")
HEAD = "335dca010d299e554a4ab351e9fb525ae15e8d5c"
DONOR = "1e129ef0ed6682c998f81a498e76bd4de61c6fec"
OUT = COORD / "portable-v2-pr811-buf-golden-producer-v309"
OUT.mkdir()
GOLDEN = "api/proto/phase1-descriptor-contract.json"
buf = Path(shutil.which("buf"))
assert subprocess.check_output([str(buf), "--version"], text=True).strip() == "1.72.0"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=TREE, text=True).strip() == HEAD
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=TREE, text=True).strip()
names = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", HEAD, "api/proto"], cwd=TREE, text=True).splitlines()
inputs = [p for p in names if p.endswith((".proto", "buf.yaml", "buf.lock"))]
inputs.append("tools/validate_phase1_descriptor.py")
identity = []
for path in inputs:
    current = subprocess.check_output(["git", "show", f"{HEAD}:{path}"], cwd=TREE)
    donor = subprocess.check_output(["git", "show", f"{DONOR}:{path}"], cwd=TREE)
    assert current == donor, path
    identity.append({"path": path, "bytes": len(current), "sha256": hashlib.sha256(current).hexdigest()})
before = subprocess.check_output(["git", "show", f"{HEAD}:{GOLDEN}"], cwd=TREE)
(OUT / "original-golden.json").write_bytes(before)
actual = OUT / "actual-file-descriptor-set.json"
invocation = [str(buf), "build", "api/proto", "--as-file-descriptor-set", "-o", str(actual)]
process = subprocess.run(invocation, cwd=TREE, capture_output=True, timeout=180, check=True)
(OUT / "buf-build.log").write_bytes(process.stdout + process.stderr)
assert actual.is_file()
validator = TREE / "tools/validate_phase1_descriptor.py"
normalized_raw = subprocess.check_output([sys.executable, "-X", "utf8", "-B", str(validator), str(actual), "--print-compact"], cwd=TREE, timeout=60)
normalized_raw = normalized_raw.replace(b"\r\n", b"\n")
spec = importlib.util.spec_from_file_location("actual_descriptor_validator", validator)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
old = module.normalize_descriptor(json.loads(before))
new = module.normalize_descriptor(json.loads(normalized_raw))
assert [f["name"] for f in old["file"]] == [f["name"] for f in new["file"]]
changed = []
for left, right in zip(old["file"], new["file"], strict=True):
    if left != right:
        changed.append((left, right))
assert {left["name"] for left, _ in changed} == {"latent/control/v1/node.proto", "latent/control/v1/state.proto"}
old_files = {left["name"]: left for left, _ in changed}
new_files = {right["name"]: right for _, right in changed}
old_node, new_node = old_files["latent/control/v1/node.proto"], new_files["latent/control/v1/node.proto"]
old_messages = {m["name"]: m for m in old_node["messageType"]}
new_messages = {m["name"]: m for m in new_node["messageType"]}
assert set(new_messages) - set(old_messages) == {"TransactionStagingWitness"}
assert set(old_messages) <= set(new_messages)
witness = new_messages["TransactionStagingWitness"]
assert [int(f["number"]) for f in witness["field"]] == list(range(1, 11))
restored_files = copy.deepcopy(new_files)
restored = restored_files["latent/control/v1/node.proto"]
restored["messageType"] = [m for m in restored["messageType"] if m["name"] != "TransactionStagingWitness"]
field_additions = []
for file_name, message_name, field_name, number in [
    ("latent/control/v1/node.proto", "ActivationTreeNode", "transaction_staging", 15),
    ("latent/control/v1/state.proto", "NamespaceInspection", "policy_digest", 12),
]:
    message = next(m for m in restored_files[file_name]["messageType"] if m["name"] == message_name)
    field = next(f for f in message["field"] if f["name"] == field_name)
    assert int(field["number"]) == number and field["proto3Optional"] is True
    assert field["label"] == "LABEL_OPTIONAL"
    assert message["oneofDecl"][int(field["oneofIndex"])] == {"name": "_" + field_name}
    message["field"].remove(field)
    message["oneofDecl"].pop(int(field["oneofIndex"]))
    if not message["oneofDecl"]:
        del message["oneofDecl"]
    field_additions.append({"message": message_name, "field": field_name, "number": number, "optional": True})
assert restored_files == old_files, "descriptor delta contains unreviewed existing semantics"
assert len(before.splitlines()) == 1, "parent golden layout differs"
(TREE / GOLDEN).write_bytes(normalized_raw)
module.validate_descriptor(json.loads(actual.read_bytes()), json.loads((TREE / GOLDEN).read_bytes()))
check = subprocess.run([sys.executable, "-X", "utf8", "-B", str(validator), str(actual)], cwd=TREE, capture_output=True, timeout=60, check=True)
(OUT / "actual-validator.log").write_bytes(check.stdout + check.stderr)
assert hashlib.sha256(normalized_raw).hexdigest() == "66c924d37e01d2d17dcb517040a6c16564a7e07be7d32f6940c6f6fd77bbcf51"
result = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "sourceHead": HEAD,
    "bufPath": str(buf), "bufVersion": "1.72.0", "bufSha256": hashlib.sha256(buf.read_bytes()).hexdigest(),
    "actualInvocation": invocation, "actualDescriptorBytes": actual.stat().st_size,
    "actualDescriptorSha256": hashlib.sha256(actual.read_bytes()).hexdigest(),
    "oldGoldenSha256": hashlib.sha256(before).hexdigest(), "newGoldenSha256": hashlib.sha256(normalized_raw).hexdigest(),
    "originalCompactLayoutPreserved": True, "normalization": "maintained --print-compact; newline normalized to tracked LF",
    "allProtoAndBufConfigAndValidatorInputsEqualActual808Producer": identity,
    "semanticAddedMessage": {"name": "TransactionStagingWitness", "fields": [{"name": f["name"], "number": f["number"], "type": f["type"]} for f in witness["field"]]},
    "semanticAddedFields": field_additions,
    "allExistingDescriptorSemanticsPreserved": True,
    "actualBufBuildPassed": True, "maintainedValidatorPassed": True,
    "sourceQualificationPending": True, "completeCI": False,
    "previousGuardRefusalPreserved": "v308 correctly retained original golden when two changed files exceeded the initial one-file assumption; Node and State additions are now reviewed separately.",
}
(OUT / "receipt.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in result.items() if k not in ("allProtoAndBufConfigAndValidatorInputsEqualActual808Producer", "semanticAddedMessage", "actualInvocation")}))
