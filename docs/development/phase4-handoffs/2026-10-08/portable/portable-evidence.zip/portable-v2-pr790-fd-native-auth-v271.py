from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
HEAD='9cfe58a9587d08adf8fdbee29e7d0360fd788f3e'
OUT=COORD/'portable-v2-pr790-fd-current-native-20261008-v268'
raw=(OUT/'receipt.json').read_bytes();r=json.loads(raw)
assert r['head']==HEAD and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped'] and r['infrastructureError'] is None
assert len(r['steps'])==13
logs=[]
for row in r['steps']:
    data=(OUT/Path(row['log']).name).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped']
    logs.append(data.decode())
metadata=json.loads(subprocess.check_output(['git','-C',str(REPO),'show',HEAD+':tools/ci/suites.json']))
rows={x['id']:x for x in metadata['suites']}
for index,key,count in [(0,'latent-signing.lib.latent-signing',58),(3,'latent-node.lib.latent-node',133),(8,'latent-control-store.lib.latent-control-store',264)]:
    listed=set(re.findall(r'^([\w:]+): test$',logs[index],re.M))
    assert listed==set(rows[key]['expectedCases']) and len(listed)==count
for index,count in [(1,58),(4,133),(5,66),(9,3)]:assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in logs[index]
assert '263 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out' in logs[10]
assert 'AOT sandbox: 12 unprivileged real-entry probes and exact-policy syscall probe passed' in logs[6]
proof=dict(at=datetime.now(timezone.utc).isoformat(),head=HEAD,nativeReceiptSha256=hashlib.sha256(raw).hexdigest(),
           allThirteenStepsPass=True,allLogsAuthenticated=True,allProcessesReaped=True,sourceClean=True,sourceHeadUnchanged=True,
           exactSigning58Node133Activation66Pass=True,exactControlStore264RequiredSetPass=True,originalBinding3Pass=True,
           controlPass263OriginalIgnored1=True,actualCustomAOT12AndSyscallPass=True,
           ordinaryClippyAndOriginalSelectedStrictPass=True,elapsedSeconds=r['elapsedSeconds'],targetGrowthBytes=r['targetGrowthBytes'],
           latest21cPythonOnlyMergePending=True,noPublicationYet=True,completeCI=False)
(COORD/'portable-v2-pr790-fd-native-qualified-v271.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
