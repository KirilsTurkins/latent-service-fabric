from pathlib import Path
import datetime,hashlib,json,os,subprocess
coord=Path(__file__).resolve().parent
root=Path(r"C:\Users\turkins\Desktop\lf-p4-pr796-completed-ci-v164")
old="9afd6990491a33d4dd38d5a69f8fe77fc77aaf0a";head="43503d8cfbd9e938aa6d798ccd00059efdae8e9e"
env=dict(os.environ,GODEBUG="http2client=0")
def read(job,steps):
 p=coord/job;raw=(p/"receipt.json").read_bytes();r=json.loads(raw)
 assert r["head"]==head and r["passed"] and r["sourceClean"] and r["sourceHeadUnchanged"] and r["originalProcessReaped"] and len(r["steps"])==steps and r["infrastructureError"] is None
 for row in r["steps"]:
  b=(p/row["log"]).read_bytes();assert len(b)==row["bytes"] and hashlib.sha256(b).hexdigest()==row["sha256"] and row["exitCode"]==0 and row["stopReason"] is None
 return hashlib.sha256(raw).hexdigest()
sourceSha=read("portable-v2-pr796-completed-ci-source-20261008-v164",7)
nativeSha=read("portable-v2-pr796-completed-ci-native-20261008-v165",2)
assert not subprocess.check_output(["git","status","--porcelain"],cwd=root)
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()==head
paths=subprocess.check_output(["git","diff","--name-only",old,head],cwd=root,text=True).splitlines();assert paths==["apps/latent/src/management/phase4/projection.rs","tools/tests/test_java_server_source.py"]
pr=json.loads(subprocess.check_output(["gh","pr","view","796","--repo","KirilsTurkins/latent-service-fabric","--json","state,headRefOid,headRefName,body"],env=env,timeout=40));assert pr["state"]=="OPEN" and pr["headRefOid"]==old
branch=pr["headRefName"];assert branch=="feat/phase4-retention-397"
assert subprocess.check_output(["git","ls-remote","origin","refs/heads/"+branch],cwd=root,env=env,text=True,timeout=45).split()[0]==old
subprocess.run(["git","push","origin",head+":refs/heads/"+branch],cwd=root,env=env,timeout=180,check=True)
assert subprocess.check_output(["git","ls-remote","origin","refs/heads/"+branch],cwd=root,env=env,text=True,timeout=45).split()[0]==head
body=pr["body"].rstrip()+"\n\nCurrent completed-CI repair supplies the generated empty-world Java bridge fixture and removes the duplicate identical effect-plan response arm. Linux source checks pass 197 cases with zero skips; the original workspace Clippy and selected warnings-as-errors recipe both pass. Every original response field, test assertion, case threshold and skip remains intact. Full CI and remaining #397 acceptance gates are pending.\n"
b=coord/"portable-v2-pr796-completed-ci-published-body-v166.md";b.write_text(body,encoding="utf-8",newline="\n");subprocess.run(["gh","pr","edit","796","--repo","KirilsTurkins/latent-service-fabric","--body-file",str(b)],env=env,timeout=45,check=True)
proof={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"pr":796,"oldHead":old,"head":head,"normalPush":True,"remoteVerified":True,"sourceReceiptSha256":sourceSha,"nativeReceiptSha256":nativeSha,"actualPythonCases":197,"zeroSkip":True,"workspaceOrdinaryAndSelectedStrictClippyPassed":True,"allOriginalFieldsCasesLimitsSkipsRetained":True,"fullCIPending":True,"noMergeOrClosure":True}
(coord/"portable-v2-pr796-completed-ci-qualified-publication-v166.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8");print(json.dumps(proof,indent=2))
