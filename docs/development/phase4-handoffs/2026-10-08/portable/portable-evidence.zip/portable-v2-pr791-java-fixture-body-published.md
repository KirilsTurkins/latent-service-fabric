Integrates the original transaction admission and completion owners for #388, retaining cancellation, response authorization, opaque read history and physical cleanup. Reconciles current development, complete host-memory accounting, canonical bindings and management APIs.



Pinned formatting, contract generation, CI coverage, focused source tests and actual Buf descriptor validation pass. Full CI, signed guest execution and installed crash/restart qualification remain pending.

The dispatcher guard initializer preserves its single original management value and native capacity field. The duplicate field that prevented the Angular and measurement builds is removed. Branch source checks pass all 188 registered cases and generated contracts; actual dispatcher compilation and all 138 dispatcher library tests pass. The Angular and measurement CI jobs remain separate fresh-head checks.

Current test-only continuation completes the generated empty-world Java fixture. Linux source checks pass 197 cases with zero skips, including all nine Java server source cases. Every production/compiler input remains byte-identical to 3043e50c; prior native receipts retain that source head. Full CI remains pending.
