from pathlib import Path
import hashlib
import json

MAX_HASH_BYTES=64*1024*1024
result={'readOnlyInspection':True,'topLevels':{},'selectedCandidates':[]}
for text in ('/tools','/tools/jdk','/tools/gradle','/tools/wasi-sdk','/tools/bin','/tools/aux','/tools/aux/bin','/tools/aux/sdk','/tools/aux/sdk/bin','/cache'):
    root=Path(text)
    if root.is_dir():
        names=sorted(value.name for value in root.iterdir())
        assert len(names)<=256
        result['topLevels'][text]=names[:64]
roots=Path('/tools/roots.json')
if roots.is_file() and roots.stat().st_size<=16384:
    result['recordedToolRoots']=json.loads(roots.read_bytes())
for group,leaf in (('jdk','bin/java'),('jdk','bin/javac'),('gradle','bin/gradle'),('wasi-sdk','bin/clang')):
    root=Path('/tools')/group
    if not root.is_dir():
        continue
    children=sorted(root.iterdir())
    assert len(children)<=32
    for child in children:
        path=child/leaf
        if not path.is_file():
            continue
        resolved=path.resolve(strict=True)
        assert resolved.is_relative_to(Path('/tools').resolve())
        size=resolved.stat().st_size
        record={'path':str(path),'realpath':str(resolved),'bytes':size}
        if size<=MAX_HASH_BYTES:
            with resolved.open('rb') as source:
                record['sha256']=hashlib.file_digest(source,'sha256').hexdigest()
        else:
            record['hashNotRead']='bounded layout inspection; use the authenticated compiler input inventory'
        result['selectedCandidates'].append(record)
        if group=='jdk' and leaf=='bin/java':
            release=child/'release'
            if release.is_file() and release.stat().st_size<=16384:
                record['release']= [line for line in release.read_text(encoding='utf8').splitlines() if line.startswith(('JAVA_VERSION=','JAVA_RUNTIME_VERSION=','IMPLEMENTOR=','OS_ARCH='))]
print(json.dumps(result,indent=2))
