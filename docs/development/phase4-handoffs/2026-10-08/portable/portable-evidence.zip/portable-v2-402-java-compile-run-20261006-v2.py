"""One owned actual Java compiler attempt, distinct from node qualification."""
from pathlib import Path
import hashlib
import json
import os
import sys
import time
import tomllib
import traceback

sys.path.insert(0, "/repo")
from tools.java_guest.compiler import Compiler
from tools.rust_capsule_project import snapshot, inventory, digest

project = Path("/input/project")
output = Path("/output")
before = inventory(snapshot(project))
declaration = json.loads((project / "capsule-project.json").read_bytes())
compiler = None
started = time.monotonic()
report = {"schemaVersion": "latent.stateful-reference.compile-attempt.v1", "language": "java",
          "application": "order-draft-v1", "sourceInventoryDigest": digest(before),
          "signed": False, "nodeQualified": False, "compiled": False,
          "compilerVolumesReadOnly": True, "deadlineSeconds": 900, "status": "running"}
try:
    pins = tomllib.loads((project / "vendor/lsf/tools/toolchain.toml").read_text())
    compiler = Compiler(output / "compiler", Path("/tools/wasi-sdk/wasi-sdk-29.0-x86_64-linux"),
                        gradle="/tools/gradle/gradle-9.1.0/bin/gradle",
                        sdk=project / "vendor/lsf/sdk/java-guest", platform=project / "vendor/lsf/wit/platform",
                        config=pins, timeout=900, offline_cache=Path("/cache"))
    (output / "compiler-inputs.json").write_bytes(compiler.compiler_inputs)
    component, details = compiler.compile(project / "src", project / "wit", declaration["world"], output / "compiled")
    compiler.check_unchanged()
    if before != inventory(snapshot(project)):
        raise ValueError("captured application source changed during compilation")
    data = component.read_bytes()
    report.update(status="passed", compiled=True, componentDigest=digest(data), componentBytes=len(data),
                  sourceAfterMatches=True, compilerInputsDigest=digest(compiler.compiler_inputs),
                  details=details, commands=compiler.records)
except BaseException as error:
    report.update(status="failed", failure=str(error), failureType=type(error).__name__)
    (output / "failure.txt").write_text(traceback.format_exc(), encoding="utf-8")
    if compiler is not None:
        report["commands"] = compiler.records
finally:
    report["seconds"] = round(time.monotonic() - started, 6)
    (output / "receipt.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report.get(key) for key in ("status", "compiled", "componentDigest", "componentBytes", "failure", "seconds")}), flush=True)
raise SystemExit(0 if report["status"] == "passed" else 1)
