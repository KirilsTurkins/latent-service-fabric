Adds atomic command, result, inbox and outbox envelopes for #386, including actual kernel-I/O and process crash schedules. Integrates development and canonical Java signing while retaining every case, guard, and redrive regression body.

Restores the omitted effect-authority rejection test module, so all four retained rejection schedules execute in the actual libtest binary. Restores the maintained credential-rotation test: the original context must fail stale, retain its physical owner until retirement, and require fresh current acceptance. The original 128-case floor is unchanged.

Linux source checks pass. Direct native listing matches every registered case, and all 128 Effects cases pass with zero failures or ignores. Fresh full CI and final persistence qualification remain pending.
