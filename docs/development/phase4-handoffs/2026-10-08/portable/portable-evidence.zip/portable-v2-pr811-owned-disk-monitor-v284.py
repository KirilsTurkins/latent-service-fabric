from datetime import datetime,timezone
import json
from pathlib import Path
import shutil
import subprocess
import time

COORD=Path(__file__).resolve().parent
OWNER='latent-p4-root-native-20261007-v6'
BASE='/var/lib/docker/volumes/'+OWNER+'/_data'
JOB='portable-v2-pr811-current-main-native-20261008-v283'
records=[]
for _ in range(24):
    free=shutil.disk_usage('C:\\').free
    local=COORD/JOB/'receipt.json'
    row=dict(at=datetime.now(timezone.utc).isoformat(),freeBytes=free,receiptVisible=local.exists())
    records.append(row)
    print(json.dumps(row),flush=True)
    if local.exists():break
    if free<1024**3:
        probe="""import os,json,signal
from pathlib import Path
base=Path(BASE_LITERAL);source=base/'native-active-portable-v3';jobs=base/'jobs'/JOB_LITERAL
assert os.getuid()==10001 and jobs.is_dir()
groups=set();matched=[]
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
        cmd=(p/'cmdline').read_bytes().split(b'\\0')
        if not cmd or not cmd[0]:continue
        cwd=(p/'cwd').resolve()
        if cwd!=source:continue
        stat=(p/'stat').read_text();tail=stat[stat.rfind(')')+2:].split();pgid=int(tail[2])
        fds=[]
        for name in ('1','2'):
            try:fds.append(str((p/'fd'/name).resolve()))
            except OSError:pass
        if any(name.startswith(str(jobs)+'/step-') and name.endswith('.log') for name in fds):
            matched.append(dict(pid=int(p.name),pgid=pgid,command=Path(cmd[0].decode()).name))
            groups.add(pgid)
    except (FileNotFoundError,PermissionError,OSError):continue
assert all(g>1 for g in groups)
(jobs/'host-low-disk-resource-custody.json').write_text(json.dumps(dict(reason='actual-host-free-below-1GiB',processes=matched,groups=sorted(groups)),indent=2)+'\\n')
for group in groups:os.killpg(group,signal.SIGTERM)
print(json.dumps(dict(exactOwnedJob=JOB_LITERAL,groupsTerminated=sorted(groups),matchedProcesses=matched)))
""".replace('BASE_LITERAL',repr(BASE)).replace('JOB_LITERAL',repr(JOB))
        result=subprocess.run(['docker','exec',OWNER,'python3','-c',probe],capture_output=True,timeout=30)
        (COORD/'portable-v2-pr811-disk-monitor-signals-v284.stdout').write_bytes(result.stdout)
        (COORD/'portable-v2-pr811-disk-monitor-signals-v284.stderr').write_bytes(result.stderr)
        row['exactOwnedSignalExit']=result.returncode
        break
    time.sleep(10)
(COORD/'portable-v2-pr811-disk-monitor-v284.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8')
