from datetime import datetime,timezone
import ast
import hashlib
import json
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-reference402-current-foundation-v292')
APP='3abbb63cd18729e3c94145066d957e286d9e2de2'
FOUNDATION='3b7af5096198ae9453b5616bc124def18798911c'
def git(*args):return subprocess.check_output(['git','-C',str(TREE),*args])
assert not git('ls-files','-u')
record=json.loads((COORD/'portable-v2-reference402-current-source-union-v173.json').read_bytes())
files=record['exactRetainedAppFiles']
if isinstance(files,dict):paths=list(files)
else:paths=[row['path'] if isinstance(row,dict) else row for row in files]
assert len(paths)==27
for path in paths:assert git('show',':'+path)==git('show',APP+':'+path),path
producer='tools/transaction_guest_project.py'
merged=git('show',':'+producer).decode()
old=git('show',APP+':'+producer).decode()
def function(text,name):
    return next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
app_branch=next(n for n in ast.walk(function(old,'put_once_requirements')) if isinstance(n,ast.If) and 'examples:order-draft/service@1.0.0' in ast.unparse(n.test))
current_branch=next(n for n in ast.walk(function(merged,'put_once_requirements')) if isinstance(n,ast.If) and 'examples:order-draft/service@1.0.0' in ast.unparse(n.test))
assert ast.dump(app_branch,include_attributes=False)==ast.dump(current_branch,include_attributes=False)
assert 'order-draft' in merged and 'order-draft' in old
assert 'examples:order-draft/service@1.0.0' in merged
rows={r['id']:r for r in json.loads(git('show',':tools/ci/suites.json'))['suites']}
for parent in (APP,FOUNDATION):
    for original in json.loads(git('show',parent+':tools/ci/suites.json'))['suites']:
        current=rows[original['id']]
        assert current['minimumCases']>=original['minimumCases']
        for field in ('expectedCases','expectedIgnored','ignoredLeaves','expectedCustomCases','prerequisites'):
            assert set(original.get(field,[]))<=set(current.get(field,[])),(original['id'],field)
assert rows['latent-wasmtime.test.aot-sandbox']['minimumCases']==1
assert rows['latent-signing.lib.latent-signing']['minimumCases']==58
git('diff','--cached','--check')
git('commit','-m','merge current qualified transaction foundation into reference application')
head=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain')
proof=dict(at=datetime.now(timezone.utc).isoformat(),head=head,appParent=APP,currentFoundation=FOUNDATION,tree=str(TREE),
           normalBothParentMerge=True,all27AppAuthoredPathsByteIdentical=True,appPaths=paths,
           boundedOrderDraftProducerBranchPreserved=True,actualCurrentFoundationProducerChangesAutoMerged=True,
           allCaseFloorsIgnoresAndGuardsRetained=True,originalAOT1Signing58Required=True,
           freshSourceActualAppSixCompilersSignedNodeAndBrowserPending=True,noAppQualificationTransfer=True,noPublicationYet=True)
(COORD/'portable-v2-reference402-current-merge-review-v292.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k!='appPaths'},indent=2))
