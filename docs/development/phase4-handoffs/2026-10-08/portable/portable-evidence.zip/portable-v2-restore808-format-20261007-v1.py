import json
import pathlib
import subprocess

ROOT = pathlib.Path(r'C:\Users\turkins\Desktop\lf-p4-restore808-review-entity-v9-20261006')
OUT = pathlib.Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-restore808-review-20261007-v1')
def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

paths = set(git('diff', '--name-only', 'HEAD', '-z').decode().strip('\0').split('\0'))
paths.update(git('ls-files', '--others', '--exclude-standard', '-z').decode().strip('\0').split('\0'))
selected = sorted(rel for rel in paths if rel.endswith('.rs') and (ROOT / rel).is_file())
result = subprocess.run(['rustup', 'run', '1.97.1', 'rustfmt', '--edition', '2021', '--config', 'skip_children=true', *selected], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(OUT / 'rustfmt.log').write_bytes(result.stdout)
print(json.dumps({'rustfmtReturnCode': result.returncode, 'changedRustFiles': len(selected), 'tail': result.stdout.decode(errors='replace')[-3000:]}))
if result.returncode:
    raise SystemExit(result.returncode)
metadata = subprocess.run(['cargo', '+1.97.1', 'metadata', '--locked', '--offline', '--no-deps', '--format-version', '1'], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(OUT / 'metadata.json').write_bytes(metadata.stdout)
(OUT / 'metadata.stderr').write_bytes(metadata.stderr)
assert metadata.returncode == 0, metadata.stderr.decode(errors='replace')
parsed = json.loads(metadata.stdout)
print(json.dumps({'lockedOfflineMetadata': True, 'workspacePackages': len(parsed['packages']), 'nativeExecuted': False}))
