from pathlib import Path
import json
import sys

root = Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out = Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
sys.path.insert(0, str(root))
from tools import ci_contracts as c
expected = c.load(root)['pythonGuards']
observed = {name: value['guards'] for name, value in c.python_expectations(root).items()}
result = []
for name in sorted(expected.keys() | observed.keys()):
    if expected.get(name) == observed.get(name):
        continue
    for case in sorted(set(expected.get(name, {})) | set(observed.get(name, {}))):
        if expected[name].get(case) != observed[name].get(case):
            result.append({'module': name, 'case': case, 'changes': {key: {'expected': expected[name][case][key], 'actual': observed[name][case][key]} for key in c.GUARD_FIELDS if expected[name][case][key] != observed[name][case][key]}})
(out / 'guard-differences-v2.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
