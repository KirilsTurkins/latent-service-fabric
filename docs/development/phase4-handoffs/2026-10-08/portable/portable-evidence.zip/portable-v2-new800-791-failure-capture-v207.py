from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

COORD = Path(__file__).resolve().parent
OUT = COORD / 'portable-v2-new800-791-completed-failures-v207'
OUT.mkdir(exist_ok=True)
ENV = dict(os.environ, GODEBUG='http2client=0')
REPO = 'KirilsTurkins/latent-service-fabric'

def api(endpoint):
    return subprocess.check_output(['gh', 'api', endpoint], env=ENV, timeout=120)

records = []
for number, job, run in ((800, 113109821288, 37707939632), (791, 113112576588, 37708107183)):
    directory = OUT / str(number)
    directory.mkdir(exist_ok=True)
    job_raw = api(f'repos/{REPO}/actions/jobs/{job}')
    run_raw = api(f'repos/{REPO}/actions/runs/{run}')
    metadata, run_metadata = json.loads(job_raw), json.loads(run_raw)
    assert metadata['run_id'] == run and metadata['status'] == 'completed' and metadata['conclusion'] == 'failure'
    for name, raw in (('job.json', job_raw), ('run.json', run_raw)):
        (directory / name).write_bytes(raw)
    log = api(f'repos/{REPO}/actions/jobs/{job}/logs')
    (directory / 'raw.log').write_bytes(log)
    row = dict(pr=number, job=job, run=run, head=run_metadata['head_sha'], bytes=len(log),
               sha256=hashlib.sha256(log).hexdigest(), name=metadata['name'],
               failedSteps=[s['name'] for s in metadata['steps'] if s.get('conclusion') == 'failure'])
    if number == 800:
        lines = log.decode('utf8', errors='replace').splitlines()
        row['diagnostics'] = [line[:500] for line in lines if any(t in line for t in
            ('Traceback', 'AssertionError', 'FAILED', 'Error:', 'error:', 'stale', 'differs', 'out of date'))][-18:]
        row['transportFailure'] = [line[:700] for line in lines if any(t in line for t in
            ('Unhandled exception', 'Vectors.cs:', 'Assert', 'semantic-vector', 'System.InvalidOperation', 'System.Exception'))][-12:]
    else:
        lines = log.decode('utf8', errors='replace').splitlines()
        row['findingLocations'] = []
        for i, line in enumerate(lines):
            if 'RuleID:' in line:
                finding = {'rule': line.split('RuleID:', 1)[1].strip()[:100]}
                for candidate in lines[i:i + 18]:
                    for label in ('File:', 'Line:', 'Commit:'):
                        if label in candidate:
                            finding[label[:-1].lower()] = candidate.split(label, 1)[1].strip()[:180]
                row['findingLocations'].append(finding)
        row['closedFindingDetails'] = [line[:550] for line in lines if (
            ('generic-api-key' in line or 'test_dev_node_policies' in line or 'findings=' in line)
            and not re.search(r'fingerprint|secret|match|entropy', line, re.I))]
        row['closedScanStatus'] = [line[:300] for line in lines if (
            'SecurityError:' in line or 'exit code' in line or 'finding-count' in line)]
    records.append(row)
receipt = dict(at=datetime.now(timezone.utc).isoformat(), readOnly=True, records=records)
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt, indent=2))
