import hashlib
import json
from pathlib import Path

COORD = Path(__file__).resolve().parent
HEAD = "1b7a8073f9ec7b354a4dd00a365deb1c4094e3aa"
common = ["--all-features", "--locked", "--offline"]
prefix = ["cargo", "+1.97.1"]
steps = [prefix + ["check", "-p", "latent-control-store", "-p", "latent", "--all-targets"] + common]
focused = [
    ("latent-control-store", "deployments::control_admission::tests::closed_stage_preserves_failure_identity_and_never_copies_private_payload"),
    ("latent-control-store", "deployments::tests::operations::lease::preparation_lease_diagnostic_preserves_rejection_without_read_or_mutation_retry"),
    ("latent-control-store", "deployments::tests::operations::lease::package_lease_diagnostic_preserves_one_read_and_cancels_unpublished_catalog"),
    ("latent", "error::tests::control_preparation_stage_survives_wire_capture_without_disclosing_peer_data_or_certainty"),
]
for package, case in focused:
    steps.append(prefix + ["test", "-p", package, "--lib"] + common + [case, "--", "--exact", "--nocapture"])
for package in ["latent-control-store", "latent"]:
    steps.append(prefix + ["test", "-p", package, "--lib"] + common + ["--", "--list"])
    steps.append(prefix + ["test", "-p", package, "--lib"] + common + ["--", "--nocapture"])
steps.append(prefix + ["clippy", "-p", "latent-control-store", "-p", "latent", "--all-targets"] + common)
recipe = COORD / "portable-v2-control-stage-native-steps-v316.json"
recipe.write_text(json.dumps(steps, indent=2) + "\n", encoding="utf-8")
proof = {
    "head": HEAD, "sourceReceipt": "portable-v2-control-preparation-stage-cli-source-20261008-v305/receipt.json",
    "recipe": str(recipe), "recipeSha256": hashlib.sha256(recipe.read_bytes()).hexdigest(),
    "steps": len(steps), "executed": False,
    "requiredFocusedCaseCount": {case: 1 for _, case in focused},
    "requiredFullCompiledSets": {"latent-control-store": 255, "latent": 162},
    "originalIgnoredCasesPreserved": {"latent-control-store": 1, "latent": 0},
    "actualListingMustEqualRegisteredExpectedCases": True,
    "originalBounds": {"deadlineSeconds": 1800, "maximumTargetGrowthBytes": 16 * 1024 ** 3, "cargoBuildJobs": 2},
    "qualificationDoesNotEstablishOriginalControl29Subphase": True,
    "freshWorkflowRequiredWithoutRetryingOriginalUnknownMutation": True,
}
(COORD / "portable-v2-control-stage-native-prepared-v316.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
print(json.dumps(proof))
