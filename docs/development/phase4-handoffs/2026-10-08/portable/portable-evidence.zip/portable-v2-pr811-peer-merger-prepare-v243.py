from pathlib import Path

COORD=Path(__file__).resolve().parent
source=(COORD/'portable-v2-owned-signing-main-union-v238.py').read_text(encoding='utf8')
source=source.replace('v238','v243').replace('c84473ec9868fc496486f864afe52f1b7105329f','cbd99cf910bde67f8a8b4681d5b4ba94371be7a7')
path=COORD/'portable-v2-pr811-peer-union-v243.py'
compile(source,str(path),'exec')
assert not path.exists()
path.write_text(source,encoding='utf8')
