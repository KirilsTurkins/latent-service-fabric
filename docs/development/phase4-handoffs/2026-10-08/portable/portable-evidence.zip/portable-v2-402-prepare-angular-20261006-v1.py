from pathlib import Path
import sys
import json

root = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
output = Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-angular-compile-20261006-v1")
if output.exists():
    raise SystemExit("refuse replacing an Angular source attempt")
output.mkdir()
sys.path.insert(0, str(root))
from tools.angular_build.inputs import capture
from tools.build_snapshot import digest

config, inventory = capture(root / "examples/stateful-reference/angular", "angular-build.json", output / "input")
(output / "source-inputs.json").write_bytes(inventory)
toolchain = output / "toolchain"
toolchain.mkdir()
for name in ("package.json", "package-lock.json"):
    (toolchain / name).write_bytes((root / "examples/renderer-profile" / name).read_bytes())
for name in ("empty-user.npmrc", "empty-global.npmrc"):
    (toolchain / name).write_bytes(b"")
(output / "preparation.json").write_text(json.dumps({"sourceInventoryDigest": digest(inventory),
    "maintainedProfile": config["profile"], "backendProfile": config["backendProfile"],
    "signed": False, "nodeQualified": False, "componentCompiled": False,
    "scope": "Actual maintained Angular source compilation; not renderer/node qualification"}, indent=2) + "\n")
print(json.dumps({"prepared": str(output), "sourceInventoryDigest": digest(inventory)}))
