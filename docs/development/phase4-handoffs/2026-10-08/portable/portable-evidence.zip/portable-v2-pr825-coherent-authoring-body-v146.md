Adds finite dispatcher capacity and retained transaction admission for #391. Reconciles development and management APIs while preserving native-owner identity, operator/physical acceptance fences, and all existing cases and bounds.

Keeps the aggregate authoring WIT and maintained Rust, C, Go, TypeScript, Java, and .NET templates coherent. Results carry the real admission view and optional original key version; no staged-value version is manufactured. Removes a duplicate initializer field without changing dispatcher behavior.

Current-head Linux source checks pass. All six maintained language compilers build both aggregate and forbidden-HTTP variants on this exact candidate with pinned tools and original limits. Full CI, signed-node execution, and installed dispatcher startup/ordering/recovery remain pending.
