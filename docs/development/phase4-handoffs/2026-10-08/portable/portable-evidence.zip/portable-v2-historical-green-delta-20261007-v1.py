import json
import pathlib
import subprocess

COORD = pathlib.Path(__file__).resolve().parent
REPO = COORD.parent / 'latent-fabric'
OUT = COORD / 'portable-v2-pr-historical-green-audit-20261007-v1'
details = json.loads((OUT / 'detailed-review.json').read_bytes())
records = []
for row in details:
    if not row['ciResultSucceeded'] or not row['wasAssociatedWithThisPr']:
        continue
    current = subprocess.check_output(['gh', 'pr', 'view', str(row['number']), '--json', 'headRefOid', '--jq', '.headRefOid'], cwd=REPO, timeout=120).decode().strip()
    changed = subprocess.run(['git', 'diff', '--name-only', row['head'], current], cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    assert changed.returncode == 0, changed.stderr.decode(errors='replace')
    paths = changed.stdout.decode().splitlines()
    functional = [path for path in paths if path.endswith(('.rs', '.py', '.wit', '.proto', '.mjs', '.ts', '.go', '.java', '.c', '.h', '.cs'))]
    records.append({'number': row['number'], 'historicalGreenHead': row['head'], 'currentHead': current,
                    'changedPathCount': len(paths), 'functionalSourcePathCount': len(functional),
                    'functionalExamples': functional[:8], 'shortcutEligible': False,
                    'reason': 'Intervening functional source and qualification changes exceed a simple conflict-only JSON repair. Retained all-green history does not qualify the current head.'})
(OUT / 'source-delta-review.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
print(json.dumps(records, indent=2))
