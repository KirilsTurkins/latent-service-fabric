from pathlib import Path
import json
import sys

root = Path(r"C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006")
output = Path(r"C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-java-compile-20261006-v4")
assert not output.exists()
output.mkdir()
sys.path.insert(0, str(root))
from tools.stateful_reference_project import create
from tools.rust_capsule_project import snapshot, inventory, digest
project = create(output / "project", "java")
before = inventory(snapshot(project))
(output / "source-inputs.json").write_bytes(before)
(output / "preparation.json").write_text(json.dumps({
    "language": "java", "application": "order-draft-v1", "sourceInventoryDigest": digest(before),
    "sourceBase": "ce284d47834b1e38b11cc39bfc99906bbecdcdb3", "authoredSourceUncommitted": False,
    "compiled": False, "signed": False, "nodeQualified": False, "compilerVolumesReadOnly": True,
    "compilerCacheSource": "latent-sdk-java-public-cache-af6d-20261006-r4",
    "compilerToolsSource": "latent-sdk-java-public-tools-af6d-20261006-r4",
}, indent=2) + "\n",encoding="utf8")
runner = output.parent / "portable-v2-402-java-compile-run-20261006-v4.py"
assert not runner.exists()
runner.write_bytes((output.parent / "portable-v2-402-java-compile-run-20261006-v3.py").read_bytes())
(output / "results").mkdir()
print(json.dumps({"prepared":str(output),"sourceInventoryDigest":digest(before)}))
