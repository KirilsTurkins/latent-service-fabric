import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path(r'C:\Users\turkins\Desktop\lf-p4-restore808-review-entity-v9-20261006')
OUT = pathlib.Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-restore808-review-20261007-v1')
PARENTS = {'peer': 'ce764ab44c744b7dad0c9b56bb2ea0451bdf8115', 'qualified': '0e0162f71127bfbd2a88e848f153f4c64c134e83'}
MAP = {v['original']: v['adapter'] for v in json.loads((OUT / 'legacy-path-map.json').read_bytes())}

# Independently reviewed fixture-only adaptations required by the retained
# engine layout and positive physical thread retirement. Exact hashes keep this
# review bounded; they cannot bless future changes or altered test conditions.
REVIEWED = {
    ('peer', 'crates/latent-state/src/embedded/tests/format.rs', 'v1_upgrade_preserves_original_rows_and_existing_read_views'): ('7026c447b2f2050c39be86a6e7eb7c1964e2705f9b4d2519ffebec51500ba7d6', 'ab161bbe7f16750942b1aad01f80046c0d2a7577f9a4ce59b3168cbca02d0791', 'Uses the retained RwLock/database guard and required engine fields; every original format/row/checkpoint assertion remains.'),
    ('peer', 'crates/latent-state/src/embedded/tests/format.rs', 'backend_sync_failure_during_upgrade_refuses_readiness_and_requires_exact_reopen'): ('4bdf333e105184e94350ff24e31ec8e63ac8d98734471a0a99d8a9be8f5e546d', 'da8d2380b4576c39bdd8461b773a529496266239a6a3822555839817dd6d66b6', 'Only reads the same native database through its current RwLock guard.'),
    ('peer', 'crates/latent-state/src/session/tests.rs', 'byte_limited_pages_require_continuation_and_never_omit_an_entry'): ('c8cef976708f67c3697d7e371983067559f16f241f6d1c0377783cc97b2acc39', '1c2845fb86a9a9b8f6ec028deb972c3b928f3391b0519123300cebb00b45719b', 'Adds the original qualified 120-byte Limit refusal; the peer 136-byte one-entry loop and every assertion remain unchanged.'),
    ('qualified', 'crates/latent-state/src/protected_store/tests/validation.rs', 'incoherent_logical_links_fail_before_ready_and_preserve_every_existing_row'): ('442241251deb90d09f2c47719676bdbac70bcf5e381b017094b675e31778c82e', '9119586ec9b79642dfa0d9169a6ac56c3ed2527b2e813c17c9808581ac416e54', 'Retains every original failure/reopen assertion and requires actual thread joins before reopen, within an earlier captured original WATCHDOG deadline.'),
    ('qualified', 'crates/latent-state/src/store_io/tests/initialization.rs', 'initialization_failure_never_delivers_ready_or_replaces_engine'): ('64c8eea7528c9f463236d5df46de676b523afe37a8cf9b73836792033f8996f6', 'f7283bc6a765573bf2e3721278a2f07e63dfc83e2929b808e176dc6961d9ca7b', 'Retains every original assertion and appends positive thread joining under the same original now+WATCHDOG cutoff.'),
}

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def tokens(source):
    result = []
    pos = 0
    pattern = re.compile(r'\s+|//[^\n]*|/\*|(?:br|rb|r)(?P<hash>\#*)"|(?:b)?"(?:\\.|[^"\\])*"|(?:b)?\'(?:\\(?:[^\n]|u\{[0-9a-fA-F]+\})|[^\'\\])\'|[A-Za-z_][A-Za-z_0-9]*|.', re.S)
    while pos < len(source):
        match = pattern.match(source, pos)
        assert match, pos
        text = match[0]
        if text == '/*':
            depth, end = 1, match.end()
            while depth:
                next_open = source.find('/*', end)
                next_close = source.find('*/', end)
                assert next_close >= 0
                if 0 <= next_open < next_close:
                    depth += 1
                    end = next_open + 2
                else:
                    depth -= 1
                    end = next_close + 2
            pos = end
            continue
        if match.group('hash') is not None:
            suffix = '"' + match.group('hash')
            end = source.find(suffix, match.end())
            assert end >= 0
            end += len(suffix)
            result.append((source[pos:end], pos, end))
            pos = end
            continue
        pos = match.end()
        if text.isspace() or text.startswith('//'):
            continue
        result.append((text, match.start(), pos))
    return result

def cases(source):
    ts = tokens(source)
    result = {}
    i = 0
    while i < len(ts) - 4:
        if [t[0] for t in ts[i:i+4]] != ['#', '[', 'test', ']']:
            i += 1
            continue
        start = i
        j = i + 4
        while ts[j][0] != 'fn':
            j += 1
        name = ts[j+1][0]
        attributes = [t[0] for t in ts[start:j]]
        while ts[j][0] != '{':
            j += 1
        body_start = j
        depth = 1
        j += 1
        while depth:
            depth += (ts[j][0] == '{') - (ts[j][0] == '}')
            j += 1
        body = [t[0] for t in ts[body_start:j]]
        assert name not in result, name
        result[name] = {'attributes': attributes, 'body': body}
        i = j
    return result

def digest(value):
    return hashlib.sha256(json.dumps(value, separators=(',', ':')).encode()).hexdigest()

def remap_source(text):
    return re.sub(r'\brecovery::(?=(?:migration|restore|resume|snapshot|offline)(?:::|\b))', 'recovery::v1::', text)

def main():
    results, problems = [], []
    for label, sha in PARENTS.items():
        files = git('ls-tree', '-r', '--name-only', sha, '--', 'crates/latent-state', 'crates/latent-protected-files', 'crates/latent-core/src/native_capacity').decode().splitlines()
        for rel in files:
            if not rel.endswith('.rs'):
                continue
            original = git('show', f'{sha}:{rel}').decode()
            target = MAP.get(rel, rel) if label == 'peer' else rel
            expected = cases(remap_source(original) if label == 'peer' and rel in MAP else original)
            if not expected:
                continue
            actual = cases((ROOT / target).read_bytes().decode())
            for name, data in expected.items():
                target_name = name
                if label == 'peer' and rel.endswith('/protected_store/tests/lifecycle.rs') and name == 'detached_view_response_witness_waits_for_actual_native_retirement_after_close':
                    target_name += '_retaining_owner'
                found = actual.get(target_name)
                ok = found == data
                record = {'parent': label, 'path': rel, 'target': target, 'case': name, 'targetCase': target_name, 'unchangedBodyAndAttributes': ok, 'originalDigest': digest(data), 'resolvedDigest': digest(found)}
                if not ok and rel == 'crates/latent-protected-files/src/rooted/tests.rs' and name in {
                    'mutable_engine_file_creation_and_reopen_never_truncate_existing_bytes',
                    'exclusive_offline_output_refuses_existing_failed_files_and_unsafe_names_without_truncation',
                    'exclusive_offline_output_refuses_existing_failed_files_and_unsafe_names_without_overwrite',
                }:
                    normalized = dict(found, body=list(found['body']))
                    additions = [
                        ['assert', '!', '(', 'fence', '.', 'was_created', '(', ')', ')', ';'],
                        ['assert', '!', '(', '!', 'new_fence', '.', 'was_created', '(', ')', ')', ';'],
                    ]
                    removed = 0
                    for added in additions:
                        for offset in range(len(normalized['body']) - len(added) + 1):
                            if normalized['body'][offset:offset + len(added)] == added:
                                del normalized['body'][offset:offset + len(added)]
                                removed += 1
                                break
                    if normalized == data and removed:
                        record['reviewedIncomingAssertions'] = 'Exact f922 exclusive-creation/reopen assertions are added; every original token and test attribute remains.'
                        ok = True
                review = REVIEWED.get((label, rel, name))
                if not ok and review:
                    assert (record['originalDigest'], record['resolvedDigest']) == review[:2], record
                    assert found['attributes'] == data['attributes'], record
                    record['reviewedFixtureAdaptation'] = review[2]
                    ok = True
                results.append(record)
                if not ok:
                    problems.append(record)
    receipt = {'cases': len(results), 'problems': problems, 'proof': 'Source tokens and test attributes, not runtime execution', 'records': results}
    (OUT / 'parent-case-audit.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'reviewedParentCases': len(results), 'problems': problems}, indent=2))
    if problems:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
