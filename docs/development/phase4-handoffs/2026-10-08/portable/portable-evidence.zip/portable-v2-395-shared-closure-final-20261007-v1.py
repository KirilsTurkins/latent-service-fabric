from pathlib import Path
import json
import subprocess

repo=Path(r'C:\Users\turkins\Desktop\latent-fabric')
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination')
audit=json.loads((coord/'portable-v2-395-shared-closure-audit-20261006-v1.json').read_bytes())
head=audit['source']; base=audit['base']
changed={row['path']:row['status'] for row in audit['runtimePaths']+audit['remainingChangesForReview']}
groups={'compiledRuntime':{row['path'] for row in audit['runtimePaths']},
        'generatedClientAndProfile':{name for name in changed if name.startswith(('sdk/rust/','sdk/profile/'))},
        'sourceAndCiSupport':set()}
support={'.github/workflows/ci.yml','tools/ci/suites.json','tools/ci/suites.d/transaction-recovery-example.json',
         'tools/tests/fixtures/ci-suites/affected.json','tools/tests/test_ci_cargo_cache.py','tools/tests/test_ci_contracts.py',
         'tools/tests/test_ci_suite_inventory.py','tools/tests/test_capability_policy_schema.py','tools/tests/test_phase1_contracts.py',
         'tools/tests/test_run_aot_tests.py','tools/tests/test_transaction_receipts.py',
         'tools/run_aot_tests.py','tools/generate_transaction_contracts.py',
         'tools/ci/contracts/workflows/ci.yml/jobs/contracts.json','tools/ci/contracts/workflows/ci.yml/jobs/fast.json',
         'tools/ci/contracts/workflows/ci.yml/jobs/rust.json','tools/ci/contracts/owners/tools/generate_transaction_contracts.py.json'}
for test in ('test_ci_cargo_cache.py','test_ci_contracts.py','test_ci_suite_inventory.py','test_capability_policy_schema.py',
             'test_phase1_contracts.py','test_run_aot_tests.py','test_transaction_receipts.py'):
    support.add('tools/ci/contracts/python/'+test+'.json')
groups['sourceAndCiSupport']={name for name in support if name in changed}
selected=set().union(*groups.values())
exclusions={name for name in changed if name.startswith('examples/stateful-reference/')
            or name.startswith('tools/stateful_reference') or name=='tools/check_stateful_reference.mjs'
            or '/test_stateful_reference' in name or name=='tools/transaction_guest_project.py'}
assert not selected&exclusions
tree={}
for line in subprocess.check_output(['git','ls-tree','-r',head],cwd=repo,text=True).splitlines():
    meta,name=line.split('\t',1)
    mode,kind,oid=meta.split()
    tree[name]={'mode':mode,'kind':kind,'oid':oid}
rows=[]
for group,names in groups.items():
    for name in sorted(names):
        row={'group':group,'path':name,'status':changed[name]}
        if changed[name]!='D':
            assert tree[name]['kind']=='blob'
            row.update(tree[name])
        rows.append(row)
record={'schemaVersion':'latent.phase4.inbox-shared-prerequisite-closure.v1','base':base,'source':head,
        'qualification':'exact selected shared source; Source union reviewed, fresh extracted-head Source and Native still required',
        'paths':rows,'explicitAppAndNotificationExclusions':sorted(exclusions),
        'runtimeLiteralReferencesVerified':True,
        'notes':['SDK guest authoring/language compilers, Java qualification campaigns, website, docs/evidence and unselected workflow changes are not copied.',
                 'Preserve base CI obligations and the copied runtime suite floors; independently reconcile expected records for the exact selected source. Do not copy all e57 contracts without their corresponding source.',
                 'The selected component binding host/native transaction modules are required. Guest selection fixes already proven on50869 can be consumed separately if current source lacks them, with matching SDK/creator opt-in; do not mix guest defaults.',
                 'tools/transaction_guest_project.py notification selector is app-owned at e57 and is explicitly excluded. Keep the destination pre-app version or immutable ad537 shared version.',
                 'No existing NATS consumer/provider/config/state-admission implementation edits are reserved by the app agent.']}
path=coord/'portable-v2-395-shared-closure-final-20261007-v1.json'
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'file':str(path),'groups':{key:len(value) for key,value in groups.items()},'paths':len(rows),'appExcluded':len(exclusions)}))
