from pathlib import Path
import hashlib
import json
import subprocess

root=Path(r'C:\Users\turkins\Desktop\lf-p4-reference-app-402-20261006')
out=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-402-http-reconcile-20261006-v1')
ours='abbeeceb7fa85534476d8b66cb8ab567f9263493'
incoming='ad537698c0178ab4325ebe4f32857d4f94d00dca'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==ours
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()==incoming
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=root).strip()
assert not subprocess.check_output(['git','diff','--name-only'],cwd=root).strip()
path='docs/evidence/native-wasmtime-lints409-r6/tests-library-r6.log'
original=subprocess.check_output(['git','show',incoming+':'+path],cwd=root)
assert original==(root/path).read_bytes()
check=subprocess.run(['git','diff','--cached','--check'],cwd=root,capture_output=True)
assert check.returncode in (0,1,2)
if check.returncode:
    assert check.stdout.decode().strip()==path+':395: new blank line at EOF.'
subprocess.run(['git','commit','-m','Merge installed transaction HTTP integration into the isolated reference app'],cwd=root,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert subprocess.check_output(['git','show','-s','--format=%P',head],cwd=root,text=True).split()==[ours,incoming]
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root).strip()
receipt={'head':head,'parents':[ours,incoming],'clean':True,'published':False,'allConflictVariantsRetained':True,'immutableHistoricalLogPreserved':{'path':path,'sha256':hashlib.sha256(original).hexdigest(),'preexistingTrailingBlankLine':True},'qualification':'host source review; fresh Linux Source and Native pending'}
(out/'merge-custody-v2.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
