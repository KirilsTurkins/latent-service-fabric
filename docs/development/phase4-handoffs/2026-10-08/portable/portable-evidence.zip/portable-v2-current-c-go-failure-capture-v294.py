from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

COORD=Path(__file__).resolve().parent
ENV=dict(os.environ,GODEBUG='http2client=0')
REPO='KirilsTurkins/latent-service-fabric'
OUT=COORD/'portable-v2-current-c-go-completed-failures-v294';OUT.mkdir(exist_ok=True)
def api(path):return subprocess.check_output(['gh','api',path],env=ENV,timeout=120)
records=[]
for number,job,run in ((825,113154150383,37729173027),(828,113151984458,37728484462)):
    path=OUT/str(number);path.mkdir(exist_ok=True)
    if number==828:
        custody=COORD/'integration-v12-current828-failed-go-ci-v20'
        files=[p for p in custody.iterdir() if p.suffix in ('.log','.txt')]
        raw=max(files,key=lambda p:p.stat().st_size).read_bytes()
        assert len(raw)==165301 and hashlib.sha256(raw).hexdigest()=='b452c6b20048f5fb92452f866b08eb985c3ad0ef7bb99ea4756b9839fa2cf985'
        job_raw=(custody/'job.json').read_bytes()
        run_raw=api(f'repos/{REPO}/actions/runs/{run}')
    else:
        job_raw=api(f'repos/{REPO}/actions/jobs/{job}')
        run_raw=api(f'repos/{REPO}/actions/runs/{run}')
        raw=api(f'repos/{REPO}/actions/jobs/{job}/logs')
    j,r=json.loads(job_raw),json.loads(run_raw)
    assert j['id']==job and j['run_id']==run and j['status']=='completed' and j['conclusion']=='failure'
    for name,data in [('job.json',job_raw),('run.json',run_raw),('raw.log',raw)]: (path/name).write_bytes(data)
    clean=re.sub(r'\x1b\[[0-9;]*m','',raw.decode('utf8'))
    lines=clean.splitlines()
    diagnostics=[x[:700] for x in lines if any(t in x for t in ('error:','error[','ValueError:','AssertionError','SecurityError','Traceback','panicked at','test result: FAILED'))][-24:]
    artifacts=[x[:400] for x in lines if 'Artifact ID ' in x or 'Final size is' in x]
    records.append(dict(pr=number,job=job,run=run,head=r['head_sha'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                        failedSteps=[s['name'] for s in j['steps'] if s.get('conclusion')=='failure'],diagnostics=diagnostics,artifactLines=artifacts))
proof=dict(at=datetime.now(timezone.utc).isoformat(),readOnly=True,noProductCauseInferred=True,records=records)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
