from datetime import datetime,timezone
import ast
import json
from pathlib import Path
import tempfile

TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr796-21c-main-v272')
COORD=Path(__file__).resolve().parent
text=(TREE/'tools/java_server_node.py').read_text(encoding='utf8')
nodes=[n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name in {'RecordedRouteClient','ObservedRouteClient'}]
assert len(nodes)==2
class Client:
    result=None
    failure=None
    calls=0
    def __init__(self,*args,**kwargs):pass
    def call(self,*args,**kwargs):
        Client.calls+=1
        if Client.failure:raise Client.failure
        return Client.result
def require(value,reason):
    if not value:raise ValueError(reason)
def fresh(path):
    path.mkdir();return path
def write_json(path,value):
    path.write_text(json.dumps(value),encoding='utf8')
namespace=dict(Path=Path,RouteClient=Client,require=require,fresh=fresh,json=json,write_json=write_json)
exec(compile(ast.Module(body=nodes,type_ignores=[]),'<reviewed combined observer>','exec'),namespace)
with tempfile.TemporaryDirectory(prefix='p4-observer-v274-') as directory:
    root=Path(directory)
    client=namespace['ObservedRouteClient'](Path('cli'),Path('config'),Path('routes'),evidence=root,deadline=123)
    result={'category':'platform-failure','error':{'code':'resource-exhausted'},'outcomeKnown':False,'requestDispatched':True,
            'data':{'privateSentinel':'do-not-copy-into-summary'}}
    Client.result=result
    returned=client.call('trigger','delete','--token','private-argument','--expected-generation','17','--expected-state-version','22')
    assert returned is result and Client.calls==1
    summary=json.loads((root/'route-delete-rejection.json').read_bytes())
    assert summary['errorCode']=='resource-exhausted' and summary['expectedGeneration']=='17' and summary['expectedStateVersion']=='22'
    assert 'private' not in json.dumps(summary)
    assert json.loads((root/'route-control/001.json').read_bytes())==result
    assert client.record_count==1
    failure=RuntimeError('fixed-original-error')
    Client.failure=failure
    try:client.call('trigger','delete')
    except RuntimeError as returned_error:assert returned_error is failure
    else:raise AssertionError('original error lost')
    assert Client.calls==2 and client.record_count==1 and not (root/'route-control/002.json').exists()
proof=dict(at=datetime.now(timezone.utc).isoformat(),actualReviewedObserverClassesExecuted=True,
           exactlyOneUnderlyingCallPerAttempt=True,returnedObjectAndOriginalErrorIdentityPreserved=True,
           genericEvidenceKept=True,rejectedSummaryContainsOnlyBoundedClosedMetadata=True,
           noCredentialArgumentOrPrivateResultInSummary=True,noActualCLIOrNodeQualificationClaim=True)
(COORD/'portable-v2-pr796-observer-behavior-v274.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
