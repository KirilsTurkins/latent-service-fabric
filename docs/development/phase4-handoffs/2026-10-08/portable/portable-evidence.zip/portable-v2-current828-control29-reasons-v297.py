import json
from pathlib import Path

OUT=Path(__file__).resolve().parent/'portable-v2-current828-control-failure-artifact-v295'
failed=json.loads((OUT/'go-capsule-dependencies__node__controls__029.json').read_bytes())
diag=json.loads((OUT/'go-capsule-dependencies__node__controls__unexpected-control-diagnostics.json').read_bytes())
allowed_reason={'admission-authority-busy','admission-authority-poisoned','admission-control-busy','admission-clock-lease-uncovered',
                'admission-clock-regression','admission-durability-uncertain','admission-owner-retired','admission-restart-clock-floor',
                'admission-verification-busy','signature-clock-regression','signature-trust-conflict','signature-stale-proof'}
def closed(value):
    if not isinstance(value,dict):return None
    error=value.get('error') or {}
    details=[]
    for row in error.get('details',[]):
        fields=row.get('fields',{})
        reason=fields.get('reason')
        if row.get('kind')=='admission.currentness' and reason in allowed_reason:details.append(dict(kind='admission.currentness',reason=reason))
    result=dict(category=value.get('category'),outcomeKnown=value.get('outcomeKnown'),requestDispatched=value.get('requestDispatched'),
                errorCode=error.get('code'),retryable=error.get('retryable'),closedDetails=details)
    data=value.get('data') or {}
    for name in ('recovery','operation','durability','auditAck'):
        if isinstance(data.get(name),dict):result[name+'Keys']=list(data[name])
    return result
result=dict(original=closed(failed),diagnosticKeys=list(diag),auditComplete=diag.get('auditComplete'),operation=closed(diag.get('operation')),
            elapsedNanos='6658608624',originalRpcTimeoutMillis=15000,originalProcessTimeoutMillis=25000,
            sdkAuthoring10AndDependencies10ActualPass=True,noCauseInferredFromUnclassifiedShape=True)
audit=diag.get('audit')
if isinstance(audit,list):
    result['auditPages']=len(audit)
    result['auditResultCategories']=[closed(row).get('category') for row in audit if isinstance(row,dict) and 'category' in row]
(OUT/'closed-control29-reasons-v297.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
