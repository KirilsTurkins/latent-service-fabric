from datetime import datetime, timezone
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
DEVELOPMENT='cbd99cf910bde67f8a8b4681d5b4ba94371be7a7'
number, parent = sys.argv[1:]
assert number in {'790','791','800','787','796','784','825','811'}
assert len(parent)==40 and all(c in '0123456789abcdef' for c in parent)
TREE=Path(r'C:\Users\turkins\Desktop')/('lf-p4-pr'+number+'-current-main-v243')
branch='fix/phase4-pr'+number+'-current-main-v243'
OUT=COORD/('portable-v2-pr'+number+'-current-main-union-v243')
assert not TREE.exists() and not OUT.exists()
OUT.mkdir()
def git(*args,cwd=REPO):
    return subprocess.check_output(['git','-C',str(cwd),*args])
git('worktree','add','--no-checkout','-b',branch,str(TREE),parent)
git('sparse-checkout','set','--no-cone','tools/ci/suites.json','tools/tests/test_java_server_source.py',cwd=TREE)
git('checkout',branch,cwd=TREE)
merge=subprocess.run(['git','-C',str(TREE),'merge','--no-commit','--no-ff',DEVELOPMENT],capture_output=True)
(OUT/'merge.stdout').write_bytes(merge.stdout)
(OUT/'merge.stderr').write_bytes(merge.stderr)
assert merge.returncode in (0,1)
unmerged=git('ls-files','-u',cwd=TREE).decode()
paths=sorted({line.split('\t',1)[1] for line in unmerged.splitlines()})
assert set(paths)<= {'tools/ci/suites.json','tools/tests/test_java_server_source.py'},paths
stages={}
for path in paths:
    stages[path]={}
    for n in (1,2,3):
        raw=git('show',f':{n}:{path}',cwd=TREE)
        stages[path][n]=raw
        (OUT/(path.replace('/','__')+f'.stage{n}')).write_bytes(raw)

def scalar(b,o,t,label):
    if o==t:return o
    if o==b:return t
    if t==b:return o
    raise AssertionError(('unreviewed-scalar-conflict',label,b,o,t))

union_fields={'expectedCases','expectedIgnored','ignoredLeaves','expectedCustomCases','prerequisites'}
if 'tools/ci/suites.json' in paths:
    path='tools/ci/suites.json'
    b,o,t=[json.loads(stages[path][n]) for n in (1,2,3)]
    result=copy.deepcopy(o)
    for key in (set(b)|set(o)|set(t))-{'suites'}:
        result[key]=scalar(b.get(key),o.get(key),t.get(key),'root.'+key)
    maps=[{row['id']:row for row in value['suites']} for value in (b,o,t)]
    rows=[]
    for identity in sorted(set(maps[1])|set(maps[2])):
        rb,ro,rt=[m.get(identity) for m in maps]
        if ro is None:row=copy.deepcopy(rt)
        elif rt is None:row=copy.deepcopy(ro)
        else:
            row={}
            for key in sorted(set(ro)|set(rt)):
                if key in union_fields:row[key]=sorted(set(ro.get(key,[]))|set(rt.get(key,[])))
                elif key=='minimumCases':row[key]=max(ro[key],rt[key],len(set(ro.get('expectedCases',[]))|set(rt.get('expectedCases',[]))))
                else:row[key]=scalar((rb or {}).get(key),ro.get(key),rt.get(key),identity+'.'+key)
        rows.append(row)
    result['suites']=rows
    (TREE/path).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf8')

fixture='tools/tests/test_java_server_source.py'
if fixture in paths:
    ours,theirs=stages[fixture][2],stages[fixture][3]
    assert ours.replace(b'/* controlled empty-world canonical bridge: no transaction imports */',b'/* controlled import probe */')==theirs
    (TREE/fixture).write_bytes(ours)
if paths:git('add','--sparse',*paths,cwd=TREE)
assert not git('ls-files','-u',cwd=TREE)
git('diff','--check','--cached',cwd=TREE)
current=json.loads(git('show',':tools/ci/suites.json',cwd=TREE))
rows={row['id']:row for row in current['suites']}
for head in (parent,DEVELOPMENT):
    original=json.loads(git('show',head+':tools/ci/suites.json',cwd=TREE))
    for old in original['suites']:
        new=rows[old['id']]
        assert old['minimumCases']<=new['minimumCases']
        for field in union_fields:assert set(old.get(field,[]))<=set(new.get(field,[]))
git('commit','-m',f'merge development into current Phase4 PR{number}',cwd=TREE)
head=git('rev-parse','HEAD',cwd=TREE).decode().strip()
assert not git('status','--porcelain',cwd=TREE)
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=int(number),parent=parent,development=DEVELOPMENT,head=head,tree=str(TREE),
           branch=branch,conflicts=paths,rawStagesPreserved=True,allParentCaseFloorsIgnoresPrerequisitesPreserved=True,
           suiteCount=len(rows),sourceAndCurrentNativePending=True,noPublication=True)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
