﻿from pathlib import Path
import json,hashlib,subprocess,shutil,sys
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');head='f4ab131b3ec60b5206b50f4dd00fff83f05410bc';source_path=coord/'entity-restore-receipt-source-linux-20261007-v2/receipt.json';s=json.loads(source_path.read_bytes());assert s['head']==head and s['passed'] and s['originalProcessReaped'] and s['sourceClean'] and s['sourceHeadUnchanged']
assert hashlib.sha256(source_path.read_bytes()).hexdigest()=='2833b43d018e374660d19b45e327b16d5e209582f259d8638019149021a3d14d'
for row in s['steps']:
 data=(source_path.parent/row['log']).read_bytes();assert row['exitCode']==0 and row['originalProcessReaped'] and row['stopReason'] is None and len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
prior=json.loads((coord/'portable-v2-go825-retained-sdk-native-20261007-v111/receipt.json').read_bytes());assert prior['passed'] and prior['originalProcessReaped'] and prior['sourceClean'] and prior['sourceHeadUnchanged']
steps=coord/'entity-contract-v65-restore-receipt-native-steps-20261007-v1.json';assert hashlib.sha256(steps.read_bytes()).hexdigest()=='b0a643f80cf9af36a4ae081e98c06198144ae3df54769d783bcbc997ba2d29a4';assert len(json.loads(steps.read_bytes()))==6
assert shutil.disk_usage(coord).free>2*1024**3
print(json.dumps(dict(head=head,sourceAllSevenLogsVerified=True,goOriginalProcessReaped=True,stepsSha256=hashlib.sha256(steps.read_bytes()).hexdigest(),freeHostBytes=shutil.disk_usage(coord).free)),flush=True)
raise SystemExit(subprocess.call([sys.executable,'-X','utf8','-B',str(coord/'portable-v2-reconstructed-native-controller-20261007-v93.py'),'portable-v2-state399-retained-receipts-native-20261007-v112',head,str(steps),'native']))
