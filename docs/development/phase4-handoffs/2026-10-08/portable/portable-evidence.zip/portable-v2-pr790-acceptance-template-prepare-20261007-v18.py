import hashlib
import json
from pathlib import Path

coord = Path(__file__).resolve().parent
parent = coord / 'root-pr790-acceptance-campaign-20261007-v17.py'
source = parent.read_text(encoding='utf-8')
head_before = '90df759198c4252e37e8dbfbcbc8d494ec070548'
head_after = '8019fefaf9d78948e2fceb95db1127f17ecbb234'
assert source.count(head_before) == 1
assert source.count('-20261007-v17') == 3
assert source.count('root-pr387-actual-') == 3
assert source.count('root-private-guest-tools-20261006-v12/receipt.json') == 1
new = source.replace(head_before, head_after).replace('-20261007-v17', '-20261007-v18').replace('root-pr387-actual-', 'portable-v2-pr790-actual-')
assert new.count('root-private-guest-tools-20261006-v12/receipt.json') == 1
assert 'job, seconds = compiler_job, 1900' in new
assert "seconds = 1800 if phase == 'build' else 900" in new
path = coord / 'portable-v2-pr790-acceptance-campaign-20261007-v18.py'
assert not path.exists()
path.write_text(new, encoding='utf-8', newline='\n')
receipt = {'originalTemplate': str(parent), 'originalTemplateSha256': hashlib.sha256(source.encode()).hexdigest(),
           'candidateHead': head_after, 'newTemplate': str(path), 'newTemplateSha256': hashlib.sha256(new.encode()).hexdigest(),
           'authenticatedV12PathUnchanged': True, 'compileSeconds': 1900, 'buildSeconds': 1800, 'executeSeconds': 900,
           'changesOnly': ['exact head', 'exact three job tails', 'exact owned job prefixes'], 'nativeStarted': False}
(coord / 'portable-v2-pr790-acceptance-template-prepare-20261007-v18.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
