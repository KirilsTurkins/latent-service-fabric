from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
COORD=Path(__file__).resolve().parent
ROOTS=('api/','apps/','crates/','sdk/','wit/','schema/','schemas/','tools/','Cargo.toml','Cargo.lock','rust-toolchain.toml')
runtime_roots=('api/','apps/','crates/','wit/','schema/','schemas/','Cargo.toml','Cargo.lock','rust-toolchain.toml')
proof=[]
for number in (790,800,791,787,796,784,825):
    union=json.loads((COORD/('portable-v2-pr'+str(number)+'-website-main-union-v224.json')).read_bytes())
    final=union['head']; merged=union['parent']
    initial=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-union-v217/receipt.json')).read_bytes()) if number!=790 else json.loads((COORD/'portable-v2-pr790-current-merge-review-v216.json').read_bytes())
    old=initial['parent'] if 'parent' in initial else initial['parents'][0]
    all_paths=subprocess.check_output(['git','-C',str(REPO),'diff','--name-only',old,final]).decode().splitlines()
    rust_paths=[p for p in all_paths if p.startswith(runtime_roots) or p in runtime_roots]
    old_rust=[p for p in rust_paths if p not in ('crates/latent-node/src/journal/tests/tree.rs','crates/latent-node/tests/activation_lifecycle/identity.rs')]
    assert not old_rust,(number,old_rust)
    web_diff=subprocess.check_output(['git','-C',str(REPO),'diff','--name-only',merged,final]).decode().splitlines()
    assert web_diff==['website/scripts/test-discovery.mjs']
    proof.append(dict(pr=number,finalHead=final,mainUnionParent=merged,priorFeatureHead=old,
                      exactRustDeltaFromPriorFeature=rust_paths,onlyNewMainTwoTestPathsInRust=True,
                      finalWebsiteOnlyDelta=True,allOtherFinalVsUnionTrackedBytesIdentical=True,
                      priorReceiptsRemainAtOriginalHeads=True,freshCurrentSourceAndNewMainNativePending=True,
                      completeCI=False))
(COORD/'portable-v2-owned-qualified-source-closures-v226.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps([dict(pr=r['pr'],finalHead=r['finalHead'],rustChangedPaths=r['exactRustDeltaFromPriorFeature']) for r in proof],indent=2))
