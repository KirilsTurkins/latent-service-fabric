from datetime import datetime,timezone
import copy
import hashlib
import json
from pathlib import Path
import subprocess

TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr811-current-main-v243')
COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-pr811-current-main-union-v243'
OURS='060d3c07a51a6b2d690a9aca7816d5f7fe5e22a0'
PEER='cbd99cf910bde67f8a8b4681d5b4ba94371be7a7'
def git(*args):return subprocess.check_output(['git','-C',str(TREE),*args])
path='tools/ci/suites.json'
o,t=[json.loads(git('show',f':{n}:{path}')) for n in (2,3)]
result=copy.deepcopy(o)
assert {k:v for k,v in o.items() if k!='suites'}=={k:v for k,v in t.items() if k!='suites'}
maps=[{r['id']:r for r in p['suites']} for p in (o,t)]
union_fields={'expectedCases','expectedIgnored','ignoredLeaves','expectedCustomCases','prerequisites'}
rows=[]
for identity in sorted(set(maps[0])|set(maps[1])):
    left,right=[m.get(identity) for m in maps]
    if left is None:row=copy.deepcopy(right)
    elif right is None:row=copy.deepcopy(left)
    else:
        row={}
        for key in set(left)|set(right):
            if key in union_fields:row[key]=sorted(set(left.get(key,[]))|set(right.get(key,[])))
            elif key=='minimumCases':row[key]=max(left[key],right[key],len(set(left.get('expectedCases',[]))|set(right.get('expectedCases',[]))))
            else:
                assert left.get(key)==right.get(key),(identity,key)
                row[key]=left.get(key)
    rows.append(row)
result['suites']=rows
(TREE/path).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf8')
git('add',path)
assert not git('ls-files','-u')
git('diff','--cached','--check')
assert next(r for r in rows if r['id']=='latent-wasmtime.test.aot-sandbox')['minimumCases']==1
for parent in (o,t):
    for old in parent['suites']:
        new=next(r for r in rows if r['id']==old['id'])
        assert old['minimumCases']<=new['minimumCases']
        for key in union_fields:assert set(old.get(key,[]))<=set(new.get(key,[]))
git('commit','-m','merge current command-completion peer while preserving SDK protocol repair')
head=git('rev-parse','HEAD').decode().strip()
changed=git('diff','--name-only',OURS,head).decode().splitlines()
assert set(changed)<= {'tools/ci/suites.json'},changed
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=811,head=head,ours=OURS,peer=PEER,tree=str(TREE),
           virtualBaseWasConflicted=True,rawThreeStagesRetained=True,allRealParentCasesFloorsIgnoresPrerequisitesPreserved=True,
           currentProtocolDescriptorAndVectorFixUnchanged=True,noProductionChangeFromOwnedRepair=True,
           sourceAndCurrentNativePending=True,noPublication=True)
(OUT/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
