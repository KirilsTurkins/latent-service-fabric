import ast
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path(r'C:\Users\turkins\Desktop\lf-p4-sdk784-ownership-20261007-v3')
COORD = pathlib.Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination')
OUT = COORD / 'portable-v2-pr784-ownership-proof-20261007-v3'
QUALIFIED = '7758fcd0742ceec2a3dd1a1499f5f6c99c46e550'
ORIGINAL = 'd751e8c4b3f831029cd3ff48548f5f4587668805'
SOURCE = 'tools/check_rust_capsule_ownership.py'
PATCH = [SOURCE, 'tools/tests/test_rust_ownership_profile.py', 'tools/ci/contracts/python/test_rust_ownership_profile.py.json']

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def constants(tree):
    return {node.targets[0].id: ast.literal_eval(node.value) for node in tree.body
            if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in {'PRELUDE', 'POSITIVE', 'CASES'}}

def main():
    OUT.mkdir(exist_ok=True)
    assert git('status', '--porcelain', '--', SOURCE).decode() == ''
    assert len(git('diff', '--name-only', QUALIFIED + '^', QUALIFIED).decode().splitlines()) == 3
    blobs = []
    for rel in PATCH:
        current, qualified = git('show', ':' + rel), git('show', QUALIFIED + ':' + rel)
        assert current == qualified, rel
        blobs.append({'path': rel, 'sha256': hashlib.sha256(current).hexdigest(), 'bytes': len(current), 'qualifiedBlobExact': True})
    before = ast.parse(git('show', ORIGINAL + ':' + SOURCE))
    selected = ast.parse(git('show', ':' + SOURCE))
    old, new = constants(before), constants(selected)
    assert old == new and len(new['CASES']) == 19
    old_check = next(node for node in before.body if isinstance(node, ast.FunctionDef) and node.name == 'check')
    new_check = next(node for node in selected.body if isinstance(node, ast.FunctionDef) and node.name == 'check')
    calls = [node for node in new_check.body if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and getattr(node.value.func, 'id', '') == 'select_transaction_types']
    assert len(calls) == 1 and ast.unparse(calls[0]) == 'select_transaction_types(project)'
    new_check.body.remove(calls[0])
    assert ast.dump(old_check) == ast.dump(new_check), 'original bodies, compiler diagnostics, exit codes, bounds or cleanup changed'
    native_dir = COORD / 'root-rust-ownership-native-20261007-v2'
    native_raw = (native_dir / 'receipt.json').read_bytes()
    native = json.loads(native_raw)
    assert native['head'] == QUALIFIED and native['passed'] and native['sourceClean'] and native['sourceHeadUnchanged'] and native['originalProcessReaped']
    log_raw = (native_dir / 'step-1.log').read_bytes()
    assert hashlib.sha256(log_raw).hexdigest() == native['steps'][0]['sha256']
    receipts = [json.loads(line) for line in log_raw.splitlines() if line.startswith(b'{')]
    actual = next(row for row in receipts if row.get('schemaVersion') == 'latent.rust-capsule.ownership.v1')
    expected = []
    for name, (diagnostic, body) in {'valid-ownership': (None, new['POSITIVE']), **new['CASES']}.items():
        raw = (new['PRELUDE'] + body + '\n').encode()
        expected.append({'name': name, 'sourceDigest': 'sha256:' + hashlib.sha256(raw).hexdigest(), 'expectedDiagnostic': diagnostic, 'exitCode': 0 if diagnostic is None else 101, 'observedDiagnostics': [] if diagnostic is None else [diagnostic]})
    assert actual['cases'] == expected, 'candidate case byte or exact refusal differs from actual qualified twenty-case receipt'
    differences = git('diff', '--name-only', QUALIFIED, '--', 'sdk/rust-guest', 'crates/latent-component-bindings', 'tools/rust_capsule_project.py', 'tools/rust_capsule_build.py', 'tools/build_snapshot.py', 'wit').decode().splitlines()
    assert differences == ['crates/latent-component-bindings/build.rs', 'crates/latent-component-bindings/src/lib.rs', 'tools/build_snapshot.py'], differences
    assert ast.dump(ast.parse(git('show', QUALIFIED + ':tools/build_snapshot.py'))) == ast.dump(ast.parse(git('show', ':tools/build_snapshot.py')))
    old_build = git('show', QUALIFIED + ':crates/latent-component-bindings/build.rs').decode()
    new_build = git('show', ':crates/latent-component-bindings/build.rs').decode()
    host_start = old_build.index('    fs::write(\n        output.join("transaction_host.rs"),')
    guest_start = old_build.index('    fs::write(\n        output.join("transaction_guest.rs"),', host_start)
    assert old_build[:host_start] + old_build[guest_start:] == new_build, 'another generator input changed'
    old_lib = git('show', QUALIFIED + ':crates/latent-component-bindings/src/lib.rs').decode()
    new_lib = git('show', ':crates/latent-component-bindings/src/lib.rs').decode()
    host_module = '''    /// Phase 4 resource types install no storage or transaction authority.
    pub mod transaction {
        include!(concat!(env!("OUT_DIR"), "/transaction_host.rs"));
    }

'''
    assert old_lib.count(host_module) == 1 and old_lib.replace(host_module, '') == new_lib
    assert '#[cfg(not(target_arch = "wasm32"))]\npub mod host {' in old_lib
    receipt = {
        'originalPrHead': ORIGINAL, 'qualifiedCheckerHead': QUALIFIED,
        'candidateHead': git('rev-parse', 'HEAD').decode().strip(),
        'candidateCheckerAndTestsExact': blobs, 'positiveAnd19NegativeSourcesAndExactDiagnostics': expected,
        'qualifiedNativeReceiptSha256': hashlib.sha256(native_raw).hexdigest(),
        'qualifiedNativeCaseLogSha256': hashlib.sha256(log_raw).hexdigest(),
        'originalCheckAddsOnlyManifestSelection': True, 'overallSeconds': 360,
        'maximumPerCaseSeconds': 180, 'maximumOutputBytes': 4 * 1024 * 1024,
        'knownCandidateInputDifferences': differences,
        'guestGeneratorBytesAndWasmModuleExact': True,
        'inputDifferenceReview': 'The candidate omits the qualified base host-only transaction_host generation/module; guest/WIT/SDK bytes are unchanged. build_snapshot differs only by two stale comments; Python AST is identical. Current full candidate Native/CI is not inferred from the historical compiler case receipt.',
        'currentCandidateNativeExecuted': False, 'completeCI': False,
    }
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'ownedActualCasesByteEquivalent': len(expected), 'exactPatchedPaths': len(blobs), 'boundsUnchanged': True, 'currentCandidateNativeExecuted': False}))

if __name__ == '__main__':
    main()
