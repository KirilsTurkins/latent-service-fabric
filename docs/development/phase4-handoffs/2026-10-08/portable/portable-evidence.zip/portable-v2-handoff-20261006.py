"""Retain exact current-head custody and a concise handoff for Root."""
from datetime import datetime, timezone
import base64
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-common-braces-runtime-20261006")
COORD = Path(__file__).resolve().parent
HEAD = "2298d9dd437b9c54aa9b524ddcd65348dc1428b5"
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=30).decode().strip()
assert git("rev-parse", "HEAD") == HEAD and not git("status", "--porcelain")
paths = git("diff", "--name-only", "HEAD^", "HEAD").splitlines()
assert set(paths) == {".github/security/inventory.json", "website/package-lock.json", "website/toolchain/package-lock.json", "website/toolchain/tests/test_prepare.py"}
receipt_file = COORD / "portable-v2-repaired-source-20261006-v1/receipt.json"
receipt = json.loads(receipt_file.read_bytes())
assert receipt["head"] == HEAD and receipt["tree"] == git("show", "-s", "--format=%T", "HEAD")
assert receipt["passed"] and receipt["sourceClean"] and receipt["sourceHeadUnchanged"] and receipt["originalProcessReaped"]
scan = json.loads((receipt_file.parent / "step-6.log").read_bytes())
assert scan["status"] == "pass" and scan["finding_count"] == 0
archive_path = ROOT / "target/website-package-manager/npm-11.19.1-lsf-bundle-v4.tar"
raw = archive_path.read_bytes()
locked = json.loads((ROOT / "website/toolchain/package-lock.json").read_bytes())["packages"]["node_modules/npm"]["integrity"]
integrity = "sha512-" + base64.b64encode(hashlib.sha512(raw).digest()).decode()
assert integrity == locked
handoff = {"at": datetime.now(timezone.utc).isoformat(), "root": str(ROOT), "head": HEAD,
           "tree": receipt["tree"], "base": git("rev-parse", "HEAD^"), "branch": git("branch", "--show-current"),
           "pr": 841, "url": "https://github.com/KirilsTurkins/latent-service-fabric/pull/841", "paths": paths,
           "sourceReceipt": str(receipt_file), "sourceReceiptSha256": hashlib.sha256(receipt_file.read_bytes()).hexdigest(),
           "linuxTestsPassed": 142, "linuxTestsSkipped": 0, "dependencyScanFindings": 0,
           "sourceClean": True, "completeCI": False, "heavyCargoStarted": False,
           "npmArchive": {"path": str(archive_path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "integrity": integrity, "matchesCurrentLock": True},
           "supersededPortableCommits": ["889d64dd7559f053568ad84562533a838fe30e3d", "31eaa513b7f940b4478cea6d03bcf9b79b40f64c"],
           "supersededCommitsPreservedOnBranch": "portable/common-web-v3-custody-20261006",
           "instruction": "Use current development's authenticated npm v4 implementation; do not reintroduce the superseded standalone v3 braces builder. Root can exact-head squash/admin merge PR 841 after all hosted checks pass and then remove this clean owned worktree.",
           "root32MiBConstraint": {"sourceBytesAtCurrentMain": 33737051, "overageBytes": 182619, "archiveBytes": 37877760, "productionLimitsChanged": False}}
output = COORD / "portable-v2-handoff-20261006.json"
assert not output.exists()
output.write_text(json.dumps(handoff, indent=2) + "\n", encoding="utf8")
print(json.dumps(handoff), flush=True)
