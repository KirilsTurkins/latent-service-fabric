import concurrent.futures
import json
import pathlib
import subprocess

COORD = pathlib.Path(__file__).resolve().parent
OUT = COORD / 'portable-v2-pr-historical-green-audit-20261007-v1'
records = json.loads((OUT / 'receipt.json').read_bytes())['records']
shas = sorted({sha for record in records for sha in record['historicalSuccessfulAggregateHeads']})

def read(sha):
    raw = subprocess.check_output(['gh', 'api', f'repos/KirilsTurkins/latent-service-fabric/commits/{sha}/check-runs?per_page=100'], cwd=COORD, timeout=120)
    (OUT / (sha + '-checks.json')).write_bytes(raw)
    body = json.loads(raw)
    checks = body['check_runs']
    return sha, {'checkCount': body['total_count'], 'names': [check['name'] for check in checks],
                 'ciResultSucceeded': any(check['name'] == 'CI result' and check['conclusion'] == 'success' for check in checks),
                 'nativeCandidateSucceeded': any(check['name'] == 'Exact-source native Linux candidate' and check['conclusion'] == 'success' for check in checks),
                 'associatedPullRequests': sorted({pr['number'] for check in checks for pr in check['pull_requests']}),
                 'allCheckRunsCompletedSuccessOrSkip': bool(checks) and all(check['status'] == 'completed' and check['conclusion'] in {'success', 'skipped', 'neutral'} for check in checks)}

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    details = dict(pool.map(read, shas))
review = []
for record in records:
    for sha in record['historicalSuccessfulAggregateHeads']:
        proof = details[sha]
        review.append({'number': record['number'], 'head': sha, **proof,
                       'wasAssociatedWithThisPr': record['number'] in proof['associatedPullRequests'],
                       'shortcutEligible': False,
                       'boundary': 'Current changes include functional binding, ownership or runtime repairs and latest Go support, rather than only a previously qualified simple conflict resolution. Exact original full-check/PR-head lineage remains required.'})
(OUT / 'detailed-review.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
print(json.dumps([{key: row[key] for key in ('number', 'head', 'checkCount', 'ciResultSucceeded', 'nativeCandidateSucceeded', 'wasAssociatedWithThisPr', 'allCheckRunsCompletedSuccessOrSkip', 'shortcutEligible')} for row in review], indent=2))
