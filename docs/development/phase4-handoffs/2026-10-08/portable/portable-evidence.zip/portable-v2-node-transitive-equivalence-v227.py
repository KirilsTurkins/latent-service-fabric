from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
heads={n:json.loads((COORD/('portable-v2-pr'+str(n)+'-website-main-union-v224.json')).read_bytes())['head'] for n in (790,800,791,787,796,784,825)}
def tracked(head):
    raw=subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r','-z',head])
    return {entry.split(b'\t',1)[1].decode():entry.split(b'\t',1)[0].decode().split()[2] for entry in raw.split(b'\0') if entry}
material={}
for number,head in heads.items():
    all_files=tracked(head)
    filtered={p:h for p,h in all_files.items() if p.startswith(('crates/','api/','wit/')) or p in ('Cargo.toml','Cargo.lock','rust-toolchain.toml')}
    material[number]=filtered
groups={}
for number,files in material.items():
    encoded=json.dumps(files,sort_keys=True,separators=(',',':')).encode()
    key=hashlib.sha256(encoded).hexdigest()
    groups.setdefault(key,[]).append(number)
baseline=material[800]
differences={number:[p for p in sorted(set(baseline)|set(files)) if baseline.get(p)!=files.get(p)] for number,files in material.items()}
proof=dict(at=datetime.now(timezone.utc).isoformat(),heads=heads,strictAllRustApiWitLockClosureGroups=groups,
           differencesFrom800=differences,noNativeReuseClaim=True)
(COORD/'portable-v2-node-transitive-equivalence-v227.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(groups=groups,differenceCounts={n:len(d) for n,d in differences.items()}),indent=2))
