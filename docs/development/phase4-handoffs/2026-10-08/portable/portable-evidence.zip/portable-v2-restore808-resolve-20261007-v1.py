import hashlib
import json
import pathlib
import re
import subprocess
import os

ROOT = pathlib.Path(r'C:\Users\turkins\Desktop\lf-p4-restore808-review-entity-v9-20261006')
CUSTODY = pathlib.Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination\portable-v2-restore808-review-20261007-v1')
PEER = 'ce764ab44c744b7dad0c9b56bb2ea0451bdf8115'
QUALIFIED = '0e0162f71127bfbd2a88e848f153f4c64c134e83'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def write(rel, text):
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())

def normalized(path):
    return path.read_bytes().decode().replace('\r\n', '\n')

def stage(number, rel):
    return normalized(CUSTODY / ('stage-' + str(number)) / rel)

def resolve(rel, choices):
    original = normalized(CUSTODY / 'original' / rel)
    blocks = list(re.finditer(r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n', original, re.M | re.S))
    assert len(blocks) == len(choices), (rel, len(blocks), len(choices))
    result, cursor = [], 0
    for block, choice in zip(blocks, choices):
        result.append(original[cursor:block.start()])
        if choice == 'peer':
            result.append(block[1])
        elif choice == 'qualified':
            result.append(block[2])
        elif choice == 'both-methods':
            result.append(block[1] + '    }\n\n' + block[2])
        elif choice == 'both-tests':
            result.append(block[1] + '}\n\n' + block[2])
        elif choice == 'both':
            result.append(block[1] + block[2])
        else:
            raise AssertionError(choice)
        cursor = block.end()
    result.append(original[cursor:])
    write(rel, ''.join(result))

def legacy_profiles():
    files = git('ls-tree', '-r', '--name-only', PEER, '--', 'crates/latent-state/src/recovery').decode().splitlines()
    selected = [rel for rel in files if any(rel == f'crates/latent-state/src/recovery/{name}.rs' or rel.startswith(f'crates/latent-state/src/recovery/{name}/') for name in ('migration', 'restore', 'resume', 'snapshot', 'offline'))]
    mapping = []
    for rel in selected:
        old = pathlib.Path(rel)
        new = pathlib.Path('crates/latent-state/src/recovery/v1') / old.relative_to('crates/latent-state/src/recovery')
        data = git('show', f'{PEER}:{rel}').decode().replace('\r\n', '\n')
        # Only source/module references change. Wire identities, limits, bodies,
        # reviewed recipe bytes and all test conditions remain version-specific.
        data = re.sub(r'\brecovery::(?=(?:migration|restore|resume|snapshot|offline)(?:::|\b))', 'recovery::v1::', data)
        data = re.sub(r'\brecovery::\{', 'recovery::v1::{', data)
        def include(match):
            target = (ROOT / old.parent / match[1]).resolve()
            assert target.is_file(), (rel, target)
            replacement = os.path.relpath(target, ROOT / new.parent).replace('\\', '/')
            return 'include_bytes!("' + replacement + '"'
        data = re.sub(r'include_bytes!\("([^"\n]+)"', include, data)
        write(new.as_posix(), data)
        mapping.append({'original': rel, 'adapter': new.as_posix(), 'originalBlob': git('rev-parse', f'{PEER}:{rel}').decode().strip()})
    # The peer facade retains its public address through this re-export. Its
    # version-specific plans use the SAME store owner and fixed I/O workers.
    for rel in selected:
        if '/offline' in rel:
            (ROOT / rel).unlink(missing_ok=True)
    write('crates/latent-state/src/recovery/v1.rs', '''//! Explicit original offline-snapshot/v1 recovery profile.
//!
//! Retained v1 bytes are never relabelled as protected snapshot/v2, migration/v2
//! or migration-resume/v1. This adapter preserves original decoding and logical
//! plans; its offline facade uses the same ProtectedStoreOwner and fixed workers.
//! Descriptions and historical grants do not establish current authority.

pub mod migration;
#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
pub mod offline;
pub mod restore;
pub mod resume;
pub mod snapshot;

pub use super::{guard_key, require_namespace_ready, require_ready, RecoveryGuard, RecoveryStatus};
''')
    (CUSTODY / 'legacy-path-map.json').write_text(json.dumps(mapping, indent=2) + '\n', encoding='utf-8')
    # Preserve all qualified module bytes at their existing public locations.
    for name in ('migration', 'restore', 'resume', 'snapshot'):
        rel = f'crates/latent-state/src/recovery/{name}.rs'
        write(rel, git('show', f'{QUALIFIED}:{rel}').decode().replace('\r\n', '\n'))
        qualified_files = git('ls-tree', '-r', '--name-only', QUALIFIED, '--', f'crates/latent-state/src/recovery/{name}').decode().splitlines()
        for child in qualified_files:
            write(child, git('show', f'{QUALIFIED}:{child}').decode().replace('\r\n', '\n'))
    common = git('show', f'{QUALIFIED}:crates/latent-state/src/recovery.rs').decode()
    common = common.replace('pub mod snapshot;\n', 'pub mod snapshot;\npub mod v1;\n#[cfg(all(target_os = "linux", target_arch = "x86_64"))]\npub use v1::offline;\n', 1)
    write('crates/latent-state/src/recovery.rs', common)

def unified_view():
    rel = 'crates/latent-state/src/protected_store/view.rs'
    data = stage(2, rel)
    changes = [
        ('    retained: StoreIoRetained<OnceLock<PhysicalStore>, RetainedReadView>,\n', '    retained: StoreIoRetained<OnceLock<PhysicalStore>, RetainedReadView>,\n    recovery: bool,\n'),
        ('self.open_view_inner(false, None)', 'self.open_view_inner(false, false, None)'),
        ('self.open_view_inner(false, Some(Box::new(owner)))', 'self.open_view_inner(false, false, Some(Box::new(owner)))'),
        ('self.open_view_inner(true, owner)', 'self.open_view_inner(true, false, owner)'),
        ('        observed: bool,\n        owner:', '        observed: bool,\n        recovery: bool,\n        owner:'),
        ('''        let mut retained = self
            .ready
            .reserve_retained::<RetainedReadView>(8192)
            .map_err(ProtectedStoreError::Io)?;''', '''        let mut retained = if recovery {
            self.ready.reserve_recovery_retained::<RetainedReadView>(8192)
        } else {
            self.ready.reserve_retained::<RetainedReadView>(8192)
        }
        .map_err(ProtectedStoreError::Io)?;'''),
        ('.submit(StoreIoKind::Read, 0, move |store| {', '.submit(\n                if recovery { StoreIoKind::RecoveryRead } else { StoreIoKind::Read },\n                0, move |store| {'),
        ('Ok(ProtectedStoreView { retained })', 'Ok(ProtectedStoreView { retained, recovery })'),
        ('.submit(StoreIoKind::Read, retained_payload_bytes, move |store| {', '.submit(\n                if view.recovery { StoreIoKind::RecoveryRead } else { StoreIoKind::Read },\n                retained_payload_bytes, move |store| {'),
    ]
    for old, new in changes:
        assert data.count(old) == 1, old
        data = data.replace(old, new, 1)
    anchor = '    /// Issue the single native retirement observer before accepting an open.\n'
    addition = '''    /// Authenticated recovery retains its admitted keeper inside the SAME
    /// affine native view, using the existing reserved I/O/retirement partition.
    /// The native snapshot drops before the original owner on the fixed worker.
    pub fn open_recovery_view_retaining<T: Send + 'static>(
        &self,
        owner: T,
    ) -> Result<ProtectedViewOpenJob, ProtectedStoreError> {
        self.open_view_inner(false, true, Some(Box::new(owner)))
            .map(|(job, _)| job)
    }

'''
    assert data.count(anchor) == 1
    data = data.replace(anchor, addition + anchor)
    write(rel, data)

def main():
    assert git('rev-parse', 'HEAD').decode().strip() == PEER
    assert git('rev-parse', 'MERGE_HEAD').decode().strip() == QUALIFIED
    choices = {
        'Cargo.lock': ['peer'],
        'crates/latent-state/Cargo.toml': ['peer'],
        'crates/latent-state/src/embedded.rs': ['qualified'],
        'crates/latent-state/src/lib.rs': ['both'],
        'crates/latent-state/src/namespace/catalog.rs': ['qualified'],
        'crates/latent-state/src/protected_store.rs': ['peer'],
        'crates/latent-state/src/protected_store/physical.rs': ['both', 'both'],
        'crates/latent-state/src/protected_store/tests.rs': ['both'],
        'crates/latent-state/src/protected_store/tests/reserved.rs': ['both-tests'],
        'crates/latent-state/src/session/mod.rs': ['both', 'qualified', 'qualified'],
        'crates/latent-state/src/session/tests.rs': ['qualified', 'peer'],
        'crates/latent-state/src/session/tests/history.rs': ['qualified'],
        'crates/latent-state/src/store_io/startup.rs': ['both-methods'],
        'crates/latent-protected-files/src/rooted.rs': ['both', 'peer', 'peer'],
    }
    for rel, selections in choices.items():
        resolve(rel, selections)
    write('crates/latent-state/src/namespace/compatibility.rs', stage(3, 'crates/latent-state/src/namespace/compatibility.rs'))
    legacy_profiles()
    unified_view()
    print(json.dumps({'resolvedCommon': len(choices) + 1, 'versionedAdapter': True, 'remainingCustom': ['protected_store/view.rs', 'tools/ci/suites.json'], 'published': False}))

if __name__ == '__main__':
    main()
