from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
HEAD='3a991d9922390edb3251c84aa8f926a717687d0b'
OWNER='latent-p4-root-native-20261007-v6'
BASE='/var/lib/docker/volumes/'+OWNER+'/_data'
JOB='portable-v2-dotnet-lock-native-reproduction-20261008-v262'
OUT=COORD/JOB
assert not OUT.exists()
OUT.mkdir()
SOURCE=OUT/'source';SOURCE.mkdir()
old=json.loads(subprocess.check_output(['git','-C',str(REPO),'show',HEAD+':sdk/dotnet/protobuf.lock.json']))
paths=['sdk/dotnet/protobuf.lock.json','sdk/dotnet/Latent.Sdk.Transport/Latent.Sdk.Transport.csproj',*['api/proto/'+p for p in old['inputs']]]
records=[]
for path in paths:
    data=subprocess.check_output(['git','-C',str(REPO),'show',HEAD+':'+path]).replace(b'\r\n',b'\n')
    target=SOURCE/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    records.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
TOOLS=OUT/'pinned';TOOLS.mkdir()
host_tools=Path(r'C:\Users\turkins\.nuget\packages\grpc.tools\2.71.0\tools\linux_x64')
for name,expected in old['tools'].items():
    data=(host_tools/name).read_bytes();assert hashlib.sha256(data).hexdigest()==expected
    (TOOLS/name).write_bytes(data)
runner=r'''
from datetime import datetime,timezone
import hashlib,json,os,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(SOURCE_LITERAL);out=root.parent;tools=out/'pinned'
assert os.getuid()==10001 and os.getgid()==10001
old=json.loads((root/'sdk/dotnet/protobuf.lock.json').read_bytes())
for name,expected in old['tools'].items():
    assert hashlib.sha256((tools/name).read_bytes()).hexdigest()==expected
    (tools/name).chmod(0o700)
version=subprocess.check_output([str(tools/'protoc'),'--version'],text=True,timeout=10).strip()
assert version=='libprotoc 29.0'
project=ET.parse(root/'sdk/dotnet/Latent.Sdk.Transport/Latent.Sdk.Transport.csproj')
protos=[]
for item in project.findall('.//Protobuf'):
    name=item.attrib['Include'].removeprefix('../../../api/proto/')
    assert name in old['inputs'] and item.attrib['Access']=='Internal' and item.attrib['GrpcServices'] in {'None','Client'}
    protos.append((name,item.attrib['GrpcServices']))
assert len(protos)==6 and {p for p,_ in protos}==set(old['inputs'])
outputs=[];commands=[]
for attempt in ('first','reproduction'):
    generated=out/attempt;generated.mkdir()
    for name,services in protos:
        destination=generated/Path(name).parent;destination.mkdir(parents=True,exist_ok=True)
        argv=[str(tools/'protoc'),'--proto_path='+str(root/'api/proto'),'--csharp_out='+str(destination),'--csharp_opt=internal_access']
        if services=='Client':
            argv+=['--grpc_out='+str(destination),'--grpc_opt=internal_access,no_server','--plugin=protoc-gen-grpc='+str(tools/'grpc_csharp_plugin')]
        argv.append(name)
        result=subprocess.run(argv,cwd=root/'api/proto',capture_output=True,timeout=15)
        assert len(result.stdout)+len(result.stderr)<=65536 and result.returncode==0
        commands.append(dict(attempt=attempt,argv=argv,returncode=result.returncode))
    files=sorted(generated.rglob('*.cs'))
    assert len(files)==10 and sum(p.stat().st_size for p in files)<10*1024**2
    outputs.append({p.relative_to(generated).as_posix():hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in files})
assert outputs[0]==outputs[1] and set(outputs[0])==set(old['outputs'])
new=dict(old)
new['inputs']={name:hashlib.sha256((root/'api/proto'/name).read_bytes()).hexdigest() for name in old['inputs']}
new['outputs']=outputs[0]
changed_inputs=[p for p in old['inputs'] if new['inputs'][p]!=old['inputs'][p]]
changed_outputs=[p for p in old['outputs'] if new['outputs'][p]!=old['outputs'][p]]
assert changed_inputs==['latent/control/v1/node.proto']
assert changed_outputs==['latent/control/v1/Node.cs']
(out/'protobuf.lock.json').write_text(json.dumps(new,indent=2)+'\n')
receipt=dict(at=datetime.now(timezone.utc).isoformat(),sourceHead=HEAD_LITERAL,toolHashes=old['tools'],protocVersion=version,
             commands=commands,reproductionsIdentical=True,generatedSources=10,changedInputs=changed_inputs,changedOutputs=changed_outputs,
             newLockSha256=hashlib.sha256((out/'protobuf.lock.json').read_bytes()).hexdigest(),msbuildExecuted=False,
             sdkRuntimeQualified=False,fullCI=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='commands'}))
'''.replace('SOURCE_LITERAL',repr(BASE+'/jobs/'+JOB+'/source')).replace('HEAD_LITERAL',repr(HEAD))
compile(runner,'runner.py','exec')
(OUT/'runner.py').write_text(runner,encoding='utf8')
guest=BASE+'/jobs/'+JOB
subprocess.run(['docker','exec',OWNER,'python3','-c','import os;from pathlib import Path;p=Path('+repr(guest)+');assert os.getuid()==10001 and not p.exists();p.mkdir(mode=0o700)'],check=True,timeout=30)
for name in ('source','pinned','runner.py'):
    subprocess.run(['docker','cp',str(OUT/name),OWNER+':'+guest+'/'+name],check=True,timeout=30)
ownership = "from pathlib import Path;import os;p=Path("+repr(guest)+");assert p.is_dir() and not p.is_symlink();xs=[p,*p.rglob('*')];assert len(xs)<64 and all(not x.is_symlink() and x.resolve().is_relative_to(p.resolve()) for x in xs);[os.chown(x,10001,10001) for x in xs]"
subprocess.run(['docker','exec','--user','0',OWNER,'python3','-c',ownership],check=True,timeout=30)
result=subprocess.run(['docker','exec',OWNER,'python3','-X','utf8','-B',guest+'/runner.py'],capture_output=True,timeout=120)
(OUT/'native.stdout').write_bytes(result.stdout);(OUT/'native.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode('utf8')
for name in ('receipt.json','protobuf.lock.json'):
    subprocess.run(['docker','cp',OWNER+':'+guest+'/'+name,str(OUT/name)],check=True,timeout=30)
receipt=json.loads((OUT/'receipt.json').read_bytes())
assert receipt['sourceHead']==HEAD and receipt['reproductionsIdentical']
receipt['capturedSources']=records
(OUT/'host-custody.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(result.stdout.decode('utf8'))
