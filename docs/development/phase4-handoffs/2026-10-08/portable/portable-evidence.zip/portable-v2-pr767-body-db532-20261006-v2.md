Select exact-pinned redb 4.3.0 for the bounded shared state, command and outbox store. Accepted ADR-0063 compares SQLite and records the locking, flush, backup, recovery, format, worker, queue, handle and snapshot decisions. The engine prototype, durability and process-crash qualification sources remain behind the shared store boundaries.

This head merges development `db532ce3` and retains the authorized 64 MiB source capture budget, separate 72 MiB archive/process allowance, and unchanged file, directory and per-file bounds. It inherits the current shell-quote 1.12.0 dependency repair, maintained authenticated npm v4 preparation, active phase3-v5 runtime identity and immutable historical descriptor versions. Nine CI contract JSON conflicts preserve all 128 parent cases, every decorator/skip/nonhash fixture guard, artifact control, deadline and historical mapping. The stronger state/full-renderer and proper narrow-profile assertions remain in the workflow.

Validation of `c99365fce5309f5dc215ff1b1d2dcba37e94478d`:

- All six bounded Linux Source steps pass: 293 discovered cases, 291 pass and two unchanged platform skips, including all 17 package-manager fixtures.
- CI coverage retains 88 historical obligations, 262 current run blocks and 140 delegated owners. Repository validation and documentation validation pass with 1,068 current documents, 548 versioned documents and 26 SVGs. The fresh dependency scan reports zero findings, zero exceptions and two verified source remediations.
- Rust formatting and locked offline Cargo metadata pass; the 51-member workspace retains exact `redb =4.3.0`. The exact source checkout stays clean, and commit/tree/log identities and process retirement are retained within the original 1,800-second Source campaign.
- The remaining Rust delta against current development is the existing test currentness read-fence fixture and its exclusive-writer contention assertion; production storage engine source is already present in development.
- Exact-head native admission checks pass all 16 actual cases: 10 in Wasmtime's admission integration target and six in control-store's `deployments::tests::supply_chain` library filter. Both original processes are reaped, their source stays clean and the head remains unchanged.

Earlier engine/native/crash receipts remain tied to their recorded commits. Current-head hosted CI and final #381 acceptance reconciliation remain required before merge or issue closure. The earlier Windows documentation observer timeout and incorrect control-store integration-target attempt are preserved independently as setup/observer failures; neither is relabelled as success or a product failure. Focused native success does not establish complete CI.

Refs #381.
