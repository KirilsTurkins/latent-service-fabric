﻿from pathlib import Path
import hashlib,json,shutil,subprocess,sys
coord=Path(r'C:\Users\turkins\Desktop\latent-phase4-coordination');repo=Path(r'C:\Users\turkins\Desktop\lf-p4-http-deferred-admission-v96');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,timeout=30).decode().strip()
assert head=='c7663996caa7722cd2a9ccc298f656e6c27a01e5' and not subprocess.check_output(['git','status','--porcelain'],cwd=repo,timeout=30)
p=coord/'portable-v2-http-retirement-fixture-source-20261007-v106/receipt.json';source=json.loads(p.read_bytes());assert source['head']==head and source['passed'] and source['originalProcessReaped'] and source['sourceClean'] and source['sourceHeadUnchanged']
for row in source['steps']:
 data=(p.parent/row['log']).read_bytes();assert row['exitCode']==0 and row['stopReason'] is None and row['originalProcessReaped'] and hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes']
released=json.loads((coord/'root-installed-recovery-rpc-native-20261007-v1/receipt.json').read_bytes());assert released['originalProcessReaped'] and released['sourceClean'] and released['sourceHeadUnchanged']
stepfile=coord/'portable-v2-http-corrected-native-steps-20261007-v107.json';assert hashlib.sha256(stepfile.read_bytes()).hexdigest()=='59407beba4db5de129526453b0661b7a2eefe175eeb22a79c17036366d2299b0'
assert shutil.disk_usage(coord).free>2*1024**3
print(json.dumps(dict(head=head,sourceReceiptSha256=hashlib.sha256(p.read_bytes()).hexdigest(),rootRpcOriginalProcessReaped=True,freeHostBytes=shutil.disk_usage(coord).free,stepsFile=str(stepfile))),flush=True)
raise SystemExit(subprocess.call([sys.executable,'-X','utf8','-B',str(coord/'portable-v2-reconstructed-native-controller-20261007-v93.py'),'portable-v2-http-corrected-native-20261007-v107',head,str(stepfile),'native']))
