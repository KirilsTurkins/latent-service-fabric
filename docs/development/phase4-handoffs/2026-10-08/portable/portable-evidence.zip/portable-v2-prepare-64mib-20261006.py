"""Review only the user-authorized source/archive ceilings and their exact guards."""
from dataclasses import asdict
from datetime import datetime, timezone
import ast
import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-common-ci-history-20261006")
OUT = Path(__file__).resolve().parent / "portable-v2-source-64mib-preparation-20261006-v1"
BASE = "3d77ab9e77849c1061ae9480902f262ac3975857"
PATHS = {"docs/reference/build-provenance.md", "tools/build_snapshot.py", "tools/build_process.py",
         "tools/tests/test_build_snapshot.py", "tools/tests/test_build_process.py"}
sys.path.insert(0, str(ROOT))
from tools import ci_contracts as contracts
from tools import ci_coverage
from tools.build_snapshot import SOURCE_ALLOWLIST, SnapshotLimits, portable_path
from tools.build_process import MAX_OUTPUT_BYTES

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=60)
assert git("rev-parse", "HEAD").decode().strip() == BASE
assert set(git("diff", "--name-only").decode().splitlines()) == PATHS
assert not git("diff", "--cached", "--name-only").strip()
assert git("show", BASE + ":tools/ci/history/commands-v1.json") == (ROOT / "tools/ci/history/commands-v1.json").read_bytes().replace(b"\r\n", b"\n")
assert not (ROOT / "tools/ci/history/commands-v1.json.gz").exists()
limits = SnapshotLimits()
assert limits.max_total_bytes == 64 * 1024 * 1024 and limits.max_archive_bytes == 72 * 1024 * 1024
assert limits.max_file_bytes == 4 * 1024 * 1024 and limits.max_entries == 8192 and limits.max_directories == 4096
assert MAX_OUTPUT_BYTES == limits.max_archive_bytes
limits.validate()
OUT.mkdir()
before = {}
for path in PATHS:
    previous = git("show", BASE + ":" + path)
    before[path] = previous
    custody = OUT / "before" / path
    custody.parent.mkdir(parents=True, exist_ok=True)
    custody.write_bytes(previous)

def cases(raw):
    return {cls.name + "." + node.name: node for cls in ast.parse(raw).body if isinstance(cls, ast.ClassDef)
            for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}

observed = contracts.python_expectations(ROOT)
guard_reviews = []
for module in ["tools/tests/test_build_snapshot.py", "tools/tests/test_build_process.py"]:
    old_cases, actual_cases = cases(before[module]), cases((ROOT / module).read_bytes())
    assert set(old_cases) <= set(actual_cases)
    for name, old in old_cases.items():
        new = copy.deepcopy(actual_cases[name])
        if name == "BuildSnapshotTests.test_archive_entry_file_and_aggregate_ceilings":
            replacement_count = 0
            for node in ast.walk(new):
                if isinstance(node, ast.Constant) and type(node.value) is int and node.value in {64, 72}:
                    node.value = {64: 48, 72: 56}[node.value]
                    replacement_count += 1
            assert replacement_count == 4
            addition = [node for node in new.body if ast.dump(node) == ast.dump(ast.parse("SnapshotLimits().validate()").body[0])]
            assert len(addition) == 1
            new.body.remove(addition[0])
        assert ast.dump(old, include_attributes=False) == ast.dump(new, include_attributes=False), name
    relative = "tools/ci/contracts/python/" + Path(module).name + ".json"
    old = contracts.semantic_record(json.loads(git("show", BASE + ":" + relative)))
    actual = observed[module]
    assert set(old["cases"]) <= set(actual["cases"])
    for case in old["cases"]:
        assert old["guards"][case] == actual["guards"][case], (module, case)
    result = copy.deepcopy(old)
    result.update(actual)
    result["reviewReason"] += " User explicitly authorizes 64 MiB source files and separately bounded 72 MiB archives; retain all existing cases, per-file/entry/directory limits, exact aggregate-overflow checks and skip/decorator guards. Add an actual process-reader check for the archive allowance; one byte beyond either hard budget remains rejected."
    stored = contracts.shared_python_record(result)
    assert contracts.semantic_record(stored) == result
    (ROOT / relative).write_text(contracts.shared_python_text(stored), encoding="utf8", newline="\n")
    PATHS.add(relative)
    guard_reviews.append({"module": module, "beforeCases": len(old_cases), "afterCases": len(actual_cases),
                          "newCases": sorted(set(actual_cases) - set(old_cases)), "allExistingExecutionGuardsUnchanged": True})

owners = ci_coverage.delegated_owners(ROOT, ci_coverage.commands(ROOT))
owner_reviews = []
for name in ["tools/build_snapshot.py", "tools/build_process.py"]:
    if name not in owners:
        continue
    relative = "tools/ci/contracts/owners/" + name + ".json"
    value = json.loads(git("show", BASE + ":" + relative))
    previous = value["sha256"]
    assert previous == hashlib.sha256(before[name]).hexdigest()
    value["sha256"] = hashlib.sha256((ROOT / name).read_bytes().replace(b"\r\n", b"\n")).hexdigest()
    value["reviewReason"] += " User-authorized 64 MiB source / 72 MiB encoded archive ceilings; all lower independent caller and snapshot bounds remain enforced."
    (ROOT / relative).write_text(json.dumps(value, indent=2) + "\n", encoding="utf8", newline="\n")
    PATHS.add(relative)
    owner_reviews.append({"path": relative, "before": previous, "after": value["sha256"]})
subprocess.run(["git", "add", "--", *sorted(PATHS)], cwd=ROOT, check=True)
subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, check=True)
tree = git("write-tree").decode().strip()
rows, directories, roots = [], set(), set()
for raw in git("ls-tree", "-r", "-z", "--long", tree, "--", *SOURCE_ALLOWLIST).split(b"\0"):
    if not raw:
        continue
    metadata, path = raw.split(b"\t", 1)
    mode, kind, oid, size = metadata.split()
    assert kind == b"blob" and mode in {b"100644", b"100755"}
    path = portable_path(path.decode("ascii"))
    size = int(size)
    assert size <= limits.max_file_bytes
    rows.append({"path": path, "bytes": size})
    directories.update(str(parent) for parent in PurePosixPath(path).parents if str(parent) != ".")
    roots.update(root for root in SOURCE_ALLOWLIST if path == root or path.startswith(root + "/"))
total = sum(row["bytes"] for row in rows)
assert total <= limits.max_total_bytes and len(rows) <= limits.max_entries and len(directories) <= limits.max_directories
archive = OUT / ("source-" + tree[:16] + ".tar")
subprocess.run(["git", "archive", "--format=tar", "--output=" + str(archive), tree, "--", *sorted(roots)], cwd=ROOT,
               check=True, capture_output=True, timeout=60)
assert archive.stat().st_size <= limits.max_archive_bytes
with tarfile.open(archive, "r:") as reader:
    assert {item.name: item.size for item in reader if item.isfile()} == {row["path"]: row["bytes"] for row in rows}
with archive.open("rb") as reader:
    archive_sha = hashlib.file_digest(reader, "sha256").hexdigest()
receipt = {"at": datetime.now(timezone.utc).isoformat(), "base": BASE, "tree": tree, "paths": sorted(PATHS),
           "limits": asdict(limits), "processMaximumOutputBytes": MAX_OUTPUT_BYTES, "archiveFramingHeadroomBytes": 8 * 1024 * 1024,
           "sourceFiles": len(rows), "sourceDirectories": len(directories), "sourceBytes": total,
           "sourceHeadroomBytes": limits.max_total_bytes - total, "archiveBytes": archive.stat().st_size,
           "archiveHeadroomBytes": limits.max_archive_bytes - archive.stat().st_size, "archiveSha256": archive_sha,
           "guardReviews": guard_reviews, "ownerReviews": owner_reviews,
           "historicalSourceBytesUnchanged": True, "jsonCompactionUsed": False, "gzipUsed": False,
           "completeCI": False, "qualified": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps(receipt), flush=True)
