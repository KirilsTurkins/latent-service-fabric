from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

COORD = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\turkins\Desktop\latent-fabric')
HEAD = '221645876350b9790d5255df588f0ce2ca728871'
PARENT = '6ab38845e5a266f38229416dc63fe57df471a40f'
blob = lambda path: subprocess.check_output(['git','-C',str(REPO),'show',f'{HEAD}:{path}'])
source = blob('crates/latent-control-store/src/deployments/tests/bindings/transaction_profile.rs')
assert source == subprocess.check_output(['git','-C',str(REPO),'show',f'{PARENT}:crates/latent-control-store/src/deployments/tests/bindings/transaction_profile.rs'])
suites = json.loads(blob('tools/ci/suites.json'))
def rows(value):
    if isinstance(value,dict):
        if value.get('id') == 'latent-control-store.lib.latent-control-store':
            yield value
        for item in value.values(): yield from rows(item)
    elif isinstance(value,list):
        for item in value: yield from rows(item)
registered = list(rows(suites))
assert len(registered) == 1
suite = registered[0]
assert len(suite['expectedCases']) == suite['minimumCases'] == 264
steps = [
 ['cargo','+1.97.1','test','-p','latent-control-store','--lib','--all-features','--locked','--offline','--','--list'],
 ['cargo','+1.97.1','test','-p','latent-control-store','--lib','--all-features','--locked','--offline','deployments::tests::bindings::transaction_profile::','--','--nocapture'],
 ['cargo','+1.97.1','test','-p','latent-control-store','--lib','--all-features','--locked','--offline','--','--nocapture'],
 ['cargo','+1.97.1','clippy','-p','latent-control-store','--all-targets','--all-features','--locked','--offline'],
]
step_file = COORD/'portable-v2-pr790-binding-native-steps-v212.json'
step_file.write_text(json.dumps(steps,indent=2)+'\n',encoding='utf8')
proof = dict(at=datetime.now(timezone.utc).isoformat(),head=HEAD,sourceReceipt=str(COORD/'portable-v2-pr790-binding-source-20261008-v208/receipt.json'),
             originalThreeBodiesByteIdentical=True,previousCIObservedCases=251,registeredCaseFloor=suite['minimumCases'],expectedCases=suite['expectedCases'],
             originalIgnores=suite.get('expectedIgnored',[]),steps=str(step_file),stepsSha256=hashlib.sha256(step_file.read_bytes()).hexdigest(),
             originalBoundsRetained=True,actualNativePending=True,noPublication=True)
(COORD/'portable-v2-pr790-binding-native-prepared-v212.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k not in ('expectedCases',)},indent=2))
