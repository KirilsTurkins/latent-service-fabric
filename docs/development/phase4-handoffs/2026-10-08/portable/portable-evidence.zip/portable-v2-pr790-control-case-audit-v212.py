import json
from pathlib import Path
import re
import subprocess

COORD = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\turkins\Desktop\latent-fabric')
HEAD = '221645876350b9790d5255df588f0ce2ca728871'
prepared = json.loads((COORD/'portable-v2-pr790-binding-native-prepared-v212.json').read_bytes())
directory = COORD/'portable-v2-pr790-durable-catalog-failure-v206'
logs = [p for p in directory.glob('*') if p.suffix in ('.log','.txt')]
assert logs
raw = max(logs,key=lambda p:p.stat().st_size).read_text(encoding='utf8')
raw = re.sub(r'\x1b\[[0-9;]*m','',raw)
start = raw.rfind('Running unittests src/lib.rs (target/debug/deps/latent_control_store')
assert start >= 0
section = raw[start:]
observed = sorted(set(re.findall(r'\btest ([\w:]+) \.\.\. (?:ok|FAILED|ignored)',section)))
missing = sorted(set(prepared['expectedCases']) - set(observed))
extra = sorted(set(observed) - set(prepared['expectedCases']))
paths = subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r','--name-only',HEAD,'crates/latent-control-store/src']).decode().splitlines()
definitions = []
by_leaf = {}
for path in paths:
    if path.endswith('.rs'):
        blob = subprocess.check_output(['git','-C',str(REPO),'show',f'{HEAD}:{path}']).decode()
        for leaf in re.findall(r'fn\s+(\w+)\s*\(',blob):
            by_leaf.setdefault(leaf,[]).append(path)
for name in missing:
    leaf = name.rsplit('::',1)[1]
    matches = by_leaf.get(leaf,[])
    definitions.append(dict(case=name,sourcePaths=matches))
proof = dict(head=HEAD,registeredFloor=prepared['registeredCaseFloor'],actualCICases=len(observed),missing=definitions,extra=extra)
(COORD/'portable-v2-pr790-control-case-source-audit-v212.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
