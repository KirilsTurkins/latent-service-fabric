"""Persist the previously interrupted host check custody and one metadata retry."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time
ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
COORD = Path(__file__).resolve().parent
OLD = COORD / "portable-v2-pr767-light-checks-20261006-v1"
OUT = COORD / "portable-v2-pr767-metadata-retry-20261006-v1"
assert OLD.is_dir() and not (OLD / "receipt.json").exists()
logs = [{"name": path.name, "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        for path in sorted(OLD.glob("*.log"))]
failure = {"at": datetime.now(timezone.utc).isoformat(), "passed": False, "qualified": False,
           "stopReason": "Windows host documentation observer deadline", "originalObserverDeadlineSeconds": 180,
           "boundExtended": False, "originalProcessReapedBySubprocessRun": True, "logs": logs}
(OLD / "observer-timeout-custody.json").write_text(json.dumps(failure, indent=2) + "\n", encoding="utf8")
OUT.mkdir()
argv = ["cargo", "+1.97.1", "metadata", "--no-deps", "--locked", "--offline", "--format-version=1"]
start = time.monotonic()
with (OUT / "metadata.log").open("xb") as output:
    result = subprocess.run(argv, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, timeout=180)
raw = (OUT / "metadata.log").read_bytes()
assert result.returncode == 0
value = json.loads(raw)
state = next(package for package in value["packages"] if package["name"] == "latent-state")
requirement = next(dep["req"] for dep in state["dependencies"] if dep["name"] == "redb")
assert requirement == "=4.3.0"
receipt = {"at": datetime.now(timezone.utc).isoformat(), "argv": argv, "exitCode": result.returncode,
           "elapsedSeconds": time.monotonic() - start, "workspaceMembers": len(value["workspace_members"]),
           "redbRequirement": requirement, "metadataSha256": hashlib.sha256(raw).hexdigest(), "metadataBytes": len(raw),
           "originalProcessReaped": True, "heavyCargoStarted": False, "completeCI": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps(receipt), flush=True)
