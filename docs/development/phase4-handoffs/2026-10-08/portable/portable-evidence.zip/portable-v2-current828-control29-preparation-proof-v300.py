import datetime
import hashlib
import json
from pathlib import Path
import subprocess

COORD = Path(__file__).resolve().parent
ARTIFACT = COORD / "portable-v2-current828-control-failure-artifact-v295"
HEAD = "912701092b03c97d6ce92e5bbac8a9f9a2f5fc68"
diag_path = ARTIFACT / "go-capsule-dependencies__node__controls__unexpected-control-diagnostics.json"
control_path = ARTIFACT / "go-capsule-dependencies__node__controls__029.json"
diagnostic = json.loads(diag_path.read_bytes())
original = json.loads(control_path.read_bytes())
rows = [row for page in diagnostic["audit"] for row in page["data"]["records"]]
attempt = next(row for row in rows if row["sequence"] == "35")
outcome = next(row for row in rows if row["sequence"] == "36")
assert attempt["data"]["attempt"]["previewReceiptDigest"] is None
assert outcome["data"]["outcome"]["attemptSequence"] == "35"
assert outcome["data"]["outcome"]["result"] == "AUDIT_OPERATION_RESULT_REJECTED"
assert outcome["data"]["outcome"]["reason"] == "unavailable"
assert diagnostic["operation"]["data"]["disposition"] == "DEPLOYMENT_OPERATION_LOOKUP_DISPOSITION_UNKNOWN"
assert diagnostic["operation"]["data"]["receipt"] is None
source_paths = [
    "crates/latent-wire/src/management/deployment/managed.rs",
    "crates/latent-rollout/src/deployment_audit/rejection.rs",
    "crates/latent-rollout/src/deployment_audit/mapping.rs",
    "crates/latent-control-store/src/deployments/operations/prepare.rs",
    "crates/latent-control-store/src/deployments/operations/commit.rs",
    "crates/latent-artifacts/src/local_repository/publication_preparation.rs",
]
sources = []
for path in source_paths:
    data = subprocess.check_output(["git", "show", f"{HEAD}:{path}"])
    sources.append({"path": path, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
result = {
    "observedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "head": HEAD, "originalCall": 29, "artifact": 11529647896,
    "originalControlSha256": hashlib.sha256(control_path.read_bytes()).hexdigest(),
    "auditDiagnosticsSha256": hashlib.sha256(diag_path.read_bytes()).hexdigest(),
    "attempt": {"sequence": "35", "previewReceiptPresent": False},
    "outcome": {"sequence": "36", "attemptSequence": "35", "result": "rejected", "reason": "unavailable"},
    "operationLookup": {"disposition": "unknown", "receiptPresent": False},
    "establishedPhase": "prepare-operation-before-writer-acceptance",
    "phaseReason": "The adapter records rejected preparation before a preview exists. A commit audit starts from a prepared preview and its missing receipt conclusion is Unknown/receipt-unavailable.",
    "originalCurrentnessReason": "admission-clock-lease-uncovered",
    "subphaseUnresolved": True,
    "existingRenewalsPreserved": ["before-catalog", "before-each-distinct-package", "after-verified-metadata", "before-commit"],
    "originalMutationNotRetried": True, "sourceNotModified": True,
    "noLeaseDeadlineBudgetOrGrantChange": True,
    "exactSourceClosure": sources,
}
out = COORD / "portable-v2-current828-control29-preparation-proof-v300.json"
out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: value for key, value in result.items() if key != "exactSourceClosure"}))
