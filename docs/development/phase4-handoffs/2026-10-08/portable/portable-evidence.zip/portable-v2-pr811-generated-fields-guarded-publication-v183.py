from pathlib import Path
import subprocess,json,hashlib,os,datetime
coord=Path(__file__).resolve().parent;root=Path(r"C:\Users\turkins\Desktop\lf-p4-pr811-generated-fields-v177")
old="47876214fdbc73af187b6a42c53d08bad0572429";head="e378fde6f67e1a34eb090d1adfc8abf4e9c20009";env=dict(os.environ,GODEBUG="http2client=0")
def qualify(job,count):
 p=coord/job;raw=(p/"receipt.json").read_bytes();r=json.loads(raw);assert r["head"]==head and r["passed"] and r["sourceClean"] and r["sourceHeadUnchanged"] and r["originalProcessReaped"] and len(r["steps"])==count
 for s in r["steps"]:
  b=(p/s["log"]).read_bytes();assert hashlib.sha256(b).hexdigest()==s["sha256"] and len(b)==s["bytes"] and s["exitCode"]==0 and s["stopReason"] is None
 return hashlib.sha256(raw).hexdigest()
sourceSha=qualify("portable-v2-pr811-generated-fields-source-20261008-v179",7);nativeSha=qualify("portable-v2-pr811-generated-fields-native-20261008-v180",2)
assert not subprocess.check_output(["git","status","--porcelain"],cwd=root);assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()==head
pr=json.loads(subprocess.check_output(["gh","pr","view","811","--repo","KirilsTurkins/latent-service-fabric","--json","state,headRefOid,headRefName,body"],env=env,timeout=40));assert pr["state"]=="OPEN" and pr["headRefOid"]==old;branch=pr["headRefName"]
assert subprocess.check_output(["git","ls-remote","origin","refs/heads/"+branch],cwd=root,env=env,text=True,timeout=45).split()[0]==old
subprocess.run(["git","push","origin",head+":refs/heads/"+branch],cwd=root,env=env,timeout=180,check=True);assert subprocess.check_output(["git","ls-remote","origin","refs/heads/"+branch],cwd=root,env=env,text=True,timeout=45).split()[0]==head
body=pr["body"].rstrip()+"\n\nCurrent completed-CI repair restores the maintained activation staging witness and namespace inspection policy fields consumed by Wire, preserving every prior protobuf allocation. All six client facades and the Java bridge are regenerated; all 77 old shared vectors remain, with one original-intent witness added (78 vectors and 16 unsigned boundaries; Java wire floor 61). Linux source checks pass 196 repository and 12 SDK profile cases with zero skips. The actual Go/TypeScript qualifier host-tools build and complete Rust SDK all-target suite pass on this head. Full guest runtime, signed-node and full CI qualification remain pending.\n";p=coord/"portable-v2-pr811-generated-fields-published-body-v183.md";p.write_text(body,encoding="utf-8",newline="\n");subprocess.run(["gh","pr","edit","811","--repo","KirilsTurkins/latent-service-fabric","--body-file",str(p)],env=env,timeout=45,check=True)
proof={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"pr":811,"oldHead":old,"head":head,"normalPushRemoteVerified":True,"sourceReceiptSha256":sourceSha,"nativeReceiptSha256":nativeSha,"originalFieldsOperationsVectorsUnsignedBoundariesPreserved":True,"actualHostToolsAndSdkNativePassed":True,"fullCIPending":True,"noMergeOrIssueClosure":True};(coord/"portable-v2-pr811-generated-fields-qualified-publication-v183.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8");print(json.dumps(proof,indent=2))
