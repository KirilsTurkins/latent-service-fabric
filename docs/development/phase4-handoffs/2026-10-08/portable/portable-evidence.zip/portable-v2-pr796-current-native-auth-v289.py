from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
HEAD='8f85a60021786138a25f75b8fbc22c32f8789844'
OUT=COORD/'portable-v2-pr796-current-main-native-20261008-v287'
raw=(OUT/'receipt.json').read_bytes();r=json.loads(raw)
assert r['head']==HEAD and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped'] and r['infrastructureError'] is None
assert len(r['steps'])==9
logs=[]
for row in r['steps']:
    data=(OUT/Path(row['log']).name).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped']
    logs.append(data.decode())
metadata=json.loads(subprocess.check_output(['git','-C',str(REPO),'show',HEAD+':tools/ci/suites.json']))
rows={x['id']:x for x in metadata['suites']}
for index,key,count in [(0,'latent-signing.lib.latent-signing',58),(3,'latent-node.lib.latent-node',91)]:
    listed=set(re.findall(r'^([\w:]+): test$',logs[index],re.M))
    assert listed==set(rows[key]['expectedCases']) and len(listed)==count
for index,count in [(1,58),(4,91),(5,66)]:assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in logs[index]
assert 'AOT sandbox: 12 unprivileged real-entry probes and exact-policy syscall probe passed' in logs[6]
proof=dict(at=datetime.now(timezone.utc).isoformat(),head=HEAD,nativeReceiptSha256=hashlib.sha256(raw).hexdigest(),
           allNineStepsPass=True,allLogsAuthenticated=True,allProcessesReaped=True,sourceClean=True,sourceHeadUnchanged=True,
           exactSigning58Node91Activation66Pass=True,actualCustomAOT12AndSyscallPass=True,
           ordinaryClippyAndOriginalSelectedStrictPass=True,elapsedSeconds=r['elapsedSeconds'],targetGrowthBytes=r['targetGrowthBytes'],
           priorFullGreenPRHead='43503d8cfbd9e938aa6d798ccd00059efdae8e9e',
           latest21cSourceAlreadyPass=True,notOnlyJSONOriginalConflict=True,noAdminMerge=True,noPublicationYet=True)
(COORD/'portable-v2-pr796-current-native-qualified-v289.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
