"""Read-only source/format/metadata checks of the resolved storage merge."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r"C:\Users\turkins\Desktop\lf-p4-root-reconcile")
OUT = Path(__file__).resolve().parent / "portable-v2-pr767-light-checks-20261006-v1"
OURS = "0a460cbaa9dcea330b00978b7b3557ab75e58b23"
THEIRS = "318eaa9aea5e0962515c7161d441ee270bcdeae4"
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, timeout=60).decode().strip()
assert git("rev-parse", "HEAD") == OURS and git("rev-parse", "MERGE_HEAD") == THEIRS
assert not git("diff", "--name-only", "--diff-filter=U")
assert not git("diff", "--name-only")
before = git("write-tree")
OUT.mkdir()
python = [sys.executable, "-X", "utf8", "-B"]
steps = [("coverage", [*python, "tools/ci_coverage.py"], 180),
         ("repository", [*python, "tools/validate_repository.py"], 180),
         ("documentation", [*python, "tools/validate_docs.py"], 180),
         ("format", ["cargo", "+1.97.1", "fmt", "--all", "--", "--check"], 180),
         ("metadata", ["cargo", "+1.97.1", "metadata", "--no-deps", "--locked", "--offline", "--format-version=1"], 180)]
def run(step):
    label, argv, timeout = step
    start = time.monotonic()
    output = OUT / (label + ".log")
    with output.open("xb") as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
    raw = output.read_bytes()
    row = {"step": label, "argv": argv, "exitCode": result.returncode, "elapsedSeconds": time.monotonic() - start,
           "log": str(output), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "originalProcessReaped": True}
    if label == "metadata" and result.returncode == 0:
        value = json.loads(raw)
        row["workspaceMemberCount"] = len(value["workspace_members"])
        state = next(package for package in value["packages"] if package["name"] == "latent-state")
        row["statePackage"] = {"version": state["version"], "features": sorted(state["features"]),
                               "redbRequirement": next(dep["req"] for dep in state["dependencies"] if dep["name"] == "redb")}
    return row
with ThreadPoolExecutor(max_workers=4) as pool:
    records = list(pool.map(run, steps))
receipt = {"at": datetime.now(timezone.utc).isoformat(), "root": str(ROOT), "ours": OURS, "incoming": THEIRS,
           "resolvedTree": before, "steps": records, "allStepsPassed": all(row["exitCode"] == 0 for row in records),
           "resolvedTreeUnchanged": before == git("write-tree"), "unstagedChanges": git("diff", "--name-only"),
           "heavyCargoStarted": False, "completeCI": False, "published": False}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps(receipt), flush=True)
raise SystemExit(not receipt["allStepsPassed"] or not receipt["resolvedTreeUnchanged"] or bool(receipt["unstagedChanges"]))
