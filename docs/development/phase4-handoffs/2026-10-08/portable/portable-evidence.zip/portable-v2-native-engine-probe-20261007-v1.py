import hashlib
import json
import pathlib
import subprocess
import time

OUT = pathlib.Path(__file__).resolve().parent / 'portable-v2-native-engine-probe-20261007-v1'
OUT.mkdir()
argv = ['docker', 'inspect', 'latent-p4-root-native-20261004-v1']
started = time.monotonic()
try:
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
    raw, error = result.stdout, result.stderr
    record = {'argv': argv, 'exitCode': result.returncode, 'timedOut': False, 'elapsedSeconds': time.monotonic() - started, 'readOnly': True}
    if result.returncode == 0:
        metadata = json.loads(raw)[0]
        record.update({'running': metadata.get('State', {}).get('Running'), 'image': metadata.get('Image'), 'owner': metadata.get('Config', {}).get('Labels', {}).get('latent.owner')})
except subprocess.TimeoutExpired as exc:
    raw, error = exc.stdout or b'', exc.stderr or b''
    record = {'argv': argv, 'timedOut': True, 'elapsedSeconds': time.monotonic() - started, 'readOnly': True, 'onlyOwnCliKilledAndWaitedBySubprocessRun': True}
(OUT / 'stdout.json').write_bytes(raw)
(OUT / 'stderr.txt').write_bytes(error)
record['stdoutSha256'] = hashlib.sha256(raw).hexdigest()
(OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
