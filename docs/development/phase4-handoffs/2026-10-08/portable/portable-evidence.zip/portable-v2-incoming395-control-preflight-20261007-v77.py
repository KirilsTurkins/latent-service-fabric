from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, shutil, subprocess, uuid
COORD=Path(__file__).resolve().parent
HEAD="5f08ca4cfec5fc08dac712c68bf22208e13b0d36"
OWNER="latent-p4-root-native-20261004-v1"
BASE="/var/lib/docker/volumes/"+OWNER+"/_data"
source_dir=COORD/"root-inbox395-control-source-20261007-v1"
source_path=source_dir/"receipt.json"
receipt=json.loads(source_path.read_bytes())
assert receipt["head"]==HEAD and receipt["passed"] and len(receipt["steps"])==7
assert receipt["sourceClean"] and receipt["sourceHeadUnchanged"] and receipt["originalProcessReaped"]
for row in receipt["steps"]:
 raw=(source_dir/row["log"]).read_bytes()
 assert row["exitCode"]==0 and row["originalProcessReaped"] and row["stopReason"] is None
 assert len(raw)==row["bytes"] and hashlib.sha256(raw).hexdigest()==row["sha256"]
step_path=COORD/"entity-contract-v53-incoming-control-native-steps-20261007.json"
steps=json.loads(step_path.read_bytes())
assert len(steps)==5 and all(row[:2]==["cargo","+1.97.1"] for row in steps)
assert hashlib.sha256(step_path.read_bytes()).hexdigest()=="7f0253361eeb4b594a8153f85737906deb9a791b6ec9e6d32823453cdea33f3a"
assert "standalone::triggers::tests::" in steps[1]
assert "config::triggers::tests::" in steps[2]
assert "standalone::shutdown::tests::" in steps[3]
assert steps[0][2]=="check" and steps[4][2]=="clippy" and "-D" not in steps[4]
controller=COORD/"portable-v2-isolated-native-controller-20261007-v33.py"
text=controller.read_text()
assert "native-active-portable-v3" in text and "deadlineSeconds=1800" in text and "maximumTargetGrowthBytes=16 * 1024 ** 3" in text
assert "root-native-active-v2.lock" in text
free=shutil.disk_usage(COORD).free
assert free > 2*1024**3, f"warm-floor-before-preflight:{free}"
container=json.loads(subprocess.check_output(["docker","inspect",OWNER],timeout=30))[0]
assert container["State"]["Running"] and container["Config"]["Labels"]["latent.owner"]=="/root"
assert container["HostConfig"]["Memory"]==8*1024**3 and container["HostConfig"]["NanoCpus"]==2_000_000_000
assert container["Image"]=="sha256:ca60c71b26838b949aa1815a64541d978c41be0acf72f2c7db0ca7ce4fd9a198"
leaf=BASE+"/tmp/portable-v2-incoming395-control-v77-"+uuid.uuid4().hex
body="""import fcntl,json,os,subprocess
from pathlib import Path
base=Path(BASE_VALUE)
assert os.getuid()==10001 and os.getgid()==10001
with (base/'jobs/root-native-active-v2.lock').open('a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 source=base/'native-active-portable-v3'
 env=dict(os.environ,GIT_CONFIG_GLOBAL=str(base/'jobs/gitconfig'))
 status=subprocess.check_output(['git','status','--porcelain'],cwd=source,env=env,timeout=30)
 assert not status,status[:200]
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,env=env,timeout=30).decode().strip()
 selected=subprocess.check_output(['git','cat-file','-t',HEAD_VALUE],cwd=source,env=env,timeout=30).decode().strip()
 assert selected=='commit'
 path=Path(LEAF_VALUE); value=b'portable-v2-incoming395-control-v77-write-proof'
 with path.open('xb') as out:
  out.write(value); out.flush(); os.fsync(out.fileno())
 assert path.read_bytes()==value
 path.unlink()
 print(json.dumps(dict(fsyncReadDeletePassed=True,uid=os.getuid(),gid=os.getgid(),nativeLockAvailable=True,priorNativeHead=head)))
""".replace('BASE_VALUE',repr(BASE)).replace('LEAF_VALUE',repr(leaf)).replace('HEAD_VALUE',repr(HEAD))
checked=subprocess.run(["docker","exec","-i","--user","10001:10001",OWNER,"python3"],input=body.encode(),capture_output=True,timeout=120)
assert checked.returncode==0,checked.stderr.decode(errors="replace")
proof=json.loads(checked.stdout)
free_after=shutil.disk_usage(COORD).free
assert free_after > 2*1024**3, f"warm-floor-after-preflight:{free_after}"
result=dict(proof,at=datetime.now(timezone.utc).isoformat(),head=HEAD,sourceReceiptSha256=hashlib.sha256(source_path.read_bytes()).hexdigest(),stepsSha256=hashlib.sha256(step_path.read_bytes()).hexdigest(),controllerSha256=hashlib.sha256(controller.read_bytes()).hexdigest(),exactFiveIncomingControlCommandsPreserved=True,freeHostBytes=free_after,completeCI=False)
out=COORD/'portable-v2-incoming395-control-preflight-20261007-v77.json'
assert not out.exists(); out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
