from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path

COORD=Path(__file__).resolve().parent
ROOT=COORD/'portable-v2-pr811-current-sdk-host-v267'
source=json.loads((ROOT/'source-receipt.json').read_bytes())
native=json.loads((ROOT/'host-native-receipt.json').read_bytes())
assert native['passed'] and native['allProcessesReaped'] and native['allSourceHashesUnchanged']
for row in source['files']:
    data=(ROOT/'source'/row['path']).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
candidates=[ROOT/'source/sdk/typescript-client/node_modules',ROOT/'source/sdk/typescript-client/dist',ROOT/'dotnet-build']
records=[]
for path in candidates:
    assert path.is_dir() and not path.is_symlink() and path.resolve().is_relative_to(ROOT.resolve())
    files=[]
    for item in path.rglob('*'):
        assert not item.is_symlink(),str(item)
        if item.is_file():
            data=item.read_bytes()
            files.append(dict(path=item.relative_to(path).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    records.append(dict(path=str(path.resolve()),fileCount=len(files),bytes=sum(row['bytes'] for row in files),files=files,
                        generatedReconstructibleDerivative=True,allRelatedProcessesReaped=True,authoredTrackedSourcesExcluded=True))
proof=dict(at=datetime.now(timezone.utc).isoformat(),ownedRoot=str(ROOT.resolve()),sourceHead=source['head'],
           sourceReceiptSha256=hashlib.sha256((ROOT/'source-receipt.json').read_bytes()).hexdigest(),
           nativeReceiptSha256=hashlib.sha256((ROOT/'host-native-receipt.json').read_bytes()).hexdigest(),
           all89SourceHashesUnchanged=True,candidates=records,totalBytes=sum(row['bytes'] for row in records),
           excludesCompilerToolsGuestsArchivesPeerWorktreesAndNativeVolume=True,notDeletedYet=True)
(COORD/'portable-v2-owned-sdk-derivative-audit-v286.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k!='candidates'}|{'candidates':[{k:v for k,v in r.items() if k!='files'} for r in records]},indent=2))
