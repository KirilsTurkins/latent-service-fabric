from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

COORD=Path(__file__).resolve().parent
REPO='KirilsTurkins/latent-service-fabric'
ENV=dict(os.environ,GODEBUG='http2client=0')
number=sys.argv[1]
assert number in {'790','787','796'}
plans={
 '790':dict(head='9977333b18c3990e52b5aebb7e0382a26dfa35aa',old='a3fb527eb067259865e22777e743614967695551',
            native='9cfe58a9587d08adf8fdbee29e7d0360fd788f3e',branch='feat/phase4-command-waiters-387',
            nativeJob='portable-v2-pr790-fd-current-native-20261008-v268',body='portable-v2-pr790-current-qualified-body-v278.md'),
 '787':dict(head='4ce4eb63a04cded8bbb4b875c1b6863a3cc84678',old='9b30480ed89915bd0a75ba39495de27ad4915359',
            native='66142de2f07a9ac45ed9cae469227bf6f7d1e505',branch='feat/phase4-atomic-envelope-386',
            nativeJob='portable-v2-pr787-current-main-native-20261008-v275',body='portable-v2-pr787-current-qualified-body-v280.md'),
 '796':dict(head='8f85a60021786138a25f75b8fbc22c32f8789844',old='43503d8cfbd9e938aa6d798ccd00059efdae8e9e',
            native='8f85a60021786138a25f75b8fbc22c32f8789844',branch='feat/phase4-retention-397',
            nativeJob='portable-v2-pr796-current-main-native-20261008-v287',body='portable-v2-pr796-current-qualified-body-v290.md'),
}
p=plans[number]
TREE=Path(r'C:\Users\turkins\Desktop')/('lf-p4-pr'+number+'-21c-main-v272')
def call(argv):return subprocess.check_output(argv,env=ENV,timeout=120)
def auth(job,head):
    out=COORD/job;raw=(out/'receipt.json').read_bytes();r=json.loads(raw)
    assert r['head']==head and r['passed'] and r['sourceClean'] and r['sourceHeadUnchanged'] and r['originalProcessReaped'] and r['infrastructureError'] is None
    for row in r['steps']:
        data=(out/Path(row['log']).name).read_bytes()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and row['exitCode']==0 and row['originalProcessReaped']
    return hashlib.sha256(raw).hexdigest()
source_sha=auth('portable-v2-pr'+number+'-final-main-source-20261008-v277',p['head'])
native_sha=auth(p['nativeJob'],p['native'])
assert call(['git','-C',str(TREE),'diff','--name-only',p['native'],p['head']]).decode().splitlines()==([] if number=='796' else ['tools/java_server_node.py'])
assert not call(['git','-C',str(TREE),'status','--porcelain'])
assert call(['git','-C',str(TREE),'rev-parse','HEAD']).decode().strip()==p['head']
pr=json.loads(call(['gh','pr','view',number,'--repo',REPO,'--json','headRefOid,headRefName,state']))
assert pr==dict(headRefOid=p['old'],headRefName=p['branch'],state='OPEN'),pr
call(['git','-C',str(TREE),'merge-base','--is-ancestor',p['old'],p['head']])
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=int(number),head=p['head'],oldHead=p['old'],nativeHead=p['native'],
           sourceReceiptSha256=source_sha,nativeReceiptSha256=native_sha,exactRustApiSdkWitCargoMetadataAndTestClosure=True,
           onlyBoundedJavaDiagnosticDeltaAfterNative=number!='796',nativeExecutedAtFinalPublishedHead=number=='796',normalPush=True,published=False,completeCI=False,noAdminMerge=True,noIssueClosure=True)
out=COORD/('portable-v2-pr'+number+'-qualified-main-publication-v281.json')
out.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
push=subprocess.run(['git','-C',str(TREE),'push','origin','HEAD:refs/heads/'+p['branch']],env=ENV,capture_output=True,timeout=120)
(COORD/('portable-v2-pr'+number+'-qualified-main-push-v281.log')).write_bytes(push.stdout+push.stderr)
assert push.returncode==0
remote=call(['git','-C',str(TREE),'ls-remote','origin','refs/heads/'+p['branch']]).decode().split()[0]
assert remote==p['head']
call(['gh','pr','edit',number,'--repo',REPO,'--body-file',str(COORD/p['body'])])
proof.update(published=True,verifiedRemoteHead=remote,bodyUpdated=True)
out.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
