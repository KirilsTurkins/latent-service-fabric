import hashlib
import json
from pathlib import Path
import re
import subprocess

COORD=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\turkins\Desktop\latent-fabric')
rows=[]
for number in (790,800,791,787,796,784,825,811):
    receipt=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-union-v238/receipt.json')).read_bytes())
    head=receipt['head']
    def blob(path):return subprocess.check_output(['git','-C',str(REPO),'show',head+':'+path])
    profile=json.loads(blob('sdk/profile/client-profile.json'))
    digest=hashlib.sha256()
    for path in sorted(profile['sources']):
        digest.update(path.encode()+b'\0'+blob(path).replace(b'\r\n',b'\n')+b'\0')
    actual='sha256:'+digest.hexdigest()
    generated=blob('sdk/typescript-client/src/node/protocol/generated.ts').decode()
    match=re.search(r'export const sourceDigest = "(sha256:[0-9a-f]{64})";',generated)
    assert match
    rows.append(dict(pr=number,head=head,authoritativeDigest=actual,generatedDigest=match.group(1),exactDigestMatches=actual==match.group(1)))
(COORD/'portable-v2-node-rpc-digest-audit-v248.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
print(json.dumps([{k:r[k] for k in ('pr','head','exactDigestMatches')} for r in rows],indent=2))
