import datetime
import json
import os
from pathlib import Path
import subprocess

COORD = Path(__file__).resolve().parent
REPO = "KirilsTurkins/latent-service-fabric"
RUN = 37729173027
JOB = 113154150383
HEAD = "601038c2b908144dadd11bcb48ddbab51606b5d4"
OUT = COORD / "portable-v2-pr825-infra-job-rerun-v299.json"
ENV = dict(os.environ, GODEBUG="http2client=0")


def api(path, method="GET"):
    process = subprocess.run(
        ["gh", "api", "--method", method, f"repos/{REPO}/{path}"],
        env=ENV, capture_output=True, timeout=60, check=True,
    )
    return json.loads(process.stdout) if process.stdout.strip() else None


if OUT.exists():
    previous = json.loads(OUT.read_text(encoding="utf-8"))
    if previous.get("rerunRequested"):
        print(json.dumps({"result": "already-requested", "job": JOB}))
        raise SystemExit(0)

run = api(f"actions/runs/{RUN}")
job = api(f"actions/jobs/{JOB}")
pr = api("pulls/825")
result = {
    "observedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "run": RUN, "job": JOB, "expectedHead": HEAD,
    "runHead": run["head_sha"], "currentPrHead": pr["head"]["sha"],
    "runStatus": run["status"], "runConclusion": run["conclusion"],
    "runAttempt": run["run_attempt"],
    "jobStatus": job["status"], "jobConclusion": job["conclusion"],
    "jobRun": job["run_id"], "jobRunAttempt": job.get("run_attempt"),
    "rerunRequested": False, "sourceChanged": False,
    "originalFailureClass": "pinned-rust-installer-tcp-connect-timeout",
    "originalFailureRawSha256": "7a4e6aaee9800a91fe4d0348b065a059af8abb2be2267a1b8a18832a0a438359",
    "scope": "Only the original infrastructure-failed job; no workflow or source mutation.",
}
safe = (
    result["runHead"] == HEAD == result["currentPrHead"]
    and result["runStatus"] == "completed"
    and result["runAttempt"] == 1
    and result["jobRun"] == RUN
    and result["jobStatus"] == "completed"
    and result["jobConclusion"] == "failure"
    and result["jobRunAttempt"] in (None, 1)
)
OUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
if not safe:
    result["result"] = "held-by-fresh-head-status-or-attempt-guard"
else:
    response = api(f"actions/jobs/{JOB}/rerun", method="POST")
    result["rerunRequested"] = True
    result["requestAcceptedAt"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result["responseWasEmpty"] = response is None
    result["result"] = "original-job-rerun-request-accepted"
OUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
