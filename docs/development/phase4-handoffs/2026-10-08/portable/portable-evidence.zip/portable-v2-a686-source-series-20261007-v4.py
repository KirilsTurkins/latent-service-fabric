import json
import pathlib
import subprocess
import sys

COORD = pathlib.Path(__file__).resolve().parent
for number in (767, 780, 821, 796):
    record = json.loads((COORD / f'portable-v2-pr{number}-a686-reconcile-20261007-v4' / 'receipt.json').read_bytes())
    job = f'portable-v2-pr{number}-a686-source-linux-20261007-v4'
    print(json.dumps({'number': number, 'head': record['head'], 'job': job, 'status': 'starting'}), flush=True)
    result = subprocess.run([sys.executable, '-X', 'utf8', str(COORD / 'root-candidate-run-20261005-v2.py'), job, record['head'], str(COORD / 'portable-v2-a686-source-steps-20261007-v4.json'), 'source'], cwd=COORD)
    print(json.dumps({'number': number, 'exitCode': result.returncode, 'status': 'reaped'}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
