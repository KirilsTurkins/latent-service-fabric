from pathlib import Path
import json

COORD=Path(__file__).resolve().parent
source=(COORD/'portable-v2-owned-final-source-sequence-v225.py').read_text(encoding='utf8')
source=source.replace("previous='portable-v2-pr790-current-main-source-20261008-v222'","previous='portable-v2-pr796-final-main-source-20261008-v225'")
source=source.replace('v225','v234')
# The previous exact completed job is the old, preserved Source attempt.
source=source.replace("previous='portable-v2-pr796-final-main-source-20261008-v234'","previous='portable-v2-pr796-final-main-source-20261008-v225'")
source=source.replace('for number in (790,800,791,787,796,784,825):','for number in (790,800,791,787,796,784,825,811):')
needle="    record=json.loads((COORD/('portable-v2-pr'+str(number)+'-website-main-union-v224.json')).read_bytes())\n    steps=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-source-steps-v222.json')).read_bytes())"
replacement="""    record=next(row for row in json.loads((COORD/'portable-v2-owned-aot-floor-restored-v233.json').read_bytes())['records'] if row['pr']==number)
    if number==811:
        steps=json.loads((COORD/'portable-v2-pr811-source-steps-v184.json').read_bytes())
        for module in ['tools.tests.test_java_diagnostic_program','tools.tests.test_java_provider_timeout','tools.tests.test_java_resource_diagnostics']:
            if module not in steps[0]:steps[0].append(module)
    else:
        steps=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-source-steps-v222.json')).read_bytes())"""
assert source.count(needle)==1
source=source.replace(needle,replacement)
source=source.replace('for row in items:\n','for row in items:\n    if (COORD/\'portable-v2-corrected-source-sequence-v234.pause\').exists():\n        print(json.dumps(dict(status=\'paused-at-reaped-boundary\',nextPr=row[\'pr\'])),flush=True)\n        break\n',1)
path=COORD/'portable-v2-owned-corrected-source-sequence-v234.py'
compile(source,str(path),'exec')
assert not path.exists()
path.write_text(source,encoding='utf8')
print(str(path))
