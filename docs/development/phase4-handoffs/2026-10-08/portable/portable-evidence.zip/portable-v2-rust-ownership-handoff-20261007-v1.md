Shared fix: `7758fcd0742ceec2a3dd1a1499f5f6c99c46e550`, parent `50869ccea15fa6b38d1091e2e7fa997c99caecb1`, custody branch `fix/phase4-rust-ownership-profile-20261007-v1`. Clean owned worktree `C:\Users\turkins\Desktop\lf-p4-rust-ownership-profile-20261007-v1`. No PR or remote publication performed.

Authenticated artifact11446465717, run37528001683, exact source50869: ZIP sha256 `cda99267a8c0cf8f558a9f3a08556f515812f0f3dc410df1f555cb5fa4f028b6` matches GitHub artifact metadata. The original positive JSON compiler message is E0432 for state/intents gated behind the SDK transaction feature. Raw selected stdout/stderr, metadata and digest receipt are in `portable-v2-rust-ownership-artifact-20261007-v1`.

Only the combined ownership checker opts its freshly generated greeting Cargo dependency into `features=["transaction"]`, before capturing original inputs. Every other project, SDK and lock byte remains identical. `PRELUDE`, `POSITIVE` and all19negative sources/expected diagnostics are AST/literal-identical, and the old check body differs by only one selector call. The original360-second overall,180-second per-check and4MiBstdout bounds remain exact. The post-campaign source restoration still checks the selected original snapshot. This type-checking harness creates no package, runtime or grant.

Changed paths:

- `tools/check_rust_capsule_ownership.py`
- `tools/tests/test_rust_ownership_profile.py`
- `tools/ci/contracts/python/test_rust_ownership_profile.py.json`

Review custody: `portable-v2-rust-ownership-review-20261007-v1/receipt.json`. Two actual creator/capture Source tests pass. The Windows mandatory symlink authoring test failed with WinError1314; its assertions and guards were not changed. The first Linux wrapper attempt stopped before execution because Docker resolved the missing old container name to its retained volume; that setup attempt is not Source evidence.

Fresh LinuxSource proof after Root restored its private container: `portable-v2-rust-ownership-profile-linux-20261007-v2/receipt.json`, all4stepsPASS, current source clean/head unchanged and processes reaped. The original symlink refusal runs in Linux. Exact generator `--check`, coverage88historical/268current/141owners and repository validation pass.

Root's required actual20-case wasm32 campaign remains pending. Invoke the existing checker `python3 -X utf8 -B tools/check_rust_capsule_ownership.py --offline --output <fresh-owned-outside-checkout-directory>` against the immutable candidate with the authenticated pinned Rust1.97.1/wasm32 tools and original limits. A Source receipt does not replace that compiler execution or the four PRs' fresh hosted checks.
