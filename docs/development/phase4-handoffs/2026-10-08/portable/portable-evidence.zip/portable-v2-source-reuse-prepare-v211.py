from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

COORD = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\turkins\Desktop\latent-fabric')
new_head, old_job, old_source, new_job, step_file, output_script = sys.argv[1:]
assert len(new_head) == 40 and all(c in '0123456789abcdef' for c in new_head)
assert old_source.startswith('source-') and '/' not in old_source
assert all(name.isascii() and all(c.isalnum() or c in '-.' for c in name) for name in (old_job,new_job,output_script))
old_raw = (COORD/old_job/'receipt.json').read_bytes()
old = json.loads(old_raw)
assert old['sourceClean'] and old['sourceHeadUnchanged'] and old['originalProcessReaped'] and old['infrastructureError'] is None
assert old['checkout'].endswith('/'+old_source)
for row in old['steps']:
    raw = (COORD/old_job/Path(row['log']).name).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'] and row['originalProcessReaped']
steps_raw = Path(step_file).read_bytes()
steps = json.loads(steps_raw)
assert steps and all(row[0] == 'python3' for row in steps)
source = (COORD/'portable-v2-reconstructed-native-controller-20261007-v93.py').read_text(encoding='utf8')
needle = "else:\n    source = base / ('source-' + head[:16])\n"
replacement = '''else:
    source = base / SOURCE_LITERAL
    reuse_lock = (base / 'jobs' / 'portable-v2-released-source-reuse-v211.lock').open('a+')
    fcntl.flock(reuse_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert source.is_dir() and not source.is_symlink() and source.resolve().is_relative_to(base.resolve())
    assert cfg['head'] == NEW_LITERAL
    assert call(['git','rev-parse','HEAD'],source) == OLD_LITERAL
    assert not call(['git','status','--porcelain'],source)
    prior = base / 'jobs' / JOB_LITERAL
    raw_receipt = (prior / 'receipt.json').read_bytes()
    assert hashlib.sha256(raw_receipt).hexdigest() == HASH_LITERAL
    previous = json.loads(raw_receipt)
    assert previous['head'] == OLD_LITERAL and previous['sourceClean'] and previous['sourceHeadUnchanged'] and previous['originalProcessReaped']
    for row in previous['steps']:
        raw = (prior / Path(row['log']).name).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == row['sha256'] and len(raw) == row['bytes'] and row['originalProcessReaped']
    custody = dict(oldHead=previous['head'], oldTree=previous['tree'], newHead=cfg['head'],
                   oldReceiptSha256=hashlib.sha256(raw_receipt).hexdigest(), oldProcessesReaped=True,
                   sourceClean=True, sourceOnly=True, noClone=True, noForcedResetOrClean=True, nativeCheckoutMutation=False)
    (out / 'source-reuse-custody.json').write_text(json.dumps(custody,indent=2)+'\\n')
'''
for label, value in [('SOURCE_LITERAL',old_source),('NEW_LITERAL',new_head),('OLD_LITERAL',old['head']),('JOB_LITERAL',old_job),('HASH_LITERAL',hashlib.sha256(old_raw).hexdigest())]:
    replacement = replacement.replace(label,repr(value))
assert source.count(needle) == 1
source = source.replace(needle,replacement).replace('assert mode in {"native", "source"}', 'assert mode == "source", "Exact released Source checkout only"',1)
script = COORD/output_script
compile(source,str(script),'exec')
assert not script.exists()
script.write_text(source,encoding='utf8')
proof = dict(at=datetime.now(timezone.utc).isoformat(),head=new_head,oldHead=old['head'],oldSource=old_source,
             oldReceiptSha256=hashlib.sha256(old_raw).hexdigest(),job=new_job,controller=str(script),
             controllerSha256=hashlib.sha256(script.read_bytes()).hexdigest(),steps=str(step_file),stepsSha256=hashlib.sha256(steps_raw).hexdigest(),
             originalBoundsPreserved=True,noClone=True,noForcedResetOrClean=True,sourceOnly=True)
(COORD/(new_job+'-reuse-prepared.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
