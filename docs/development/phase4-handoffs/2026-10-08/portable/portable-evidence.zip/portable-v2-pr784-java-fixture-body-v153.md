Delivers six authored transaction guest variants for #389, retaining actual stage-before-HTTP-denial behavior, captured compiler inputs and strict forbidden-operation assertions. Integrates development and canonical Java signing/browser contracts without dropping qualification cases.

Completes the generated empty-world Java server test fixture with the canonical C bridge file required by SDK installation. Every original service-union assertion, test guard and skip remains unchanged.

Fresh Linux source checks pass, including all nine Java server source cases and maintained SDK generation. Full CI and six signed installed guest executions remain pending.
