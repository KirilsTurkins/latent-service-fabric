import json
import pathlib
import subprocess

COORD = pathlib.Path(__file__).resolve().parent
REPO = COORD.parent / 'latent-fabric'
OUT = COORD / 'portable-v2-pr-historical-green-audit-20261007-v1'
MAIN = 'a686ed45a83d0f9de8158fd5be45f43a756abfb7'
rows = json.loads((OUT / 'source-delta-review.json').read_bytes())
results = []
for row in rows:
    raw = subprocess.check_output(['git', 'log', '--no-merges', '--format=%H %s', row['historicalGreenHead'] + '..' + row['currentHead'], '--not', MAIN], cwd=REPO)
    commits = raw.decode().splitlines()
    owned_sources = []
    for item in commits:
        sha, title = item.split(' ', 1)
        paths = subprocess.check_output(['git', 'diff-tree', '--root', '--no-commit-id', '--name-only', '-r', sha], cwd=REPO).decode().splitlines()
        source = [path for path in paths if path.endswith(('.rs', '.py', '.wit', '.proto', '.mjs', '.ts', '.go', '.java', '.c', '.h', '.cs'))]
        if source:
            owned_sources.append({'commit': sha, 'title': title, 'sourcePaths': source[:6]})
    results.append({'number': row['number'], 'historicalGreenHead': row['historicalGreenHead'], 'currentHead': row['currentHead'],
                    'nonMergeCommitsOutsideDevelopment': len(commits), 'functionalSourceCommitsOutsideDevelopment': len(owned_sources),
                    'recentOwnedSourceExamples': owned_sources[:4], 'shortcutEligible': False,
                    'review': 'Separates upstream development changes from subsequent feature-side source repairs. Those repairs require current qualification rather than the simple conflict-only shortcut.'})
(OUT / 'feature-source-review.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
print(json.dumps([{key: row[key] for key in ('number', 'historicalGreenHead', 'currentHead', 'nonMergeCommitsOutsideDevelopment', 'functionalSourceCommitsOutsideDevelopment', 'recentOwnedSourceExamples')} for row in results], indent=2))
