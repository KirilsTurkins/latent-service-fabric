import hashlib
import json
from pathlib import Path
import zipfile

COORD=Path(__file__).resolve().parent
OUT=COORD/'portable-v2-current828-control-failure-artifact-v295'
proof=[]
with zipfile.ZipFile(OUT/'artifact.zip') as z:
    names=[i.filename for i in z.infolist() if not i.is_dir() and (
        i.filename.endswith(('node/controls/029.json','node/controls/timing-029.json','unexpected-control-diagnostics.json','node/node.stderr.txt')))]
    for name in names:
        data=z.read(name);assert len(data)<4*1024**2
        (OUT/name.replace('/','__')).write_bytes(data)
        row=dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
        try:value=json.loads(data)
        except (ValueError,UnicodeError):proof.append(row);continue
        if name.endswith('/029.json'):
            row['topKeys']=list(value)
            row['closed']={k:value.get(k) for k in ('category','outcomeKnown','requestDispatched')}
            error=value.get('error')
            if isinstance(error,dict):row['closed']['errorCode']=error.get('code');row['closed']['errorKeys']=list(error)
            payload=value.get('data')
            if isinstance(payload,dict):row['closed']['dataKeys']=list(payload)
        elif 'timing-029' in name:row['timing']=value
        else:row['topKeys']=list(value) if isinstance(value,dict) else None
        proof.append(row)
(OUT/'closed-control29-v296.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
