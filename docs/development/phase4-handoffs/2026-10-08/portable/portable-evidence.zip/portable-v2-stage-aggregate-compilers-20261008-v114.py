from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,stat,subprocess,tarfile,time,zipfile
INPUTS={'typescript-managed.zip': '9d0b36a8df631a16c4b7d0a28a7c0e36cedfe2ce0c9c689f9f828ca91a334f33', 'dotnet-managed.zip': '94654363fea7ffea28aa67e8517ba2bc020b5b8ba996eb7cdbfeddb6207b5132', 'go-go.tbz': '4b4fcbbab5b5b0a45433112aa51c64a54007b24f1efd05b67018ca2cf8633e2c', 'go-componentize-go': '9f351ee76b86696e8c9f747fc65261a323254d45a1cc3f4319bcbe5137c9803d', 'go-wasm-tools': 'cc1f862d69363aac2d4a88f01c414a2dcf10858632d0c0a45e93ff60503979d6', 'dotnet-wit-bindgen': 'aefa50fcbbced25862d2b7c65c3b44b63e63302d8e2533f1aeeab6e8cff4ff72'}
base=Path('/var/lib/docker/volumes/latent-p4-root-native-20261007-v6/_data');source=Path('/root-checks/portable-v2-aggregate-version-compiler-preparation-20261008-v113');root=base/'jobs/portable-v2-aggregate-compiler-tools-20261008-v114'
assert os.getuid()==10001 and os.getgid()==10001 and not root.exists();root.mkdir(mode=0o700);deadline=time.monotonic()+900
for name,sha in INPUTS.items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==sha
rows=[]
for lang in ['typescript','dotnet']:
 manifest=json.loads((source/(lang+'-managed-inputs.json')).read_bytes());target=root/lang;target.mkdir(mode=0o700);expected={r['path']:r for r in manifest['files']}
 with zipfile.ZipFile(source/(lang+'-managed.zip')) as z:
  assert len(z.infolist())==len(expected)<65536 and sum(i.file_size for i in z.infolist())<4*1024**3
  for item in z.infolist():
   assert time.monotonic()<deadline
   p=Path(item.filename);assert not p.is_absolute() and '..' not in p.parts and ':' not in item.filename and stat.S_IFMT(item.external_attr>>16)!=stat.S_IFLNK
   row=expected[item.filename];dest=target/p;dest.parent.mkdir(mode=0o700,parents=True,exist_ok=True);count=0;h=hashlib.sha256()
   with z.open(item) as src,dest.open('xb') as out:
    for block in iter(lambda:src.read(1024**2),b''):
     count+=len(block);assert count<=row['size'];h.update(block);out.write(block)
   assert count==row['size'] and 'sha256:'+h.hexdigest()==row['sha256'];dest.chmod(0o700 if row['executable'] else 0o600)
 rows.append(dict(language=lang,files=len(expected),logicalBytes=sum(r['size'] for r in expected.values()),originalToolIdentity=manifest['identity'],originalFilesByteIdentical=True))
go=root/'go';go.mkdir(mode=0o700)
with tarfile.open(source/'go-go.tbz','r:bz2') as archive:
 members=archive.getmembers();assert len(members)<32768 and sum(m.size for m in members)<1024**3
 for m in members:
  p=Path(m.name);assert not p.is_absolute() and '..' not in p.parts and (m.isdir() or m.isfile()),m.name
 archive.extractall(go,filter='data')
(root/'bin').mkdir(mode=0o700)
for original,name in [('go-componentize-go','componentize-go'),('go-wasm-tools','wasm-tools'),('dotnet-wit-bindgen','wit-bindgen')]:
 raw=(source/original).read_bytes();dest=root/'bin'/name;dest.write_bytes(raw);dest.chmod(0o700)
# Private physical path relocation is separate from original authenticated bytes.
p=root/'dotnet/tools/wasi-sdk.json';before=p.read_bytes();p.write_text(json.dumps(dict(path=str(root/'dotnet/wasi-sdk')))+'\n')
receipt=dict(at=datetime.now(timezone.utc).isoformat(),uid=os.getuid(),root=str(root),managed=rows,upstreamInputs=INPUTS,wasiPathRelocation=dict(originalSha256=hashlib.sha256(before).hexdigest(),newSha256=hashlib.sha256(p.read_bytes()).hexdigest()),sourceCheckoutMutated=False,compilersNotYetExecuted=True,newCompilationQualification=False)
(root/'stage-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
