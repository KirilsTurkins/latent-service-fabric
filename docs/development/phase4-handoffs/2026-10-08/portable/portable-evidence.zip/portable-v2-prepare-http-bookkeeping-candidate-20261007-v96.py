﻿from pathlib import Path
import json
repo=Path(r'C:\Users\turkins\Desktop\lf-p4-http-deferred-admission-v96')
p=repo/'crates/latent-capabilities/src/broker/pools/deferred.rs';s=p.read_text();s=s.replace('use super::{IngressRequest, MaintenanceRequest, PlatformError, ProviderClient, ProviderPools};','use super::{\n    client::ClientCore, IngressRequest, MaintenanceRequest, PlatformError, ProviderClient, ProviderPools,\n};')
needle='impl DeferredRequest {\n';insert='''impl DeferredRequest {
    /// Borrow only the already-sealed physical request. No new admission,
    /// running slot, deadline or protocol-operation allowance is created.
    pub(super) fn connection_owners(
        &self,
        client: &Arc<ClientCore>,
    ) -> Result<(Option<MaintenanceRequest>, Option<IngressRequest>), PlatformError> {
        match &self.request {
            Request::Execute(request) => {
                request.check_client(client)?;
                Ok((None, Some(request.clone())))
            }
            Request::Reconcile(request) => {
                request.check_client(client)?;
                Ok((Some(request.clone()), None))
            }
        }
    }
''';assert s.count(needle)==1;s=s.replace(needle,insert);p.write_text(s,newline='\n')
p=repo/'crates/latent-capabilities/src/broker/pools/client/admission.rs';s=p.read_text();s=s.replace('Arc, ConnectionReservation, PlatformError, PoolCall, PooledConnection, ProviderClient,','Arc, ConnectionReservation, PlatformError, PoolCall, PooledConnection, ProviderClient,');s=s.replace('use std::sync::{Mutex, MutexGuard, TryLockError};','use super::super::DeferredRequest;\nuse std::sync::{Mutex, MutexGuard, TryLockError};')
append='''
impl<T: Send + 'static> ProviderClient<T> {
    /// Wait only for unacquired idle bookkeeping under the original request.
    /// Fresh reconciliation never borrows an idle guest connection.
    pub async fn checkout_deferred_wait(
        self: &Arc<Self>,
        request: &DeferredRequest,
    ) -> Result<Option<PooledConnection<T>>, PlatformError> {
        loop {
            let (maintenance, ingress) = request.connection_owners(&self.core)?;
            if maintenance.is_some() {
                return Ok(None);
            }
            match self.checkout_owned(None, ingress) {
                Ok(value) => return Ok(value),
                Err(ClientAccessError::Failed(error)) => return Err(error),
                Err(ClientAccessError::Contended) => {
                    request
                        .wait_for(tokio::time::sleep(Duration::from_millis(1)))
                        .await?;
                }
            }
        }
    }

    /// Reuse the accepted request's immutable deadline while bookkeeping is
    /// held by maintenance/status inspection. Reserve once after access; actual
    /// capacity, active dial, backoff and poison retain their immediate refusals.
    /// This never repeats any protocol operation or allocates another request.
    pub async fn reserve_deferred_connection_wait(
        self: &Arc<Self>,
        request: &DeferredRequest,
    ) -> Result<ConnectionReservation<T>, PlatformError> {
        loop {
            let (maintenance, ingress) = request.connection_owners(&self.core)?;
            match self.reserve_owned(None, maintenance, ingress) {
                Ok(value) => return Ok(value),
                Err(ClientAccessError::Failed(error)) => return Err(error),
                Err(ClientAccessError::Contended) => {
                    request
                        .wait_for(tokio::time::sleep(Duration::from_millis(1)))
                        .await?;
                }
            }
        }
    }
}
'''
s+=append;p.write_text(s,newline='\n')
p=repo/'crates/latent-http/src/network.rs';s=p.read_text();assert s.count('client.checkout_deferred(request)?')==1 and s.count('client.reserve_deferred_connection(request)?')==1
s=s.replace('client.checkout_deferred(request)?','client.checkout_deferred_wait(request).await?').replace('client.reserve_deferred_connection(request)?','client.reserve_deferred_connection_wait(request).await?');p.write_text(s,newline='\n')
# Keep original cases/helpers intact and add a distinct real request regression module.
p=repo/'crates/latent-capabilities/src/broker/pools/tests/deferred.rs';s=p.read_text();assert 'mod admission;' not in s;s+='\nmod admission;\n';p.write_text(s,newline='\n')
p=repo/'crates/latent-capabilities/src/broker/pools/tests/deferred/admission.rs';p.parent.mkdir(exist_ok=True)
existing=(repo/'crates/latent-capabilities/src/broker/pools/tests/deferred.rs').read_text();start=existing.index('fn grant(');end=existing.index('\n#[tokio::test]',start);helper=existing[start:end]
helper=helper.replace('fn grant(provider: &str, tenant: &str) -> (DispatchContext, DispatchGrant) {','fn original_grant(lookup: bool, deadline: Option<Instant>) -> (DispatchContext, DispatchGrant) {\n    let provider = "secrets";\n    let tenant = "tenant-a";')
needle='    let mut context = owner.accept(&authority, 1, time).unwrap();';assert needle in helper
helper=helper.replace(needle,'''    let mut context = if lookup {
        owner
            .accept_lookup(
                &authority,
                1,
                time,
                deadline.unwrap_or_else(|| Instant::now() + Duration::from_secs(1)),
                Arc::new(LookupPermission),
            )
            .unwrap()
    } else {
        let mut context = owner.accept(&authority, 1, time).unwrap();
        if let Some(deadline) = deadline {
            context.tighten_deadline(deadline).unwrap();
        }
        context
    };''')
imports='''use super::*;
use crate::broker::pools::{limits::Kind, DeferredRequest};
use latent_core::PlatformErrorCode;
use latent_effects::authority::{AuthorityError, ProviderLookupAuthorization};
use std::time::Instant;

struct LookupPermission;
impl ProviderLookupAuthorization for LookupPermission {
    fn with_current(
        &self,
        accept: &mut dyn FnMut() -> Result<(), AuthorityError>,
    ) -> Result<(), AuthorityError> {
        accept()
    }
    fn with_live(
        &self,
        accept: &mut dyn FnMut() -> Result<(), AuthorityError>,
    ) -> Result<(), AuthorityError> {
        accept()
    }
}

'''
fixture='''
fn request(
    setup: &Setup,
    lookup: bool,
    deadline: Option<Instant>,
) -> (DispatchContext, DeferredRequest) {
    let (context, grant) = original_grant(lookup, deadline);
    let request = setup.pools.deferred(&setup.client, grant, 2, 16384).unwrap();
    (context, request)
}

'''
p.write_text(imports+helper+fixture,encoding='utf8',newline='\n')
print('Applied three production paths and separate regression fixture; original immediate APIs and existing test bodies untouched.')
