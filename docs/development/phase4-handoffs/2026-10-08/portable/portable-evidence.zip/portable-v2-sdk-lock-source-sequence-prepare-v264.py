from pathlib import Path

COORD=Path(__file__).resolve().parent
source=(COORD/'portable-v2-owned-signing-source-sequence-v239.py').read_text(encoding='utf8')
source=source.replace('v239','v264')
source=source.replace("previous='portable-v2-pr796-final-main-source-20261008-v234'","previous='portable-v2-pr784-final-main-source-20261008-v252'")
source=source.replace('for number in (790,800,791,787,796,784,825,811):','for number in (800,811,828):')
needle="    record=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-union-v238/receipt.json')).read_bytes())"
replacement="""    if number==800:
        record={'head':'592db6f7b7a677a0a5a502e82d4333776ca71d6e'}
    elif number==811:
        record=json.loads((COORD/'portable-v2-pr811-derived-six-lock-child-v263.json').read_bytes())
    else:
        record=json.loads((COORD/'portable-v2-pr828-current-prep-diagnostic-prepared-v257.json').read_bytes())"""
assert source.count(needle)==1
source=source.replace(needle,replacement)
old="    else:\n        steps=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-source-steps-v222.json')).read_bytes())"
new="""    elif number==828:
        steps=json.loads((COORD/'integration-v12-union-review/current-http-native-source-steps.json').read_bytes())
    else:
        steps=json.loads((COORD/('portable-v2-pr'+str(number)+'-current-main-source-steps-v222.json')).read_bytes())"""
assert source.count(old)==1
source=source.replace(old,new)
path=COORD/'portable-v2-sdk-lock-source-sequence-v264.py'
compile(source,str(path),'exec')
assert not path.exists()
path.write_text(source,encoding='utf8')
print(str(path))
