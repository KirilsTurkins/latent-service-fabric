from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

TREE=Path(r'C:\Users\turkins\Desktop\lf-p4-pr828-current-prep-diag-v257')
COORD=Path(__file__).resolve().parent
PARENT='0a637ba7844c7fe461873d0fa783bca8166f4971'
DIAG='1da58713c254b81501c1594dac68f9d15ec104a8'
def git(*args):return subprocess.check_output(['git','-C',str(TREE),*args])
assert not git('ls-files','-u')
rows={r['id']:r for r in json.loads(git('show',':tools/ci/suites.json'))['suites']}
for head in (PARENT,DIAG):
    for old in json.loads(git('show',head+':tools/ci/suites.json'))['suites']:
        new=rows[old['id']]
        assert old['minimumCases']<=new['minimumCases']
        for key in ('expectedCases','expectedIgnored','ignoredLeaves','expectedCustomCases','prerequisites'):
            assert set(old.get(key,[]))<=set(new.get(key,[]))
assert rows['latent-wasmtime.test.aot-sandbox']['minimumCases']==1
assert rows['latent-wasmtime.test.local-service-diagnostics']['minimumCases']==10
assert rows['latent-signing.lib.latent-signing']['minimumCases']==58
git('diff','--cached','--check')
git('commit','-m','merge current HTTP foundation into closed preparation diagnostics')
head=git('rev-parse','HEAD').decode().strip()
paths=git('diff','--name-only',PARENT,head).decode().splitlines()
assert set(paths)=={'crates/latent-wasmtime/tests/local_service/diagnostics/reason.rs','crates/latent-wasmtime/tests/local_service_diagnostics.rs','tools/ci/suites.json'},paths
proof=dict(at=datetime.now(timezone.utc).isoformat(),pr=828,head=head,currentParent=PARENT,diagnosticParent=DIAG,tree=str(TREE),
           allCurrentProductionBytesPreserved=True,testOnlyClosedReasonsAndOneAdditiveSignatureCase=True,
           originalCases8to9to10AllPreserved=True,signing58AndAOT1Preserved=True,
           allGuest10BodiesLimitsAndRetainedComponentsUntouched=True,sourceAndNativePending=True,noCauseOrRepairClaim=True,noPublication=True)
(COORD/'portable-v2-pr828-current-prep-diagnostic-prepared-v257.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof,indent=2))
