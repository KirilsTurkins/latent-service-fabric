use std::sync::{Arc, Mutex, OnceLock};

use super::startup_memory::{InitializationMemory, ResidentMemory};
use super::{ProtectedFencedStoreError, ProtectedStoreConfig, ProtectedStoreError};
use crate::embedded::{
    AtomicBatch, EmbeddedStore, Family, FencedStoreError, ReadView, RowKey, StoreError,
    StoreFileStatus,
};
use crate::store_io::{StoreIoError, StoreIoKind};

#[derive(Default)]
pub(super) struct FailureLatch {
    error: Mutex<Option<ProtectedStoreError>>,
    gate: OnceLock<Box<dyn Fn(StoreIoError) + Send + Sync>>,
}

impl FailureLatch {
    pub fn get(&self) -> Option<ProtectedStoreError> {
        *self
            .error
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
    }

    pub fn install(&self, gate: impl Fn(StoreIoError) + Send + Sync + 'static) {
        let _ = self.gate.set(Box::new(gate));
    }

    pub fn record(&self, error: ProtectedStoreError) {
        {
            let mut first = self
                .error
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner);
            first.get_or_insert(error);
        }
        if let Some(gate) = self.gate.get() {
            gate(StoreIoError::RecoveryRequired);
        }
    }
}

pub(super) struct PhysicalStore {
    engine: Option<EmbeddedStore>,
    pub(super) status: StoreFileStatus,
    failure: Arc<FailureLatch>,
    pub(super) dispatcher: Arc<std::sync::atomic::AtomicBool>,
<<<<<<< HEAD
    pub(super) fresh_identity: Mutex<Option<crate::store_identity::StoreIdentity>>,
=======
>>>>>>> 7ccc3291d22a78644f059beaea2bf5067bd364ed
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    root: latent_protected_files::ProtectedRoot,
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    fence: latent_protected_files::ProtectedMutableFile,
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    root_lock: std::fs::File,
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    lock_fence: latent_protected_files::ProtectedMutableFile,
    #[cfg(all(test, target_os = "linux", target_arch = "x86_64"))]
    drop_probe: Mutex<Option<Box<dyn FnOnce() + Send>>>,
    // Last: original global memory outlives every native resource destructor.
    _resident_memory: Option<ResidentMemory>,
}

impl PhysicalStore {
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    pub fn initialize(
        config: &ProtectedStoreConfig,
        failure: Arc<FailureLatch>,
        validator: impl FnOnce(&ReadView) -> Result<(), StoreError>,
        identity: Option<crate::store_identity::StoreIdentity>,
        resident_memory: Option<ResidentMemory>,
        initialization_memory: Option<&InitializationMemory>,
    ) -> Result<Self, ProtectedStoreError> {
        use latent_protected_files::ProtectedRoot;
        check_initialization(initialization_memory)?;
        let root =
            ProtectedRoot::open(&config.root).map_err(|_| ProtectedStoreError::UnsafeRoot)?;
        if root
            .filesystem_type()
            .map_err(|_| ProtectedStoreError::UnsafeRoot)?
            != 0xef53
        {
            return Err(ProtectedStoreError::UnsupportedFilesystem);
        }
        // Engine-file locking alone would allow two configured leaf names to
        // establish distinct databases in one supposedly exclusive node root.
        let (root_lock, lock_fence) = root
            .open_mutable_file("transaction-owner.lock", 1, true)
            .map_err(|_| ProtectedStoreError::UnsafeRoot)?;
        root_lock
            .try_lock()
            .map_err(|_| ProtectedStoreError::Store(StoreError::Unavailable))?;
        let (file, fence) = root
            .open_mutable_file(
                &config.file_name,
                config.maximum_file_bytes,
                config.create_if_missing,
            )
            .map_err(|_| ProtectedStoreError::UnsafeRoot)?;
        check_initialization(initialization_memory)?;
        let (engine, status) =
            EmbeddedStore::open_bounded_file(file, config.engine, config.maximum_file_bytes)
                .map_err(ProtectedStoreError::Store)?;
        {
            let view = engine.snapshot().map_err(ProtectedStoreError::Store)?;
            validator(&view).map_err(ProtectedStoreError::Store)?;
        }
        check_initialization(initialization_memory)?;
        // The engine is still private to its single initializer. No read/job,
        // command or dispatcher consumer can race the coherent empty-store
        // check and actual identity transaction before readiness publication.
        let fresh_identity = if let Some(identity) = identity {
            let batch = identity
                .prepare_initialization(&engine.snapshot().map_err(ProtectedStoreError::Store)?)
                .map_err(ProtectedStoreError::Store)?;
            if let Some(batch) = batch {
                root.check_mutable_file(&lock_fence)
                    .map_err(|_| ProtectedStoreError::UnsafeRoot)?;
                root.check_mutable_file(&fence)
                    .map_err(|_| ProtectedStoreError::UnsafeRoot)?;
                engine
                    .apply_fenced(batch, || check_initialization(initialization_memory))
                    .map_err(|error| match error {
                        FencedStoreError::Store(error) => ProtectedStoreError::Store(error),
                        FencedStoreError::Fence(error) => error,
                    })?;
                Some(identity)
            } else {
                None
            }
        } else {
            None
        };
        let post_identity_root_error = if fresh_identity.is_some() {
            ProtectedStoreError::CommitUncertain
        } else {
            ProtectedStoreError::UnsafeRoot
        };
        root.check_mutable_file(&lock_fence)
            .map_err(|_| post_identity_root_error)?;
        root.check_mutable_file(&fence)
            .map_err(|_| post_identity_root_error)?;
        check_initialization(initialization_memory).map_err(|error| {
            if fresh_identity.is_some() {
                ProtectedStoreError::CommitUncertain
            } else {
                error
            }
        })?;
        Ok(Self {
            engine: Some(engine),
            status,
            failure,
            dispatcher: Arc::new(std::sync::atomic::AtomicBool::new(false)),
<<<<<<< HEAD
            // Set only after the real identity apply and both original root
            // fences above succeeded. Reopen equality never grants Fresh.
            fresh_identity: Mutex::new(fresh_identity),
=======
>>>>>>> 7ccc3291d22a78644f059beaea2bf5067bd364ed
            root,
            fence,
            root_lock,
            lock_fence,
            #[cfg(test)]
            drop_probe: Mutex::new(None),
            _resident_memory: resident_memory,
        })
    }

    #[cfg(not(all(target_os = "linux", target_arch = "x86_64")))]
    pub fn initialize(
        _: &ProtectedStoreConfig,
        _: Arc<FailureLatch>,
        _: impl FnOnce(&ReadView) -> Result<(), StoreError>,
        _: Option<crate::store_identity::StoreIdentity>,
        _: Option<ResidentMemory>,
        _: Option<&InitializationMemory>,
    ) -> Result<Self, ProtectedStoreError> {
        Err(ProtectedStoreError::UnsupportedPlatform)
    }

    pub fn engine(&self) -> &EmbeddedStore {
        self.engine.as_ref().expect("worker-owned live engine")
    }

    #[cfg_attr(
        not(all(target_os = "linux", target_arch = "x86_64")),
        allow(clippy::unused_self)
    )]
    pub(super) fn ensure_state_mode_marker(
        &self,
        identity: &crate::store_identity::StoreIdentity,
        original: &latent_core::native_capacity::NativeReservation,
        before_native_retirement: impl FnOnce(),
    ) -> Result<super::mode::StateModeObservation, StoreError> {
        #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
        {
            let view = self.engine().snapshot()?;
            let stored_identity = view
                .get_bounded(
                    &crate::store_identity::StoreIdentity::row_key(),
                    crate::store_identity::MAXIMUM_ENCODED_BYTES,
                )?
                .as_deref()
                .map(crate::store_identity::StoreIdentity::decode)
                .transpose()?;
            if stored_identity.as_ref() != Some(identity) {
                return Err(StoreError::Conflict);
            }
            // This metadata is set only after the actual exclusive initializer
            // applied its identity batch and checked the retained root fences.
            // Reopen equality never sets it. The checkpoint consumes it later.
            let actual_fresh_identity = self
                .fresh_identity
                .lock()
                .map_err(|_| StoreError::Unavailable)?
                .as_ref()
                == Some(identity);
            if actual_fresh_identity {
                // Fresh initialization is not permission to create a marker
                // after trusted startup code has already written business or
                // dispatcher rows. Use this same coherent view and bounded
                // indexed existence checks before any mode file I/O.
                super::mode::require_initializer_only(&view, identity)?;
            }
            drop(view);
            super::mode::ensure_native(
                &self.root,
                identity,
                actual_fresh_identity,
                original,
                before_native_retirement,
            )
        }
        #[cfg(not(all(target_os = "linux", target_arch = "x86_64")))]
        {
            let _unused = (identity, original, before_native_retirement);
            Err(StoreError::UnsupportedFormat)
        }
    }

    #[cfg(all(test, target_os = "linux", target_arch = "x86_64"))]
    pub(super) fn install_drop_probe(&self, probe: impl FnOnce() + Send + 'static) {
        let mut selected = self.drop_probe.lock().unwrap();
        assert!(selected.is_none(), "one bounded native destruction probe");
        *selected = Some(Box::new(probe));
    }

    /// Protected descriptor identity metadata only. The root itself never
    /// escapes a fixed worker or becomes caller-provided confinement evidence.
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    pub(super) fn root_identity(&self) -> Result<(u64, u64), ProtectedStoreError> {
        self.check()?;
        Ok(self.root.identity())
    }

    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    pub(super) fn is_separate_root(
        &self,
        other: &latent_protected_files::ProtectedRoot,
    ) -> Result<bool, ProtectedStoreError> {
        self.check()?;
        self.root
            .is_separate_from(other)
            .map_err(|_| ProtectedStoreError::UnsafeRoot)
    }

    pub fn check(&self) -> Result<(), ProtectedStoreError> {
        if let Some(error) = self.failure.get() {
            return Err(error);
        }
        self.check_root()
            .inspect_err(|error| self.failure.record(*error))
    }

    #[cfg_attr(
        not(all(target_os = "linux", target_arch = "x86_64")),
        allow(clippy::unused_self)
    )]
    fn check_root(&self) -> Result<(), ProtectedStoreError> {
        #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
        {
            self.root
                .check_mutable_file(&self.lock_fence)
                .map_err(|_| ProtectedStoreError::UnsafeRoot)?;
            self.root
                .check_mutable_file(&self.fence)
                .map_err(|_| ProtectedStoreError::UnsafeRoot)
        }
        #[cfg(not(all(target_os = "linux", target_arch = "x86_64")))]
        {
            Err(ProtectedStoreError::UnsupportedPlatform)
        }
    }

    pub fn classify<T>(&self, result: Result<T, StoreError>) -> Result<T, ProtectedStoreError> {
        result.map_err(|error| {
            let error = ProtectedStoreError::Store(error);
            if matches!(
                error,
                ProtectedStoreError::Store(
                    StoreError::Corrupt
                        | StoreError::UnsupportedFormat
                        | StoreError::Unavailable
                        | StoreError::CommitUncertain
                )
            ) {
                self.failure.record(error);
            }
            error
        })
    }

    pub fn apply(&self, batch: AtomicBatch) -> Result<(), ProtectedStoreError> {
        match self.apply_fenced(batch, || Ok::<(), std::convert::Infallible>(())) {
            Ok(()) => Ok(()),
            Err(ProtectedFencedStoreError::Store(error)) => Err(error),
            Err(ProtectedFencedStoreError::Fence(impossible)) => match impossible {},
        }
    }

    pub fn with_store<T>(
        &self,
        kind: StoreIoKind,
        operation: impl FnOnce(&EmbeddedStore) -> Result<T, StoreError>,
    ) -> Result<T, ProtectedStoreError> {
        self.check()?;
        let result = self.classify(operation(self.engine()));
        if self.check_root().is_err() {
            let error = if kind.is_write() && result.is_ok() {
                ProtectedStoreError::CommitUncertain
            } else {
                ProtectedStoreError::UnsafeRoot
            };
            self.failure.record(error);
            return Err(error);
        }
        result
    }

    pub fn apply_fenced<E>(
        &self,
        batch: AtomicBatch,
        fence: impl FnOnce() -> Result<(), E>,
    ) -> Result<(), ProtectedFencedStoreError<E>> {
        self.check().map_err(ProtectedFencedStoreError::Store)?;
        match self.engine().apply_fenced(batch, fence) {
            Ok(()) => {
                if self.check_root().is_err() {
                    self.failure.record(ProtectedStoreError::CommitUncertain);
                    return Err(ProtectedFencedStoreError::Store(
                        ProtectedStoreError::CommitUncertain,
                    ));
                }
                Ok(())
            }
            Err(FencedStoreError::Store(error)) => Err(ProtectedFencedStoreError::Store(
                self.classify::<()>(Err(error)).unwrap_err(),
            )),
            Err(FencedStoreError::Fence(error)) => {
                self.check().map_err(ProtectedFencedStoreError::Store)?;
                Err(ProtectedFencedStoreError::Fence(error))
            }
        }
    }

    pub fn finalize(&self) -> Result<(), StoreIoError> {
        if self.engine().live_views() != 0 {
            self.failure
                .record(ProtectedStoreError::Io(StoreIoError::RecoveryRequired));
            return Err(StoreIoError::FinalizationFailed);
        }
        // An immediate empty transaction is a flush barrier after all jobs.
        self.apply(AtomicBatch::default())
            .map_err(|_| StoreIoError::FinalizationFailed)
    }
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn check_initialization(memory: Option<&InitializationMemory>) -> Result<(), ProtectedStoreError> {
    memory.map_or(Ok(()), InitializationMemory::check)
}

pub(super) fn validate_records(
    view: &ReadView,
    validator: &mut impl FnMut(&RowKey, &[u8]) -> Result<(), StoreError>,
) -> Result<(), StoreError> {
    for family in [
        Family::Namespace,
        Family::State,
        Family::Tombstone,
        Family::Command,
        Family::Result,
        Family::Outbox,
        Family::Attempt,
        Family::Inbox,
        Family::PayloadReference,
        Family::Maintenance,
    ] {
        let mut resume = None;
        loop {
            let page = view.scan_after(family, &[], resume.as_deref(), 256, 4 * 1024 * 1024)?;
            for (key, value) in &page.rows {
                validator(key, value)?;
            }
            resume = page.resume;
            if resume.is_none() {
                break;
            }
        }
    }
    Ok(())
}

impl Drop for PhysicalStore {
    fn drop(&mut self) {
        #[cfg(all(test, target_os = "linux", target_arch = "x86_64"))]
        {
            let probe = self.drop_probe.lock().unwrap().take();
            if let Some(probe) = probe {
                probe();
            }
        }
        drop(self.engine.take());
        // The root lock outlives actual engine destruction, including its final
        // native flush. Release failure cannot be reported as a clean drain.
        #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
        if self.root_lock.unlock().is_err() {
            self.failure
                .record(ProtectedStoreError::Io(StoreIoError::FinalizationFailed));
        }
        if self.status.close_failed() || !self.status.close_observed() {
            self.failure
                .record(ProtectedStoreError::Io(StoreIoError::FinalizationFailed));
        }
    }
}
