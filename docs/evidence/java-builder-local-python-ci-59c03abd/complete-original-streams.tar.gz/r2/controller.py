from pathlib import Path
import os,subprocess,time,json,sys,shutil
SOURCE='59c03abd1fbf2bcc39430ebe9866eb5ab23ee020';root=Path('/tmp/local-repository785-59-r2');root.mkdir(mode=0o700);source=root/'source';home=root/'home';home.mkdir(mode=0o700);cargo=root/'cargo';cargo.mkdir(mode=0o700);out=Path('/output');start=time.monotonic();stages=[]
os.environ.update(HOME=str(home),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',CARGO_HOME=str(cargo),CARGO_TARGET_DIR=str(source/'target'),CARGO_BUILD_JOBS='2',RUSTUP_TOOLCHAIN='1.97.1',CI='true',GITHUB_ACTIONS='true',GITHUB_SHA=SOURCE,CI_CONTRACT_LANE='python',RUNNER_TEMP=str(out),LSF_REQUIRE_NATIVE_PROCESS_TESTS='1',LSF_REQUIRE_COMPILER_ISOLATION='1')
config=root/'gitconfig';config.write_text('[safe]\n\tdirectory = /repository\n\tdirectory = /repository/.git\n');os.environ['GIT_CONFIG_GLOBAL']=str(config)
receipt={'sourceHead':SOURCE,'job':'contracts','lane':'python','originalRunBlock':'tools/validate_contracts.sh "$CI_CONTRACT_LANE"','fullRepositoryCiPassed':False,'image':'sha256:c19db1b2bb887c214b87d05aa7f15a6d2108758fa4f2cf04d09bddce8a627502','seccomp':'unconfined','extraCapabilities':[],'missingToolsFailClosed':True,'runBlockPassed':False,'sharedNativeCacheUsed':False,'stages':stages,'actualOsRelease':Path('/etc/os-release').read_text(),'actualPythonVersion':sys.version,'uid':os.geteuid(),'tools':{n:shutil.which(n) for n in ['cargo','rustc','node','javac','go','dotnet','wasm-tools','buf','zig','wit-bindgen']}}
def save():
 receipt['seconds']=round(time.monotonic()-start,6);(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(stage,args,cwd=None):
 now=time.monotonic();r=subprocess.run(args,cwd=cwd,capture_output=True,timeout=1800-(time.monotonic()-start));assert len(r.stdout)+len(r.stderr)<=64*1024*1024
 for suffix,payload in [('stdout',r.stdout),('stderr',r.stderr)]:(out/(stage+'.'+suffix+'.log')).write_bytes(payload)
 stages.append({'stage':stage,'command':args,'seconds':round(time.monotonic()-now,6),'exitCode':r.returncode});save();print(stage+' exit='+str(r.returncode),flush=True);assert r.returncode==0,(stage,r.stderr.decode(errors='replace')[-5000:])
try:
 assert os.geteuid()==23001 and sys.version_info[:3]==(3,13,5)
 run('clone',['git','clone','--shared','--no-checkout','/repository',str(source)])
 run('checkout',['git','checkout','--detach',SOURCE],source)
 assert source.resolve().is_relative_to(root.resolve()) and (source/'target/contracts').resolve().is_relative_to(source.resolve())
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD']).decode().strip()==SOURCE and not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
 run('original-python-contracts',['bash','-e','-o','pipefail','-c','tools/validate_contracts.sh "$CI_CONTRACT_LANE"'],source)
 receipt.update(runBlockPassed=True,trackedSourceUnchanged=not bool(subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no'])))
except BaseException as error:receipt['failedReason']=str(error);raise
finally:save()
