from pathlib import Path
import sys,tempfile,shutil,json
sys.path.insert(0,'/source')
from tools.captured_compiler_isolation import Isolation
from tools.build_process import run_bounded_result
with tempfile.TemporaryDirectory() as temp:
 work=Path(temp)/'selected';work.mkdir();selected=work/'selected.bin';selected.write_bytes(b'captured');cat=Path(shutil.which('cat')).resolve();isolation=Isolation(work,{'cat':cat},{})
 command=isolation.wrap(cat,[str(selected)],work,{'PATH':'/usr/bin:/bin'})
 r=run_bounded_result(command,work,{'PATH':'/usr/bin:/bin'},5,16384)
 data={'returncode':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace'),'actualUid':__import__('os').geteuid()};Path('/output/namespace-probe.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))
