/* Generated from authoritative WIT. DO NOT EDIT. */
#include "bridge.h"
uint64_t exports_latent_java_guest_check_identity(uint64_t arg0) {
lsf_wire output = {0};
lsf_put(&output, (uint64_t)(arg0), 8);
void *owned; lsf_wire input = lsf_invoke(0, &output, &owned);
uint64_t result = {0};
uint64_t local_3 = lsf_get(&input, 8);  (result) = (__typeof__((result)))local_3;
lsf_finish(&input); lsf_java_free(owned);
return result;
}
void *lsf_java_host(int32_t operation, void *bytes, int32_t length) {
lsf_require(length >= 0 && (uint32_t)length <= LSF_MAX_BYTES);
lsf_wire input = {bytes, (size_t)length, 0, (size_t)length}; lsf_wire output = {0};
switch (operation) {
case 0: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_monotonic_now_nanos();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 1: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_wall_now_unix_millis();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 2: {
uint32_t arg0 = {0};
uint64_t local_8 = lsf_get(&input, 4);  (arg0) = (__typeof__((arg0)))local_8;
lsf_finish(&input);
latent_random_random_result_list_u8_random_error_t result = {0};
latent_random_random_bytes(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
default: __builtin_trap(); }
} else {
lsf_require(((result).val.ok).len <= LSF_MAX_BYTES); lsf_put(&output, ((result).val.ok).len, 4);
for (size_t local_17 = 0; local_17 < ((result).val.ok).len; local_17++) {
lsf_put(&output, (uint64_t)(((result).val.ok).ptr[local_17]), 1);
}
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
default: __builtin_trap(); }
} else {
for (size_t local_25 = 0; local_25 < ((result).val.ok).len; local_25++) {
}
lsf_release(((result).val.ok).ptr, ((result).val.ok).len * sizeof(*((result).val.ok).ptr)); ((result).val.ok).ptr = NULL; ((result).val.ok).len = 0;
}
break; }
case 3: {
lsf_finish(&input);
latent_random_random_result_u64_random_error_t result = {0};
latent_random_random_u64_value(&result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)((result).val.ok), 8);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 4: {
probe_string_t arg0 = {0};
(arg0).len = (size_t)lsf_get(&input, 4);
lsf_require((arg0).len <= LSF_MAX_BYTES);
(arg0).ptr = lsf_allocate((arg0).len, 1);
for (size_t local_42 = 0; local_42 < (arg0).len; local_42++) (arg0).ptr[local_42] = (uint8_t)lsf_get(&input, 1);
probe_option_u64_t arg1 = {0};
uint64_t local_44 = lsf_get(&input, 1); lsf_require(local_44 <= 1); ((arg1).is_some) = (__typeof__(((arg1).is_some)))local_44;
if ((arg1).is_some) {
uint64_t local_45 = lsf_get(&input, 8);  ((arg1).val) = (__typeof__(((arg1).val)))local_45;
}
lsf_finish(&input);
latent_blob_blob_result_blob_handle_blob_error_t result = {0};
latent_blob_blob_create(&arg0, &arg1, &result);
lsf_release((arg0).ptr, (arg0).len); (arg0).ptr = NULL; (arg0).len = 0;
if ((arg1).is_some) {
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)(((result).val.ok)), 8);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 5: {
latent_blob_blob_blob_reference_t arg0 = {0};
((arg0).digest).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).digest).len <= LSF_MAX_BYTES);
((arg0).digest).ptr = lsf_allocate(((arg0).digest).len, 1);
for (size_t local_82 = 0; local_82 < ((arg0).digest).len; local_82++) ((arg0).digest).ptr[local_82] = (uint8_t)lsf_get(&input, 1);
uint64_t local_83 = lsf_get(&input, 8);  ((arg0).size) = (__typeof__(((arg0).size)))local_83;
((arg0).media_type).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).media_type).len <= LSF_MAX_BYTES);
((arg0).media_type).ptr = lsf_allocate(((arg0).media_type).len, 1);
for (size_t local_84 = 0; local_84 < ((arg0).media_type).len; local_84++) ((arg0).media_type).ptr[local_84] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input);
latent_blob_blob_result_blob_handle_blob_error_t result = {0};
latent_blob_blob_open(&arg0, &result);
lsf_release(((arg0).digest).ptr, ((arg0).digest).len); ((arg0).digest).ptr = NULL; ((arg0).digest).len = 0;
lsf_release(((arg0).media_type).ptr, ((arg0).media_type).len); ((arg0).media_type).ptr = NULL; ((arg0).media_type).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)(((result).val.ok)), 8);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 6: {
latent_blob_blob_blob_handle_t arg0 = {0};
uint64_t local_121 = lsf_get(&input, 8);  ((arg0)) = (__typeof__(((arg0))))local_121;
uint64_t arg1 = {0};
uint64_t local_122 = lsf_get(&input, 8);  (arg1) = (__typeof__((arg1)))local_122;
probe_list_u8_t arg2 = {0};
(arg2).len = (size_t)lsf_get(&input, 4); lsf_require((arg2).len <= LSF_MAX_BYTES);
(arg2).ptr = lsf_allocate((arg2).len, sizeof(*(arg2).ptr));
for (size_t local_123 = 0; local_123 < (arg2).len; local_123++) {
uint64_t local_124 = lsf_get(&input, 1);  ((arg2).ptr[local_123]) = (__typeof__(((arg2).ptr[local_123])))local_124;
}
lsf_finish(&input);
latent_blob_blob_result_u64_blob_error_t result = {0};
latent_blob_blob_write(arg0, arg1, &arg2, &result);
for (size_t local_128 = 0; local_128 < (arg2).len; local_128++) {
}
lsf_release((arg2).ptr, (arg2).len * sizeof(*(arg2).ptr)); (arg2).ptr = NULL; (arg2).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)((result).val.ok), 8);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 7: {
latent_blob_blob_blob_handle_t arg0 = {0};
uint64_t local_160 = lsf_get(&input, 8);  ((arg0)) = (__typeof__(((arg0))))local_160;
uint64_t arg1 = {0};
uint64_t local_161 = lsf_get(&input, 8);  (arg1) = (__typeof__((arg1)))local_161;
uint32_t arg2 = {0};
uint64_t local_162 = lsf_get(&input, 4);  (arg2) = (__typeof__((arg2)))local_162;
lsf_finish(&input);
latent_blob_blob_result_own_chunk_blob_error_t result = {0};
latent_blob_blob_read(arg0, arg1, arg2, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 8: {
latent_blob_blob_borrow_chunk_t arg0 = {0};
uint64_t local_198 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_198;
lsf_finish(&input);
latent_blob_blob_result_list_u8_blob_error_t result = {0};
latent_blob_blob_chunk_bytes(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
lsf_require(((result).val.ok).len <= LSF_MAX_BYTES); lsf_put(&output, ((result).val.ok).len, 4);
for (size_t local_214 = 0; local_214 < ((result).val.ok).len; local_214++) {
lsf_put(&output, (uint64_t)(((result).val.ok).ptr[local_214]), 1);
}
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
for (size_t local_229 = 0; local_229 < ((result).val.ok).len; local_229++) {
}
lsf_release(((result).val.ok).ptr, ((result).val.ok).len * sizeof(*((result).val.ok).ptr)); ((result).val.ok).ptr = NULL; ((result).val.ok).len = 0;
}
break; }
case 9: {
latent_blob_blob_blob_handle_t arg0 = {0};
uint64_t local_232 = lsf_get(&input, 8);  ((arg0)) = (__typeof__(((arg0))))local_232;
lsf_finish(&input);
latent_blob_blob_result_blob_reference_blob_error_t result = {0};
latent_blob_blob_seal(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
lsf_require((((result).val.ok).digest).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).digest).len, 4);
for (size_t local_250 = 0; local_250 < (((result).val.ok).digest).len; local_250++) lsf_put(&output, (((result).val.ok).digest).ptr[local_250], 1);
lsf_put(&output, (uint64_t)(((result).val.ok).size), 8);
lsf_require((((result).val.ok).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).media_type).len, 4);
for (size_t local_252 = 0; local_252 < (((result).val.ok).media_type).len; local_252++) lsf_put(&output, (((result).val.ok).media_type).ptr[local_252], 1);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
lsf_release((((result).val.ok).digest).ptr, (((result).val.ok).digest).len); (((result).val.ok).digest).ptr = NULL; (((result).val.ok).digest).len = 0;
lsf_release((((result).val.ok).media_type).ptr, (((result).val.ok).media_type).len); (((result).val.ok).media_type).ptr = NULL; (((result).val.ok).media_type).len = 0;
}
break; }
case 10: {
latent_blob_blob_blob_handle_t arg0 = {0};
uint64_t local_271 = lsf_get(&input, 8);  ((arg0)) = (__typeof__(((arg0))))local_271;
lsf_finish(&input);
latent_blob_blob_result_bool_blob_error_t result = {0};
latent_blob_blob_close(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)((result).val.ok), 1);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 11: {
probe_string_t arg0 = {0};
(arg0).len = (size_t)lsf_get(&input, 4);
lsf_require((arg0).len <= LSF_MAX_BYTES);
(arg0).ptr = lsf_allocate((arg0).len, 1);
for (size_t local_303 = 0; local_303 < (arg0).len; local_303++) (arg0).ptr[local_303] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input);
latent_secrets_reader_result_secret_value_secret_error_t result = {0};
latent_secrets_reader_read(&arg0, &result);
lsf_release((arg0).ptr, (arg0).len); (arg0).ptr = NULL; (arg0).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
default: __builtin_trap(); }
} else {
lsf_require((((result).val.ok).bytes).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).bytes).len, 4);
for (size_t local_314 = 0; local_314 < (((result).val.ok).bytes).len; local_314++) {
lsf_put(&output, (uint64_t)((((result).val.ok).bytes).ptr[local_314]), 1);
}
lsf_require((((result).val.ok).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).media_type).len, 4);
for (size_t local_316 = 0; local_316 < (((result).val.ok).media_type).len; local_316++) lsf_put(&output, (((result).val.ok).media_type).ptr[local_316], 1);
lsf_put(&output, (uint64_t)((((result).val.ok).version).is_some), 1);
if ((((result).val.ok).version).is_some) {
lsf_require(((((result).val.ok).version).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).version).val).len, 4);
for (size_t local_319 = 0; local_319 < ((((result).val.ok).version).val).len; local_319++) lsf_put(&output, ((((result).val.ok).version).val).ptr[local_319], 1);
}
lsf_put(&output, (uint64_t)((((result).val.ok).expires_at_unix_millis).is_some), 1);
if ((((result).val.ok).expires_at_unix_millis).is_some) {
lsf_put(&output, (uint64_t)((((result).val.ok).expires_at_unix_millis).val), 8);
}
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
default: __builtin_trap(); }
} else {
for (size_t local_331 = 0; local_331 < (((result).val.ok).bytes).len; local_331++) {
}
lsf_release((((result).val.ok).bytes).ptr, (((result).val.ok).bytes).len * sizeof(*(((result).val.ok).bytes).ptr)); (((result).val.ok).bytes).ptr = NULL; (((result).val.ok).bytes).len = 0;
lsf_release((((result).val.ok).media_type).ptr, (((result).val.ok).media_type).len); (((result).val.ok).media_type).ptr = NULL; (((result).val.ok).media_type).len = 0;
if ((((result).val.ok).version).is_some) {
lsf_release(((((result).val.ok).version).val).ptr, ((((result).val.ok).version).val).len); ((((result).val.ok).version).val).ptr = NULL; ((((result).val.ok).version).val).len = 0;
}
if ((((result).val.ok).expires_at_unix_millis).is_some) {
}
}
break; }
case 12: {
latent_events_publisher_event_t arg0 = {0};
((arg0).topic).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).topic).len <= LSF_MAX_BYTES);
((arg0).topic).ptr = lsf_allocate(((arg0).topic).len, 1);
for (size_t local_341 = 0; local_341 < ((arg0).topic).len; local_341++) ((arg0).topic).ptr[local_341] = (uint8_t)lsf_get(&input, 1);
uint64_t local_343 = lsf_get(&input, 1); lsf_require(local_343 <= 1); (((arg0).key).is_some) = (__typeof__((((arg0).key).is_some)))local_343;
if (((arg0).key).is_some) {
(((arg0).key).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).key).val).len <= LSF_MAX_BYTES);
(((arg0).key).val).ptr = lsf_allocate((((arg0).key).val).len, 1);
for (size_t local_344 = 0; local_344 < (((arg0).key).val).len; local_344++) (((arg0).key).val).ptr[local_344] = (uint8_t)lsf_get(&input, 1);
}
((arg0).payload).len = (size_t)lsf_get(&input, 4); lsf_require(((arg0).payload).len <= LSF_MAX_BYTES);
((arg0).payload).ptr = lsf_allocate(((arg0).payload).len, sizeof(*((arg0).payload).ptr));
for (size_t local_345 = 0; local_345 < ((arg0).payload).len; local_345++) {
uint64_t local_346 = lsf_get(&input, 1);  (((arg0).payload).ptr[local_345]) = (__typeof__((((arg0).payload).ptr[local_345])))local_346;
}
((arg0).media_type).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).media_type).len <= LSF_MAX_BYTES);
((arg0).media_type).ptr = lsf_allocate(((arg0).media_type).len, 1);
for (size_t local_347 = 0; local_347 < ((arg0).media_type).len; local_347++) ((arg0).media_type).ptr[local_347] = (uint8_t)lsf_get(&input, 1);
((arg0).attributes).len = lsf_count(&input); lsf_require(((arg0).attributes).len <= LSF_MAX_ITEMS);
((arg0).attributes).ptr = lsf_allocate(((arg0).attributes).len, sizeof(*((arg0).attributes).ptr));
for (size_t local_348 = 0; local_348 < ((arg0).attributes).len; local_348++) {
((((arg0).attributes).ptr[local_348]).f0).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).attributes).ptr[local_348]).f0).len <= LSF_MAX_BYTES);
((((arg0).attributes).ptr[local_348]).f0).ptr = lsf_allocate(((((arg0).attributes).ptr[local_348]).f0).len, 1);
for (size_t local_350 = 0; local_350 < ((((arg0).attributes).ptr[local_348]).f0).len; local_350++) ((((arg0).attributes).ptr[local_348]).f0).ptr[local_350] = (uint8_t)lsf_get(&input, 1);
((((arg0).attributes).ptr[local_348]).f1).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).attributes).ptr[local_348]).f1).len <= LSF_MAX_BYTES);
((((arg0).attributes).ptr[local_348]).f1).ptr = lsf_allocate(((((arg0).attributes).ptr[local_348]).f1).len, 1);
for (size_t local_351 = 0; local_351 < ((((arg0).attributes).ptr[local_348]).f1).len; local_351++) ((((arg0).attributes).ptr[local_348]).f1).ptr[local_351] = (uint8_t)lsf_get(&input, 1);
}
((arg0).idempotency_key).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).idempotency_key).len <= LSF_MAX_BYTES);
((arg0).idempotency_key).ptr = lsf_allocate(((arg0).idempotency_key).len, 1);
for (size_t local_352 = 0; local_352 < ((arg0).idempotency_key).len; local_352++) ((arg0).idempotency_key).ptr[local_352] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input);
latent_events_publisher_result_publish_receipt_event_error_t result = {0};
latent_events_publisher_publish(&arg0, &result);
lsf_release(((arg0).topic).ptr, ((arg0).topic).len); ((arg0).topic).ptr = NULL; ((arg0).topic).len = 0;
if (((arg0).key).is_some) {
lsf_release((((arg0).key).val).ptr, (((arg0).key).val).len); (((arg0).key).val).ptr = NULL; (((arg0).key).val).len = 0;
}
for (size_t local_358 = 0; local_358 < ((arg0).payload).len; local_358++) {
}
lsf_release(((arg0).payload).ptr, ((arg0).payload).len * sizeof(*((arg0).payload).ptr)); ((arg0).payload).ptr = NULL; ((arg0).payload).len = 0;
lsf_release(((arg0).media_type).ptr, ((arg0).media_type).len); ((arg0).media_type).ptr = NULL; ((arg0).media_type).len = 0;
for (size_t local_361 = 0; local_361 < ((arg0).attributes).len; local_361++) {
lsf_release(((((arg0).attributes).ptr[local_361]).f0).ptr, ((((arg0).attributes).ptr[local_361]).f0).len); ((((arg0).attributes).ptr[local_361]).f0).ptr = NULL; ((((arg0).attributes).ptr[local_361]).f0).len = 0;
lsf_release(((((arg0).attributes).ptr[local_361]).f1).ptr, ((((arg0).attributes).ptr[local_361]).f1).len); ((((arg0).attributes).ptr[local_361]).f1).ptr = NULL; ((((arg0).attributes).ptr[local_361]).f1).len = 0;
}
lsf_release(((arg0).attributes).ptr, ((arg0).attributes).len * sizeof(*((arg0).attributes).ptr)); ((arg0).attributes).ptr = NULL; ((arg0).attributes).len = 0;
lsf_release(((arg0).idempotency_key).ptr, ((arg0).idempotency_key).len); ((arg0).idempotency_key).ptr = NULL; ((arg0).idempotency_key).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
default: __builtin_trap(); }
} else {
lsf_require((((result).val.ok).event_id).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).event_id).len, 4);
for (size_t local_379 = 0; local_379 < (((result).val.ok).event_id).len; local_379++) lsf_put(&output, (((result).val.ok).event_id).ptr[local_379], 1);
lsf_put(&output, (uint64_t)(((result).val.ok).accepted_at_unix_millis), 8);
lsf_require((((result).val.ok).stream_name).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).stream_name).len, 4);
for (size_t local_381 = 0; local_381 < (((result).val.ok).stream_name).len; local_381++) lsf_put(&output, (((result).val.ok).stream_name).ptr[local_381], 1);
lsf_put(&output, (uint64_t)(((result).val.ok).sequence), 8);
lsf_put(&output, (uint64_t)(((result).val.ok).duplicate), 1);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
default: __builtin_trap(); }
} else {
lsf_release((((result).val.ok).event_id).ptr, (((result).val.ok).event_id).len); (((result).val.ok).event_id).ptr = NULL; (((result).val.ok).event_id).len = 0;
lsf_release((((result).val.ok).stream_name).ptr, (((result).val.ok).stream_name).len); (((result).val.ok).stream_name).ptr = NULL; (((result).val.ok).stream_name).len = 0;
}
break; }
case 13: {
latent_http_0_2_0_client_request_t arg0 = {0};
uint64_t local_402 = lsf_get(&input, 4); lsf_require(local_402 < 7);
((arg0).method) = (__typeof__(((arg0).method)))local_402;
lsf_require(((arg0).method) < 7);
((arg0).url).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).url).len <= LSF_MAX_BYTES);
((arg0).url).ptr = lsf_allocate(((arg0).url).len, 1);
for (size_t local_403 = 0; local_403 < ((arg0).url).len; local_403++) ((arg0).url).ptr[local_403] = (uint8_t)lsf_get(&input, 1);
((arg0).headers).len = lsf_count(&input); lsf_require(((arg0).headers).len <= LSF_MAX_ITEMS);
((arg0).headers).ptr = lsf_allocate(((arg0).headers).len, sizeof(*((arg0).headers).ptr));
for (size_t local_404 = 0; local_404 < ((arg0).headers).len; local_404++) {
((((arg0).headers).ptr[local_404]).name).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).headers).ptr[local_404]).name).len <= LSF_MAX_BYTES);
((((arg0).headers).ptr[local_404]).name).ptr = lsf_allocate(((((arg0).headers).ptr[local_404]).name).len, 1);
for (size_t local_406 = 0; local_406 < ((((arg0).headers).ptr[local_404]).name).len; local_406++) ((((arg0).headers).ptr[local_404]).name).ptr[local_406] = (uint8_t)lsf_get(&input, 1);
((((arg0).headers).ptr[local_404]).value).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).headers).ptr[local_404]).value).len <= LSF_MAX_BYTES);
((((arg0).headers).ptr[local_404]).value).ptr = lsf_allocate(((((arg0).headers).ptr[local_404]).value).len, 1);
for (size_t local_407 = 0; local_407 < ((((arg0).headers).ptr[local_404]).value).len; local_407++) ((((arg0).headers).ptr[local_404]).value).ptr[local_407] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_409 = lsf_get(&input, 1); lsf_require(local_409 <= 1); (((arg0).body).is_some) = (__typeof__((((arg0).body).is_some)))local_409;
if (((arg0).body).is_some) {
(((arg0).body).val).len = (size_t)lsf_get(&input, 4); lsf_require((((arg0).body).val).len <= LSF_MAX_BYTES);
(((arg0).body).val).ptr = lsf_allocate((((arg0).body).val).len, sizeof(*(((arg0).body).val).ptr));
for (size_t local_410 = 0; local_410 < (((arg0).body).val).len; local_410++) {
uint64_t local_411 = lsf_get(&input, 1);  ((((arg0).body).val).ptr[local_410]) = (__typeof__(((((arg0).body).val).ptr[local_410])))local_411;
}
}
uint64_t local_413 = lsf_get(&input, 1); lsf_require(local_413 <= 1); (((arg0).body_media_type).is_some) = (__typeof__((((arg0).body_media_type).is_some)))local_413;
if (((arg0).body_media_type).is_some) {
(((arg0).body_media_type).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).body_media_type).val).len <= LSF_MAX_BYTES);
(((arg0).body_media_type).val).ptr = lsf_allocate((((arg0).body_media_type).val).len, 1);
for (size_t local_414 = 0; local_414 < (((arg0).body_media_type).val).len; local_414++) (((arg0).body_media_type).val).ptr[local_414] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_416 = lsf_get(&input, 1); lsf_require(local_416 <= 1); (((arg0).idempotency_key).is_some) = (__typeof__((((arg0).idempotency_key).is_some)))local_416;
if (((arg0).idempotency_key).is_some) {
(((arg0).idempotency_key).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).idempotency_key).val).len <= LSF_MAX_BYTES);
(((arg0).idempotency_key).val).ptr = lsf_allocate((((arg0).idempotency_key).val).len, 1);
for (size_t local_417 = 0; local_417 < (((arg0).idempotency_key).val).len; local_417++) (((arg0).idempotency_key).val).ptr[local_417] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_419 = lsf_get(&input, 1); lsf_require(local_419 <= 1); (((arg0).timeout_millis).is_some) = (__typeof__((((arg0).timeout_millis).is_some)))local_419;
if (((arg0).timeout_millis).is_some) {
uint64_t local_420 = lsf_get(&input, 8);  (((arg0).timeout_millis).val) = (__typeof__((((arg0).timeout_millis).val)))local_420;
}
lsf_finish(&input);
latent_http_0_2_0_client_result_response_http_error_t result = {0};
latent_http_0_2_0_client_send(&arg0, &result);
lsf_release(((arg0).url).ptr, ((arg0).url).len); ((arg0).url).ptr = NULL; ((arg0).url).len = 0;
for (size_t local_424 = 0; local_424 < ((arg0).headers).len; local_424++) {
lsf_release(((((arg0).headers).ptr[local_424]).name).ptr, ((((arg0).headers).ptr[local_424]).name).len); ((((arg0).headers).ptr[local_424]).name).ptr = NULL; ((((arg0).headers).ptr[local_424]).name).len = 0;
lsf_release(((((arg0).headers).ptr[local_424]).value).ptr, ((((arg0).headers).ptr[local_424]).value).len); ((((arg0).headers).ptr[local_424]).value).ptr = NULL; ((((arg0).headers).ptr[local_424]).value).len = 0;
}
lsf_release(((arg0).headers).ptr, ((arg0).headers).len * sizeof(*((arg0).headers).ptr)); ((arg0).headers).ptr = NULL; ((arg0).headers).len = 0;
if (((arg0).body).is_some) {
for (size_t local_430 = 0; local_430 < (((arg0).body).val).len; local_430++) {
}
lsf_release((((arg0).body).val).ptr, (((arg0).body).val).len * sizeof(*(((arg0).body).val).ptr)); (((arg0).body).val).ptr = NULL; (((arg0).body).val).len = 0;
}
if (((arg0).body_media_type).is_some) {
lsf_release((((arg0).body_media_type).val).ptr, (((arg0).body_media_type).val).len); (((arg0).body_media_type).val).ptr = NULL; (((arg0).body_media_type).val).len = 0;
}
if (((arg0).idempotency_key).is_some) {
lsf_release((((arg0).idempotency_key).val).ptr, (((arg0).idempotency_key).val).len); (((arg0).idempotency_key).val).ptr = NULL; (((arg0).idempotency_key).val).len = 0;
}
if (((arg0).timeout_millis).is_some) {
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).status), 2);
lsf_require((((result).val.ok).headers).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.ok).headers).len, 4);
for (size_t local_460 = 0; local_460 < (((result).val.ok).headers).len; local_460++) {
lsf_require((((((result).val.ok).headers).ptr[local_460]).name).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).headers).ptr[local_460]).name).len, 4);
for (size_t local_462 = 0; local_462 < (((((result).val.ok).headers).ptr[local_460]).name).len; local_462++) lsf_put(&output, (((((result).val.ok).headers).ptr[local_460]).name).ptr[local_462], 1);
lsf_require((((((result).val.ok).headers).ptr[local_460]).value).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).headers).ptr[local_460]).value).len, 4);
for (size_t local_463 = 0; local_463 < (((((result).val.ok).headers).ptr[local_460]).value).len; local_463++) lsf_put(&output, (((((result).val.ok).headers).ptr[local_460]).value).ptr[local_463], 1);
}
lsf_require((((result).val.ok).body).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).body).len, 4);
for (size_t local_464 = 0; local_464 < (((result).val.ok).body).len; local_464++) {
lsf_put(&output, (uint64_t)((((result).val.ok).body).ptr[local_464]), 1);
}
lsf_put(&output, (uint64_t)((((result).val.ok).body_media_type).is_some), 1);
if ((((result).val.ok).body_media_type).is_some) {
lsf_require(((((result).val.ok).body_media_type).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).body_media_type).val).len, 4);
for (size_t local_468 = 0; local_468 < ((((result).val.ok).body_media_type).val).len; local_468++) lsf_put(&output, ((((result).val.ok).body_media_type).val).ptr[local_468], 1);
}
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
default: __builtin_trap(); }
} else {
for (size_t local_487 = 0; local_487 < (((result).val.ok).headers).len; local_487++) {
lsf_release((((((result).val.ok).headers).ptr[local_487]).name).ptr, (((((result).val.ok).headers).ptr[local_487]).name).len); (((((result).val.ok).headers).ptr[local_487]).name).ptr = NULL; (((((result).val.ok).headers).ptr[local_487]).name).len = 0;
lsf_release((((((result).val.ok).headers).ptr[local_487]).value).ptr, (((((result).val.ok).headers).ptr[local_487]).value).len); (((((result).val.ok).headers).ptr[local_487]).value).ptr = NULL; (((((result).val.ok).headers).ptr[local_487]).value).len = 0;
}
lsf_release((((result).val.ok).headers).ptr, (((result).val.ok).headers).len * sizeof(*(((result).val.ok).headers).ptr)); (((result).val.ok).headers).ptr = NULL; (((result).val.ok).headers).len = 0;
for (size_t local_491 = 0; local_491 < (((result).val.ok).body).len; local_491++) {
}
lsf_release((((result).val.ok).body).ptr, (((result).val.ok).body).len * sizeof(*(((result).val.ok).body).ptr)); (((result).val.ok).body).ptr = NULL; (((result).val.ok).body).len = 0;
if ((((result).val.ok).body_media_type).is_some) {
lsf_release(((((result).val.ok).body_media_type).val).ptr, ((((result).val.ok).body_media_type).val).len); ((((result).val.ok).body_media_type).val).ptr = NULL; ((((result).val.ok).body_media_type).val).len = 0;
}
}
break; }
case 14: {
latent_http_0_3_0_streaming_request_t arg0 = {0};
uint64_t local_497 = lsf_get(&input, 4); lsf_require(local_497 < 7);
((arg0).method) = (__typeof__(((arg0).method)))local_497;
lsf_require(((arg0).method) < 7);
((arg0).url).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).url).len <= LSF_MAX_BYTES);
((arg0).url).ptr = lsf_allocate(((arg0).url).len, 1);
for (size_t local_498 = 0; local_498 < ((arg0).url).len; local_498++) ((arg0).url).ptr[local_498] = (uint8_t)lsf_get(&input, 1);
((arg0).headers).len = lsf_count(&input); lsf_require(((arg0).headers).len <= LSF_MAX_ITEMS);
((arg0).headers).ptr = lsf_allocate(((arg0).headers).len, sizeof(*((arg0).headers).ptr));
for (size_t local_499 = 0; local_499 < ((arg0).headers).len; local_499++) {
((((arg0).headers).ptr[local_499]).name).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).headers).ptr[local_499]).name).len <= LSF_MAX_BYTES);
((((arg0).headers).ptr[local_499]).name).ptr = lsf_allocate(((((arg0).headers).ptr[local_499]).name).len, 1);
for (size_t local_501 = 0; local_501 < ((((arg0).headers).ptr[local_499]).name).len; local_501++) ((((arg0).headers).ptr[local_499]).name).ptr[local_501] = (uint8_t)lsf_get(&input, 1);
((((arg0).headers).ptr[local_499]).value).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).headers).ptr[local_499]).value).len <= LSF_MAX_BYTES);
((((arg0).headers).ptr[local_499]).value).ptr = lsf_allocate(((((arg0).headers).ptr[local_499]).value).len, 1);
for (size_t local_502 = 0; local_502 < ((((arg0).headers).ptr[local_499]).value).len; local_502++) ((((arg0).headers).ptr[local_499]).value).ptr[local_502] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_504 = lsf_get(&input, 1); lsf_require(local_504 <= 1); (((arg0).body_length).is_some) = (__typeof__((((arg0).body_length).is_some)))local_504;
if (((arg0).body_length).is_some) {
uint64_t local_505 = lsf_get(&input, 8);  (((arg0).body_length).val) = (__typeof__((((arg0).body_length).val)))local_505;
}
uint64_t local_507 = lsf_get(&input, 1); lsf_require(local_507 <= 1); (((arg0).body_media_type).is_some) = (__typeof__((((arg0).body_media_type).is_some)))local_507;
if (((arg0).body_media_type).is_some) {
(((arg0).body_media_type).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).body_media_type).val).len <= LSF_MAX_BYTES);
(((arg0).body_media_type).val).ptr = lsf_allocate((((arg0).body_media_type).val).len, 1);
for (size_t local_508 = 0; local_508 < (((arg0).body_media_type).val).len; local_508++) (((arg0).body_media_type).val).ptr[local_508] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_510 = lsf_get(&input, 1); lsf_require(local_510 <= 1); (((arg0).idempotency_key).is_some) = (__typeof__((((arg0).idempotency_key).is_some)))local_510;
if (((arg0).idempotency_key).is_some) {
(((arg0).idempotency_key).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).idempotency_key).val).len <= LSF_MAX_BYTES);
(((arg0).idempotency_key).val).ptr = lsf_allocate((((arg0).idempotency_key).val).len, 1);
for (size_t local_511 = 0; local_511 < (((arg0).idempotency_key).val).len; local_511++) (((arg0).idempotency_key).val).ptr[local_511] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_513 = lsf_get(&input, 1); lsf_require(local_513 <= 1); (((arg0).timeout_millis).is_some) = (__typeof__((((arg0).timeout_millis).is_some)))local_513;
if (((arg0).timeout_millis).is_some) {
uint64_t local_514 = lsf_get(&input, 8);  (((arg0).timeout_millis).val) = (__typeof__((((arg0).timeout_millis).val)))local_514;
}
lsf_finish(&input);
latent_http_0_3_0_streaming_result_own_upload_http_error_t result = {0};
latent_http_0_3_0_streaming_open(&arg0, &result);
lsf_release(((arg0).url).ptr, ((arg0).url).len); ((arg0).url).ptr = NULL; ((arg0).url).len = 0;
for (size_t local_518 = 0; local_518 < ((arg0).headers).len; local_518++) {
lsf_release(((((arg0).headers).ptr[local_518]).name).ptr, ((((arg0).headers).ptr[local_518]).name).len); ((((arg0).headers).ptr[local_518]).name).ptr = NULL; ((((arg0).headers).ptr[local_518]).name).len = 0;
lsf_release(((((arg0).headers).ptr[local_518]).value).ptr, ((((arg0).headers).ptr[local_518]).value).len); ((((arg0).headers).ptr[local_518]).value).ptr = NULL; ((((arg0).headers).ptr[local_518]).value).len = 0;
}
lsf_release(((arg0).headers).ptr, ((arg0).headers).len * sizeof(*((arg0).headers).ptr)); ((arg0).headers).ptr = NULL; ((arg0).headers).len = 0;
if (((arg0).body_length).is_some) {
}
if (((arg0).body_media_type).is_some) {
lsf_release((((arg0).body_media_type).val).ptr, (((arg0).body_media_type).val).len); (((arg0).body_media_type).val).ptr = NULL; (((arg0).body_media_type).val).len = 0;
}
if (((arg0).idempotency_key).is_some) {
lsf_release((((arg0).idempotency_key).val).ptr, (((arg0).idempotency_key).val).len); (((arg0).idempotency_key).val).ptr = NULL; (((arg0).idempotency_key).val).len = 0;
}
if (((arg0).timeout_millis).is_some) {
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 15: {
latent_http_0_3_0_streaming_borrow_upload_t arg0 = {0};
uint64_t local_577 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_577;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_578 = 0; local_578 < (arg1).len; local_578++) {
uint64_t local_579 = lsf_get(&input, 1);  ((arg1).ptr[local_578]) = (__typeof__(((arg1).ptr[local_578])))local_579;
}
lsf_finish(&input);
latent_http_0_3_0_streaming_result_void_http_error_t result = {0};
latent_http_0_3_0_streaming_write(arg0, &arg1, &result);
for (size_t local_581 = 0; local_581 < (arg1).len; local_581++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 16: {
latent_http_0_3_0_streaming_own_upload_t arg0 = {0};
uint64_t local_625 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_625;
lsf_finish(&input);
latent_http_0_3_0_streaming_result_response_http_error_t result = {0};
latent_http_0_3_0_streaming_finish(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).status), 2);
lsf_require((((result).val.ok).headers).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.ok).headers).len, 4);
for (size_t local_649 = 0; local_649 < (((result).val.ok).headers).len; local_649++) {
lsf_require((((((result).val.ok).headers).ptr[local_649]).name).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).headers).ptr[local_649]).name).len, 4);
for (size_t local_651 = 0; local_651 < (((((result).val.ok).headers).ptr[local_649]).name).len; local_651++) lsf_put(&output, (((((result).val.ok).headers).ptr[local_649]).name).ptr[local_651], 1);
lsf_require((((((result).val.ok).headers).ptr[local_649]).value).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).headers).ptr[local_649]).value).len, 4);
for (size_t local_652 = 0; local_652 < (((((result).val.ok).headers).ptr[local_649]).value).len; local_652++) lsf_put(&output, (((((result).val.ok).headers).ptr[local_649]).value).ptr[local_652], 1);
}
lsf_put(&output, (uint64_t)((((result).val.ok).body_media_type).is_some), 1);
if ((((result).val.ok).body_media_type).is_some) {
lsf_require(((((result).val.ok).body_media_type).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).body_media_type).val).len, 4);
for (size_t local_655 = 0; local_655 < ((((result).val.ok).body_media_type).val).len; local_655++) lsf_put(&output, ((((result).val.ok).body_media_type).val).ptr[local_655], 1);
}
lsf_put(&output, (uint64_t)((((result).val.ok).body).__handle), 4);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
for (size_t local_679 = 0; local_679 < (((result).val.ok).headers).len; local_679++) {
lsf_release((((((result).val.ok).headers).ptr[local_679]).name).ptr, (((((result).val.ok).headers).ptr[local_679]).name).len); (((((result).val.ok).headers).ptr[local_679]).name).ptr = NULL; (((((result).val.ok).headers).ptr[local_679]).name).len = 0;
lsf_release((((((result).val.ok).headers).ptr[local_679]).value).ptr, (((((result).val.ok).headers).ptr[local_679]).value).len); (((((result).val.ok).headers).ptr[local_679]).value).ptr = NULL; (((((result).val.ok).headers).ptr[local_679]).value).len = 0;
}
lsf_release((((result).val.ok).headers).ptr, (((result).val.ok).headers).len * sizeof(*(((result).val.ok).headers).ptr)); (((result).val.ok).headers).ptr = NULL; (((result).val.ok).headers).len = 0;
if ((((result).val.ok).body_media_type).is_some) {
lsf_release(((((result).val.ok).body_media_type).val).ptr, ((((result).val.ok).body_media_type).val).len); ((((result).val.ok).body_media_type).val).ptr = NULL; ((((result).val.ok).body_media_type).val).len = 0;
}
}
break; }
case 17: {
latent_http_0_3_0_streaming_borrow_body_t arg0 = {0};
uint64_t local_688 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_688;
uint32_t arg1 = {0};
uint64_t local_689 = lsf_get(&input, 4);  (arg1) = (__typeof__((arg1)))local_689;
lsf_finish(&input);
latent_http_0_3_0_streaming_result_option_own_chunk_http_error_t result = {0};
latent_http_0_3_0_streaming_read(arg0, arg1, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).is_some), 1);
if (((result).val.ok).is_some) {
lsf_put(&output, (uint64_t)((((result).val.ok).val).__handle), 4);
}
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
if (((result).val.ok).is_some) {
}
}
break; }
case 18: {
latent_http_0_3_0_streaming_borrow_chunk_t arg0 = {0};
uint64_t local_739 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_739;
lsf_finish(&input);
latent_http_0_3_0_streaming_result_list_u8_http_error_t result = {0};
latent_http_0_3_0_streaming_chunk_bytes(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
lsf_require(((result).val.ok).len <= LSF_MAX_BYTES); lsf_put(&output, ((result).val.ok).len, 4);
for (size_t local_761 = 0; local_761 < ((result).val.ok).len; local_761++) {
lsf_put(&output, (uint64_t)(((result).val.ok).ptr[local_761]), 1);
}
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
for (size_t local_782 = 0; local_782 < ((result).val.ok).len; local_782++) {
}
lsf_release(((result).val.ok).ptr, ((result).val.ok).len * sizeof(*((result).val.ok).ptr)); ((result).val.ok).ptr = NULL; ((result).val.ok).len = 0;
}
break; }
case 19: {
latent_http_0_3_0_streaming_borrow_body_t arg0 = {0};
uint64_t local_785 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_785;
lsf_finish(&input);
latent_http_0_3_0_streaming_result_list_header_http_error_t result = {0};
latent_http_0_3_0_streaming_trailers(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
lsf_require(((result).val.ok).len <= LSF_MAX_ITEMS); lsf_put(&output, ((result).val.ok).len, 4);
for (size_t local_807 = 0; local_807 < ((result).val.ok).len; local_807++) {
lsf_require(((((result).val.ok).ptr[local_807]).name).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).ptr[local_807]).name).len, 4);
for (size_t local_809 = 0; local_809 < ((((result).val.ok).ptr[local_807]).name).len; local_809++) lsf_put(&output, ((((result).val.ok).ptr[local_807]).name).ptr[local_809], 1);
lsf_require(((((result).val.ok).ptr[local_807]).value).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).ptr[local_807]).value).len, 4);
for (size_t local_810 = 0; local_810 < ((((result).val.ok).ptr[local_807]).value).len; local_810++) lsf_put(&output, ((((result).val.ok).ptr[local_807]).value).ptr[local_810], 1);
}
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
for (size_t local_830 = 0; local_830 < ((result).val.ok).len; local_830++) {
lsf_release(((((result).val.ok).ptr[local_830]).name).ptr, ((((result).val.ok).ptr[local_830]).name).len); ((((result).val.ok).ptr[local_830]).name).ptr = NULL; ((((result).val.ok).ptr[local_830]).name).len = 0;
lsf_release(((((result).val.ok).ptr[local_830]).value).ptr, ((((result).val.ok).ptr[local_830]).value).len); ((((result).val.ok).ptr[local_830]).value).ptr = NULL; ((((result).val.ok).ptr[local_830]).value).len = 0;
}
lsf_release(((result).val.ok).ptr, ((result).val.ok).len * sizeof(*((result).val.ok).ptr)); ((result).val.ok).ptr = NULL; ((result).val.ok).len = 0;
}
break; }
case 20: {
latent_http_0_3_0_streaming_own_upload_t arg0 = {0};
uint64_t local_835 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_835;
lsf_finish(&input);
latent_http_0_3_0_streaming_result_void_http_error_t result = {0};
latent_http_0_3_0_streaming_abort_upload(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 21: {
latent_http_0_3_0_streaming_own_body_t arg0 = {0};
uint64_t local_879 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_879;
lsf_finish(&input);
latent_http_0_3_0_streaming_result_void_http_error_t result = {0};
latent_http_0_3_0_streaming_abort_body(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
case 13: {
break; }
case 14: {
break; }
case 15: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 22: {
latent_telemetry_custom_metric_t arg0 = {0};
((arg0).name).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).name).len <= LSF_MAX_BYTES);
((arg0).name).ptr = lsf_allocate(((arg0).name).len, 1);
for (size_t local_923 = 0; local_923 < ((arg0).name).len; local_923++) ((arg0).name).ptr[local_923] = (uint8_t)lsf_get(&input, 1);
uint64_t local_924 = lsf_get(&input, 4); lsf_require(local_924 < 4);
((arg0).kind) = (__typeof__(((arg0).kind)))local_924;
lsf_require(((arg0).kind) < 4);
uint64_t local_925 = (uint64_t)lsf_get(&input, 8); memcpy(&((arg0).value), &local_925, 8);
((arg0).unit).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).unit).len <= LSF_MAX_BYTES);
((arg0).unit).ptr = lsf_allocate(((arg0).unit).len, 1);
for (size_t local_926 = 0; local_926 < ((arg0).unit).len; local_926++) ((arg0).unit).ptr[local_926] = (uint8_t)lsf_get(&input, 1);
((arg0).attributes).len = lsf_count(&input); lsf_require(((arg0).attributes).len <= LSF_MAX_ITEMS);
((arg0).attributes).ptr = lsf_allocate(((arg0).attributes).len, sizeof(*((arg0).attributes).ptr));
for (size_t local_927 = 0; local_927 < ((arg0).attributes).len; local_927++) {
((((arg0).attributes).ptr[local_927]).f0).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).attributes).ptr[local_927]).f0).len <= LSF_MAX_BYTES);
((((arg0).attributes).ptr[local_927]).f0).ptr = lsf_allocate(((((arg0).attributes).ptr[local_927]).f0).len, 1);
for (size_t local_929 = 0; local_929 < ((((arg0).attributes).ptr[local_927]).f0).len; local_929++) ((((arg0).attributes).ptr[local_927]).f0).ptr[local_929] = (uint8_t)lsf_get(&input, 1);
((((arg0).attributes).ptr[local_927]).f1).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).attributes).ptr[local_927]).f1).len <= LSF_MAX_BYTES);
((((arg0).attributes).ptr[local_927]).f1).ptr = lsf_allocate(((((arg0).attributes).ptr[local_927]).f1).len, 1);
for (size_t local_930 = 0; local_930 < ((((arg0).attributes).ptr[local_927]).f1).len; local_930++) ((((arg0).attributes).ptr[local_927]).f1).ptr[local_930] = (uint8_t)lsf_get(&input, 1);
}
lsf_finish(&input);
latent_telemetry_custom_result_bool_telemetry_error_t result = {0};
latent_telemetry_custom_emit_metric(&arg0, &result);
lsf_release(((arg0).name).ptr, ((arg0).name).len); ((arg0).name).ptr = NULL; ((arg0).name).len = 0;
lsf_release(((arg0).unit).ptr, ((arg0).unit).len); ((arg0).unit).ptr = NULL; ((arg0).unit).len = 0;
for (size_t local_936 = 0; local_936 < ((arg0).attributes).len; local_936++) {
lsf_release(((((arg0).attributes).ptr[local_936]).f0).ptr, ((((arg0).attributes).ptr[local_936]).f0).len); ((((arg0).attributes).ptr[local_936]).f0).ptr = NULL; ((((arg0).attributes).ptr[local_936]).f0).len = 0;
lsf_release(((((arg0).attributes).ptr[local_936]).f1).ptr, ((((arg0).attributes).ptr[local_936]).f1).len); ((((arg0).attributes).ptr[local_936]).f1).ptr = NULL; ((((arg0).attributes).ptr[local_936]).f1).len = 0;
}
lsf_release(((arg0).attributes).ptr, ((arg0).attributes).len * sizeof(*((arg0).attributes).ptr)); ((arg0).attributes).ptr = NULL; ((arg0).attributes).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)((result).val.ok), 1);
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
default: __builtin_trap(); }
} else {
}
break; }
case 23: {
latent_service_invoke_target_t arg0 = {0};
uint64_t local_957 = lsf_get(&input, 1); lsf_require(local_957 <= 1); (((arg0).tenant).is_some) = (__typeof__((((arg0).tenant).is_some)))local_957;
if (((arg0).tenant).is_some) {
(((arg0).tenant).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).tenant).val).len <= LSF_MAX_BYTES);
(((arg0).tenant).val).ptr = lsf_allocate((((arg0).tenant).val).len, 1);
for (size_t local_958 = 0; local_958 < (((arg0).tenant).val).len; local_958++) (((arg0).tenant).val).ptr[local_958] = (uint8_t)lsf_get(&input, 1);
}
((arg0).service).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).service).len <= LSF_MAX_BYTES);
((arg0).service).ptr = lsf_allocate(((arg0).service).len, 1);
for (size_t local_959 = 0; local_959 < ((arg0).service).len; local_959++) ((arg0).service).ptr[local_959] = (uint8_t)lsf_get(&input, 1);
((arg0).contract).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).contract).len <= LSF_MAX_BYTES);
((arg0).contract).ptr = lsf_allocate(((arg0).contract).len, 1);
for (size_t local_960 = 0; local_960 < ((arg0).contract).len; local_960++) ((arg0).contract).ptr[local_960] = (uint8_t)lsf_get(&input, 1);
((arg0).function).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).function).len <= LSF_MAX_BYTES);
((arg0).function).ptr = lsf_allocate(((arg0).function).len, 1);
for (size_t local_961 = 0; local_961 < ((arg0).function).len; local_961++) ((arg0).function).ptr[local_961] = (uint8_t)lsf_get(&input, 1);
uint64_t local_963 = lsf_get(&input, 1); lsf_require(local_963 <= 1); (((arg0).route).is_some) = (__typeof__((((arg0).route).is_some)))local_963;
if (((arg0).route).is_some) {
(((arg0).route).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).route).val).len <= LSF_MAX_BYTES);
(((arg0).route).val).ptr = lsf_allocate((((arg0).route).val).len, 1);
for (size_t local_964 = 0; local_964 < (((arg0).route).val).len; local_964++) (((arg0).route).val).ptr[local_964] = (uint8_t)lsf_get(&input, 1);
}
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_965 = 0; local_965 < (arg1).len; local_965++) {
uint64_t local_966 = lsf_get(&input, 1);  ((arg1).ptr[local_965]) = (__typeof__(((arg1).ptr[local_965])))local_966;
}
probe_string_t arg2 = {0};
(arg2).len = (size_t)lsf_get(&input, 4);
lsf_require((arg2).len <= LSF_MAX_BYTES);
(arg2).ptr = lsf_allocate((arg2).len, 1);
for (size_t local_967 = 0; local_967 < (arg2).len; local_967++) (arg2).ptr[local_967] = (uint8_t)lsf_get(&input, 1);
latent_service_invoke_call_options_t arg3 = {0};
uint64_t local_970 = lsf_get(&input, 1); lsf_require(local_970 <= 1); (((arg3).deadline_unix_millis).is_some) = (__typeof__((((arg3).deadline_unix_millis).is_some)))local_970;
if (((arg3).deadline_unix_millis).is_some) {
uint64_t local_971 = lsf_get(&input, 8);  (((arg3).deadline_unix_millis).val) = (__typeof__((((arg3).deadline_unix_millis).val)))local_971;
}
uint64_t local_972 = lsf_get(&input, 1);  ((arg3).priority) = (__typeof__(((arg3).priority)))local_972;
uint64_t local_974 = lsf_get(&input, 1); lsf_require(local_974 <= 1); (((arg3).idempotency_key).is_some) = (__typeof__((((arg3).idempotency_key).is_some)))local_974;
if (((arg3).idempotency_key).is_some) {
(((arg3).idempotency_key).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg3).idempotency_key).val).len <= LSF_MAX_BYTES);
(((arg3).idempotency_key).val).ptr = lsf_allocate((((arg3).idempotency_key).val).len, 1);
for (size_t local_975 = 0; local_975 < (((arg3).idempotency_key).val).len; local_975++) (((arg3).idempotency_key).val).ptr[local_975] = (uint8_t)lsf_get(&input, 1);
}
((arg3).metadata).len = lsf_count(&input); lsf_require(((arg3).metadata).len <= LSF_MAX_ITEMS);
((arg3).metadata).ptr = lsf_allocate(((arg3).metadata).len, sizeof(*((arg3).metadata).ptr));
for (size_t local_976 = 0; local_976 < ((arg3).metadata).len; local_976++) {
((((arg3).metadata).ptr[local_976]).f0).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg3).metadata).ptr[local_976]).f0).len <= LSF_MAX_BYTES);
((((arg3).metadata).ptr[local_976]).f0).ptr = lsf_allocate(((((arg3).metadata).ptr[local_976]).f0).len, 1);
for (size_t local_978 = 0; local_978 < ((((arg3).metadata).ptr[local_976]).f0).len; local_978++) ((((arg3).metadata).ptr[local_976]).f0).ptr[local_978] = (uint8_t)lsf_get(&input, 1);
((((arg3).metadata).ptr[local_976]).f1).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg3).metadata).ptr[local_976]).f1).len <= LSF_MAX_BYTES);
((((arg3).metadata).ptr[local_976]).f1).ptr = lsf_allocate(((((arg3).metadata).ptr[local_976]).f1).len, 1);
for (size_t local_979 = 0; local_979 < ((((arg3).metadata).ptr[local_976]).f1).len; local_979++) ((((arg3).metadata).ptr[local_976]).f1).ptr[local_979] = (uint8_t)lsf_get(&input, 1);
}
lsf_finish(&input);
latent_service_invoke_invocation_outcome_t result = {0};
latent_service_invoke_call(&arg0, &arg1, &arg2, &arg3, &result);
if (((arg0).tenant).is_some) {
lsf_release((((arg0).tenant).val).ptr, (((arg0).tenant).val).len); (((arg0).tenant).val).ptr = NULL; (((arg0).tenant).val).len = 0;
}
lsf_release(((arg0).service).ptr, ((arg0).service).len); ((arg0).service).ptr = NULL; ((arg0).service).len = 0;
lsf_release(((arg0).contract).ptr, ((arg0).contract).len); ((arg0).contract).ptr = NULL; ((arg0).contract).len = 0;
lsf_release(((arg0).function).ptr, ((arg0).function).len); ((arg0).function).ptr = NULL; ((arg0).function).len = 0;
if (((arg0).route).is_some) {
lsf_release((((arg0).route).val).ptr, (((arg0).route).val).len); (((arg0).route).val).ptr = NULL; (((arg0).route).val).len = 0;
}
for (size_t local_990 = 0; local_990 < (arg1).len; local_990++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
lsf_release((arg2).ptr, (arg2).len); (arg2).ptr = NULL; (arg2).len = 0;
if (((arg3).deadline_unix_millis).is_some) {
}
if (((arg3).idempotency_key).is_some) {
lsf_release((((arg3).idempotency_key).val).ptr, (((arg3).idempotency_key).val).len); (((arg3).idempotency_key).val).ptr = NULL; (((arg3).idempotency_key).val).len = 0;
}
for (size_t local_1001 = 0; local_1001 < ((arg3).metadata).len; local_1001++) {
lsf_release(((((arg3).metadata).ptr[local_1001]).f0).ptr, ((((arg3).metadata).ptr[local_1001]).f0).len); ((((arg3).metadata).ptr[local_1001]).f0).ptr = NULL; ((((arg3).metadata).ptr[local_1001]).f0).len = 0;
lsf_release(((((arg3).metadata).ptr[local_1001]).f1).ptr, ((((arg3).metadata).ptr[local_1001]).f1).len); ((((arg3).metadata).ptr[local_1001]).f1).ptr = NULL; ((((arg3).metadata).ptr[local_1001]).f1).len = 0;
}
lsf_release(((arg3).metadata).ptr, ((arg3).metadata).len * sizeof(*((arg3).metadata).ptr)); ((arg3).metadata).ptr = NULL; ((arg3).metadata).len = 0;
lsf_put(&output, (uint64_t)((result).tag), 4);
switch ((result).tag) {
case 0: {
lsf_require((((result).val.success).payload).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.success).payload).len, 4);
for (size_t local_1008 = 0; local_1008 < (((result).val.success).payload).len; local_1008++) {
lsf_put(&output, (uint64_t)((((result).val.success).payload).ptr[local_1008]), 1);
}
lsf_require((((result).val.success).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.success).media_type).len, 4);
for (size_t local_1010 = 0; local_1010 < (((result).val.success).media_type).len; local_1010++) lsf_put(&output, (((result).val.success).media_type).ptr[local_1010], 1);
lsf_require((((result).val.success).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.success).metadata).len, 4);
for (size_t local_1011 = 0; local_1011 < (((result).val.success).metadata).len; local_1011++) {
lsf_require((((((result).val.success).metadata).ptr[local_1011]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.success).metadata).ptr[local_1011]).f0).len, 4);
for (size_t local_1013 = 0; local_1013 < (((((result).val.success).metadata).ptr[local_1011]).f0).len; local_1013++) lsf_put(&output, (((((result).val.success).metadata).ptr[local_1011]).f0).ptr[local_1013], 1);
lsf_require((((((result).val.success).metadata).ptr[local_1011]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.success).metadata).ptr[local_1011]).f1).len, 4);
for (size_t local_1014 = 0; local_1014 < (((((result).val.success).metadata).ptr[local_1011]).f1).len; local_1014++) lsf_put(&output, (((((result).val.success).metadata).ptr[local_1011]).f1).ptr[local_1014], 1);
}
break; }
case 1: {
lsf_require((((result).val.declared_error).code).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.declared_error).code).len, 4);
for (size_t local_1016 = 0; local_1016 < (((result).val.declared_error).code).len; local_1016++) lsf_put(&output, (((result).val.declared_error).code).ptr[local_1016], 1);
lsf_require((((result).val.declared_error).message).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.declared_error).message).len, 4);
for (size_t local_1017 = 0; local_1017 < (((result).val.declared_error).message).len; local_1017++) lsf_put(&output, (((result).val.declared_error).message).ptr[local_1017], 1);
lsf_require((((result).val.declared_error).payload).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.declared_error).payload).len, 4);
for (size_t local_1018 = 0; local_1018 < (((result).val.declared_error).payload).len; local_1018++) {
lsf_put(&output, (uint64_t)((((result).val.declared_error).payload).ptr[local_1018]), 1);
}
lsf_require((((result).val.declared_error).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.declared_error).media_type).len, 4);
for (size_t local_1020 = 0; local_1020 < (((result).val.declared_error).media_type).len; local_1020++) lsf_put(&output, (((result).val.declared_error).media_type).ptr[local_1020], 1);
lsf_require((((result).val.declared_error).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.declared_error).metadata).len, 4);
for (size_t local_1021 = 0; local_1021 < (((result).val.declared_error).metadata).len; local_1021++) {
lsf_require((((((result).val.declared_error).metadata).ptr[local_1021]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.declared_error).metadata).ptr[local_1021]).f0).len, 4);
for (size_t local_1023 = 0; local_1023 < (((((result).val.declared_error).metadata).ptr[local_1021]).f0).len; local_1023++) lsf_put(&output, (((((result).val.declared_error).metadata).ptr[local_1021]).f0).ptr[local_1023], 1);
lsf_require((((((result).val.declared_error).metadata).ptr[local_1021]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.declared_error).metadata).ptr[local_1021]).f1).len, 4);
for (size_t local_1024 = 0; local_1024 < (((((result).val.declared_error).metadata).ptr[local_1021]).f1).len; local_1024++) lsf_put(&output, (((((result).val.declared_error).metadata).ptr[local_1021]).f1).ptr[local_1024], 1);
}
break; }
case 2: {
lsf_put(&output, (uint64_t)((((result).val.platform_failure).code)), 4);
lsf_require((((result).val.platform_failure).code) < 17);
lsf_require((((result).val.platform_failure).message).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.platform_failure).message).len, 4);
for (size_t local_1028 = 0; local_1028 < (((result).val.platform_failure).message).len; local_1028++) lsf_put(&output, (((result).val.platform_failure).message).ptr[local_1028], 1);
lsf_put(&output, (uint64_t)(((result).val.platform_failure).retryable), 1);
lsf_require((((result).val.platform_failure).details).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.platform_failure).details).len, 4);
for (size_t local_1030 = 0; local_1030 < (((result).val.platform_failure).details).len; local_1030++) {
lsf_require((((((result).val.platform_failure).details).ptr[local_1030]).kind).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.platform_failure).details).ptr[local_1030]).kind).len, 4);
for (size_t local_1032 = 0; local_1032 < (((((result).val.platform_failure).details).ptr[local_1030]).kind).len; local_1032++) lsf_put(&output, (((((result).val.platform_failure).details).ptr[local_1030]).kind).ptr[local_1032], 1);
lsf_require((((((result).val.platform_failure).details).ptr[local_1030]).fields).len <= LSF_MAX_ITEMS); lsf_put(&output, (((((result).val.platform_failure).details).ptr[local_1030]).fields).len, 4);
for (size_t local_1033 = 0; local_1033 < (((((result).val.platform_failure).details).ptr[local_1030]).fields).len; local_1033++) {
lsf_require((((((((result).val.platform_failure).details).ptr[local_1030]).fields).ptr[local_1033]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.platform_failure).details).ptr[local_1030]).fields).ptr[local_1033]).f0).len, 4);
for (size_t local_1035 = 0; local_1035 < (((((((result).val.platform_failure).details).ptr[local_1030]).fields).ptr[local_1033]).f0).len; local_1035++) lsf_put(&output, (((((((result).val.platform_failure).details).ptr[local_1030]).fields).ptr[local_1033]).f0).ptr[local_1035], 1);
lsf_require((((((((result).val.platform_failure).details).ptr[local_1030]).fields).ptr[local_1033]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.platform_failure).details).ptr[local_1030]).fields).ptr[local_1033]).f1).len, 4);
for (size_t local_1036 = 0; local_1036 < (((((((result).val.platform_failure).details).ptr[local_1030]).fields).ptr[local_1033]).f1).len; local_1036++) lsf_put(&output, (((((((result).val.platform_failure).details).ptr[local_1030]).fields).ptr[local_1033]).f1).ptr[local_1036], 1);
}
}
break; }
default: __builtin_trap(); }
switch ((result).tag) {
case 0: {
for (size_t local_1039 = 0; local_1039 < (((result).val.success).payload).len; local_1039++) {
}
lsf_release((((result).val.success).payload).ptr, (((result).val.success).payload).len * sizeof(*(((result).val.success).payload).ptr)); (((result).val.success).payload).ptr = NULL; (((result).val.success).payload).len = 0;
lsf_release((((result).val.success).media_type).ptr, (((result).val.success).media_type).len); (((result).val.success).media_type).ptr = NULL; (((result).val.success).media_type).len = 0;
for (size_t local_1042 = 0; local_1042 < (((result).val.success).metadata).len; local_1042++) {
lsf_release((((((result).val.success).metadata).ptr[local_1042]).f0).ptr, (((((result).val.success).metadata).ptr[local_1042]).f0).len); (((((result).val.success).metadata).ptr[local_1042]).f0).ptr = NULL; (((((result).val.success).metadata).ptr[local_1042]).f0).len = 0;
lsf_release((((((result).val.success).metadata).ptr[local_1042]).f1).ptr, (((((result).val.success).metadata).ptr[local_1042]).f1).len); (((((result).val.success).metadata).ptr[local_1042]).f1).ptr = NULL; (((((result).val.success).metadata).ptr[local_1042]).f1).len = 0;
}
lsf_release((((result).val.success).metadata).ptr, (((result).val.success).metadata).len * sizeof(*(((result).val.success).metadata).ptr)); (((result).val.success).metadata).ptr = NULL; (((result).val.success).metadata).len = 0;
break; }
case 1: {
lsf_release((((result).val.declared_error).code).ptr, (((result).val.declared_error).code).len); (((result).val.declared_error).code).ptr = NULL; (((result).val.declared_error).code).len = 0;
lsf_release((((result).val.declared_error).message).ptr, (((result).val.declared_error).message).len); (((result).val.declared_error).message).ptr = NULL; (((result).val.declared_error).message).len = 0;
for (size_t local_1049 = 0; local_1049 < (((result).val.declared_error).payload).len; local_1049++) {
}
lsf_release((((result).val.declared_error).payload).ptr, (((result).val.declared_error).payload).len * sizeof(*(((result).val.declared_error).payload).ptr)); (((result).val.declared_error).payload).ptr = NULL; (((result).val.declared_error).payload).len = 0;
lsf_release((((result).val.declared_error).media_type).ptr, (((result).val.declared_error).media_type).len); (((result).val.declared_error).media_type).ptr = NULL; (((result).val.declared_error).media_type).len = 0;
for (size_t local_1052 = 0; local_1052 < (((result).val.declared_error).metadata).len; local_1052++) {
lsf_release((((((result).val.declared_error).metadata).ptr[local_1052]).f0).ptr, (((((result).val.declared_error).metadata).ptr[local_1052]).f0).len); (((((result).val.declared_error).metadata).ptr[local_1052]).f0).ptr = NULL; (((((result).val.declared_error).metadata).ptr[local_1052]).f0).len = 0;
lsf_release((((((result).val.declared_error).metadata).ptr[local_1052]).f1).ptr, (((((result).val.declared_error).metadata).ptr[local_1052]).f1).len); (((((result).val.declared_error).metadata).ptr[local_1052]).f1).ptr = NULL; (((((result).val.declared_error).metadata).ptr[local_1052]).f1).len = 0;
}
lsf_release((((result).val.declared_error).metadata).ptr, (((result).val.declared_error).metadata).len * sizeof(*(((result).val.declared_error).metadata).ptr)); (((result).val.declared_error).metadata).ptr = NULL; (((result).val.declared_error).metadata).len = 0;
break; }
case 2: {
lsf_release((((result).val.platform_failure).message).ptr, (((result).val.platform_failure).message).len); (((result).val.platform_failure).message).ptr = NULL; (((result).val.platform_failure).message).len = 0;
for (size_t local_1060 = 0; local_1060 < (((result).val.platform_failure).details).len; local_1060++) {
lsf_release((((((result).val.platform_failure).details).ptr[local_1060]).kind).ptr, (((((result).val.platform_failure).details).ptr[local_1060]).kind).len); (((((result).val.platform_failure).details).ptr[local_1060]).kind).ptr = NULL; (((((result).val.platform_failure).details).ptr[local_1060]).kind).len = 0;
for (size_t local_1063 = 0; local_1063 < (((((result).val.platform_failure).details).ptr[local_1060]).fields).len; local_1063++) {
lsf_release((((((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr[local_1063]).f0).ptr, (((((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr[local_1063]).f0).len); (((((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr[local_1063]).f0).ptr = NULL; (((((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr[local_1063]).f0).len = 0;
lsf_release((((((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr[local_1063]).f1).ptr, (((((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr[local_1063]).f1).len); (((((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr[local_1063]).f1).ptr = NULL; (((((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr[local_1063]).f1).len = 0;
}
lsf_release((((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr, (((((result).val.platform_failure).details).ptr[local_1060]).fields).len * sizeof(*(((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr)); (((((result).val.platform_failure).details).ptr[local_1060]).fields).ptr = NULL; (((((result).val.platform_failure).details).ptr[local_1060]).fields).len = 0;
}
lsf_release((((result).val.platform_failure).details).ptr, (((result).val.platform_failure).details).len * sizeof(*(((result).val.platform_failure).details).ptr)); (((result).val.platform_failure).details).ptr = NULL; (((result).val.platform_failure).details).len = 0;
break; }
default: __builtin_trap(); }
break; }
case -1: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_blob_blob_chunk_drop_own((latent_blob_blob_own_chunk_t){(int32_t)handle}); break; }
case -2: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_http_0_3_0_streaming_upload_drop_own((latent_http_0_3_0_streaming_own_upload_t){(int32_t)handle}); break; }
case -3: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_http_0_3_0_streaming_body_drop_own((latent_http_0_3_0_streaming_own_body_t){(int32_t)handle}); break; }
case -4: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_http_0_3_0_streaming_chunk_drop_own((latent_http_0_3_0_streaming_own_chunk_t){(int32_t)handle}); break; }
default: __builtin_trap(); }
return lsf_result(&output);
}
