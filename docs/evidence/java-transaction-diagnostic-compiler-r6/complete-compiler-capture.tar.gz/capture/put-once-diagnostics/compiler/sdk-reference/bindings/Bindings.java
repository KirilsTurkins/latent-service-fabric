// Generated from authoritative WIT and maintained wit-bindgen C. DO NOT EDIT.
package dev.latent.generated;
import dev.latent.guest.*;
import org.teavm.interop.Address;
import org.teavm.interop.Export;
import org.teavm.interop.Function;
public final class Bindings {
private Bindings() { }
public static final class LatentBlobBlobChunk extends Resource { private LatentBlobBlobChunk(int handle) { super(handle, -1); } }
public record LatentBlobBlobBlobReference(String digest, Unsigned64 size, String mediaType) { public LatentBlobBlobBlobReference { java.util.Objects.requireNonNull(digest); java.util.Objects.requireNonNull(size); java.util.Objects.requireNonNull(mediaType); } }
public static final class LatentBlobBlobBlobError {
private final int tag; private final Object value;
private LatentBlobBlobBlobError(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentBlobBlobBlobError notFound() { return new LatentBlobBlobBlobError(0, Unit.VALUE); }
public static LatentBlobBlobBlobError permissionDenied() { return new LatentBlobBlobBlobError(1, Unit.VALUE); }
public static LatentBlobBlobBlobError invalidRange() { return new LatentBlobBlobBlobError(2, Unit.VALUE); }
public static LatentBlobBlobBlobError invalidState() { return new LatentBlobBlobBlobError(3, Unit.VALUE); }
public static LatentBlobBlobBlobError checksumMismatch() { return new LatentBlobBlobBlobError(4, Unit.VALUE); }
public static LatentBlobBlobBlobError budgetExhausted() { return new LatentBlobBlobBlobError(5, Unit.VALUE); }
public static LatentBlobBlobBlobError unavailable() { return new LatentBlobBlobBlobError(6, Unit.VALUE); }
public static LatentBlobBlobBlobError uncertain() { return new LatentBlobBlobBlobError(7, Unit.VALUE); }
public static LatentBlobBlobBlobError deadlineExceeded() { return new LatentBlobBlobBlobError(8, Unit.VALUE); }
public static LatentBlobBlobBlobError cancelled() { return new LatentBlobBlobBlobError(9, Unit.VALUE); }
}
public record Value16(String f0, String f1) { public Value16 { java.util.Objects.requireNonNull(f0); java.util.Objects.requireNonNull(f1); } }
public record LatentEventsPublisherEvent(String topic, Option<String> key, byte[] payload, String mediaType, java.util.List<Value16> attributes, String idempotencyKey) { public LatentEventsPublisherEvent { java.util.Objects.requireNonNull(topic); java.util.Objects.requireNonNull(key); java.util.Objects.requireNonNull(payload); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(attributes); java.util.Objects.requireNonNull(idempotencyKey); } }
public record LatentEventsPublisherPublishReceipt(String eventId, Unsigned64 acceptedAtUnixMillis, String streamName, Unsigned64 sequence, Boolean duplicate) { public LatentEventsPublisherPublishReceipt { java.util.Objects.requireNonNull(eventId); java.util.Objects.requireNonNull(acceptedAtUnixMillis); java.util.Objects.requireNonNull(streamName); java.util.Objects.requireNonNull(sequence); java.util.Objects.requireNonNull(duplicate); } }
public static final class LatentEventsPublisherEventError {
private final int tag; private final Object value;
private LatentEventsPublisherEventError(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentEventsPublisherEventError invalidTopic() { return new LatentEventsPublisherEventError(0, Unit.VALUE); }
public static LatentEventsPublisherEventError invalidEvent() { return new LatentEventsPublisherEventError(1, Unit.VALUE); }
public static LatentEventsPublisherEventError permissionDenied() { return new LatentEventsPublisherEventError(2, Unit.VALUE); }
public static LatentEventsPublisherEventError budgetExhausted() { return new LatentEventsPublisherEventError(3, Unit.VALUE); }
public static LatentEventsPublisherEventError deadlineExceeded() { return new LatentEventsPublisherEventError(4, Unit.VALUE); }
public static LatentEventsPublisherEventError cancelled() { return new LatentEventsPublisherEventError(5, Unit.VALUE); }
public static LatentEventsPublisherEventError unavailable() { return new LatentEventsPublisherEventError(6, Unit.VALUE); }
public static LatentEventsPublisherEventError uncertain() { return new LatentEventsPublisherEventError(7, Unit.VALUE); }
}
public enum LatentHttpClientMethod { Get, Head, Post, Put, Patch, Delete, Options }
public record LatentHttpClientHeader(String name, String value) { public LatentHttpClientHeader { java.util.Objects.requireNonNull(name); java.util.Objects.requireNonNull(value); } }
public record LatentHttpClientRequest(LatentHttpClientMethod method, String url, java.util.List<LatentHttpClientHeader> headers, Option<byte[]> body, Option<String> bodyMediaType, Option<String> idempotencyKey, Option<Unsigned64> timeoutMillis) { public LatentHttpClientRequest { java.util.Objects.requireNonNull(method); java.util.Objects.requireNonNull(url); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(body); java.util.Objects.requireNonNull(bodyMediaType); java.util.Objects.requireNonNull(idempotencyKey); java.util.Objects.requireNonNull(timeoutMillis); } }
public record LatentHttpClientResponse(Integer status, java.util.List<LatentHttpClientHeader> headers, byte[] body, Option<String> bodyMediaType) { public LatentHttpClientResponse { java.util.Objects.requireNonNull(status); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(body); java.util.Objects.requireNonNull(bodyMediaType); } }
public static final class LatentHttpClientHttpError {
private final int tag; private final Object value;
private LatentHttpClientHttpError(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentHttpClientHttpError invalidUrl() { return new LatentHttpClientHttpError(0, Unit.VALUE); }
public static LatentHttpClientHttpError invalidRequest() { return new LatentHttpClientHttpError(1, Unit.VALUE); }
public static LatentHttpClientHttpError permissionDenied() { return new LatentHttpClientHttpError(2, Unit.VALUE); }
public static LatentHttpClientHttpError requestTooLarge() { return new LatentHttpClientHttpError(3, Unit.VALUE); }
public static LatentHttpClientHttpError responseTooLarge() { return new LatentHttpClientHttpError(4, Unit.VALUE); }
public static LatentHttpClientHttpError deadlineExceeded() { return new LatentHttpClientHttpError(5, Unit.VALUE); }
public static LatentHttpClientHttpError cancelled() { return new LatentHttpClientHttpError(6, Unit.VALUE); }
public static LatentHttpClientHttpError budgetExhausted() { return new LatentHttpClientHttpError(7, Unit.VALUE); }
public static LatentHttpClientHttpError dnsFailed() { return new LatentHttpClientHttpError(8, Unit.VALUE); }
public static LatentHttpClientHttpError tlsFailed() { return new LatentHttpClientHttpError(9, Unit.VALUE); }
public static LatentHttpClientHttpError connectionFailed() { return new LatentHttpClientHttpError(10, Unit.VALUE); }
public static LatentHttpClientHttpError unavailable() { return new LatentHttpClientHttpError(11, Unit.VALUE); }
public static LatentHttpClientHttpError uncertain() { return new LatentHttpClientHttpError(12, Unit.VALUE); }
}
public enum LatentHttpStreamingMethod { Get, Head, Post, Put, Patch, Delete, Options }
public record LatentHttpStreamingHeader(String name, String value) { public LatentHttpStreamingHeader { java.util.Objects.requireNonNull(name); java.util.Objects.requireNonNull(value); } }
public record LatentHttpStreamingRequest(LatentHttpStreamingMethod method, String url, java.util.List<LatentHttpStreamingHeader> headers, Option<Unsigned64> bodyLength, Option<String> bodyMediaType, Option<String> idempotencyKey, Option<Unsigned64> timeoutMillis) { public LatentHttpStreamingRequest { java.util.Objects.requireNonNull(method); java.util.Objects.requireNonNull(url); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(bodyLength); java.util.Objects.requireNonNull(bodyMediaType); java.util.Objects.requireNonNull(idempotencyKey); java.util.Objects.requireNonNull(timeoutMillis); } }
public static final class LatentHttpStreamingUpload extends Resource { private LatentHttpStreamingUpload(int handle) { super(handle, -2); } }
public static final class LatentHttpStreamingBody extends Resource { private LatentHttpStreamingBody(int handle) { super(handle, -3); } }
public static final class LatentHttpStreamingChunk extends Resource { private LatentHttpStreamingChunk(int handle) { super(handle, -4); } }
public record LatentHttpStreamingResponse(Integer status, java.util.List<LatentHttpStreamingHeader> headers, Option<String> bodyMediaType, LatentHttpStreamingBody body) { public LatentHttpStreamingResponse { java.util.Objects.requireNonNull(status); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(bodyMediaType); java.util.Objects.requireNonNull(body); } }
public static final class LatentHttpStreamingHttpError {
private final int tag; private final Object value;
private LatentHttpStreamingHttpError(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentHttpStreamingHttpError invalidUrl() { return new LatentHttpStreamingHttpError(0, Unit.VALUE); }
public static LatentHttpStreamingHttpError invalidRequest() { return new LatentHttpStreamingHttpError(1, Unit.VALUE); }
public static LatentHttpStreamingHttpError permissionDenied() { return new LatentHttpStreamingHttpError(2, Unit.VALUE); }
public static LatentHttpStreamingHttpError requestTooLarge() { return new LatentHttpStreamingHttpError(3, Unit.VALUE); }
public static LatentHttpStreamingHttpError responseTooLarge() { return new LatentHttpStreamingHttpError(4, Unit.VALUE); }
public static LatentHttpStreamingHttpError deadlineExceeded() { return new LatentHttpStreamingHttpError(5, Unit.VALUE); }
public static LatentHttpStreamingHttpError cancelled() { return new LatentHttpStreamingHttpError(6, Unit.VALUE); }
public static LatentHttpStreamingHttpError budgetExhausted() { return new LatentHttpStreamingHttpError(7, Unit.VALUE); }
public static LatentHttpStreamingHttpError dnsFailed() { return new LatentHttpStreamingHttpError(8, Unit.VALUE); }
public static LatentHttpStreamingHttpError tlsFailed() { return new LatentHttpStreamingHttpError(9, Unit.VALUE); }
public static LatentHttpStreamingHttpError connectionFailed() { return new LatentHttpStreamingHttpError(10, Unit.VALUE); }
public static LatentHttpStreamingHttpError unavailable() { return new LatentHttpStreamingHttpError(11, Unit.VALUE); }
public static LatentHttpStreamingHttpError uncertain() { return new LatentHttpStreamingHttpError(12, Unit.VALUE); }
public static LatentHttpStreamingHttpError invalidState() { return new LatentHttpStreamingHttpError(13, Unit.VALUE); }
public static LatentHttpStreamingHttpError unexpectedEof() { return new LatentHttpStreamingHttpError(14, Unit.VALUE); }
public static LatentHttpStreamingHttpError unsupportedEncoding() { return new LatentHttpStreamingHttpError(15, Unit.VALUE); }
}
public static final class LatentRandomRandomRandomError {
private final int tag; private final Object value;
private LatentRandomRandomRandomError(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentRandomRandomRandomError invalidLength() { return new LatentRandomRandomRandomError(0, Unit.VALUE); }
public static LatentRandomRandomRandomError budgetExhausted() { return new LatentRandomRandomRandomError(1, Unit.VALUE); }
public static LatentRandomRandomRandomError unavailable() { return new LatentRandomRandomRandomError(2, Unit.VALUE); }
}
public record LatentSecretsReaderSecretValue(byte[] bytes, String mediaType, Option<String> version, Option<Unsigned64> expiresAtUnixMillis) { public LatentSecretsReaderSecretValue { java.util.Objects.requireNonNull(bytes); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(version); java.util.Objects.requireNonNull(expiresAtUnixMillis); } }
public static final class LatentSecretsReaderSecretError {
private final int tag; private final Object value;
private LatentSecretsReaderSecretError(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentSecretsReaderSecretError notFound() { return new LatentSecretsReaderSecretError(0, Unit.VALUE); }
public static LatentSecretsReaderSecretError permissionDenied() { return new LatentSecretsReaderSecretError(1, Unit.VALUE); }
public static LatentSecretsReaderSecretError expired() { return new LatentSecretsReaderSecretError(2, Unit.VALUE); }
public static LatentSecretsReaderSecretError unavailable() { return new LatentSecretsReaderSecretError(3, Unit.VALUE); }
}
public enum LatentTelemetryCustomMetricKind { Counter, UpDownCounter, Gauge, Histogram }
public record Value69(String f0, String f1) { public Value69 { java.util.Objects.requireNonNull(f0); java.util.Objects.requireNonNull(f1); } }
public record LatentTelemetryCustomMetric(String name, LatentTelemetryCustomMetricKind kind, Double value, String unit, java.util.List<Value69> attributes) { public LatentTelemetryCustomMetric { java.util.Objects.requireNonNull(name); java.util.Objects.requireNonNull(kind); java.util.Objects.requireNonNull(value); java.util.Objects.requireNonNull(unit); java.util.Objects.requireNonNull(attributes); } }
public static final class LatentTelemetryCustomTelemetryError {
private final int tag; private final Object value;
private LatentTelemetryCustomTelemetryError(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentTelemetryCustomTelemetryError invalidName() { return new LatentTelemetryCustomTelemetryError(0, Unit.VALUE); }
public static LatentTelemetryCustomTelemetryError budgetExhausted() { return new LatentTelemetryCustomTelemetryError(1, Unit.VALUE); }
public static LatentTelemetryCustomTelemetryError unavailable() { return new LatentTelemetryCustomTelemetryError(2, Unit.VALUE); }
}
public record LatentServiceInvokeTarget(Option<String> tenant, String service, String contract, String function, Option<String> route) { public LatentServiceInvokeTarget { java.util.Objects.requireNonNull(tenant); java.util.Objects.requireNonNull(service); java.util.Objects.requireNonNull(contract); java.util.Objects.requireNonNull(function); java.util.Objects.requireNonNull(route); } }
public record Value77(String f0, String f1) { public Value77 { java.util.Objects.requireNonNull(f0); java.util.Objects.requireNonNull(f1); } }
public record LatentServiceInvokeCallOptions(Option<Unsigned64> deadlineUnixMillis, Short priority, Option<String> idempotencyKey, java.util.List<Value77> metadata) { public LatentServiceInvokeCallOptions { java.util.Objects.requireNonNull(deadlineUnixMillis); java.util.Objects.requireNonNull(priority); java.util.Objects.requireNonNull(idempotencyKey); java.util.Objects.requireNonNull(metadata); } }
public record LatentServiceInvokeInvocationResult(byte[] payload, String mediaType, java.util.List<Value77> metadata) { public LatentServiceInvokeInvocationResult { java.util.Objects.requireNonNull(payload); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(metadata); } }
public record LatentServiceInvokeErrorDetail(String kind, java.util.List<Value77> fields) { public LatentServiceInvokeErrorDetail { java.util.Objects.requireNonNull(kind); java.util.Objects.requireNonNull(fields); } }
public enum LatentServiceInvokePlatformErrorCode { Unavailable, DeadlineExceeded, Cancelled, ResourceExhausted, PermissionDenied, Unauthenticated, InvalidArgument, NotFound, AlreadyExists, IncompatibleContract, StateConflict, DependencyFailed, GuestTrap, CorruptArtifact, RouteUnavailable, AdmissionRejected, Internal }
public record LatentServiceInvokePlatformError(LatentServiceInvokePlatformErrorCode code, String message, Boolean retryable, java.util.List<LatentServiceInvokeErrorDetail> details) { public LatentServiceInvokePlatformError { java.util.Objects.requireNonNull(code); java.util.Objects.requireNonNull(message); java.util.Objects.requireNonNull(retryable); java.util.Objects.requireNonNull(details); } }
public record LatentServiceInvokeDeclaredError(String code, String message, byte[] payload, String mediaType, java.util.List<Value77> metadata) { public LatentServiceInvokeDeclaredError { java.util.Objects.requireNonNull(code); java.util.Objects.requireNonNull(message); java.util.Objects.requireNonNull(payload); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(metadata); } }
public static final class LatentServiceInvokeInvocationOutcome {
private final int tag; private final Object value;
private LatentServiceInvokeInvocationOutcome(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentServiceInvokeInvocationOutcome success(LatentServiceInvokeInvocationResult value) { return new LatentServiceInvokeInvocationOutcome(0, java.util.Objects.requireNonNull(value)); }
@SuppressWarnings("unchecked") public LatentServiceInvokeInvocationResult successValue() { Wire.require(tag == 0); return (LatentServiceInvokeInvocationResult) value; }
public static LatentServiceInvokeInvocationOutcome declaredError(LatentServiceInvokeDeclaredError value) { return new LatentServiceInvokeInvocationOutcome(1, java.util.Objects.requireNonNull(value)); }
@SuppressWarnings("unchecked") public LatentServiceInvokeDeclaredError declaredErrorValue() { Wire.require(tag == 1); return (LatentServiceInvokeDeclaredError) value; }
public static LatentServiceInvokeInvocationOutcome platformFailure(LatentServiceInvokePlatformError value) { return new LatentServiceInvokeInvocationOutcome(2, java.util.Objects.requireNonNull(value)); }
@SuppressWarnings("unchecked") public LatentServiceInvokePlatformError platformFailureValue() { Wire.require(tag == 2); return (LatentServiceInvokePlatformError) value; }
}
public interface Exports {
Unsigned64 identity(Unsigned64 arg0);
}
public static final class LatentBlobBlob { private LatentBlobBlob() { }
public static Result<Unsigned64, LatentBlobBlobBlobError> create(String arg0, Option<Unsigned64> arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeString(arguments, arg0);
writeT4(arguments, arg1);
try (Wire.Reader input = arguments.call(4)) {
Result<Unsigned64, LatentBlobBlobBlobError> result = readT5(input);
input.finish(); return result;
} } }
public static Result<Unsigned64, LatentBlobBlobBlobError> open(LatentBlobBlobBlobReference arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT2(arguments, arg0);
try (Wire.Reader input = arguments.call(5)) {
Result<Unsigned64, LatentBlobBlobBlobError> result = readT5(input);
input.finish(); return result;
} } }
public static Result<Unsigned64, LatentBlobBlobBlobError> write(Unsigned64 arg0, Unsigned64 arg1, byte[] arg2) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT0(arguments, arg0);
writeU64(arguments, arg1);
writeT6(arguments, arg2);
try (Wire.Reader input = arguments.call(6)) {
Result<Unsigned64, LatentBlobBlobBlobError> result = readT7(input);
input.finish(); return result;
} } }
public static Result<LatentBlobBlobChunk, LatentBlobBlobBlobError> read(Unsigned64 arg0, Unsigned64 arg1, Long arg2) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT0(arguments, arg0);
writeU64(arguments, arg1);
writeU32(arguments, arg2);
try (Wire.Reader input = arguments.call(7)) {
Result<LatentBlobBlobChunk, LatentBlobBlobBlobError> result = readT9(input);
input.finish(); return result;
} } }
public static Result<byte[], LatentBlobBlobBlobError> chunkBytes(LatentBlobBlobChunk arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT10(arguments, arg0);
try (Wire.Reader input = arguments.call(8)) {
Result<byte[], LatentBlobBlobBlobError> result = readT11(input);
input.finish(); return result;
} } }
public static Result<LatentBlobBlobBlobReference, LatentBlobBlobBlobError> seal(Unsigned64 arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT0(arguments, arg0);
try (Wire.Reader input = arguments.call(9)) {
Result<LatentBlobBlobBlobReference, LatentBlobBlobBlobError> result = readT12(input);
input.finish(); return result;
} } }
public static Result<Boolean, LatentBlobBlobBlobError> close(Unsigned64 arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT0(arguments, arg0);
try (Wire.Reader input = arguments.call(10)) {
Result<Boolean, LatentBlobBlobBlobError> result = readT13(input);
input.finish(); return result;
} } }
}
public static final class LatentClockMonotonic { private LatentClockMonotonic() { }
public static Unsigned64 nowNanos() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(0)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentClockWall { private LatentClockWall() { }
public static Unsigned64 nowUnixMillis() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(1)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentEventsPublisher { private LatentEventsPublisher() { }
public static Result<LatentEventsPublisherPublishReceipt, LatentEventsPublisherEventError> publish(LatentEventsPublisherEvent arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT18(arguments, arg0);
try (Wire.Reader input = arguments.call(12)) {
Result<LatentEventsPublisherPublishReceipt, LatentEventsPublisherEventError> result = readT21(input);
input.finish(); return result;
} } }
}
public static final class LatentHttpClient { private LatentHttpClient() { }
public static Result<LatentHttpClientResponse, LatentHttpClientHttpError> send(LatentHttpClientRequest arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT29(arguments, arg0);
try (Wire.Reader input = arguments.call(13)) {
Result<LatentHttpClientResponse, LatentHttpClientHttpError> result = readT32(input);
input.finish(); return result;
} } }
}
public static final class LatentHttpStreaming { private LatentHttpStreaming() { }
public static Result<LatentHttpStreamingUpload, LatentHttpStreamingHttpError> open(LatentHttpStreamingRequest arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT38(arguments, arg0);
try (Wire.Reader input = arguments.call(14)) {
Result<LatentHttpStreamingUpload, LatentHttpStreamingHttpError> result = readT46(input);
input.finish(); return result;
} } }
public static Result<Unit, LatentHttpStreamingHttpError> write(LatentHttpStreamingUpload arg0, byte[] arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT47(arguments, arg0);
writeT48(arguments, arg1);
try (Wire.Reader input = arguments.call(15)) {
Result<Unit, LatentHttpStreamingHttpError> result = readT49(input);
input.finish(); return result;
} } }
public static Result<LatentHttpStreamingResponse, LatentHttpStreamingHttpError> finish(LatentHttpStreamingUpload arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT45(arguments, arg0);
try (Wire.Reader input = arguments.call(16)) {
Result<LatentHttpStreamingResponse, LatentHttpStreamingHttpError> result = readT50(input);
input.finish(); return result;
} } }
public static Result<Option<LatentHttpStreamingChunk>, LatentHttpStreamingHttpError> read(LatentHttpStreamingBody arg0, Long arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT51(arguments, arg0);
writeU32(arguments, arg1);
try (Wire.Reader input = arguments.call(17)) {
Result<Option<LatentHttpStreamingChunk>, LatentHttpStreamingHttpError> result = readT54(input);
input.finish(); return result;
} } }
public static Result<byte[], LatentHttpStreamingHttpError> chunkBytes(LatentHttpStreamingChunk arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT55(arguments, arg0);
try (Wire.Reader input = arguments.call(18)) {
Result<byte[], LatentHttpStreamingHttpError> result = readT56(input);
input.finish(); return result;
} } }
public static Result<java.util.List<LatentHttpStreamingHeader>, LatentHttpStreamingHttpError> trailers(LatentHttpStreamingBody arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT51(arguments, arg0);
try (Wire.Reader input = arguments.call(19)) {
Result<java.util.List<LatentHttpStreamingHeader>, LatentHttpStreamingHttpError> result = readT57(input);
input.finish(); return result;
} } }
public static Result<Unit, LatentHttpStreamingHttpError> abortUpload(LatentHttpStreamingUpload arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT45(arguments, arg0);
try (Wire.Reader input = arguments.call(20)) {
Result<Unit, LatentHttpStreamingHttpError> result = readT49(input);
input.finish(); return result;
} } }
public static Result<Unit, LatentHttpStreamingHttpError> abortBody(LatentHttpStreamingBody arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT42(arguments, arg0);
try (Wire.Reader input = arguments.call(21)) {
Result<Unit, LatentHttpStreamingHttpError> result = readT49(input);
input.finish(); return result;
} } }
}
public static final class LatentRandomRandom { private LatentRandomRandom() { }
public static Result<byte[], LatentRandomRandomRandomError> bytes(Long arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeU32(arguments, arg0);
try (Wire.Reader input = arguments.call(2)) {
Result<byte[], LatentRandomRandomRandomError> result = readT60(input);
input.finish(); return result;
} } }
public static Result<Unsigned64, LatentRandomRandomRandomError> u64Value() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(3)) {
Result<Unsigned64, LatentRandomRandomRandomError> result = readT61(input);
input.finish(); return result;
} } }
}
public static final class LatentSecretsReader { private LatentSecretsReader() { }
public static Result<LatentSecretsReaderSecretValue, LatentSecretsReaderSecretError> read(String arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeString(arguments, arg0);
try (Wire.Reader input = arguments.call(11)) {
Result<LatentSecretsReaderSecretValue, LatentSecretsReaderSecretError> result = readT67(input);
input.finish(); return result;
} } }
}
public static final class LatentTelemetryCustom { private LatentTelemetryCustom() { }
public static Result<Boolean, LatentTelemetryCustomTelemetryError> emitMetric(LatentTelemetryCustomMetric arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT71(arguments, arg0);
try (Wire.Reader input = arguments.call(22)) {
Result<Boolean, LatentTelemetryCustomTelemetryError> result = readT73(input);
input.finish(); return result;
} } }
}
public static final class LatentServiceInvoke { private LatentServiceInvoke() { }
public static LatentServiceInvokeInvocationOutcome call(LatentServiceInvokeTarget arg0, byte[] arg1, String arg2, LatentServiceInvokeCallOptions arg3) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT75(arguments, arg0);
writeT80(arguments, arg1);
writeString(arguments, arg2);
writeT79(arguments, arg3);
try (Wire.Reader input = arguments.call(23)) {
LatentServiceInvokeInvocationOutcome result = readT87(input);
input.finish(); return result;
} } }
}
public abstract static class Dispatch extends Function { public abstract Address apply(int operation, Address data, int length); }
public static void main(String[] args) { Function.get(Dispatch.class, Bindings.class, "dispatch"); }
@Export(name = "lsf_java_dispatch") public static Address dispatch(int operation, Address data, int length) {
try (Wire.Reader input = Wire.Reader.copy(data, length); Wire.Writer output = new Wire.Writer()) {
switch (operation) {
case 0: {
Unsigned64 arg0 = readU64(input);
input.finish();
writeU64(output, new dev.latent.app.Capsule().identity(arg0));
return output.nativeResult(); }
default: throw new IllegalArgumentException("unknown Java export"); } } }
private static Unit readUnit(Wire.Reader input) { return Unit.VALUE; }
private static void writeUnit(Wire.Writer output, Unit value) { java.util.Objects.requireNonNull(value); }
private static Integer readCharValue(Wire.Reader input) { long value = input.integer(4); Wire.require(value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); return (int) value; }
private static Boolean readBool(Wire.Reader input) { return input.bool(); }
private static void writeBool(Wire.Writer output, Boolean value) { output.bool(value); }
private static Integer readChar(Wire.Reader input) { return readCharValue(input); }
private static void writeChar(Wire.Writer output, Integer value) { Wire.require(value >= 0 && value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); output.unsigned(value, 4); }
private static Float readF32(Wire.Reader input) { return Float.intBitsToFloat((int) input.integer(4)); }
private static void writeF32(Wire.Writer output, Float value) { output.integer(Float.floatToRawIntBits(value), 4); }
private static Double readF64(Wire.Reader input) { return Double.longBitsToDouble(input.integer(8)); }
private static void writeF64(Wire.Writer output, Double value) { output.integer(Double.doubleToRawLongBits(value), 8); }
private static Short readS16(Wire.Reader input) { return (short) input.integer(2); }
private static void writeS16(Wire.Writer output, Short value) { output.integer(value, 2); }
private static Integer readS32(Wire.Reader input) { return (int) input.integer(4); }
private static void writeS32(Wire.Writer output, Integer value) { output.integer(value, 4); }
private static Long readS64(Wire.Reader input) { return (long) input.integer(8); }
private static void writeS64(Wire.Writer output, Long value) { output.integer(value, 8); }
private static Byte readS8(Wire.Reader input) { return (byte) input.integer(1); }
private static void writeS8(Wire.Writer output, Byte value) { output.integer(value, 1); }
private static String readString(Wire.Reader input) { return input.string(); }
private static void writeString(Wire.Writer output, String value) { output.string(value); }
private static Integer readU16(Wire.Reader input) { return (int) input.integer(2); }
private static void writeU16(Wire.Writer output, Integer value) { output.unsigned(value, 2); }
private static Long readU32(Wire.Reader input) { return (long) input.integer(4); }
private static void writeU32(Wire.Writer output, Long value) { output.unsigned(value, 4); }
private static Unsigned64 readU64(Wire.Reader input) { return new Unsigned64(input.integer(8)); }
private static void writeU64(Wire.Writer output, Unsigned64 value) { output.integer(value.bits(), 8); }
private static Short readU8(Wire.Reader input) { return (short) input.integer(1); }
private static void writeU8(Wire.Writer output, Short value) { output.unsigned(value, 1); }
private static void writeT0(Wire.Writer output, Unsigned64 value) {
writeU64(output, value);
}
private static Unsigned64 readT0(Wire.Reader input) {
return readU64(input);
}
private static void writeT2(Wire.Writer output, LatentBlobBlobBlobReference value) {
writeString(output, value.digest());
writeU64(output, value.size());
writeString(output, value.mediaType());
}
private static LatentBlobBlobBlobReference readT2(Wire.Reader input) {
return new LatentBlobBlobBlobReference(readString(input), readU64(input), readString(input));
}
private static void writeT3(Wire.Writer output, LatentBlobBlobBlobError value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0:  break;
case 1:  break;
case 2:  break;
case 3:  break;
case 4:  break;
case 5:  break;
case 6:  break;
case 7:  break;
case 8:  break;
case 9:  break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentBlobBlobBlobError readT3(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentBlobBlobBlobError.notFound();
case 1: return LatentBlobBlobBlobError.permissionDenied();
case 2: return LatentBlobBlobBlobError.invalidRange();
case 3: return LatentBlobBlobBlobError.invalidState();
case 4: return LatentBlobBlobBlobError.checksumMismatch();
case 5: return LatentBlobBlobBlobError.budgetExhausted();
case 6: return LatentBlobBlobBlobError.unavailable();
case 7: return LatentBlobBlobBlobError.uncertain();
case 8: return LatentBlobBlobBlobError.deadlineExceeded();
case 9: return LatentBlobBlobBlobError.cancelled();
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT4(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT4(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT5(Wire.Writer output, Result<Unsigned64, LatentBlobBlobBlobError> value) {
output.bool(value.isError()); if (value.isError()) { writeT3(output, value.error()); } else { writeT0(output, value.value()); }
}
private static Result<Unsigned64, LatentBlobBlobBlobError> readT5(Wire.Reader input) {
return input.bool() ? Result.err(readT3(input)) : Result.ok(readT0(input));
}
private static void writeT6(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT6(Wire.Reader input) {
return input.bytes();
}
private static void writeT7(Wire.Writer output, Result<Unsigned64, LatentBlobBlobBlobError> value) {
output.bool(value.isError()); if (value.isError()) { writeT3(output, value.error()); } else { writeU64(output, value.value()); }
}
private static Result<Unsigned64, LatentBlobBlobBlobError> readT7(Wire.Reader input) {
return input.bool() ? Result.err(readT3(input)) : Result.ok(readU64(input));
}
private static void writeT8(Wire.Writer output, LatentBlobBlobChunk value) {
output.resource(value, true);
}
private static LatentBlobBlobChunk readT8(Wire.Reader input) {
return new LatentBlobBlobChunk((int) input.integer(4));
}
private static void writeT9(Wire.Writer output, Result<LatentBlobBlobChunk, LatentBlobBlobBlobError> value) {
output.bool(value.isError()); if (value.isError()) { writeT3(output, value.error()); } else { writeT8(output, value.value()); }
}
private static Result<LatentBlobBlobChunk, LatentBlobBlobBlobError> readT9(Wire.Reader input) {
return input.bool() ? Result.err(readT3(input)) : Result.ok(readT8(input));
}
private static void writeT10(Wire.Writer output, LatentBlobBlobChunk value) {
output.resource(value, false);
}
private static LatentBlobBlobChunk readT10(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT11(Wire.Writer output, Result<byte[], LatentBlobBlobBlobError> value) {
output.bool(value.isError()); if (value.isError()) { writeT3(output, value.error()); } else { writeT6(output, value.value()); }
}
private static Result<byte[], LatentBlobBlobBlobError> readT11(Wire.Reader input) {
return input.bool() ? Result.err(readT3(input)) : Result.ok(readT6(input));
}
private static void writeT12(Wire.Writer output, Result<LatentBlobBlobBlobReference, LatentBlobBlobBlobError> value) {
output.bool(value.isError()); if (value.isError()) { writeT3(output, value.error()); } else { writeT2(output, value.value()); }
}
private static Result<LatentBlobBlobBlobReference, LatentBlobBlobBlobError> readT12(Wire.Reader input) {
return input.bool() ? Result.err(readT3(input)) : Result.ok(readT2(input));
}
private static void writeT13(Wire.Writer output, Result<Boolean, LatentBlobBlobBlobError> value) {
output.bool(value.isError()); if (value.isError()) { writeT3(output, value.error()); } else { writeBool(output, value.value()); }
}
private static Result<Boolean, LatentBlobBlobBlobError> readT13(Wire.Reader input) {
return input.bool() ? Result.err(readT3(input)) : Result.ok(readBool(input));
}
private static void writeT14(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT14(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT15(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT15(Wire.Reader input) {
return input.bytes();
}
private static void writeT16(Wire.Writer output, Value16 value) {
writeString(output, value.f0());
writeString(output, value.f1());
}
private static Value16 readT16(Wire.Reader input) {
return new Value16(readString(input), readString(input));
}
private static void writeT17(Wire.Writer output, java.util.List<Value16> value) {
output.count(value.size());
for (Value16 item : value) { writeT16(output, item); }
}
private static java.util.List<Value16> readT17(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<Value16> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT16(input));
return values;
}
private static void writeT18(Wire.Writer output, LatentEventsPublisherEvent value) {
writeString(output, value.topic());
writeT14(output, value.key());
writeT15(output, value.payload());
writeString(output, value.mediaType());
writeT17(output, value.attributes());
writeString(output, value.idempotencyKey());
}
private static LatentEventsPublisherEvent readT18(Wire.Reader input) {
return new LatentEventsPublisherEvent(readString(input), readT14(input), readT15(input), readString(input), readT17(input), readString(input));
}
private static void writeT19(Wire.Writer output, LatentEventsPublisherPublishReceipt value) {
writeString(output, value.eventId());
writeU64(output, value.acceptedAtUnixMillis());
writeString(output, value.streamName());
writeU64(output, value.sequence());
writeBool(output, value.duplicate());
}
private static LatentEventsPublisherPublishReceipt readT19(Wire.Reader input) {
return new LatentEventsPublisherPublishReceipt(readString(input), readU64(input), readString(input), readU64(input), readBool(input));
}
private static void writeT20(Wire.Writer output, LatentEventsPublisherEventError value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0:  break;
case 1:  break;
case 2:  break;
case 3:  break;
case 4:  break;
case 5:  break;
case 6:  break;
case 7:  break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentEventsPublisherEventError readT20(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentEventsPublisherEventError.invalidTopic();
case 1: return LatentEventsPublisherEventError.invalidEvent();
case 2: return LatentEventsPublisherEventError.permissionDenied();
case 3: return LatentEventsPublisherEventError.budgetExhausted();
case 4: return LatentEventsPublisherEventError.deadlineExceeded();
case 5: return LatentEventsPublisherEventError.cancelled();
case 6: return LatentEventsPublisherEventError.unavailable();
case 7: return LatentEventsPublisherEventError.uncertain();
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT21(Wire.Writer output, Result<LatentEventsPublisherPublishReceipt, LatentEventsPublisherEventError> value) {
output.bool(value.isError()); if (value.isError()) { writeT20(output, value.error()); } else { writeT19(output, value.value()); }
}
private static Result<LatentEventsPublisherPublishReceipt, LatentEventsPublisherEventError> readT21(Wire.Reader input) {
return input.bool() ? Result.err(readT20(input)) : Result.ok(readT19(input));
}
private static void writeT22(Wire.Writer output, LatentHttpClientMethod value) {
output.integer(value.ordinal(), 4);
}
private static LatentHttpClientMethod readT22(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 7);
return LatentHttpClientMethod.values()[(int) tag];
}
private static void writeT23(Wire.Writer output, LatentHttpClientHeader value) {
writeString(output, value.name());
writeString(output, value.value());
}
private static LatentHttpClientHeader readT23(Wire.Reader input) {
return new LatentHttpClientHeader(readString(input), readString(input));
}
private static void writeT24(Wire.Writer output, java.util.List<LatentHttpClientHeader> value) {
output.count(value.size());
for (LatentHttpClientHeader item : value) { writeT23(output, item); }
}
private static java.util.List<LatentHttpClientHeader> readT24(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<LatentHttpClientHeader> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT23(input));
return values;
}
private static void writeT25(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT25(Wire.Reader input) {
return input.bytes();
}
private static void writeT26(Wire.Writer output, Option<byte[]> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT25(output, value.value()); }
}
private static Option<byte[]> readT26(Wire.Reader input) {
return input.bool() ? Option.some(readT25(input)) : Option.none();
}
private static void writeT27(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT27(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT28(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT28(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT29(Wire.Writer output, LatentHttpClientRequest value) {
writeT22(output, value.method());
writeString(output, value.url());
writeT24(output, value.headers());
writeT26(output, value.body());
writeT27(output, value.bodyMediaType());
writeT27(output, value.idempotencyKey());
writeT28(output, value.timeoutMillis());
}
private static LatentHttpClientRequest readT29(Wire.Reader input) {
return new LatentHttpClientRequest(readT22(input), readString(input), readT24(input), readT26(input), readT27(input), readT27(input), readT28(input));
}
private static void writeT30(Wire.Writer output, LatentHttpClientResponse value) {
writeU16(output, value.status());
writeT24(output, value.headers());
writeT25(output, value.body());
writeT27(output, value.bodyMediaType());
}
private static LatentHttpClientResponse readT30(Wire.Reader input) {
return new LatentHttpClientResponse(readU16(input), readT24(input), readT25(input), readT27(input));
}
private static void writeT31(Wire.Writer output, LatentHttpClientHttpError value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0:  break;
case 1:  break;
case 2:  break;
case 3:  break;
case 4:  break;
case 5:  break;
case 6:  break;
case 7:  break;
case 8:  break;
case 9:  break;
case 10:  break;
case 11:  break;
case 12:  break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentHttpClientHttpError readT31(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentHttpClientHttpError.invalidUrl();
case 1: return LatentHttpClientHttpError.invalidRequest();
case 2: return LatentHttpClientHttpError.permissionDenied();
case 3: return LatentHttpClientHttpError.requestTooLarge();
case 4: return LatentHttpClientHttpError.responseTooLarge();
case 5: return LatentHttpClientHttpError.deadlineExceeded();
case 6: return LatentHttpClientHttpError.cancelled();
case 7: return LatentHttpClientHttpError.budgetExhausted();
case 8: return LatentHttpClientHttpError.dnsFailed();
case 9: return LatentHttpClientHttpError.tlsFailed();
case 10: return LatentHttpClientHttpError.connectionFailed();
case 11: return LatentHttpClientHttpError.unavailable();
case 12: return LatentHttpClientHttpError.uncertain();
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT32(Wire.Writer output, Result<LatentHttpClientResponse, LatentHttpClientHttpError> value) {
output.bool(value.isError()); if (value.isError()) { writeT31(output, value.error()); } else { writeT30(output, value.value()); }
}
private static Result<LatentHttpClientResponse, LatentHttpClientHttpError> readT32(Wire.Reader input) {
return input.bool() ? Result.err(readT31(input)) : Result.ok(readT30(input));
}
private static void writeT33(Wire.Writer output, LatentHttpStreamingMethod value) {
output.integer(value.ordinal(), 4);
}
private static LatentHttpStreamingMethod readT33(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 7);
return LatentHttpStreamingMethod.values()[(int) tag];
}
private static void writeT34(Wire.Writer output, LatentHttpStreamingHeader value) {
writeString(output, value.name());
writeString(output, value.value());
}
private static LatentHttpStreamingHeader readT34(Wire.Reader input) {
return new LatentHttpStreamingHeader(readString(input), readString(input));
}
private static void writeT35(Wire.Writer output, java.util.List<LatentHttpStreamingHeader> value) {
output.count(value.size());
for (LatentHttpStreamingHeader item : value) { writeT34(output, item); }
}
private static java.util.List<LatentHttpStreamingHeader> readT35(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<LatentHttpStreamingHeader> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT34(input));
return values;
}
private static void writeT36(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT36(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT37(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT37(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT38(Wire.Writer output, LatentHttpStreamingRequest value) {
writeT33(output, value.method());
writeString(output, value.url());
writeT35(output, value.headers());
writeT36(output, value.bodyLength());
writeT37(output, value.bodyMediaType());
writeT37(output, value.idempotencyKey());
writeT36(output, value.timeoutMillis());
}
private static LatentHttpStreamingRequest readT38(Wire.Reader input) {
return new LatentHttpStreamingRequest(readT33(input), readString(input), readT35(input), readT36(input), readT37(input), readT37(input), readT36(input));
}
private static void writeT42(Wire.Writer output, LatentHttpStreamingBody value) {
output.resource(value, true);
}
private static LatentHttpStreamingBody readT42(Wire.Reader input) {
return new LatentHttpStreamingBody((int) input.integer(4));
}
private static void writeT43(Wire.Writer output, LatentHttpStreamingResponse value) {
writeU16(output, value.status());
writeT35(output, value.headers());
writeT37(output, value.bodyMediaType());
writeT42(output, value.body());
}
private static LatentHttpStreamingResponse readT43(Wire.Reader input) {
return new LatentHttpStreamingResponse(readU16(input), readT35(input), readT37(input), readT42(input));
}
private static void writeT44(Wire.Writer output, LatentHttpStreamingHttpError value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0:  break;
case 1:  break;
case 2:  break;
case 3:  break;
case 4:  break;
case 5:  break;
case 6:  break;
case 7:  break;
case 8:  break;
case 9:  break;
case 10:  break;
case 11:  break;
case 12:  break;
case 13:  break;
case 14:  break;
case 15:  break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentHttpStreamingHttpError readT44(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentHttpStreamingHttpError.invalidUrl();
case 1: return LatentHttpStreamingHttpError.invalidRequest();
case 2: return LatentHttpStreamingHttpError.permissionDenied();
case 3: return LatentHttpStreamingHttpError.requestTooLarge();
case 4: return LatentHttpStreamingHttpError.responseTooLarge();
case 5: return LatentHttpStreamingHttpError.deadlineExceeded();
case 6: return LatentHttpStreamingHttpError.cancelled();
case 7: return LatentHttpStreamingHttpError.budgetExhausted();
case 8: return LatentHttpStreamingHttpError.dnsFailed();
case 9: return LatentHttpStreamingHttpError.tlsFailed();
case 10: return LatentHttpStreamingHttpError.connectionFailed();
case 11: return LatentHttpStreamingHttpError.unavailable();
case 12: return LatentHttpStreamingHttpError.uncertain();
case 13: return LatentHttpStreamingHttpError.invalidState();
case 14: return LatentHttpStreamingHttpError.unexpectedEof();
case 15: return LatentHttpStreamingHttpError.unsupportedEncoding();
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT45(Wire.Writer output, LatentHttpStreamingUpload value) {
output.resource(value, true);
}
private static LatentHttpStreamingUpload readT45(Wire.Reader input) {
return new LatentHttpStreamingUpload((int) input.integer(4));
}
private static void writeT46(Wire.Writer output, Result<LatentHttpStreamingUpload, LatentHttpStreamingHttpError> value) {
output.bool(value.isError()); if (value.isError()) { writeT44(output, value.error()); } else { writeT45(output, value.value()); }
}
private static Result<LatentHttpStreamingUpload, LatentHttpStreamingHttpError> readT46(Wire.Reader input) {
return input.bool() ? Result.err(readT44(input)) : Result.ok(readT45(input));
}
private static void writeT47(Wire.Writer output, LatentHttpStreamingUpload value) {
output.resource(value, false);
}
private static LatentHttpStreamingUpload readT47(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT48(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT48(Wire.Reader input) {
return input.bytes();
}
private static void writeT49(Wire.Writer output, Result<Unit, LatentHttpStreamingHttpError> value) {
output.bool(value.isError()); if (value.isError()) { writeT44(output, value.error()); } else { writeUnit(output, value.value()); }
}
private static Result<Unit, LatentHttpStreamingHttpError> readT49(Wire.Reader input) {
return input.bool() ? Result.err(readT44(input)) : Result.ok(readUnit(input));
}
private static void writeT50(Wire.Writer output, Result<LatentHttpStreamingResponse, LatentHttpStreamingHttpError> value) {
output.bool(value.isError()); if (value.isError()) { writeT44(output, value.error()); } else { writeT43(output, value.value()); }
}
private static Result<LatentHttpStreamingResponse, LatentHttpStreamingHttpError> readT50(Wire.Reader input) {
return input.bool() ? Result.err(readT44(input)) : Result.ok(readT43(input));
}
private static void writeT51(Wire.Writer output, LatentHttpStreamingBody value) {
output.resource(value, false);
}
private static LatentHttpStreamingBody readT51(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT52(Wire.Writer output, LatentHttpStreamingChunk value) {
output.resource(value, true);
}
private static LatentHttpStreamingChunk readT52(Wire.Reader input) {
return new LatentHttpStreamingChunk((int) input.integer(4));
}
private static void writeT53(Wire.Writer output, Option<LatentHttpStreamingChunk> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT52(output, value.value()); }
}
private static Option<LatentHttpStreamingChunk> readT53(Wire.Reader input) {
return input.bool() ? Option.some(readT52(input)) : Option.none();
}
private static void writeT54(Wire.Writer output, Result<Option<LatentHttpStreamingChunk>, LatentHttpStreamingHttpError> value) {
output.bool(value.isError()); if (value.isError()) { writeT44(output, value.error()); } else { writeT53(output, value.value()); }
}
private static Result<Option<LatentHttpStreamingChunk>, LatentHttpStreamingHttpError> readT54(Wire.Reader input) {
return input.bool() ? Result.err(readT44(input)) : Result.ok(readT53(input));
}
private static void writeT55(Wire.Writer output, LatentHttpStreamingChunk value) {
output.resource(value, false);
}
private static LatentHttpStreamingChunk readT55(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT56(Wire.Writer output, Result<byte[], LatentHttpStreamingHttpError> value) {
output.bool(value.isError()); if (value.isError()) { writeT44(output, value.error()); } else { writeT48(output, value.value()); }
}
private static Result<byte[], LatentHttpStreamingHttpError> readT56(Wire.Reader input) {
return input.bool() ? Result.err(readT44(input)) : Result.ok(readT48(input));
}
private static void writeT57(Wire.Writer output, Result<java.util.List<LatentHttpStreamingHeader>, LatentHttpStreamingHttpError> value) {
output.bool(value.isError()); if (value.isError()) { writeT44(output, value.error()); } else { writeT35(output, value.value()); }
}
private static Result<java.util.List<LatentHttpStreamingHeader>, LatentHttpStreamingHttpError> readT57(Wire.Reader input) {
return input.bool() ? Result.err(readT44(input)) : Result.ok(readT35(input));
}
private static void writeT58(Wire.Writer output, LatentRandomRandomRandomError value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0:  break;
case 1:  break;
case 2:  break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentRandomRandomRandomError readT58(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentRandomRandomRandomError.invalidLength();
case 1: return LatentRandomRandomRandomError.budgetExhausted();
case 2: return LatentRandomRandomRandomError.unavailable();
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT59(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT59(Wire.Reader input) {
return input.bytes();
}
private static void writeT60(Wire.Writer output, Result<byte[], LatentRandomRandomRandomError> value) {
output.bool(value.isError()); if (value.isError()) { writeT58(output, value.error()); } else { writeT59(output, value.value()); }
}
private static Result<byte[], LatentRandomRandomRandomError> readT60(Wire.Reader input) {
return input.bool() ? Result.err(readT58(input)) : Result.ok(readT59(input));
}
private static void writeT61(Wire.Writer output, Result<Unsigned64, LatentRandomRandomRandomError> value) {
output.bool(value.isError()); if (value.isError()) { writeT58(output, value.error()); } else { writeU64(output, value.value()); }
}
private static Result<Unsigned64, LatentRandomRandomRandomError> readT61(Wire.Reader input) {
return input.bool() ? Result.err(readT58(input)) : Result.ok(readU64(input));
}
private static void writeT62(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT62(Wire.Reader input) {
return input.bytes();
}
private static void writeT63(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT63(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT64(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT64(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT65(Wire.Writer output, LatentSecretsReaderSecretValue value) {
writeT62(output, value.bytes());
writeString(output, value.mediaType());
writeT63(output, value.version());
writeT64(output, value.expiresAtUnixMillis());
}
private static LatentSecretsReaderSecretValue readT65(Wire.Reader input) {
return new LatentSecretsReaderSecretValue(readT62(input), readString(input), readT63(input), readT64(input));
}
private static void writeT66(Wire.Writer output, LatentSecretsReaderSecretError value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0:  break;
case 1:  break;
case 2:  break;
case 3:  break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentSecretsReaderSecretError readT66(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentSecretsReaderSecretError.notFound();
case 1: return LatentSecretsReaderSecretError.permissionDenied();
case 2: return LatentSecretsReaderSecretError.expired();
case 3: return LatentSecretsReaderSecretError.unavailable();
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT67(Wire.Writer output, Result<LatentSecretsReaderSecretValue, LatentSecretsReaderSecretError> value) {
output.bool(value.isError()); if (value.isError()) { writeT66(output, value.error()); } else { writeT65(output, value.value()); }
}
private static Result<LatentSecretsReaderSecretValue, LatentSecretsReaderSecretError> readT67(Wire.Reader input) {
return input.bool() ? Result.err(readT66(input)) : Result.ok(readT65(input));
}
private static void writeT68(Wire.Writer output, LatentTelemetryCustomMetricKind value) {
output.integer(value.ordinal(), 4);
}
private static LatentTelemetryCustomMetricKind readT68(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 4);
return LatentTelemetryCustomMetricKind.values()[(int) tag];
}
private static void writeT69(Wire.Writer output, Value69 value) {
writeString(output, value.f0());
writeString(output, value.f1());
}
private static Value69 readT69(Wire.Reader input) {
return new Value69(readString(input), readString(input));
}
private static void writeT70(Wire.Writer output, java.util.List<Value69> value) {
output.count(value.size());
for (Value69 item : value) { writeT69(output, item); }
}
private static java.util.List<Value69> readT70(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<Value69> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT69(input));
return values;
}
private static void writeT71(Wire.Writer output, LatentTelemetryCustomMetric value) {
writeString(output, value.name());
writeT68(output, value.kind());
writeF64(output, value.value());
writeString(output, value.unit());
writeT70(output, value.attributes());
}
private static LatentTelemetryCustomMetric readT71(Wire.Reader input) {
return new LatentTelemetryCustomMetric(readString(input), readT68(input), readF64(input), readString(input), readT70(input));
}
private static void writeT72(Wire.Writer output, LatentTelemetryCustomTelemetryError value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0:  break;
case 1:  break;
case 2:  break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentTelemetryCustomTelemetryError readT72(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentTelemetryCustomTelemetryError.invalidName();
case 1: return LatentTelemetryCustomTelemetryError.budgetExhausted();
case 2: return LatentTelemetryCustomTelemetryError.unavailable();
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT73(Wire.Writer output, Result<Boolean, LatentTelemetryCustomTelemetryError> value) {
output.bool(value.isError()); if (value.isError()) { writeT72(output, value.error()); } else { writeBool(output, value.value()); }
}
private static Result<Boolean, LatentTelemetryCustomTelemetryError> readT73(Wire.Reader input) {
return input.bool() ? Result.err(readT72(input)) : Result.ok(readBool(input));
}
private static void writeT74(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT74(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT75(Wire.Writer output, LatentServiceInvokeTarget value) {
writeT74(output, value.tenant());
writeString(output, value.service());
writeString(output, value.contract());
writeString(output, value.function());
writeT74(output, value.route());
}
private static LatentServiceInvokeTarget readT75(Wire.Reader input) {
return new LatentServiceInvokeTarget(readT74(input), readString(input), readString(input), readString(input), readT74(input));
}
private static void writeT76(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT76(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT77(Wire.Writer output, Value77 value) {
writeString(output, value.f0());
writeString(output, value.f1());
}
private static Value77 readT77(Wire.Reader input) {
return new Value77(readString(input), readString(input));
}
private static void writeT78(Wire.Writer output, java.util.List<Value77> value) {
output.count(value.size());
for (Value77 item : value) { writeT77(output, item); }
}
private static java.util.List<Value77> readT78(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<Value77> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT77(input));
return values;
}
private static void writeT79(Wire.Writer output, LatentServiceInvokeCallOptions value) {
writeT76(output, value.deadlineUnixMillis());
writeU8(output, value.priority());
writeT74(output, value.idempotencyKey());
writeT78(output, value.metadata());
}
private static LatentServiceInvokeCallOptions readT79(Wire.Reader input) {
return new LatentServiceInvokeCallOptions(readT76(input), readU8(input), readT74(input), readT78(input));
}
private static void writeT80(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT80(Wire.Reader input) {
return input.bytes();
}
private static void writeT81(Wire.Writer output, LatentServiceInvokeInvocationResult value) {
writeT80(output, value.payload());
writeString(output, value.mediaType());
writeT78(output, value.metadata());
}
private static LatentServiceInvokeInvocationResult readT81(Wire.Reader input) {
return new LatentServiceInvokeInvocationResult(readT80(input), readString(input), readT78(input));
}
private static void writeT82(Wire.Writer output, LatentServiceInvokeErrorDetail value) {
writeString(output, value.kind());
writeT78(output, value.fields());
}
private static LatentServiceInvokeErrorDetail readT82(Wire.Reader input) {
return new LatentServiceInvokeErrorDetail(readString(input), readT78(input));
}
private static void writeT83(Wire.Writer output, LatentServiceInvokePlatformErrorCode value) {
output.integer(value.ordinal(), 4);
}
private static LatentServiceInvokePlatformErrorCode readT83(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 17);
return LatentServiceInvokePlatformErrorCode.values()[(int) tag];
}
private static void writeT84(Wire.Writer output, java.util.List<LatentServiceInvokeErrorDetail> value) {
output.count(value.size());
for (LatentServiceInvokeErrorDetail item : value) { writeT82(output, item); }
}
private static java.util.List<LatentServiceInvokeErrorDetail> readT84(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<LatentServiceInvokeErrorDetail> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT82(input));
return values;
}
private static void writeT85(Wire.Writer output, LatentServiceInvokePlatformError value) {
writeT83(output, value.code());
writeString(output, value.message());
writeBool(output, value.retryable());
writeT84(output, value.details());
}
private static LatentServiceInvokePlatformError readT85(Wire.Reader input) {
return new LatentServiceInvokePlatformError(readT83(input), readString(input), readBool(input), readT84(input));
}
private static void writeT86(Wire.Writer output, LatentServiceInvokeDeclaredError value) {
writeString(output, value.code());
writeString(output, value.message());
writeT80(output, value.payload());
writeString(output, value.mediaType());
writeT78(output, value.metadata());
}
private static LatentServiceInvokeDeclaredError readT86(Wire.Reader input) {
return new LatentServiceInvokeDeclaredError(readString(input), readString(input), readT80(input), readString(input), readT78(input));
}
private static void writeT87(Wire.Writer output, LatentServiceInvokeInvocationOutcome value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0: writeT81(output, value.successValue()); break;
case 1: writeT86(output, value.declaredErrorValue()); break;
case 2: writeT85(output, value.platformFailureValue()); break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentServiceInvokeInvocationOutcome readT87(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentServiceInvokeInvocationOutcome.success(readT81(input));
case 1: return LatentServiceInvokeInvocationOutcome.declaredError(readT86(input));
case 2: return LatentServiceInvokeInvocationOutcome.platformFailure(readT85(input));
default: throw new IllegalArgumentException("invalid variant tag"); }
}
}
