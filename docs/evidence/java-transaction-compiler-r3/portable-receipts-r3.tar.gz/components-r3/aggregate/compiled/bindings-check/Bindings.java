// Generated from authoritative WIT and maintained wit-bindgen C. DO NOT EDIT.
package dev.latent.generated;
import dev.latent.guest.*;
import org.teavm.interop.Address;
import org.teavm.interop.Export;
import org.teavm.interop.Function;
public final class Bindings {
private Bindings() { }
public static final class LatentStateKeyValueTransaction extends Resource { private LatentStateKeyValueTransaction(int handle) { super(handle, -1); } }
public static final class LatentStateKeyValueQueryView extends Resource { private LatentStateKeyValueQueryView(int handle) { super(handle, -2); } }
public static final class LatentStateKeyValuePage extends Resource { private LatentStateKeyValuePage(int handle) { super(handle, -3); } }
public record Value4(String f0, String f1) { public Value4 { java.util.Objects.requireNonNull(f0); java.util.Objects.requireNonNull(f1); } }
public record LatentStateKeyValueValue(byte[] bytes, String mediaType, java.util.List<Value4> metadata) { public LatentStateKeyValueValue { java.util.Objects.requireNonNull(bytes); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(metadata); } }
public record LatentStateKeyValueVersionedValue(LatentStateKeyValueValue value, byte[] version) { public LatentStateKeyValueVersionedValue { java.util.Objects.requireNonNull(value); java.util.Objects.requireNonNull(version); } }
public record LatentStateKeyValueEntry(byte[] key, LatentStateKeyValueVersionedValue value) { public LatentStateKeyValueEntry { java.util.Objects.requireNonNull(key); java.util.Objects.requireNonNull(value); } }
public record LatentStateKeyValueViewIdentity(String namespace, String incarnation, byte[] version, String stateSchema) { public LatentStateKeyValueViewIdentity { java.util.Objects.requireNonNull(namespace); java.util.Objects.requireNonNull(incarnation); java.util.Objects.requireNonNull(version); java.util.Objects.requireNonNull(stateSchema); } }
public record LatentStateKeyValueCommandInfo(LatentStateKeyValueViewIdentity view, String commandId, String attemptId, Option<String> entity) { public LatentStateKeyValueCommandInfo { java.util.Objects.requireNonNull(view); java.util.Objects.requireNonNull(commandId); java.util.Objects.requireNonNull(attemptId); java.util.Objects.requireNonNull(entity); } }
public record LatentStateKeyValuePageInfo(LatentStateKeyValueViewIdentity view, Long entryCount, Unsigned64 encodedBytes, Boolean hasMore, Option<byte[]> nextCursor) { public LatentStateKeyValuePageInfo { java.util.Objects.requireNonNull(view); java.util.Objects.requireNonNull(entryCount); java.util.Objects.requireNonNull(encodedBytes); java.util.Objects.requireNonNull(hasMore); java.util.Objects.requireNonNull(nextCursor); } }
public enum LatentStateKeyValueStateError { PermissionDenied, InvalidKey, InvalidValue, InvalidLimit, InvalidCursor, StaleInput, Conflict, ReadBudgetExhausted, WriteBudgetExhausted, HandleClosed, WrongActivation, WrongMode, UnsupportedVersion, Cancelled, Unavailable }
public record LatentIntentsStagingIntent(String binding, String operation, LatentStateKeyValueValue payload, Option<Unsigned64> expiresAtUnixMillis) { public LatentIntentsStagingIntent { java.util.Objects.requireNonNull(binding); java.util.Objects.requireNonNull(operation); java.util.Objects.requireNonNull(payload); java.util.Objects.requireNonNull(expiresAtUnixMillis); } }
public record LatentIntentsStagingStagedIntent(Long sequence) { public LatentIntentsStagingStagedIntent { java.util.Objects.requireNonNull(sequence); } }
public enum LatentIntentsStagingIntentError { PermissionDenied, InvalidBinding, InvalidOperation, InvalidPayload, InvalidExpiry, CountLimit, ByteLimit, HandleClosed, WrongActivation, WrongMode, UnsupportedProfile, Cancelled, Unavailable }
public record ExamplesTransactionalAggregateApiUpdateRequest(Long delta, Boolean reject) { public ExamplesTransactionalAggregateApiUpdateRequest { java.util.Objects.requireNonNull(delta); java.util.Objects.requireNonNull(reject); } }
public record ExamplesTransactionalAggregateApiAggregate(Unsigned64 count, byte[] viewVersion, Option<byte[]> keyVersion) { public ExamplesTransactionalAggregateApiAggregate { java.util.Objects.requireNonNull(count); java.util.Objects.requireNonNull(viewVersion); java.util.Objects.requireNonNull(keyVersion); } }
public record ExamplesTransactionalAggregateApiScanResult(Long count, Unsigned64 encodedBytes, byte[] viewVersion, Option<byte[]> nextCursor) { public ExamplesTransactionalAggregateApiScanResult { java.util.Objects.requireNonNull(count); java.util.Objects.requireNonNull(encodedBytes); java.util.Objects.requireNonNull(viewVersion); java.util.Objects.requireNonNull(nextCursor); } }
public enum ExamplesTransactionalAggregateApiBusinessError { Rejected, MalformedState, Overflow }
public interface Exports {
Result<ExamplesTransactionalAggregateApiAggregate, ExamplesTransactionalAggregateApiBusinessError> update(ExamplesTransactionalAggregateApiUpdateRequest arg0);
Result<ExamplesTransactionalAggregateApiAggregate, ExamplesTransactionalAggregateApiBusinessError> query();
Result<ExamplesTransactionalAggregateApiScanResult, ExamplesTransactionalAggregateApiBusinessError> scan(byte[] arg0, Long arg1, Option<byte[]> arg2);
}
public static final class LatentClockMonotonic { private LatentClockMonotonic() { }
public static Unsigned64 nowNanos() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(0)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentClockWall { private LatentClockWall() { }
public static Unsigned64 nowUnixMillis() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(1)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentStateKeyValue { private LatentStateKeyValue() { }
public static Result<LatentStateKeyValueTransaction, LatentStateKeyValueStateError> acquireCommand() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(2)) {
Result<LatentStateKeyValueTransaction, LatentStateKeyValueStateError> result = readT17(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValueQueryView, LatentStateKeyValueStateError> acquireQuery() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(3)) {
Result<LatentStateKeyValueQueryView, LatentStateKeyValueStateError> result = readT19(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValueCommandInfo, LatentStateKeyValueStateError> info(LatentStateKeyValueTransaction arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT20(arguments, arg0);
try (Wire.Reader input = arguments.call(4)) {
Result<LatentStateKeyValueCommandInfo, LatentStateKeyValueStateError> result = readT21(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValueViewIdentity, LatentStateKeyValueStateError> queryInfo(LatentStateKeyValueQueryView arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT22(arguments, arg0);
try (Wire.Reader input = arguments.call(5)) {
Result<LatentStateKeyValueViewIdentity, LatentStateKeyValueStateError> result = readT23(input);
input.finish(); return result;
} } }
public static Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> get(LatentStateKeyValueTransaction arg0, byte[] arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT20(arguments, arg0);
writeT3(arguments, arg1);
try (Wire.Reader input = arguments.call(6)) {
Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> result = readT25(input);
input.finish(); return result;
} } }
public static Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> getQuery(LatentStateKeyValueQueryView arg0, byte[] arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT22(arguments, arg0);
writeT3(arguments, arg1);
try (Wire.Reader input = arguments.call(7)) {
Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> result = readT25(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> scan(LatentStateKeyValueTransaction arg0, byte[] arg1, Long arg2, Option<byte[]> arg3) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT20(arguments, arg0);
writeT3(arguments, arg1);
writeU32(arguments, arg2);
writeT13(arguments, arg3);
try (Wire.Reader input = arguments.call(8)) {
Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> result = readT27(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> scanQuery(LatentStateKeyValueQueryView arg0, byte[] arg1, Long arg2, Option<byte[]> arg3) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT22(arguments, arg0);
writeT3(arguments, arg1);
writeU32(arguments, arg2);
writeT13(arguments, arg3);
try (Wire.Reader input = arguments.call(9)) {
Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> result = readT27(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValuePageInfo, LatentStateKeyValueStateError> describePage(LatentStateKeyValuePage arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT28(arguments, arg0);
try (Wire.Reader input = arguments.call(10)) {
Result<LatentStateKeyValuePageInfo, LatentStateKeyValueStateError> result = readT29(input);
input.finish(); return result;
} } }
public static Result<Option<LatentStateKeyValueEntry>, LatentStateKeyValueStateError> pageNext(LatentStateKeyValuePage arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT28(arguments, arg0);
try (Wire.Reader input = arguments.call(11)) {
Result<Option<LatentStateKeyValueEntry>, LatentStateKeyValueStateError> result = readT31(input);
input.finish(); return result;
} } }
public static Result<Unit, LatentStateKeyValueStateError> put(LatentStateKeyValueTransaction arg0, byte[] arg1, LatentStateKeyValueValue arg2) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT20(arguments, arg0);
writeT3(arguments, arg1);
writeT6(arguments, arg2);
try (Wire.Reader input = arguments.call(12)) {
Result<Unit, LatentStateKeyValueStateError> result = readT32(input);
input.finish(); return result;
} } }
public static Result<Unit, LatentStateKeyValueStateError> delete(LatentStateKeyValueTransaction arg0, byte[] arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT20(arguments, arg0);
writeT3(arguments, arg1);
try (Wire.Reader input = arguments.call(13)) {
Result<Unit, LatentStateKeyValueStateError> result = readT32(input);
input.finish(); return result;
} } }
}
public static final class LatentIntentsStaging { private LatentIntentsStaging() { }
public static Result<LatentIntentsStagingStagedIntent, LatentIntentsStagingIntentError> stage(LatentStateKeyValueTransaction arg0, LatentIntentsStagingIntent arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT39(arguments, arg0);
writeT36(arguments, arg1);
try (Wire.Reader input = arguments.call(14)) {
Result<LatentIntentsStagingStagedIntent, LatentIntentsStagingIntentError> result = readT40(input);
input.finish(); return result;
} } }
}
public abstract static class Dispatch extends Function { public abstract Address apply(int operation, Address data, int length); }
public static void main(String[] args) { Function.get(Dispatch.class, Bindings.class, "dispatch"); }
@Export(name = "lsf_java_dispatch") public static Address dispatch(int operation, Address data, int length) {
try (Wire.Reader input = Wire.Reader.copy(data, length); Wire.Writer output = new Wire.Writer()) {
switch (operation) {
case 0: {
ExamplesTransactionalAggregateApiUpdateRequest arg0 = readT41(input);
input.finish();
writeT47(output, new dev.latent.app.Capsule().update(arg0));
return output.nativeResult(); }
case 1: {
input.finish();
writeT47(output, new dev.latent.app.Capsule().query());
return output.nativeResult(); }
case 2: {
byte[] arg0 = readT42(input);
Long arg1 = readU32(input);
Option<byte[]> arg2 = readT43(input);
input.finish();
writeT48(output, new dev.latent.app.Capsule().scan(arg0, arg1, arg2));
return output.nativeResult(); }
default: throw new IllegalArgumentException("unknown Java export"); } } }
private static Unit readUnit(Wire.Reader input) { return Unit.VALUE; }
private static void writeUnit(Wire.Writer output, Unit value) { java.util.Objects.requireNonNull(value); }
private static Integer readCharValue(Wire.Reader input) { long value = input.integer(4); Wire.require(value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); return (int) value; }
private static Boolean readBool(Wire.Reader input) { return input.bool(); }
private static void writeBool(Wire.Writer output, Boolean value) { output.bool(value); }
private static Integer readChar(Wire.Reader input) { return readCharValue(input); }
private static void writeChar(Wire.Writer output, Integer value) { Wire.require(value >= 0 && value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); output.unsigned(value, 4); }
private static Float readF32(Wire.Reader input) { return Float.intBitsToFloat((int) input.integer(4)); }
private static void writeF32(Wire.Writer output, Float value) { output.integer(Float.floatToRawIntBits(value), 4); }
private static Double readF64(Wire.Reader input) { return Double.longBitsToDouble(input.integer(8)); }
private static void writeF64(Wire.Writer output, Double value) { output.integer(Double.doubleToRawLongBits(value), 8); }
private static Short readS16(Wire.Reader input) { return (short) input.integer(2); }
private static void writeS16(Wire.Writer output, Short value) { output.integer(value, 2); }
private static Integer readS32(Wire.Reader input) { return (int) input.integer(4); }
private static void writeS32(Wire.Writer output, Integer value) { output.integer(value, 4); }
private static Long readS64(Wire.Reader input) { return (long) input.integer(8); }
private static void writeS64(Wire.Writer output, Long value) { output.integer(value, 8); }
private static Byte readS8(Wire.Reader input) { return (byte) input.integer(1); }
private static void writeS8(Wire.Writer output, Byte value) { output.integer(value, 1); }
private static String readString(Wire.Reader input) { return input.string(); }
private static void writeString(Wire.Writer output, String value) { output.string(value); }
private static Integer readU16(Wire.Reader input) { return (int) input.integer(2); }
private static void writeU16(Wire.Writer output, Integer value) { output.unsigned(value, 2); }
private static Long readU32(Wire.Reader input) { return (long) input.integer(4); }
private static void writeU32(Wire.Writer output, Long value) { output.unsigned(value, 4); }
private static Unsigned64 readU64(Wire.Reader input) { return new Unsigned64(input.integer(8)); }
private static void writeU64(Wire.Writer output, Unsigned64 value) { output.integer(value.bits(), 8); }
private static Short readU8(Wire.Reader input) { return (short) input.integer(1); }
private static void writeU8(Wire.Writer output, Short value) { output.unsigned(value, 1); }
private static void writeT3(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT3(Wire.Reader input) {
return input.bytes();
}
private static void writeT4(Wire.Writer output, Value4 value) {
writeString(output, value.f0());
writeString(output, value.f1());
}
private static Value4 readT4(Wire.Reader input) {
return new Value4(readString(input), readString(input));
}
private static void writeT5(Wire.Writer output, java.util.List<Value4> value) {
output.count(value.size());
for (Value4 item : value) { writeT4(output, item); }
}
private static java.util.List<Value4> readT5(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<Value4> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT4(input));
return values;
}
private static void writeT6(Wire.Writer output, LatentStateKeyValueValue value) {
writeT3(output, value.bytes());
writeString(output, value.mediaType());
writeT5(output, value.metadata());
}
private static LatentStateKeyValueValue readT6(Wire.Reader input) {
return new LatentStateKeyValueValue(readT3(input), readString(input), readT5(input));
}
private static void writeT7(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT7(Wire.Reader input) {
return input.bytes();
}
private static void writeT8(Wire.Writer output, LatentStateKeyValueVersionedValue value) {
writeT6(output, value.value());
writeT7(output, value.version());
}
private static LatentStateKeyValueVersionedValue readT8(Wire.Reader input) {
return new LatentStateKeyValueVersionedValue(readT6(input), readT7(input));
}
private static void writeT9(Wire.Writer output, LatentStateKeyValueEntry value) {
writeT3(output, value.key());
writeT8(output, value.value());
}
private static LatentStateKeyValueEntry readT9(Wire.Reader input) {
return new LatentStateKeyValueEntry(readT3(input), readT8(input));
}
private static void writeT10(Wire.Writer output, LatentStateKeyValueViewIdentity value) {
writeString(output, value.namespace());
writeString(output, value.incarnation());
writeT7(output, value.version());
writeString(output, value.stateSchema());
}
private static LatentStateKeyValueViewIdentity readT10(Wire.Reader input) {
return new LatentStateKeyValueViewIdentity(readString(input), readString(input), readT7(input), readString(input));
}
private static void writeT11(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT11(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT12(Wire.Writer output, LatentStateKeyValueCommandInfo value) {
writeT10(output, value.view());
writeString(output, value.commandId());
writeString(output, value.attemptId());
writeT11(output, value.entity());
}
private static LatentStateKeyValueCommandInfo readT12(Wire.Reader input) {
return new LatentStateKeyValueCommandInfo(readT10(input), readString(input), readString(input), readT11(input));
}
private static void writeT13(Wire.Writer output, Option<byte[]> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT3(output, value.value()); }
}
private static Option<byte[]> readT13(Wire.Reader input) {
return input.bool() ? Option.some(readT3(input)) : Option.none();
}
private static void writeT14(Wire.Writer output, LatentStateKeyValuePageInfo value) {
writeT10(output, value.view());
writeU32(output, value.entryCount());
writeU64(output, value.encodedBytes());
writeBool(output, value.hasMore());
writeT13(output, value.nextCursor());
}
private static LatentStateKeyValuePageInfo readT14(Wire.Reader input) {
return new LatentStateKeyValuePageInfo(readT10(input), readU32(input), readU64(input), readBool(input), readT13(input));
}
private static void writeT15(Wire.Writer output, LatentStateKeyValueStateError value) {
output.integer(value.ordinal(), 4);
}
private static LatentStateKeyValueStateError readT15(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 15);
return LatentStateKeyValueStateError.values()[(int) tag];
}
private static void writeT16(Wire.Writer output, LatentStateKeyValueTransaction value) {
output.resource(value, true);
}
private static LatentStateKeyValueTransaction readT16(Wire.Reader input) {
return new LatentStateKeyValueTransaction((int) input.integer(4));
}
private static void writeT17(Wire.Writer output, Result<LatentStateKeyValueTransaction, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT15(output, value.error()); } else { writeT16(output, value.value()); }
}
private static Result<LatentStateKeyValueTransaction, LatentStateKeyValueStateError> readT17(Wire.Reader input) {
return input.bool() ? Result.err(readT15(input)) : Result.ok(readT16(input));
}
private static void writeT18(Wire.Writer output, LatentStateKeyValueQueryView value) {
output.resource(value, true);
}
private static LatentStateKeyValueQueryView readT18(Wire.Reader input) {
return new LatentStateKeyValueQueryView((int) input.integer(4));
}
private static void writeT19(Wire.Writer output, Result<LatentStateKeyValueQueryView, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT15(output, value.error()); } else { writeT18(output, value.value()); }
}
private static Result<LatentStateKeyValueQueryView, LatentStateKeyValueStateError> readT19(Wire.Reader input) {
return input.bool() ? Result.err(readT15(input)) : Result.ok(readT18(input));
}
private static void writeT20(Wire.Writer output, LatentStateKeyValueTransaction value) {
output.resource(value, false);
}
private static LatentStateKeyValueTransaction readT20(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT21(Wire.Writer output, Result<LatentStateKeyValueCommandInfo, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT15(output, value.error()); } else { writeT12(output, value.value()); }
}
private static Result<LatentStateKeyValueCommandInfo, LatentStateKeyValueStateError> readT21(Wire.Reader input) {
return input.bool() ? Result.err(readT15(input)) : Result.ok(readT12(input));
}
private static void writeT22(Wire.Writer output, LatentStateKeyValueQueryView value) {
output.resource(value, false);
}
private static LatentStateKeyValueQueryView readT22(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT23(Wire.Writer output, Result<LatentStateKeyValueViewIdentity, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT15(output, value.error()); } else { writeT10(output, value.value()); }
}
private static Result<LatentStateKeyValueViewIdentity, LatentStateKeyValueStateError> readT23(Wire.Reader input) {
return input.bool() ? Result.err(readT15(input)) : Result.ok(readT10(input));
}
private static void writeT24(Wire.Writer output, Option<LatentStateKeyValueVersionedValue> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT8(output, value.value()); }
}
private static Option<LatentStateKeyValueVersionedValue> readT24(Wire.Reader input) {
return input.bool() ? Option.some(readT8(input)) : Option.none();
}
private static void writeT25(Wire.Writer output, Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT15(output, value.error()); } else { writeT24(output, value.value()); }
}
private static Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> readT25(Wire.Reader input) {
return input.bool() ? Result.err(readT15(input)) : Result.ok(readT24(input));
}
private static void writeT26(Wire.Writer output, LatentStateKeyValuePage value) {
output.resource(value, true);
}
private static LatentStateKeyValuePage readT26(Wire.Reader input) {
return new LatentStateKeyValuePage((int) input.integer(4));
}
private static void writeT27(Wire.Writer output, Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT15(output, value.error()); } else { writeT26(output, value.value()); }
}
private static Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> readT27(Wire.Reader input) {
return input.bool() ? Result.err(readT15(input)) : Result.ok(readT26(input));
}
private static void writeT28(Wire.Writer output, LatentStateKeyValuePage value) {
output.resource(value, false);
}
private static LatentStateKeyValuePage readT28(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT29(Wire.Writer output, Result<LatentStateKeyValuePageInfo, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT15(output, value.error()); } else { writeT14(output, value.value()); }
}
private static Result<LatentStateKeyValuePageInfo, LatentStateKeyValueStateError> readT29(Wire.Reader input) {
return input.bool() ? Result.err(readT15(input)) : Result.ok(readT14(input));
}
private static void writeT30(Wire.Writer output, Option<LatentStateKeyValueEntry> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT9(output, value.value()); }
}
private static Option<LatentStateKeyValueEntry> readT30(Wire.Reader input) {
return input.bool() ? Option.some(readT9(input)) : Option.none();
}
private static void writeT31(Wire.Writer output, Result<Option<LatentStateKeyValueEntry>, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT15(output, value.error()); } else { writeT30(output, value.value()); }
}
private static Result<Option<LatentStateKeyValueEntry>, LatentStateKeyValueStateError> readT31(Wire.Reader input) {
return input.bool() ? Result.err(readT15(input)) : Result.ok(readT30(input));
}
private static void writeT32(Wire.Writer output, Result<Unit, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT15(output, value.error()); } else { writeUnit(output, value.value()); }
}
private static Result<Unit, LatentStateKeyValueStateError> readT32(Wire.Reader input) {
return input.bool() ? Result.err(readT15(input)) : Result.ok(readUnit(input));
}
private static void writeT34(Wire.Writer output, LatentStateKeyValueValue value) {
writeT6(output, value);
}
private static LatentStateKeyValueValue readT34(Wire.Reader input) {
return readT6(input);
}
private static void writeT35(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT35(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT36(Wire.Writer output, LatentIntentsStagingIntent value) {
writeString(output, value.binding());
writeString(output, value.operation());
writeT34(output, value.payload());
writeT35(output, value.expiresAtUnixMillis());
}
private static LatentIntentsStagingIntent readT36(Wire.Reader input) {
return new LatentIntentsStagingIntent(readString(input), readString(input), readT34(input), readT35(input));
}
private static void writeT37(Wire.Writer output, LatentIntentsStagingStagedIntent value) {
writeU32(output, value.sequence());
}
private static LatentIntentsStagingStagedIntent readT37(Wire.Reader input) {
return new LatentIntentsStagingStagedIntent(readU32(input));
}
private static void writeT38(Wire.Writer output, LatentIntentsStagingIntentError value) {
output.integer(value.ordinal(), 4);
}
private static LatentIntentsStagingIntentError readT38(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 13);
return LatentIntentsStagingIntentError.values()[(int) tag];
}
private static void writeT39(Wire.Writer output, LatentStateKeyValueTransaction value) {
output.resource(value, false);
}
private static LatentStateKeyValueTransaction readT39(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT40(Wire.Writer output, Result<LatentIntentsStagingStagedIntent, LatentIntentsStagingIntentError> value) {
output.bool(value.isError()); if (value.isError()) { writeT38(output, value.error()); } else { writeT37(output, value.value()); }
}
private static Result<LatentIntentsStagingStagedIntent, LatentIntentsStagingIntentError> readT40(Wire.Reader input) {
return input.bool() ? Result.err(readT38(input)) : Result.ok(readT37(input));
}
private static void writeT41(Wire.Writer output, ExamplesTransactionalAggregateApiUpdateRequest value) {
writeU32(output, value.delta());
writeBool(output, value.reject());
}
private static ExamplesTransactionalAggregateApiUpdateRequest readT41(Wire.Reader input) {
return new ExamplesTransactionalAggregateApiUpdateRequest(readU32(input), readBool(input));
}
private static void writeT42(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT42(Wire.Reader input) {
return input.bytes();
}
private static void writeT43(Wire.Writer output, Option<byte[]> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT42(output, value.value()); }
}
private static Option<byte[]> readT43(Wire.Reader input) {
return input.bool() ? Option.some(readT42(input)) : Option.none();
}
private static void writeT44(Wire.Writer output, ExamplesTransactionalAggregateApiAggregate value) {
writeU64(output, value.count());
writeT42(output, value.viewVersion());
writeT43(output, value.keyVersion());
}
private static ExamplesTransactionalAggregateApiAggregate readT44(Wire.Reader input) {
return new ExamplesTransactionalAggregateApiAggregate(readU64(input), readT42(input), readT43(input));
}
private static void writeT45(Wire.Writer output, ExamplesTransactionalAggregateApiScanResult value) {
writeU32(output, value.count());
writeU64(output, value.encodedBytes());
writeT42(output, value.viewVersion());
writeT43(output, value.nextCursor());
}
private static ExamplesTransactionalAggregateApiScanResult readT45(Wire.Reader input) {
return new ExamplesTransactionalAggregateApiScanResult(readU32(input), readU64(input), readT42(input), readT43(input));
}
private static void writeT46(Wire.Writer output, ExamplesTransactionalAggregateApiBusinessError value) {
output.integer(value.ordinal(), 4);
}
private static ExamplesTransactionalAggregateApiBusinessError readT46(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 3);
return ExamplesTransactionalAggregateApiBusinessError.values()[(int) tag];
}
private static void writeT47(Wire.Writer output, Result<ExamplesTransactionalAggregateApiAggregate, ExamplesTransactionalAggregateApiBusinessError> value) {
output.bool(value.isError()); if (value.isError()) { writeT46(output, value.error()); } else { writeT44(output, value.value()); }
}
private static Result<ExamplesTransactionalAggregateApiAggregate, ExamplesTransactionalAggregateApiBusinessError> readT47(Wire.Reader input) {
return input.bool() ? Result.err(readT46(input)) : Result.ok(readT44(input));
}
private static void writeT48(Wire.Writer output, Result<ExamplesTransactionalAggregateApiScanResult, ExamplesTransactionalAggregateApiBusinessError> value) {
output.bool(value.isError()); if (value.isError()) { writeT46(output, value.error()); } else { writeT45(output, value.value()); }
}
private static Result<ExamplesTransactionalAggregateApiScanResult, ExamplesTransactionalAggregateApiBusinessError> readT48(Wire.Reader input) {
return input.bool() ? Result.err(readT46(input)) : Result.ok(readT45(input));
}
}
