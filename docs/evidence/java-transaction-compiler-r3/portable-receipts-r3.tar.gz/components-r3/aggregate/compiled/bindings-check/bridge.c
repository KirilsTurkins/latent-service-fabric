/* Generated from authoritative WIT. DO NOT EDIT. */
#include "bridge.h"
void exports_examples_transactional_aggregate_api_update(exports_examples_transactional_aggregate_api_update_request_t *arg0, exports_examples_transactional_aggregate_api_result_aggregate_business_error_t *arg1) {
lsf_wire output = {0};
lsf_put(&output, (uint64_t)((*arg0).delta), 4);
lsf_put(&output, (uint64_t)((*arg0).reject), 1);
void *owned; lsf_wire input = lsf_invoke(0, &output, &owned);
uint64_t local_8 = lsf_get(&input, 1); lsf_require(local_8 <= 1); ((*arg1).is_err) = (__typeof__(((*arg1).is_err)))local_8;
if ((*arg1).is_err) {
uint64_t local_9 = lsf_get(&input, 4); lsf_require(local_9 < 3);
((*arg1).val.err) = (__typeof__(((*arg1).val.err)))local_9;
lsf_require(((*arg1).val.err) < 3);
} else {
uint64_t local_11 = lsf_get(&input, 8);  (((*arg1).val.ok).count) = (__typeof__((((*arg1).val.ok).count)))local_11;
(((*arg1).val.ok).view_version).len = (size_t)lsf_get(&input, 4); lsf_require((((*arg1).val.ok).view_version).len <= LSF_MAX_BYTES);
(((*arg1).val.ok).view_version).ptr = lsf_allocate((((*arg1).val.ok).view_version).len, sizeof(*(((*arg1).val.ok).view_version).ptr));
for (size_t local_12 = 0; local_12 < (((*arg1).val.ok).view_version).len; local_12++) {
uint64_t local_13 = lsf_get(&input, 1);  ((((*arg1).val.ok).view_version).ptr[local_12]) = (__typeof__(((((*arg1).val.ok).view_version).ptr[local_12])))local_13;
}
uint64_t local_15 = lsf_get(&input, 1); lsf_require(local_15 <= 1); ((((*arg1).val.ok).key_version).is_some) = (__typeof__(((((*arg1).val.ok).key_version).is_some)))local_15;
if ((((*arg1).val.ok).key_version).is_some) {
((((*arg1).val.ok).key_version).val).len = (size_t)lsf_get(&input, 4); lsf_require(((((*arg1).val.ok).key_version).val).len <= LSF_MAX_BYTES);
((((*arg1).val.ok).key_version).val).ptr = lsf_allocate(((((*arg1).val.ok).key_version).val).len, sizeof(*((((*arg1).val.ok).key_version).val).ptr));
for (size_t local_16 = 0; local_16 < ((((*arg1).val.ok).key_version).val).len; local_16++) {
uint64_t local_17 = lsf_get(&input, 1);  (((((*arg1).val.ok).key_version).val).ptr[local_16]) = (__typeof__((((((*arg1).val.ok).key_version).val).ptr[local_16])))local_17;
}
}
}
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_transactional_aggregate_api_query(exports_examples_transactional_aggregate_api_result_aggregate_business_error_t *arg0) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(1, &output, &owned);
uint64_t local_19 = lsf_get(&input, 1); lsf_require(local_19 <= 1); ((*arg0).is_err) = (__typeof__(((*arg0).is_err)))local_19;
if ((*arg0).is_err) {
uint64_t local_20 = lsf_get(&input, 4); lsf_require(local_20 < 3);
((*arg0).val.err) = (__typeof__(((*arg0).val.err)))local_20;
lsf_require(((*arg0).val.err) < 3);
} else {
uint64_t local_22 = lsf_get(&input, 8);  (((*arg0).val.ok).count) = (__typeof__((((*arg0).val.ok).count)))local_22;
(((*arg0).val.ok).view_version).len = (size_t)lsf_get(&input, 4); lsf_require((((*arg0).val.ok).view_version).len <= LSF_MAX_BYTES);
(((*arg0).val.ok).view_version).ptr = lsf_allocate((((*arg0).val.ok).view_version).len, sizeof(*(((*arg0).val.ok).view_version).ptr));
for (size_t local_23 = 0; local_23 < (((*arg0).val.ok).view_version).len; local_23++) {
uint64_t local_24 = lsf_get(&input, 1);  ((((*arg0).val.ok).view_version).ptr[local_23]) = (__typeof__(((((*arg0).val.ok).view_version).ptr[local_23])))local_24;
}
uint64_t local_26 = lsf_get(&input, 1); lsf_require(local_26 <= 1); ((((*arg0).val.ok).key_version).is_some) = (__typeof__(((((*arg0).val.ok).key_version).is_some)))local_26;
if ((((*arg0).val.ok).key_version).is_some) {
((((*arg0).val.ok).key_version).val).len = (size_t)lsf_get(&input, 4); lsf_require(((((*arg0).val.ok).key_version).val).len <= LSF_MAX_BYTES);
((((*arg0).val.ok).key_version).val).ptr = lsf_allocate(((((*arg0).val.ok).key_version).val).len, sizeof(*((((*arg0).val.ok).key_version).val).ptr));
for (size_t local_27 = 0; local_27 < ((((*arg0).val.ok).key_version).val).len; local_27++) {
uint64_t local_28 = lsf_get(&input, 1);  (((((*arg0).val.ok).key_version).val).ptr[local_27]) = (__typeof__((((((*arg0).val.ok).key_version).val).ptr[local_27])))local_28;
}
}
}
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_transactional_aggregate_api_scan(probe_list_u8_t *arg0, uint32_t arg1, probe_option_list_u8_t *arg2, exports_examples_transactional_aggregate_api_result_scan_result_business_error_t *arg3) {
lsf_wire output = {0};
lsf_require((*arg0).len <= LSF_MAX_BYTES); lsf_put(&output, (*arg0).len, 4);
for (size_t local_29 = 0; local_29 < (*arg0).len; local_29++) {
lsf_put(&output, (uint64_t)((*arg0).ptr[local_29]), 1);
}
for (size_t local_31 = 0; local_31 < (*arg0).len; local_31++) {
}
lsf_release((*arg0).ptr, (*arg0).len * sizeof(*(*arg0).ptr)); (*arg0).ptr = NULL; (*arg0).len = 0;
lsf_put(&output, (uint64_t)(arg1), 4);
lsf_put(&output, (uint64_t)((*arg2).is_some), 1);
if ((*arg2).is_some) {
lsf_require(((*arg2).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((*arg2).val).len, 4);
for (size_t local_37 = 0; local_37 < ((*arg2).val).len; local_37++) {
lsf_put(&output, (uint64_t)(((*arg2).val).ptr[local_37]), 1);
}
}
if ((*arg2).is_some) {
for (size_t local_41 = 0; local_41 < ((*arg2).val).len; local_41++) {
}
lsf_release(((*arg2).val).ptr, ((*arg2).val).len * sizeof(*((*arg2).val).ptr)); ((*arg2).val).ptr = NULL; ((*arg2).val).len = 0;
}
void *owned; lsf_wire input = lsf_invoke(2, &output, &owned);
uint64_t local_44 = lsf_get(&input, 1); lsf_require(local_44 <= 1); ((*arg3).is_err) = (__typeof__(((*arg3).is_err)))local_44;
if ((*arg3).is_err) {
uint64_t local_45 = lsf_get(&input, 4); lsf_require(local_45 < 3);
((*arg3).val.err) = (__typeof__(((*arg3).val.err)))local_45;
lsf_require(((*arg3).val.err) < 3);
} else {
uint64_t local_47 = lsf_get(&input, 4);  (((*arg3).val.ok).count) = (__typeof__((((*arg3).val.ok).count)))local_47;
uint64_t local_48 = lsf_get(&input, 8);  (((*arg3).val.ok).encoded_bytes) = (__typeof__((((*arg3).val.ok).encoded_bytes)))local_48;
(((*arg3).val.ok).view_version).len = (size_t)lsf_get(&input, 4); lsf_require((((*arg3).val.ok).view_version).len <= LSF_MAX_BYTES);
(((*arg3).val.ok).view_version).ptr = lsf_allocate((((*arg3).val.ok).view_version).len, sizeof(*(((*arg3).val.ok).view_version).ptr));
for (size_t local_49 = 0; local_49 < (((*arg3).val.ok).view_version).len; local_49++) {
uint64_t local_50 = lsf_get(&input, 1);  ((((*arg3).val.ok).view_version).ptr[local_49]) = (__typeof__(((((*arg3).val.ok).view_version).ptr[local_49])))local_50;
}
uint64_t local_52 = lsf_get(&input, 1); lsf_require(local_52 <= 1); ((((*arg3).val.ok).next_cursor).is_some) = (__typeof__(((((*arg3).val.ok).next_cursor).is_some)))local_52;
if ((((*arg3).val.ok).next_cursor).is_some) {
((((*arg3).val.ok).next_cursor).val).len = (size_t)lsf_get(&input, 4); lsf_require(((((*arg3).val.ok).next_cursor).val).len <= LSF_MAX_BYTES);
((((*arg3).val.ok).next_cursor).val).ptr = lsf_allocate(((((*arg3).val.ok).next_cursor).val).len, sizeof(*((((*arg3).val.ok).next_cursor).val).ptr));
for (size_t local_53 = 0; local_53 < ((((*arg3).val.ok).next_cursor).val).len; local_53++) {
uint64_t local_54 = lsf_get(&input, 1);  (((((*arg3).val.ok).next_cursor).val).ptr[local_53]) = (__typeof__((((((*arg3).val.ok).next_cursor).val).ptr[local_53])))local_54;
}
}
}
lsf_finish(&input); lsf_java_free(owned);
}
void *lsf_java_host(int32_t operation, void *bytes, int32_t length) {
lsf_require(length >= 0 && (uint32_t)length <= LSF_MAX_BYTES);
lsf_wire input = {bytes, (size_t)length, 0, (size_t)length}; lsf_wire output = {0};
switch (operation) {
case 0: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_monotonic_now_nanos();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 1: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_wall_now_unix_millis();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 2: {
lsf_finish(&input);
latent_state_key_value_result_own_transaction_state_error_t result = {0};
latent_state_key_value_acquire_command(&result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
} else {
}
break; }
case 3: {
lsf_finish(&input);
latent_state_key_value_result_own_query_view_state_error_t result = {0};
latent_state_key_value_acquire_query(&result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
} else {
}
break; }
case 4: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_80 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_80;
lsf_finish(&input);
latent_state_key_value_result_command_info_state_error_t result = {0};
latent_state_key_value_info(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_require(((((result).val.ok).view).namespace_).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).namespace_).len, 4);
for (size_t local_88 = 0; local_88 < ((((result).val.ok).view).namespace_).len; local_88++) lsf_put(&output, ((((result).val.ok).view).namespace_).ptr[local_88], 1);
lsf_require(((((result).val.ok).view).incarnation).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).incarnation).len, 4);
for (size_t local_89 = 0; local_89 < ((((result).val.ok).view).incarnation).len; local_89++) lsf_put(&output, ((((result).val.ok).view).incarnation).ptr[local_89], 1);
lsf_require(((((result).val.ok).view).version).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).version).len, 4);
for (size_t local_90 = 0; local_90 < ((((result).val.ok).view).version).len; local_90++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).view).version).ptr[local_90]), 1);
}
lsf_require(((((result).val.ok).view).state_schema).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).state_schema).len, 4);
for (size_t local_92 = 0; local_92 < ((((result).val.ok).view).state_schema).len; local_92++) lsf_put(&output, ((((result).val.ok).view).state_schema).ptr[local_92], 1);
lsf_require((((result).val.ok).command_id).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).command_id).len, 4);
for (size_t local_93 = 0; local_93 < (((result).val.ok).command_id).len; local_93++) lsf_put(&output, (((result).val.ok).command_id).ptr[local_93], 1);
lsf_require((((result).val.ok).attempt_id).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).attempt_id).len, 4);
for (size_t local_94 = 0; local_94 < (((result).val.ok).attempt_id).len; local_94++) lsf_put(&output, (((result).val.ok).attempt_id).ptr[local_94], 1);
lsf_put(&output, (uint64_t)((((result).val.ok).entity).is_some), 1);
if ((((result).val.ok).entity).is_some) {
lsf_require(((((result).val.ok).entity).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).entity).val).len, 4);
for (size_t local_97 = 0; local_97 < ((((result).val.ok).entity).val).len; local_97++) lsf_put(&output, ((((result).val.ok).entity).val).ptr[local_97], 1);
}
}
if ((result).is_err) {
} else {
lsf_release(((((result).val.ok).view).namespace_).ptr, ((((result).val.ok).view).namespace_).len); ((((result).val.ok).view).namespace_).ptr = NULL; ((((result).val.ok).view).namespace_).len = 0;
lsf_release(((((result).val.ok).view).incarnation).ptr, ((((result).val.ok).view).incarnation).len); ((((result).val.ok).view).incarnation).ptr = NULL; ((((result).val.ok).view).incarnation).len = 0;
for (size_t local_105 = 0; local_105 < ((((result).val.ok).view).version).len; local_105++) {
}
lsf_release(((((result).val.ok).view).version).ptr, ((((result).val.ok).view).version).len * sizeof(*((((result).val.ok).view).version).ptr)); ((((result).val.ok).view).version).ptr = NULL; ((((result).val.ok).view).version).len = 0;
lsf_release(((((result).val.ok).view).state_schema).ptr, ((((result).val.ok).view).state_schema).len); ((((result).val.ok).view).state_schema).ptr = NULL; ((((result).val.ok).view).state_schema).len = 0;
lsf_release((((result).val.ok).command_id).ptr, (((result).val.ok).command_id).len); (((result).val.ok).command_id).ptr = NULL; (((result).val.ok).command_id).len = 0;
lsf_release((((result).val.ok).attempt_id).ptr, (((result).val.ok).attempt_id).len); (((result).val.ok).attempt_id).ptr = NULL; (((result).val.ok).attempt_id).len = 0;
if ((((result).val.ok).entity).is_some) {
lsf_release(((((result).val.ok).entity).val).ptr, ((((result).val.ok).entity).val).len); ((((result).val.ok).entity).val).ptr = NULL; ((((result).val.ok).entity).val).len = 0;
}
}
break; }
case 5: {
latent_state_key_value_borrow_query_view_t arg0 = {0};
uint64_t local_114 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_114;
lsf_finish(&input);
latent_state_key_value_result_view_identity_state_error_t result = {0};
latent_state_key_value_query_info(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_require((((result).val.ok).namespace_).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).namespace_).len, 4);
for (size_t local_121 = 0; local_121 < (((result).val.ok).namespace_).len; local_121++) lsf_put(&output, (((result).val.ok).namespace_).ptr[local_121], 1);
lsf_require((((result).val.ok).incarnation).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).incarnation).len, 4);
for (size_t local_122 = 0; local_122 < (((result).val.ok).incarnation).len; local_122++) lsf_put(&output, (((result).val.ok).incarnation).ptr[local_122], 1);
lsf_require((((result).val.ok).version).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).version).len, 4);
for (size_t local_123 = 0; local_123 < (((result).val.ok).version).len; local_123++) {
lsf_put(&output, (uint64_t)((((result).val.ok).version).ptr[local_123]), 1);
}
lsf_require((((result).val.ok).state_schema).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).state_schema).len, 4);
for (size_t local_125 = 0; local_125 < (((result).val.ok).state_schema).len; local_125++) lsf_put(&output, (((result).val.ok).state_schema).ptr[local_125], 1);
}
if ((result).is_err) {
} else {
lsf_release((((result).val.ok).namespace_).ptr, (((result).val.ok).namespace_).len); (((result).val.ok).namespace_).ptr = NULL; (((result).val.ok).namespace_).len = 0;
lsf_release((((result).val.ok).incarnation).ptr, (((result).val.ok).incarnation).len); (((result).val.ok).incarnation).ptr = NULL; (((result).val.ok).incarnation).len = 0;
for (size_t local_132 = 0; local_132 < (((result).val.ok).version).len; local_132++) {
}
lsf_release((((result).val.ok).version).ptr, (((result).val.ok).version).len * sizeof(*(((result).val.ok).version).ptr)); (((result).val.ok).version).ptr = NULL; (((result).val.ok).version).len = 0;
lsf_release((((result).val.ok).state_schema).ptr, (((result).val.ok).state_schema).len); (((result).val.ok).state_schema).ptr = NULL; (((result).val.ok).state_schema).len = 0;
}
break; }
case 6: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_136 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_136;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_137 = 0; local_137 < (arg1).len; local_137++) {
uint64_t local_138 = lsf_get(&input, 1);  ((arg1).ptr[local_137]) = (__typeof__(((arg1).ptr[local_137])))local_138;
}
lsf_finish(&input);
latent_state_key_value_result_option_versioned_value_state_error_t result = {0};
latent_state_key_value_get(arg0, &arg1, &result);
for (size_t local_140 = 0; local_140 < (arg1).len; local_140++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).is_some), 1);
if (((result).val.ok).is_some) {
lsf_require((((((result).val.ok).val).value).bytes).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).bytes).len, 4);
for (size_t local_150 = 0; local_150 < (((((result).val.ok).val).value).bytes).len; local_150++) {
lsf_put(&output, (uint64_t)((((((result).val.ok).val).value).bytes).ptr[local_150]), 1);
}
lsf_require((((((result).val.ok).val).value).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).media_type).len, 4);
for (size_t local_152 = 0; local_152 < (((((result).val.ok).val).value).media_type).len; local_152++) lsf_put(&output, (((((result).val.ok).val).value).media_type).ptr[local_152], 1);
lsf_require((((((result).val.ok).val).value).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, (((((result).val.ok).val).value).metadata).len, 4);
for (size_t local_153 = 0; local_153 < (((((result).val.ok).val).value).metadata).len; local_153++) {
lsf_require((((((((result).val.ok).val).value).metadata).ptr[local_153]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_153]).f0).len, 4);
for (size_t local_155 = 0; local_155 < (((((((result).val.ok).val).value).metadata).ptr[local_153]).f0).len; local_155++) lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_153]).f0).ptr[local_155], 1);
lsf_require((((((((result).val.ok).val).value).metadata).ptr[local_153]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_153]).f1).len, 4);
for (size_t local_156 = 0; local_156 < (((((((result).val.ok).val).value).metadata).ptr[local_153]).f1).len; local_156++) lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_153]).f1).ptr[local_156], 1);
}
lsf_require(((((result).val.ok).val).version).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).val).version).len, 4);
for (size_t local_157 = 0; local_157 < ((((result).val.ok).val).version).len; local_157++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).val).version).ptr[local_157]), 1);
}
}
}
if ((result).is_err) {
} else {
if (((result).val.ok).is_some) {
for (size_t local_166 = 0; local_166 < (((((result).val.ok).val).value).bytes).len; local_166++) {
}
lsf_release((((((result).val.ok).val).value).bytes).ptr, (((((result).val.ok).val).value).bytes).len * sizeof(*(((((result).val.ok).val).value).bytes).ptr)); (((((result).val.ok).val).value).bytes).ptr = NULL; (((((result).val.ok).val).value).bytes).len = 0;
lsf_release((((((result).val.ok).val).value).media_type).ptr, (((((result).val.ok).val).value).media_type).len); (((((result).val.ok).val).value).media_type).ptr = NULL; (((((result).val.ok).val).value).media_type).len = 0;
for (size_t local_169 = 0; local_169 < (((((result).val.ok).val).value).metadata).len; local_169++) {
lsf_release((((((((result).val.ok).val).value).metadata).ptr[local_169]).f0).ptr, (((((((result).val.ok).val).value).metadata).ptr[local_169]).f0).len); (((((((result).val.ok).val).value).metadata).ptr[local_169]).f0).ptr = NULL; (((((((result).val.ok).val).value).metadata).ptr[local_169]).f0).len = 0;
lsf_release((((((((result).val.ok).val).value).metadata).ptr[local_169]).f1).ptr, (((((((result).val.ok).val).value).metadata).ptr[local_169]).f1).len); (((((((result).val.ok).val).value).metadata).ptr[local_169]).f1).ptr = NULL; (((((((result).val.ok).val).value).metadata).ptr[local_169]).f1).len = 0;
}
lsf_release((((((result).val.ok).val).value).metadata).ptr, (((((result).val.ok).val).value).metadata).len * sizeof(*(((((result).val.ok).val).value).metadata).ptr)); (((((result).val.ok).val).value).metadata).ptr = NULL; (((((result).val.ok).val).value).metadata).len = 0;
for (size_t local_173 = 0; local_173 < ((((result).val.ok).val).version).len; local_173++) {
}
lsf_release(((((result).val.ok).val).version).ptr, ((((result).val.ok).val).version).len * sizeof(*((((result).val.ok).val).version).ptr)); ((((result).val.ok).val).version).ptr = NULL; ((((result).val.ok).val).version).len = 0;
}
}
break; }
case 7: {
latent_state_key_value_borrow_query_view_t arg0 = {0};
uint64_t local_176 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_176;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_177 = 0; local_177 < (arg1).len; local_177++) {
uint64_t local_178 = lsf_get(&input, 1);  ((arg1).ptr[local_177]) = (__typeof__(((arg1).ptr[local_177])))local_178;
}
lsf_finish(&input);
latent_state_key_value_result_option_versioned_value_state_error_t result = {0};
latent_state_key_value_get_query(arg0, &arg1, &result);
for (size_t local_180 = 0; local_180 < (arg1).len; local_180++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).is_some), 1);
if (((result).val.ok).is_some) {
lsf_require((((((result).val.ok).val).value).bytes).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).bytes).len, 4);
for (size_t local_190 = 0; local_190 < (((((result).val.ok).val).value).bytes).len; local_190++) {
lsf_put(&output, (uint64_t)((((((result).val.ok).val).value).bytes).ptr[local_190]), 1);
}
lsf_require((((((result).val.ok).val).value).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).media_type).len, 4);
for (size_t local_192 = 0; local_192 < (((((result).val.ok).val).value).media_type).len; local_192++) lsf_put(&output, (((((result).val.ok).val).value).media_type).ptr[local_192], 1);
lsf_require((((((result).val.ok).val).value).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, (((((result).val.ok).val).value).metadata).len, 4);
for (size_t local_193 = 0; local_193 < (((((result).val.ok).val).value).metadata).len; local_193++) {
lsf_require((((((((result).val.ok).val).value).metadata).ptr[local_193]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_193]).f0).len, 4);
for (size_t local_195 = 0; local_195 < (((((((result).val.ok).val).value).metadata).ptr[local_193]).f0).len; local_195++) lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_193]).f0).ptr[local_195], 1);
lsf_require((((((((result).val.ok).val).value).metadata).ptr[local_193]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_193]).f1).len, 4);
for (size_t local_196 = 0; local_196 < (((((((result).val.ok).val).value).metadata).ptr[local_193]).f1).len; local_196++) lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_193]).f1).ptr[local_196], 1);
}
lsf_require(((((result).val.ok).val).version).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).val).version).len, 4);
for (size_t local_197 = 0; local_197 < ((((result).val.ok).val).version).len; local_197++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).val).version).ptr[local_197]), 1);
}
}
}
if ((result).is_err) {
} else {
if (((result).val.ok).is_some) {
for (size_t local_206 = 0; local_206 < (((((result).val.ok).val).value).bytes).len; local_206++) {
}
lsf_release((((((result).val.ok).val).value).bytes).ptr, (((((result).val.ok).val).value).bytes).len * sizeof(*(((((result).val.ok).val).value).bytes).ptr)); (((((result).val.ok).val).value).bytes).ptr = NULL; (((((result).val.ok).val).value).bytes).len = 0;
lsf_release((((((result).val.ok).val).value).media_type).ptr, (((((result).val.ok).val).value).media_type).len); (((((result).val.ok).val).value).media_type).ptr = NULL; (((((result).val.ok).val).value).media_type).len = 0;
for (size_t local_209 = 0; local_209 < (((((result).val.ok).val).value).metadata).len; local_209++) {
lsf_release((((((((result).val.ok).val).value).metadata).ptr[local_209]).f0).ptr, (((((((result).val.ok).val).value).metadata).ptr[local_209]).f0).len); (((((((result).val.ok).val).value).metadata).ptr[local_209]).f0).ptr = NULL; (((((((result).val.ok).val).value).metadata).ptr[local_209]).f0).len = 0;
lsf_release((((((((result).val.ok).val).value).metadata).ptr[local_209]).f1).ptr, (((((((result).val.ok).val).value).metadata).ptr[local_209]).f1).len); (((((((result).val.ok).val).value).metadata).ptr[local_209]).f1).ptr = NULL; (((((((result).val.ok).val).value).metadata).ptr[local_209]).f1).len = 0;
}
lsf_release((((((result).val.ok).val).value).metadata).ptr, (((((result).val.ok).val).value).metadata).len * sizeof(*(((((result).val.ok).val).value).metadata).ptr)); (((((result).val.ok).val).value).metadata).ptr = NULL; (((((result).val.ok).val).value).metadata).len = 0;
for (size_t local_213 = 0; local_213 < ((((result).val.ok).val).version).len; local_213++) {
}
lsf_release(((((result).val.ok).val).version).ptr, ((((result).val.ok).val).version).len * sizeof(*((((result).val.ok).val).version).ptr)); ((((result).val.ok).val).version).ptr = NULL; ((((result).val.ok).val).version).len = 0;
}
}
break; }
case 8: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_216 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_216;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_217 = 0; local_217 < (arg1).len; local_217++) {
uint64_t local_218 = lsf_get(&input, 1);  ((arg1).ptr[local_217]) = (__typeof__(((arg1).ptr[local_217])))local_218;
}
uint32_t arg2 = {0};
uint64_t local_219 = lsf_get(&input, 4);  (arg2) = (__typeof__((arg2)))local_219;
probe_option_list_u8_t arg3 = {0};
uint64_t local_221 = lsf_get(&input, 1); lsf_require(local_221 <= 1); ((arg3).is_some) = (__typeof__(((arg3).is_some)))local_221;
if ((arg3).is_some) {
((arg3).val).len = (size_t)lsf_get(&input, 4); lsf_require(((arg3).val).len <= LSF_MAX_BYTES);
((arg3).val).ptr = lsf_allocate(((arg3).val).len, sizeof(*((arg3).val).ptr));
for (size_t local_222 = 0; local_222 < ((arg3).val).len; local_222++) {
uint64_t local_223 = lsf_get(&input, 1);  (((arg3).val).ptr[local_222]) = (__typeof__((((arg3).val).ptr[local_222])))local_223;
}
}
lsf_finish(&input);
latent_state_key_value_result_own_page_state_error_t result = {0};
latent_state_key_value_scan(arg0, &arg1, arg2, &arg3, &result);
for (size_t local_225 = 0; local_225 < (arg1).len; local_225++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
if ((arg3).is_some) {
for (size_t local_230 = 0; local_230 < ((arg3).val).len; local_230++) {
}
lsf_release(((arg3).val).ptr, ((arg3).val).len * sizeof(*((arg3).val).ptr)); ((arg3).val).ptr = NULL; ((arg3).val).len = 0;
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
} else {
}
break; }
case 9: {
latent_state_key_value_borrow_query_view_t arg0 = {0};
uint64_t local_243 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_243;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_244 = 0; local_244 < (arg1).len; local_244++) {
uint64_t local_245 = lsf_get(&input, 1);  ((arg1).ptr[local_244]) = (__typeof__(((arg1).ptr[local_244])))local_245;
}
uint32_t arg2 = {0};
uint64_t local_246 = lsf_get(&input, 4);  (arg2) = (__typeof__((arg2)))local_246;
probe_option_list_u8_t arg3 = {0};
uint64_t local_248 = lsf_get(&input, 1); lsf_require(local_248 <= 1); ((arg3).is_some) = (__typeof__(((arg3).is_some)))local_248;
if ((arg3).is_some) {
((arg3).val).len = (size_t)lsf_get(&input, 4); lsf_require(((arg3).val).len <= LSF_MAX_BYTES);
((arg3).val).ptr = lsf_allocate(((arg3).val).len, sizeof(*((arg3).val).ptr));
for (size_t local_249 = 0; local_249 < ((arg3).val).len; local_249++) {
uint64_t local_250 = lsf_get(&input, 1);  (((arg3).val).ptr[local_249]) = (__typeof__((((arg3).val).ptr[local_249])))local_250;
}
}
lsf_finish(&input);
latent_state_key_value_result_own_page_state_error_t result = {0};
latent_state_key_value_scan_query(arg0, &arg1, arg2, &arg3, &result);
for (size_t local_252 = 0; local_252 < (arg1).len; local_252++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
if ((arg3).is_some) {
for (size_t local_257 = 0; local_257 < ((arg3).val).len; local_257++) {
}
lsf_release(((arg3).val).ptr, ((arg3).val).len * sizeof(*((arg3).val).ptr)); ((arg3).val).ptr = NULL; ((arg3).val).len = 0;
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
} else {
}
break; }
case 10: {
latent_state_key_value_borrow_page_t arg0 = {0};
uint64_t local_270 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_270;
lsf_finish(&input);
latent_state_key_value_result_page_info_state_error_t result = {0};
latent_state_key_value_describe_page(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_require(((((result).val.ok).view).namespace_).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).namespace_).len, 4);
for (size_t local_278 = 0; local_278 < ((((result).val.ok).view).namespace_).len; local_278++) lsf_put(&output, ((((result).val.ok).view).namespace_).ptr[local_278], 1);
lsf_require(((((result).val.ok).view).incarnation).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).incarnation).len, 4);
for (size_t local_279 = 0; local_279 < ((((result).val.ok).view).incarnation).len; local_279++) lsf_put(&output, ((((result).val.ok).view).incarnation).ptr[local_279], 1);
lsf_require(((((result).val.ok).view).version).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).version).len, 4);
for (size_t local_280 = 0; local_280 < ((((result).val.ok).view).version).len; local_280++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).view).version).ptr[local_280]), 1);
}
lsf_require(((((result).val.ok).view).state_schema).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).state_schema).len, 4);
for (size_t local_282 = 0; local_282 < ((((result).val.ok).view).state_schema).len; local_282++) lsf_put(&output, ((((result).val.ok).view).state_schema).ptr[local_282], 1);
lsf_put(&output, (uint64_t)(((result).val.ok).entry_count), 4);
lsf_put(&output, (uint64_t)(((result).val.ok).encoded_bytes), 8);
lsf_put(&output, (uint64_t)(((result).val.ok).has_more), 1);
lsf_put(&output, (uint64_t)((((result).val.ok).next_cursor).is_some), 1);
if ((((result).val.ok).next_cursor).is_some) {
lsf_require(((((result).val.ok).next_cursor).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).next_cursor).val).len, 4);
for (size_t local_288 = 0; local_288 < ((((result).val.ok).next_cursor).val).len; local_288++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).next_cursor).val).ptr[local_288]), 1);
}
}
}
if ((result).is_err) {
} else {
lsf_release(((((result).val.ok).view).namespace_).ptr, ((((result).val.ok).view).namespace_).len); ((((result).val.ok).view).namespace_).ptr = NULL; ((((result).val.ok).view).namespace_).len = 0;
lsf_release(((((result).val.ok).view).incarnation).ptr, ((((result).val.ok).view).incarnation).len); ((((result).val.ok).view).incarnation).ptr = NULL; ((((result).val.ok).view).incarnation).len = 0;
for (size_t local_297 = 0; local_297 < ((((result).val.ok).view).version).len; local_297++) {
}
lsf_release(((((result).val.ok).view).version).ptr, ((((result).val.ok).view).version).len * sizeof(*((((result).val.ok).view).version).ptr)); ((((result).val.ok).view).version).ptr = NULL; ((((result).val.ok).view).version).len = 0;
lsf_release(((((result).val.ok).view).state_schema).ptr, ((((result).val.ok).view).state_schema).len); ((((result).val.ok).view).state_schema).ptr = NULL; ((((result).val.ok).view).state_schema).len = 0;
if ((((result).val.ok).next_cursor).is_some) {
for (size_t local_305 = 0; local_305 < ((((result).val.ok).next_cursor).val).len; local_305++) {
}
lsf_release(((((result).val.ok).next_cursor).val).ptr, ((((result).val.ok).next_cursor).val).len * sizeof(*((((result).val.ok).next_cursor).val).ptr)); ((((result).val.ok).next_cursor).val).ptr = NULL; ((((result).val.ok).next_cursor).val).len = 0;
}
}
break; }
case 11: {
latent_state_key_value_borrow_page_t arg0 = {0};
uint64_t local_308 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_308;
lsf_finish(&input);
latent_state_key_value_result_option_entry_state_error_t result = {0};
latent_state_key_value_page_next(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).is_some), 1);
if (((result).val.ok).is_some) {
lsf_require(((((result).val.ok).val).key).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).val).key).len, 4);
for (size_t local_317 = 0; local_317 < ((((result).val.ok).val).key).len; local_317++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).val).key).ptr[local_317]), 1);
}
lsf_require(((((((result).val.ok).val).value).value).bytes).len <= LSF_MAX_BYTES); lsf_put(&output, ((((((result).val.ok).val).value).value).bytes).len, 4);
for (size_t local_321 = 0; local_321 < ((((((result).val.ok).val).value).value).bytes).len; local_321++) {
lsf_put(&output, (uint64_t)(((((((result).val.ok).val).value).value).bytes).ptr[local_321]), 1);
}
lsf_require(((((((result).val.ok).val).value).value).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, ((((((result).val.ok).val).value).value).media_type).len, 4);
for (size_t local_323 = 0; local_323 < ((((((result).val.ok).val).value).value).media_type).len; local_323++) lsf_put(&output, ((((((result).val.ok).val).value).value).media_type).ptr[local_323], 1);
lsf_require(((((((result).val.ok).val).value).value).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, ((((((result).val.ok).val).value).value).metadata).len, 4);
for (size_t local_324 = 0; local_324 < ((((((result).val.ok).val).value).value).metadata).len; local_324++) {
lsf_require(((((((((result).val.ok).val).value).value).metadata).ptr[local_324]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, ((((((((result).val.ok).val).value).value).metadata).ptr[local_324]).f0).len, 4);
for (size_t local_326 = 0; local_326 < ((((((((result).val.ok).val).value).value).metadata).ptr[local_324]).f0).len; local_326++) lsf_put(&output, ((((((((result).val.ok).val).value).value).metadata).ptr[local_324]).f0).ptr[local_326], 1);
lsf_require(((((((((result).val.ok).val).value).value).metadata).ptr[local_324]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, ((((((((result).val.ok).val).value).value).metadata).ptr[local_324]).f1).len, 4);
for (size_t local_327 = 0; local_327 < ((((((((result).val.ok).val).value).value).metadata).ptr[local_324]).f1).len; local_327++) lsf_put(&output, ((((((((result).val.ok).val).value).value).metadata).ptr[local_324]).f1).ptr[local_327], 1);
}
lsf_require((((((result).val.ok).val).value).version).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).version).len, 4);
for (size_t local_328 = 0; local_328 < (((((result).val.ok).val).value).version).len; local_328++) {
lsf_put(&output, (uint64_t)((((((result).val.ok).val).value).version).ptr[local_328]), 1);
}
}
}
if ((result).is_err) {
} else {
if (((result).val.ok).is_some) {
for (size_t local_336 = 0; local_336 < ((((result).val.ok).val).key).len; local_336++) {
}
lsf_release(((((result).val.ok).val).key).ptr, ((((result).val.ok).val).key).len * sizeof(*((((result).val.ok).val).key).ptr)); ((((result).val.ok).val).key).ptr = NULL; ((((result).val.ok).val).key).len = 0;
for (size_t local_340 = 0; local_340 < ((((((result).val.ok).val).value).value).bytes).len; local_340++) {
}
lsf_release(((((((result).val.ok).val).value).value).bytes).ptr, ((((((result).val.ok).val).value).value).bytes).len * sizeof(*((((((result).val.ok).val).value).value).bytes).ptr)); ((((((result).val.ok).val).value).value).bytes).ptr = NULL; ((((((result).val.ok).val).value).value).bytes).len = 0;
lsf_release(((((((result).val.ok).val).value).value).media_type).ptr, ((((((result).val.ok).val).value).value).media_type).len); ((((((result).val.ok).val).value).value).media_type).ptr = NULL; ((((((result).val.ok).val).value).value).media_type).len = 0;
for (size_t local_343 = 0; local_343 < ((((((result).val.ok).val).value).value).metadata).len; local_343++) {
lsf_release(((((((((result).val.ok).val).value).value).metadata).ptr[local_343]).f0).ptr, ((((((((result).val.ok).val).value).value).metadata).ptr[local_343]).f0).len); ((((((((result).val.ok).val).value).value).metadata).ptr[local_343]).f0).ptr = NULL; ((((((((result).val.ok).val).value).value).metadata).ptr[local_343]).f0).len = 0;
lsf_release(((((((((result).val.ok).val).value).value).metadata).ptr[local_343]).f1).ptr, ((((((((result).val.ok).val).value).value).metadata).ptr[local_343]).f1).len); ((((((((result).val.ok).val).value).value).metadata).ptr[local_343]).f1).ptr = NULL; ((((((((result).val.ok).val).value).value).metadata).ptr[local_343]).f1).len = 0;
}
lsf_release(((((((result).val.ok).val).value).value).metadata).ptr, ((((((result).val.ok).val).value).value).metadata).len * sizeof(*((((((result).val.ok).val).value).value).metadata).ptr)); ((((((result).val.ok).val).value).value).metadata).ptr = NULL; ((((((result).val.ok).val).value).value).metadata).len = 0;
for (size_t local_347 = 0; local_347 < (((((result).val.ok).val).value).version).len; local_347++) {
}
lsf_release((((((result).val.ok).val).value).version).ptr, (((((result).val.ok).val).value).version).len * sizeof(*(((((result).val.ok).val).value).version).ptr)); (((((result).val.ok).val).value).version).ptr = NULL; (((((result).val.ok).val).value).version).len = 0;
}
}
break; }
case 12: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_350 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_350;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_351 = 0; local_351 < (arg1).len; local_351++) {
uint64_t local_352 = lsf_get(&input, 1);  ((arg1).ptr[local_351]) = (__typeof__(((arg1).ptr[local_351])))local_352;
}
latent_state_key_value_value_t arg2 = {0};
((arg2).bytes).len = (size_t)lsf_get(&input, 4); lsf_require(((arg2).bytes).len <= LSF_MAX_BYTES);
((arg2).bytes).ptr = lsf_allocate(((arg2).bytes).len, sizeof(*((arg2).bytes).ptr));
for (size_t local_354 = 0; local_354 < ((arg2).bytes).len; local_354++) {
uint64_t local_355 = lsf_get(&input, 1);  (((arg2).bytes).ptr[local_354]) = (__typeof__((((arg2).bytes).ptr[local_354])))local_355;
}
((arg2).media_type).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg2).media_type).len <= LSF_MAX_BYTES);
((arg2).media_type).ptr = lsf_allocate(((arg2).media_type).len, 1);
for (size_t local_356 = 0; local_356 < ((arg2).media_type).len; local_356++) ((arg2).media_type).ptr[local_356] = (uint8_t)lsf_get(&input, 1);
((arg2).metadata).len = lsf_count(&input); lsf_require(((arg2).metadata).len <= LSF_MAX_ITEMS);
((arg2).metadata).ptr = lsf_allocate(((arg2).metadata).len, sizeof(*((arg2).metadata).ptr));
for (size_t local_357 = 0; local_357 < ((arg2).metadata).len; local_357++) {
((((arg2).metadata).ptr[local_357]).f0).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg2).metadata).ptr[local_357]).f0).len <= LSF_MAX_BYTES);
((((arg2).metadata).ptr[local_357]).f0).ptr = lsf_allocate(((((arg2).metadata).ptr[local_357]).f0).len, 1);
for (size_t local_359 = 0; local_359 < ((((arg2).metadata).ptr[local_357]).f0).len; local_359++) ((((arg2).metadata).ptr[local_357]).f0).ptr[local_359] = (uint8_t)lsf_get(&input, 1);
((((arg2).metadata).ptr[local_357]).f1).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg2).metadata).ptr[local_357]).f1).len <= LSF_MAX_BYTES);
((((arg2).metadata).ptr[local_357]).f1).ptr = lsf_allocate(((((arg2).metadata).ptr[local_357]).f1).len, 1);
for (size_t local_360 = 0; local_360 < ((((arg2).metadata).ptr[local_357]).f1).len; local_360++) ((((arg2).metadata).ptr[local_357]).f1).ptr[local_360] = (uint8_t)lsf_get(&input, 1);
}
lsf_finish(&input);
latent_state_key_value_result_void_state_error_t result = {0};
latent_state_key_value_put(arg0, &arg1, &arg2, &result);
for (size_t local_362 = 0; local_362 < (arg1).len; local_362++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
for (size_t local_365 = 0; local_365 < ((arg2).bytes).len; local_365++) {
}
lsf_release(((arg2).bytes).ptr, ((arg2).bytes).len * sizeof(*((arg2).bytes).ptr)); ((arg2).bytes).ptr = NULL; ((arg2).bytes).len = 0;
lsf_release(((arg2).media_type).ptr, ((arg2).media_type).len); ((arg2).media_type).ptr = NULL; ((arg2).media_type).len = 0;
for (size_t local_368 = 0; local_368 < ((arg2).metadata).len; local_368++) {
lsf_release(((((arg2).metadata).ptr[local_368]).f0).ptr, ((((arg2).metadata).ptr[local_368]).f0).len); ((((arg2).metadata).ptr[local_368]).f0).ptr = NULL; ((((arg2).metadata).ptr[local_368]).f0).len = 0;
lsf_release(((((arg2).metadata).ptr[local_368]).f1).ptr, ((((arg2).metadata).ptr[local_368]).f1).len); ((((arg2).metadata).ptr[local_368]).f1).ptr = NULL; ((((arg2).metadata).ptr[local_368]).f1).len = 0;
}
lsf_release(((arg2).metadata).ptr, ((arg2).metadata).len * sizeof(*((arg2).metadata).ptr)); ((arg2).metadata).ptr = NULL; ((arg2).metadata).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
}
if ((result).is_err) {
} else {
}
break; }
case 13: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_382 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_382;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_383 = 0; local_383 < (arg1).len; local_383++) {
uint64_t local_384 = lsf_get(&input, 1);  ((arg1).ptr[local_383]) = (__typeof__(((arg1).ptr[local_383])))local_384;
}
lsf_finish(&input);
latent_state_key_value_result_void_state_error_t result = {0};
latent_state_key_value_delete(arg0, &arg1, &result);
for (size_t local_386 = 0; local_386 < (arg1).len; local_386++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
}
if ((result).is_err) {
} else {
}
break; }
case 14: {
latent_intents_staging_borrow_transaction_t arg0 = {0};
uint64_t local_398 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_398;
latent_intents_staging_intent_t arg1 = {0};
((arg1).binding).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg1).binding).len <= LSF_MAX_BYTES);
((arg1).binding).ptr = lsf_allocate(((arg1).binding).len, 1);
for (size_t local_400 = 0; local_400 < ((arg1).binding).len; local_400++) ((arg1).binding).ptr[local_400] = (uint8_t)lsf_get(&input, 1);
((arg1).operation).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg1).operation).len <= LSF_MAX_BYTES);
((arg1).operation).ptr = lsf_allocate(((arg1).operation).len, 1);
for (size_t local_401 = 0; local_401 < ((arg1).operation).len; local_401++) ((arg1).operation).ptr[local_401] = (uint8_t)lsf_get(&input, 1);
((((arg1).payload)).bytes).len = (size_t)lsf_get(&input, 4); lsf_require(((((arg1).payload)).bytes).len <= LSF_MAX_BYTES);
((((arg1).payload)).bytes).ptr = lsf_allocate(((((arg1).payload)).bytes).len, sizeof(*((((arg1).payload)).bytes).ptr));
for (size_t local_404 = 0; local_404 < ((((arg1).payload)).bytes).len; local_404++) {
uint64_t local_405 = lsf_get(&input, 1);  (((((arg1).payload)).bytes).ptr[local_404]) = (__typeof__((((((arg1).payload)).bytes).ptr[local_404])))local_405;
}
((((arg1).payload)).media_type).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg1).payload)).media_type).len <= LSF_MAX_BYTES);
((((arg1).payload)).media_type).ptr = lsf_allocate(((((arg1).payload)).media_type).len, 1);
for (size_t local_406 = 0; local_406 < ((((arg1).payload)).media_type).len; local_406++) ((((arg1).payload)).media_type).ptr[local_406] = (uint8_t)lsf_get(&input, 1);
((((arg1).payload)).metadata).len = lsf_count(&input); lsf_require(((((arg1).payload)).metadata).len <= LSF_MAX_ITEMS);
((((arg1).payload)).metadata).ptr = lsf_allocate(((((arg1).payload)).metadata).len, sizeof(*((((arg1).payload)).metadata).ptr));
for (size_t local_407 = 0; local_407 < ((((arg1).payload)).metadata).len; local_407++) {
((((((arg1).payload)).metadata).ptr[local_407]).f0).len = (size_t)lsf_get(&input, 4);
lsf_require(((((((arg1).payload)).metadata).ptr[local_407]).f0).len <= LSF_MAX_BYTES);
((((((arg1).payload)).metadata).ptr[local_407]).f0).ptr = lsf_allocate(((((((arg1).payload)).metadata).ptr[local_407]).f0).len, 1);
for (size_t local_409 = 0; local_409 < ((((((arg1).payload)).metadata).ptr[local_407]).f0).len; local_409++) ((((((arg1).payload)).metadata).ptr[local_407]).f0).ptr[local_409] = (uint8_t)lsf_get(&input, 1);
((((((arg1).payload)).metadata).ptr[local_407]).f1).len = (size_t)lsf_get(&input, 4);
lsf_require(((((((arg1).payload)).metadata).ptr[local_407]).f1).len <= LSF_MAX_BYTES);
((((((arg1).payload)).metadata).ptr[local_407]).f1).ptr = lsf_allocate(((((((arg1).payload)).metadata).ptr[local_407]).f1).len, 1);
for (size_t local_410 = 0; local_410 < ((((((arg1).payload)).metadata).ptr[local_407]).f1).len; local_410++) ((((((arg1).payload)).metadata).ptr[local_407]).f1).ptr[local_410] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_412 = lsf_get(&input, 1); lsf_require(local_412 <= 1); (((arg1).expires_at_unix_millis).is_some) = (__typeof__((((arg1).expires_at_unix_millis).is_some)))local_412;
if (((arg1).expires_at_unix_millis).is_some) {
uint64_t local_413 = lsf_get(&input, 8);  (((arg1).expires_at_unix_millis).val) = (__typeof__((((arg1).expires_at_unix_millis).val)))local_413;
}
lsf_finish(&input);
latent_intents_staging_result_staged_intent_intent_error_t result = {0};
latent_intents_staging_stage(arg0, &arg1, &result);
lsf_release(((arg1).binding).ptr, ((arg1).binding).len); ((arg1).binding).ptr = NULL; ((arg1).binding).len = 0;
lsf_release(((arg1).operation).ptr, ((arg1).operation).len); ((arg1).operation).ptr = NULL; ((arg1).operation).len = 0;
for (size_t local_420 = 0; local_420 < ((((arg1).payload)).bytes).len; local_420++) {
}
lsf_release(((((arg1).payload)).bytes).ptr, ((((arg1).payload)).bytes).len * sizeof(*((((arg1).payload)).bytes).ptr)); ((((arg1).payload)).bytes).ptr = NULL; ((((arg1).payload)).bytes).len = 0;
lsf_release(((((arg1).payload)).media_type).ptr, ((((arg1).payload)).media_type).len); ((((arg1).payload)).media_type).ptr = NULL; ((((arg1).payload)).media_type).len = 0;
for (size_t local_423 = 0; local_423 < ((((arg1).payload)).metadata).len; local_423++) {
lsf_release(((((((arg1).payload)).metadata).ptr[local_423]).f0).ptr, ((((((arg1).payload)).metadata).ptr[local_423]).f0).len); ((((((arg1).payload)).metadata).ptr[local_423]).f0).ptr = NULL; ((((((arg1).payload)).metadata).ptr[local_423]).f0).len = 0;
lsf_release(((((((arg1).payload)).metadata).ptr[local_423]).f1).ptr, ((((((arg1).payload)).metadata).ptr[local_423]).f1).len); ((((((arg1).payload)).metadata).ptr[local_423]).f1).ptr = NULL; ((((((arg1).payload)).metadata).ptr[local_423]).f1).len = 0;
}
lsf_release(((((arg1).payload)).metadata).ptr, ((((arg1).payload)).metadata).len * sizeof(*((((arg1).payload)).metadata).ptr)); ((((arg1).payload)).metadata).ptr = NULL; ((((arg1).payload)).metadata).len = 0;
if (((arg1).expires_at_unix_millis).is_some) {
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 13);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).sequence), 4);
}
if ((result).is_err) {
} else {
}
break; }
case -1: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_state_key_value_transaction_drop_own((latent_state_key_value_own_transaction_t){(int32_t)handle}); break; }
case -2: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_state_key_value_query_view_drop_own((latent_state_key_value_own_query_view_t){(int32_t)handle}); break; }
case -3: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_state_key_value_page_drop_own((latent_state_key_value_own_page_t){(int32_t)handle}); break; }
default: __builtin_trap(); }
return lsf_result(&output);
}
