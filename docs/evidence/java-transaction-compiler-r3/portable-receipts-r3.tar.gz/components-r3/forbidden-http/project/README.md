# transaction-java-forbidden-http

Edit `src/dev/latent/app/Capsule.java` and `wit/world.wit`.
Keep `vendor/lsf` unchanged. Build with `tools/java_capsule.py` from the SDK checkout.
The complete guide is `docs/component-development/java-authoring.md`.
WIT declares the runtime clocks; only an operator can grant them. No JVM is deployed.
