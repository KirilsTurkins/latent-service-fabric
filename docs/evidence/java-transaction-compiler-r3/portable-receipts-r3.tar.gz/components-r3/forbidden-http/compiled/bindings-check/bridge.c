/* Generated from authoritative WIT. DO NOT EDIT. */
#include "bridge.h"
void exports_examples_transactional_aggregate_api_update(exports_examples_transactional_aggregate_api_update_request_t *arg0, exports_examples_transactional_aggregate_api_result_aggregate_business_error_t *arg1) {
lsf_wire output = {0};
lsf_put(&output, (uint64_t)((*arg0).delta), 4);
lsf_put(&output, (uint64_t)((*arg0).reject), 1);
void *owned; lsf_wire input = lsf_invoke(0, &output, &owned);
uint64_t local_8 = lsf_get(&input, 1); lsf_require(local_8 <= 1); ((*arg1).is_err) = (__typeof__(((*arg1).is_err)))local_8;
if ((*arg1).is_err) {
uint64_t local_9 = lsf_get(&input, 4); lsf_require(local_9 < 3);
((*arg1).val.err) = (__typeof__(((*arg1).val.err)))local_9;
lsf_require(((*arg1).val.err) < 3);
} else {
uint64_t local_11 = lsf_get(&input, 8);  (((*arg1).val.ok).count) = (__typeof__((((*arg1).val.ok).count)))local_11;
(((*arg1).val.ok).view_version).len = (size_t)lsf_get(&input, 4); lsf_require((((*arg1).val.ok).view_version).len <= LSF_MAX_BYTES);
(((*arg1).val.ok).view_version).ptr = lsf_allocate((((*arg1).val.ok).view_version).len, sizeof(*(((*arg1).val.ok).view_version).ptr));
for (size_t local_12 = 0; local_12 < (((*arg1).val.ok).view_version).len; local_12++) {
uint64_t local_13 = lsf_get(&input, 1);  ((((*arg1).val.ok).view_version).ptr[local_12]) = (__typeof__(((((*arg1).val.ok).view_version).ptr[local_12])))local_13;
}
uint64_t local_15 = lsf_get(&input, 1); lsf_require(local_15 <= 1); ((((*arg1).val.ok).key_version).is_some) = (__typeof__(((((*arg1).val.ok).key_version).is_some)))local_15;
if ((((*arg1).val.ok).key_version).is_some) {
((((*arg1).val.ok).key_version).val).len = (size_t)lsf_get(&input, 4); lsf_require(((((*arg1).val.ok).key_version).val).len <= LSF_MAX_BYTES);
((((*arg1).val.ok).key_version).val).ptr = lsf_allocate(((((*arg1).val.ok).key_version).val).len, sizeof(*((((*arg1).val.ok).key_version).val).ptr));
for (size_t local_16 = 0; local_16 < ((((*arg1).val.ok).key_version).val).len; local_16++) {
uint64_t local_17 = lsf_get(&input, 1);  (((((*arg1).val.ok).key_version).val).ptr[local_16]) = (__typeof__((((((*arg1).val.ok).key_version).val).ptr[local_16])))local_17;
}
}
}
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_transactional_aggregate_api_query(exports_examples_transactional_aggregate_api_result_aggregate_business_error_t *arg0) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(1, &output, &owned);
uint64_t local_19 = lsf_get(&input, 1); lsf_require(local_19 <= 1); ((*arg0).is_err) = (__typeof__(((*arg0).is_err)))local_19;
if ((*arg0).is_err) {
uint64_t local_20 = lsf_get(&input, 4); lsf_require(local_20 < 3);
((*arg0).val.err) = (__typeof__(((*arg0).val.err)))local_20;
lsf_require(((*arg0).val.err) < 3);
} else {
uint64_t local_22 = lsf_get(&input, 8);  (((*arg0).val.ok).count) = (__typeof__((((*arg0).val.ok).count)))local_22;
(((*arg0).val.ok).view_version).len = (size_t)lsf_get(&input, 4); lsf_require((((*arg0).val.ok).view_version).len <= LSF_MAX_BYTES);
(((*arg0).val.ok).view_version).ptr = lsf_allocate((((*arg0).val.ok).view_version).len, sizeof(*(((*arg0).val.ok).view_version).ptr));
for (size_t local_23 = 0; local_23 < (((*arg0).val.ok).view_version).len; local_23++) {
uint64_t local_24 = lsf_get(&input, 1);  ((((*arg0).val.ok).view_version).ptr[local_23]) = (__typeof__(((((*arg0).val.ok).view_version).ptr[local_23])))local_24;
}
uint64_t local_26 = lsf_get(&input, 1); lsf_require(local_26 <= 1); ((((*arg0).val.ok).key_version).is_some) = (__typeof__(((((*arg0).val.ok).key_version).is_some)))local_26;
if ((((*arg0).val.ok).key_version).is_some) {
((((*arg0).val.ok).key_version).val).len = (size_t)lsf_get(&input, 4); lsf_require(((((*arg0).val.ok).key_version).val).len <= LSF_MAX_BYTES);
((((*arg0).val.ok).key_version).val).ptr = lsf_allocate(((((*arg0).val.ok).key_version).val).len, sizeof(*((((*arg0).val.ok).key_version).val).ptr));
for (size_t local_27 = 0; local_27 < ((((*arg0).val.ok).key_version).val).len; local_27++) {
uint64_t local_28 = lsf_get(&input, 1);  (((((*arg0).val.ok).key_version).val).ptr[local_27]) = (__typeof__((((((*arg0).val.ok).key_version).val).ptr[local_27])))local_28;
}
}
}
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_transactional_aggregate_api_scan(probe_list_u8_t *arg0, uint32_t arg1, probe_option_list_u8_t *arg2, exports_examples_transactional_aggregate_api_result_scan_result_business_error_t *arg3) {
lsf_wire output = {0};
lsf_require((*arg0).len <= LSF_MAX_BYTES); lsf_put(&output, (*arg0).len, 4);
for (size_t local_29 = 0; local_29 < (*arg0).len; local_29++) {
lsf_put(&output, (uint64_t)((*arg0).ptr[local_29]), 1);
}
for (size_t local_31 = 0; local_31 < (*arg0).len; local_31++) {
}
lsf_release((*arg0).ptr, (*arg0).len * sizeof(*(*arg0).ptr)); (*arg0).ptr = NULL; (*arg0).len = 0;
lsf_put(&output, (uint64_t)(arg1), 4);
lsf_put(&output, (uint64_t)((*arg2).is_some), 1);
if ((*arg2).is_some) {
lsf_require(((*arg2).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((*arg2).val).len, 4);
for (size_t local_37 = 0; local_37 < ((*arg2).val).len; local_37++) {
lsf_put(&output, (uint64_t)(((*arg2).val).ptr[local_37]), 1);
}
}
if ((*arg2).is_some) {
for (size_t local_41 = 0; local_41 < ((*arg2).val).len; local_41++) {
}
lsf_release(((*arg2).val).ptr, ((*arg2).val).len * sizeof(*((*arg2).val).ptr)); ((*arg2).val).ptr = NULL; ((*arg2).val).len = 0;
}
void *owned; lsf_wire input = lsf_invoke(2, &output, &owned);
uint64_t local_44 = lsf_get(&input, 1); lsf_require(local_44 <= 1); ((*arg3).is_err) = (__typeof__(((*arg3).is_err)))local_44;
if ((*arg3).is_err) {
uint64_t local_45 = lsf_get(&input, 4); lsf_require(local_45 < 3);
((*arg3).val.err) = (__typeof__(((*arg3).val.err)))local_45;
lsf_require(((*arg3).val.err) < 3);
} else {
uint64_t local_47 = lsf_get(&input, 4);  (((*arg3).val.ok).count) = (__typeof__((((*arg3).val.ok).count)))local_47;
uint64_t local_48 = lsf_get(&input, 8);  (((*arg3).val.ok).encoded_bytes) = (__typeof__((((*arg3).val.ok).encoded_bytes)))local_48;
(((*arg3).val.ok).view_version).len = (size_t)lsf_get(&input, 4); lsf_require((((*arg3).val.ok).view_version).len <= LSF_MAX_BYTES);
(((*arg3).val.ok).view_version).ptr = lsf_allocate((((*arg3).val.ok).view_version).len, sizeof(*(((*arg3).val.ok).view_version).ptr));
for (size_t local_49 = 0; local_49 < (((*arg3).val.ok).view_version).len; local_49++) {
uint64_t local_50 = lsf_get(&input, 1);  ((((*arg3).val.ok).view_version).ptr[local_49]) = (__typeof__(((((*arg3).val.ok).view_version).ptr[local_49])))local_50;
}
uint64_t local_52 = lsf_get(&input, 1); lsf_require(local_52 <= 1); ((((*arg3).val.ok).next_cursor).is_some) = (__typeof__(((((*arg3).val.ok).next_cursor).is_some)))local_52;
if ((((*arg3).val.ok).next_cursor).is_some) {
((((*arg3).val.ok).next_cursor).val).len = (size_t)lsf_get(&input, 4); lsf_require(((((*arg3).val.ok).next_cursor).val).len <= LSF_MAX_BYTES);
((((*arg3).val.ok).next_cursor).val).ptr = lsf_allocate(((((*arg3).val.ok).next_cursor).val).len, sizeof(*((((*arg3).val.ok).next_cursor).val).ptr));
for (size_t local_53 = 0; local_53 < ((((*arg3).val.ok).next_cursor).val).len; local_53++) {
uint64_t local_54 = lsf_get(&input, 1);  (((((*arg3).val.ok).next_cursor).val).ptr[local_53]) = (__typeof__((((((*arg3).val.ok).next_cursor).val).ptr[local_53])))local_54;
}
}
}
lsf_finish(&input); lsf_java_free(owned);
}
void *lsf_java_host(int32_t operation, void *bytes, int32_t length) {
lsf_require(length >= 0 && (uint32_t)length <= LSF_MAX_BYTES);
lsf_wire input = {bytes, (size_t)length, 0, (size_t)length}; lsf_wire output = {0};
switch (operation) {
case 0: {
latent_http_client_request_t arg0 = {0};
uint64_t local_56 = lsf_get(&input, 4); lsf_require(local_56 < 7);
((arg0).method) = (__typeof__(((arg0).method)))local_56;
lsf_require(((arg0).method) < 7);
((arg0).url).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).url).len <= LSF_MAX_BYTES);
((arg0).url).ptr = lsf_allocate(((arg0).url).len, 1);
for (size_t local_57 = 0; local_57 < ((arg0).url).len; local_57++) ((arg0).url).ptr[local_57] = (uint8_t)lsf_get(&input, 1);
((arg0).headers).len = lsf_count(&input); lsf_require(((arg0).headers).len <= LSF_MAX_ITEMS);
((arg0).headers).ptr = lsf_allocate(((arg0).headers).len, sizeof(*((arg0).headers).ptr));
for (size_t local_58 = 0; local_58 < ((arg0).headers).len; local_58++) {
((((arg0).headers).ptr[local_58]).name).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).headers).ptr[local_58]).name).len <= LSF_MAX_BYTES);
((((arg0).headers).ptr[local_58]).name).ptr = lsf_allocate(((((arg0).headers).ptr[local_58]).name).len, 1);
for (size_t local_60 = 0; local_60 < ((((arg0).headers).ptr[local_58]).name).len; local_60++) ((((arg0).headers).ptr[local_58]).name).ptr[local_60] = (uint8_t)lsf_get(&input, 1);
((((arg0).headers).ptr[local_58]).value).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).headers).ptr[local_58]).value).len <= LSF_MAX_BYTES);
((((arg0).headers).ptr[local_58]).value).ptr = lsf_allocate(((((arg0).headers).ptr[local_58]).value).len, 1);
for (size_t local_61 = 0; local_61 < ((((arg0).headers).ptr[local_58]).value).len; local_61++) ((((arg0).headers).ptr[local_58]).value).ptr[local_61] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_63 = lsf_get(&input, 1); lsf_require(local_63 <= 1); (((arg0).body).is_some) = (__typeof__((((arg0).body).is_some)))local_63;
if (((arg0).body).is_some) {
(((arg0).body).val).len = (size_t)lsf_get(&input, 4); lsf_require((((arg0).body).val).len <= LSF_MAX_BYTES);
(((arg0).body).val).ptr = lsf_allocate((((arg0).body).val).len, sizeof(*(((arg0).body).val).ptr));
for (size_t local_64 = 0; local_64 < (((arg0).body).val).len; local_64++) {
uint64_t local_65 = lsf_get(&input, 1);  ((((arg0).body).val).ptr[local_64]) = (__typeof__(((((arg0).body).val).ptr[local_64])))local_65;
}
}
uint64_t local_67 = lsf_get(&input, 1); lsf_require(local_67 <= 1); (((arg0).body_media_type).is_some) = (__typeof__((((arg0).body_media_type).is_some)))local_67;
if (((arg0).body_media_type).is_some) {
(((arg0).body_media_type).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).body_media_type).val).len <= LSF_MAX_BYTES);
(((arg0).body_media_type).val).ptr = lsf_allocate((((arg0).body_media_type).val).len, 1);
for (size_t local_68 = 0; local_68 < (((arg0).body_media_type).val).len; local_68++) (((arg0).body_media_type).val).ptr[local_68] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_70 = lsf_get(&input, 1); lsf_require(local_70 <= 1); (((arg0).idempotency_key).is_some) = (__typeof__((((arg0).idempotency_key).is_some)))local_70;
if (((arg0).idempotency_key).is_some) {
(((arg0).idempotency_key).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).idempotency_key).val).len <= LSF_MAX_BYTES);
(((arg0).idempotency_key).val).ptr = lsf_allocate((((arg0).idempotency_key).val).len, 1);
for (size_t local_71 = 0; local_71 < (((arg0).idempotency_key).val).len; local_71++) (((arg0).idempotency_key).val).ptr[local_71] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_73 = lsf_get(&input, 1); lsf_require(local_73 <= 1); (((arg0).timeout_millis).is_some) = (__typeof__((((arg0).timeout_millis).is_some)))local_73;
if (((arg0).timeout_millis).is_some) {
uint64_t local_74 = lsf_get(&input, 8);  (((arg0).timeout_millis).val) = (__typeof__((((arg0).timeout_millis).val)))local_74;
}
lsf_finish(&input);
latent_http_client_result_response_http_error_t result = {0};
latent_http_client_send(&arg0, &result);
lsf_release(((arg0).url).ptr, ((arg0).url).len); ((arg0).url).ptr = NULL; ((arg0).url).len = 0;
for (size_t local_78 = 0; local_78 < ((arg0).headers).len; local_78++) {
lsf_release(((((arg0).headers).ptr[local_78]).name).ptr, ((((arg0).headers).ptr[local_78]).name).len); ((((arg0).headers).ptr[local_78]).name).ptr = NULL; ((((arg0).headers).ptr[local_78]).name).len = 0;
lsf_release(((((arg0).headers).ptr[local_78]).value).ptr, ((((arg0).headers).ptr[local_78]).value).len); ((((arg0).headers).ptr[local_78]).value).ptr = NULL; ((((arg0).headers).ptr[local_78]).value).len = 0;
}
lsf_release(((arg0).headers).ptr, ((arg0).headers).len * sizeof(*((arg0).headers).ptr)); ((arg0).headers).ptr = NULL; ((arg0).headers).len = 0;
if (((arg0).body).is_some) {
for (size_t local_84 = 0; local_84 < (((arg0).body).val).len; local_84++) {
}
lsf_release((((arg0).body).val).ptr, (((arg0).body).val).len * sizeof(*(((arg0).body).val).ptr)); (((arg0).body).val).ptr = NULL; (((arg0).body).val).len = 0;
}
if (((arg0).body_media_type).is_some) {
lsf_release((((arg0).body_media_type).val).ptr, (((arg0).body_media_type).val).len); (((arg0).body_media_type).val).ptr = NULL; (((arg0).body_media_type).val).len = 0;
}
if (((arg0).idempotency_key).is_some) {
lsf_release((((arg0).idempotency_key).val).ptr, (((arg0).idempotency_key).val).len); (((arg0).idempotency_key).val).ptr = NULL; (((arg0).idempotency_key).val).len = 0;
}
if (((arg0).timeout_millis).is_some) {
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).status), 2);
lsf_require((((result).val.ok).headers).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.ok).headers).len, 4);
for (size_t local_114 = 0; local_114 < (((result).val.ok).headers).len; local_114++) {
lsf_require((((((result).val.ok).headers).ptr[local_114]).name).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).headers).ptr[local_114]).name).len, 4);
for (size_t local_116 = 0; local_116 < (((((result).val.ok).headers).ptr[local_114]).name).len; local_116++) lsf_put(&output, (((((result).val.ok).headers).ptr[local_114]).name).ptr[local_116], 1);
lsf_require((((((result).val.ok).headers).ptr[local_114]).value).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).headers).ptr[local_114]).value).len, 4);
for (size_t local_117 = 0; local_117 < (((((result).val.ok).headers).ptr[local_114]).value).len; local_117++) lsf_put(&output, (((((result).val.ok).headers).ptr[local_114]).value).ptr[local_117], 1);
}
lsf_require((((result).val.ok).body).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).body).len, 4);
for (size_t local_118 = 0; local_118 < (((result).val.ok).body).len; local_118++) {
lsf_put(&output, (uint64_t)((((result).val.ok).body).ptr[local_118]), 1);
}
lsf_put(&output, (uint64_t)((((result).val.ok).body_media_type).is_some), 1);
if ((((result).val.ok).body_media_type).is_some) {
lsf_require(((((result).val.ok).body_media_type).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).body_media_type).val).len, 4);
for (size_t local_122 = 0; local_122 < ((((result).val.ok).body_media_type).val).len; local_122++) lsf_put(&output, ((((result).val.ok).body_media_type).val).ptr[local_122], 1);
}
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
default: __builtin_trap(); }
} else {
for (size_t local_141 = 0; local_141 < (((result).val.ok).headers).len; local_141++) {
lsf_release((((((result).val.ok).headers).ptr[local_141]).name).ptr, (((((result).val.ok).headers).ptr[local_141]).name).len); (((((result).val.ok).headers).ptr[local_141]).name).ptr = NULL; (((((result).val.ok).headers).ptr[local_141]).name).len = 0;
lsf_release((((((result).val.ok).headers).ptr[local_141]).value).ptr, (((((result).val.ok).headers).ptr[local_141]).value).len); (((((result).val.ok).headers).ptr[local_141]).value).ptr = NULL; (((((result).val.ok).headers).ptr[local_141]).value).len = 0;
}
lsf_release((((result).val.ok).headers).ptr, (((result).val.ok).headers).len * sizeof(*(((result).val.ok).headers).ptr)); (((result).val.ok).headers).ptr = NULL; (((result).val.ok).headers).len = 0;
for (size_t local_145 = 0; local_145 < (((result).val.ok).body).len; local_145++) {
}
lsf_release((((result).val.ok).body).ptr, (((result).val.ok).body).len * sizeof(*(((result).val.ok).body).ptr)); (((result).val.ok).body).ptr = NULL; (((result).val.ok).body).len = 0;
if ((((result).val.ok).body_media_type).is_some) {
lsf_release(((((result).val.ok).body_media_type).val).ptr, ((((result).val.ok).body_media_type).val).len); ((((result).val.ok).body_media_type).val).ptr = NULL; ((((result).val.ok).body_media_type).val).len = 0;
}
}
break; }
case 1: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_monotonic_now_nanos();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 2: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_wall_now_unix_millis();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 3: {
lsf_finish(&input);
latent_state_key_value_result_own_transaction_state_error_t result = {0};
latent_state_key_value_acquire_command(&result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
} else {
}
break; }
case 4: {
lsf_finish(&input);
latent_state_key_value_result_own_query_view_state_error_t result = {0};
latent_state_key_value_acquire_query(&result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
} else {
}
break; }
case 5: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_175 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_175;
lsf_finish(&input);
latent_state_key_value_result_command_info_state_error_t result = {0};
latent_state_key_value_info(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_require(((((result).val.ok).view).namespace_).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).namespace_).len, 4);
for (size_t local_183 = 0; local_183 < ((((result).val.ok).view).namespace_).len; local_183++) lsf_put(&output, ((((result).val.ok).view).namespace_).ptr[local_183], 1);
lsf_require(((((result).val.ok).view).incarnation).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).incarnation).len, 4);
for (size_t local_184 = 0; local_184 < ((((result).val.ok).view).incarnation).len; local_184++) lsf_put(&output, ((((result).val.ok).view).incarnation).ptr[local_184], 1);
lsf_require(((((result).val.ok).view).version).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).version).len, 4);
for (size_t local_185 = 0; local_185 < ((((result).val.ok).view).version).len; local_185++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).view).version).ptr[local_185]), 1);
}
lsf_require(((((result).val.ok).view).state_schema).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).state_schema).len, 4);
for (size_t local_187 = 0; local_187 < ((((result).val.ok).view).state_schema).len; local_187++) lsf_put(&output, ((((result).val.ok).view).state_schema).ptr[local_187], 1);
lsf_require((((result).val.ok).command_id).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).command_id).len, 4);
for (size_t local_188 = 0; local_188 < (((result).val.ok).command_id).len; local_188++) lsf_put(&output, (((result).val.ok).command_id).ptr[local_188], 1);
lsf_require((((result).val.ok).attempt_id).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).attempt_id).len, 4);
for (size_t local_189 = 0; local_189 < (((result).val.ok).attempt_id).len; local_189++) lsf_put(&output, (((result).val.ok).attempt_id).ptr[local_189], 1);
lsf_put(&output, (uint64_t)((((result).val.ok).entity).is_some), 1);
if ((((result).val.ok).entity).is_some) {
lsf_require(((((result).val.ok).entity).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).entity).val).len, 4);
for (size_t local_192 = 0; local_192 < ((((result).val.ok).entity).val).len; local_192++) lsf_put(&output, ((((result).val.ok).entity).val).ptr[local_192], 1);
}
}
if ((result).is_err) {
} else {
lsf_release(((((result).val.ok).view).namespace_).ptr, ((((result).val.ok).view).namespace_).len); ((((result).val.ok).view).namespace_).ptr = NULL; ((((result).val.ok).view).namespace_).len = 0;
lsf_release(((((result).val.ok).view).incarnation).ptr, ((((result).val.ok).view).incarnation).len); ((((result).val.ok).view).incarnation).ptr = NULL; ((((result).val.ok).view).incarnation).len = 0;
for (size_t local_200 = 0; local_200 < ((((result).val.ok).view).version).len; local_200++) {
}
lsf_release(((((result).val.ok).view).version).ptr, ((((result).val.ok).view).version).len * sizeof(*((((result).val.ok).view).version).ptr)); ((((result).val.ok).view).version).ptr = NULL; ((((result).val.ok).view).version).len = 0;
lsf_release(((((result).val.ok).view).state_schema).ptr, ((((result).val.ok).view).state_schema).len); ((((result).val.ok).view).state_schema).ptr = NULL; ((((result).val.ok).view).state_schema).len = 0;
lsf_release((((result).val.ok).command_id).ptr, (((result).val.ok).command_id).len); (((result).val.ok).command_id).ptr = NULL; (((result).val.ok).command_id).len = 0;
lsf_release((((result).val.ok).attempt_id).ptr, (((result).val.ok).attempt_id).len); (((result).val.ok).attempt_id).ptr = NULL; (((result).val.ok).attempt_id).len = 0;
if ((((result).val.ok).entity).is_some) {
lsf_release(((((result).val.ok).entity).val).ptr, ((((result).val.ok).entity).val).len); ((((result).val.ok).entity).val).ptr = NULL; ((((result).val.ok).entity).val).len = 0;
}
}
break; }
case 6: {
latent_state_key_value_borrow_query_view_t arg0 = {0};
uint64_t local_209 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_209;
lsf_finish(&input);
latent_state_key_value_result_view_identity_state_error_t result = {0};
latent_state_key_value_query_info(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_require((((result).val.ok).namespace_).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).namespace_).len, 4);
for (size_t local_216 = 0; local_216 < (((result).val.ok).namespace_).len; local_216++) lsf_put(&output, (((result).val.ok).namespace_).ptr[local_216], 1);
lsf_require((((result).val.ok).incarnation).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).incarnation).len, 4);
for (size_t local_217 = 0; local_217 < (((result).val.ok).incarnation).len; local_217++) lsf_put(&output, (((result).val.ok).incarnation).ptr[local_217], 1);
lsf_require((((result).val.ok).version).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).version).len, 4);
for (size_t local_218 = 0; local_218 < (((result).val.ok).version).len; local_218++) {
lsf_put(&output, (uint64_t)((((result).val.ok).version).ptr[local_218]), 1);
}
lsf_require((((result).val.ok).state_schema).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).state_schema).len, 4);
for (size_t local_220 = 0; local_220 < (((result).val.ok).state_schema).len; local_220++) lsf_put(&output, (((result).val.ok).state_schema).ptr[local_220], 1);
}
if ((result).is_err) {
} else {
lsf_release((((result).val.ok).namespace_).ptr, (((result).val.ok).namespace_).len); (((result).val.ok).namespace_).ptr = NULL; (((result).val.ok).namespace_).len = 0;
lsf_release((((result).val.ok).incarnation).ptr, (((result).val.ok).incarnation).len); (((result).val.ok).incarnation).ptr = NULL; (((result).val.ok).incarnation).len = 0;
for (size_t local_227 = 0; local_227 < (((result).val.ok).version).len; local_227++) {
}
lsf_release((((result).val.ok).version).ptr, (((result).val.ok).version).len * sizeof(*(((result).val.ok).version).ptr)); (((result).val.ok).version).ptr = NULL; (((result).val.ok).version).len = 0;
lsf_release((((result).val.ok).state_schema).ptr, (((result).val.ok).state_schema).len); (((result).val.ok).state_schema).ptr = NULL; (((result).val.ok).state_schema).len = 0;
}
break; }
case 7: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_231 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_231;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_232 = 0; local_232 < (arg1).len; local_232++) {
uint64_t local_233 = lsf_get(&input, 1);  ((arg1).ptr[local_232]) = (__typeof__(((arg1).ptr[local_232])))local_233;
}
lsf_finish(&input);
latent_state_key_value_result_option_versioned_value_state_error_t result = {0};
latent_state_key_value_get(arg0, &arg1, &result);
for (size_t local_235 = 0; local_235 < (arg1).len; local_235++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).is_some), 1);
if (((result).val.ok).is_some) {
lsf_require((((((result).val.ok).val).value).bytes).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).bytes).len, 4);
for (size_t local_245 = 0; local_245 < (((((result).val.ok).val).value).bytes).len; local_245++) {
lsf_put(&output, (uint64_t)((((((result).val.ok).val).value).bytes).ptr[local_245]), 1);
}
lsf_require((((((result).val.ok).val).value).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).media_type).len, 4);
for (size_t local_247 = 0; local_247 < (((((result).val.ok).val).value).media_type).len; local_247++) lsf_put(&output, (((((result).val.ok).val).value).media_type).ptr[local_247], 1);
lsf_require((((((result).val.ok).val).value).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, (((((result).val.ok).val).value).metadata).len, 4);
for (size_t local_248 = 0; local_248 < (((((result).val.ok).val).value).metadata).len; local_248++) {
lsf_require((((((((result).val.ok).val).value).metadata).ptr[local_248]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_248]).f0).len, 4);
for (size_t local_250 = 0; local_250 < (((((((result).val.ok).val).value).metadata).ptr[local_248]).f0).len; local_250++) lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_248]).f0).ptr[local_250], 1);
lsf_require((((((((result).val.ok).val).value).metadata).ptr[local_248]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_248]).f1).len, 4);
for (size_t local_251 = 0; local_251 < (((((((result).val.ok).val).value).metadata).ptr[local_248]).f1).len; local_251++) lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_248]).f1).ptr[local_251], 1);
}
lsf_require(((((result).val.ok).val).version).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).val).version).len, 4);
for (size_t local_252 = 0; local_252 < ((((result).val.ok).val).version).len; local_252++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).val).version).ptr[local_252]), 1);
}
}
}
if ((result).is_err) {
} else {
if (((result).val.ok).is_some) {
for (size_t local_261 = 0; local_261 < (((((result).val.ok).val).value).bytes).len; local_261++) {
}
lsf_release((((((result).val.ok).val).value).bytes).ptr, (((((result).val.ok).val).value).bytes).len * sizeof(*(((((result).val.ok).val).value).bytes).ptr)); (((((result).val.ok).val).value).bytes).ptr = NULL; (((((result).val.ok).val).value).bytes).len = 0;
lsf_release((((((result).val.ok).val).value).media_type).ptr, (((((result).val.ok).val).value).media_type).len); (((((result).val.ok).val).value).media_type).ptr = NULL; (((((result).val.ok).val).value).media_type).len = 0;
for (size_t local_264 = 0; local_264 < (((((result).val.ok).val).value).metadata).len; local_264++) {
lsf_release((((((((result).val.ok).val).value).metadata).ptr[local_264]).f0).ptr, (((((((result).val.ok).val).value).metadata).ptr[local_264]).f0).len); (((((((result).val.ok).val).value).metadata).ptr[local_264]).f0).ptr = NULL; (((((((result).val.ok).val).value).metadata).ptr[local_264]).f0).len = 0;
lsf_release((((((((result).val.ok).val).value).metadata).ptr[local_264]).f1).ptr, (((((((result).val.ok).val).value).metadata).ptr[local_264]).f1).len); (((((((result).val.ok).val).value).metadata).ptr[local_264]).f1).ptr = NULL; (((((((result).val.ok).val).value).metadata).ptr[local_264]).f1).len = 0;
}
lsf_release((((((result).val.ok).val).value).metadata).ptr, (((((result).val.ok).val).value).metadata).len * sizeof(*(((((result).val.ok).val).value).metadata).ptr)); (((((result).val.ok).val).value).metadata).ptr = NULL; (((((result).val.ok).val).value).metadata).len = 0;
for (size_t local_268 = 0; local_268 < ((((result).val.ok).val).version).len; local_268++) {
}
lsf_release(((((result).val.ok).val).version).ptr, ((((result).val.ok).val).version).len * sizeof(*((((result).val.ok).val).version).ptr)); ((((result).val.ok).val).version).ptr = NULL; ((((result).val.ok).val).version).len = 0;
}
}
break; }
case 8: {
latent_state_key_value_borrow_query_view_t arg0 = {0};
uint64_t local_271 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_271;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_272 = 0; local_272 < (arg1).len; local_272++) {
uint64_t local_273 = lsf_get(&input, 1);  ((arg1).ptr[local_272]) = (__typeof__(((arg1).ptr[local_272])))local_273;
}
lsf_finish(&input);
latent_state_key_value_result_option_versioned_value_state_error_t result = {0};
latent_state_key_value_get_query(arg0, &arg1, &result);
for (size_t local_275 = 0; local_275 < (arg1).len; local_275++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).is_some), 1);
if (((result).val.ok).is_some) {
lsf_require((((((result).val.ok).val).value).bytes).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).bytes).len, 4);
for (size_t local_285 = 0; local_285 < (((((result).val.ok).val).value).bytes).len; local_285++) {
lsf_put(&output, (uint64_t)((((((result).val.ok).val).value).bytes).ptr[local_285]), 1);
}
lsf_require((((((result).val.ok).val).value).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).media_type).len, 4);
for (size_t local_287 = 0; local_287 < (((((result).val.ok).val).value).media_type).len; local_287++) lsf_put(&output, (((((result).val.ok).val).value).media_type).ptr[local_287], 1);
lsf_require((((((result).val.ok).val).value).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, (((((result).val.ok).val).value).metadata).len, 4);
for (size_t local_288 = 0; local_288 < (((((result).val.ok).val).value).metadata).len; local_288++) {
lsf_require((((((((result).val.ok).val).value).metadata).ptr[local_288]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_288]).f0).len, 4);
for (size_t local_290 = 0; local_290 < (((((((result).val.ok).val).value).metadata).ptr[local_288]).f0).len; local_290++) lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_288]).f0).ptr[local_290], 1);
lsf_require((((((((result).val.ok).val).value).metadata).ptr[local_288]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_288]).f1).len, 4);
for (size_t local_291 = 0; local_291 < (((((((result).val.ok).val).value).metadata).ptr[local_288]).f1).len; local_291++) lsf_put(&output, (((((((result).val.ok).val).value).metadata).ptr[local_288]).f1).ptr[local_291], 1);
}
lsf_require(((((result).val.ok).val).version).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).val).version).len, 4);
for (size_t local_292 = 0; local_292 < ((((result).val.ok).val).version).len; local_292++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).val).version).ptr[local_292]), 1);
}
}
}
if ((result).is_err) {
} else {
if (((result).val.ok).is_some) {
for (size_t local_301 = 0; local_301 < (((((result).val.ok).val).value).bytes).len; local_301++) {
}
lsf_release((((((result).val.ok).val).value).bytes).ptr, (((((result).val.ok).val).value).bytes).len * sizeof(*(((((result).val.ok).val).value).bytes).ptr)); (((((result).val.ok).val).value).bytes).ptr = NULL; (((((result).val.ok).val).value).bytes).len = 0;
lsf_release((((((result).val.ok).val).value).media_type).ptr, (((((result).val.ok).val).value).media_type).len); (((((result).val.ok).val).value).media_type).ptr = NULL; (((((result).val.ok).val).value).media_type).len = 0;
for (size_t local_304 = 0; local_304 < (((((result).val.ok).val).value).metadata).len; local_304++) {
lsf_release((((((((result).val.ok).val).value).metadata).ptr[local_304]).f0).ptr, (((((((result).val.ok).val).value).metadata).ptr[local_304]).f0).len); (((((((result).val.ok).val).value).metadata).ptr[local_304]).f0).ptr = NULL; (((((((result).val.ok).val).value).metadata).ptr[local_304]).f0).len = 0;
lsf_release((((((((result).val.ok).val).value).metadata).ptr[local_304]).f1).ptr, (((((((result).val.ok).val).value).metadata).ptr[local_304]).f1).len); (((((((result).val.ok).val).value).metadata).ptr[local_304]).f1).ptr = NULL; (((((((result).val.ok).val).value).metadata).ptr[local_304]).f1).len = 0;
}
lsf_release((((((result).val.ok).val).value).metadata).ptr, (((((result).val.ok).val).value).metadata).len * sizeof(*(((((result).val.ok).val).value).metadata).ptr)); (((((result).val.ok).val).value).metadata).ptr = NULL; (((((result).val.ok).val).value).metadata).len = 0;
for (size_t local_308 = 0; local_308 < ((((result).val.ok).val).version).len; local_308++) {
}
lsf_release(((((result).val.ok).val).version).ptr, ((((result).val.ok).val).version).len * sizeof(*((((result).val.ok).val).version).ptr)); ((((result).val.ok).val).version).ptr = NULL; ((((result).val.ok).val).version).len = 0;
}
}
break; }
case 9: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_311 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_311;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_312 = 0; local_312 < (arg1).len; local_312++) {
uint64_t local_313 = lsf_get(&input, 1);  ((arg1).ptr[local_312]) = (__typeof__(((arg1).ptr[local_312])))local_313;
}
uint32_t arg2 = {0};
uint64_t local_314 = lsf_get(&input, 4);  (arg2) = (__typeof__((arg2)))local_314;
probe_option_list_u8_t arg3 = {0};
uint64_t local_316 = lsf_get(&input, 1); lsf_require(local_316 <= 1); ((arg3).is_some) = (__typeof__(((arg3).is_some)))local_316;
if ((arg3).is_some) {
((arg3).val).len = (size_t)lsf_get(&input, 4); lsf_require(((arg3).val).len <= LSF_MAX_BYTES);
((arg3).val).ptr = lsf_allocate(((arg3).val).len, sizeof(*((arg3).val).ptr));
for (size_t local_317 = 0; local_317 < ((arg3).val).len; local_317++) {
uint64_t local_318 = lsf_get(&input, 1);  (((arg3).val).ptr[local_317]) = (__typeof__((((arg3).val).ptr[local_317])))local_318;
}
}
lsf_finish(&input);
latent_state_key_value_result_own_page_state_error_t result = {0};
latent_state_key_value_scan(arg0, &arg1, arg2, &arg3, &result);
for (size_t local_320 = 0; local_320 < (arg1).len; local_320++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
if ((arg3).is_some) {
for (size_t local_325 = 0; local_325 < ((arg3).val).len; local_325++) {
}
lsf_release(((arg3).val).ptr, ((arg3).val).len * sizeof(*((arg3).val).ptr)); ((arg3).val).ptr = NULL; ((arg3).val).len = 0;
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
} else {
}
break; }
case 10: {
latent_state_key_value_borrow_query_view_t arg0 = {0};
uint64_t local_338 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_338;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_339 = 0; local_339 < (arg1).len; local_339++) {
uint64_t local_340 = lsf_get(&input, 1);  ((arg1).ptr[local_339]) = (__typeof__(((arg1).ptr[local_339])))local_340;
}
uint32_t arg2 = {0};
uint64_t local_341 = lsf_get(&input, 4);  (arg2) = (__typeof__((arg2)))local_341;
probe_option_list_u8_t arg3 = {0};
uint64_t local_343 = lsf_get(&input, 1); lsf_require(local_343 <= 1); ((arg3).is_some) = (__typeof__(((arg3).is_some)))local_343;
if ((arg3).is_some) {
((arg3).val).len = (size_t)lsf_get(&input, 4); lsf_require(((arg3).val).len <= LSF_MAX_BYTES);
((arg3).val).ptr = lsf_allocate(((arg3).val).len, sizeof(*((arg3).val).ptr));
for (size_t local_344 = 0; local_344 < ((arg3).val).len; local_344++) {
uint64_t local_345 = lsf_get(&input, 1);  (((arg3).val).ptr[local_344]) = (__typeof__((((arg3).val).ptr[local_344])))local_345;
}
}
lsf_finish(&input);
latent_state_key_value_result_own_page_state_error_t result = {0};
latent_state_key_value_scan_query(arg0, &arg1, arg2, &arg3, &result);
for (size_t local_347 = 0; local_347 < (arg1).len; local_347++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
if ((arg3).is_some) {
for (size_t local_352 = 0; local_352 < ((arg3).val).len; local_352++) {
}
lsf_release(((arg3).val).ptr, ((arg3).val).len * sizeof(*((arg3).val).ptr)); ((arg3).val).ptr = NULL; ((arg3).val).len = 0;
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).__handle), 4);
}
if ((result).is_err) {
} else {
}
break; }
case 11: {
latent_state_key_value_borrow_page_t arg0 = {0};
uint64_t local_365 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_365;
lsf_finish(&input);
latent_state_key_value_result_page_info_state_error_t result = {0};
latent_state_key_value_describe_page(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_require(((((result).val.ok).view).namespace_).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).namespace_).len, 4);
for (size_t local_373 = 0; local_373 < ((((result).val.ok).view).namespace_).len; local_373++) lsf_put(&output, ((((result).val.ok).view).namespace_).ptr[local_373], 1);
lsf_require(((((result).val.ok).view).incarnation).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).incarnation).len, 4);
for (size_t local_374 = 0; local_374 < ((((result).val.ok).view).incarnation).len; local_374++) lsf_put(&output, ((((result).val.ok).view).incarnation).ptr[local_374], 1);
lsf_require(((((result).val.ok).view).version).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).version).len, 4);
for (size_t local_375 = 0; local_375 < ((((result).val.ok).view).version).len; local_375++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).view).version).ptr[local_375]), 1);
}
lsf_require(((((result).val.ok).view).state_schema).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).view).state_schema).len, 4);
for (size_t local_377 = 0; local_377 < ((((result).val.ok).view).state_schema).len; local_377++) lsf_put(&output, ((((result).val.ok).view).state_schema).ptr[local_377], 1);
lsf_put(&output, (uint64_t)(((result).val.ok).entry_count), 4);
lsf_put(&output, (uint64_t)(((result).val.ok).encoded_bytes), 8);
lsf_put(&output, (uint64_t)(((result).val.ok).has_more), 1);
lsf_put(&output, (uint64_t)((((result).val.ok).next_cursor).is_some), 1);
if ((((result).val.ok).next_cursor).is_some) {
lsf_require(((((result).val.ok).next_cursor).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).next_cursor).val).len, 4);
for (size_t local_383 = 0; local_383 < ((((result).val.ok).next_cursor).val).len; local_383++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).next_cursor).val).ptr[local_383]), 1);
}
}
}
if ((result).is_err) {
} else {
lsf_release(((((result).val.ok).view).namespace_).ptr, ((((result).val.ok).view).namespace_).len); ((((result).val.ok).view).namespace_).ptr = NULL; ((((result).val.ok).view).namespace_).len = 0;
lsf_release(((((result).val.ok).view).incarnation).ptr, ((((result).val.ok).view).incarnation).len); ((((result).val.ok).view).incarnation).ptr = NULL; ((((result).val.ok).view).incarnation).len = 0;
for (size_t local_392 = 0; local_392 < ((((result).val.ok).view).version).len; local_392++) {
}
lsf_release(((((result).val.ok).view).version).ptr, ((((result).val.ok).view).version).len * sizeof(*((((result).val.ok).view).version).ptr)); ((((result).val.ok).view).version).ptr = NULL; ((((result).val.ok).view).version).len = 0;
lsf_release(((((result).val.ok).view).state_schema).ptr, ((((result).val.ok).view).state_schema).len); ((((result).val.ok).view).state_schema).ptr = NULL; ((((result).val.ok).view).state_schema).len = 0;
if ((((result).val.ok).next_cursor).is_some) {
for (size_t local_400 = 0; local_400 < ((((result).val.ok).next_cursor).val).len; local_400++) {
}
lsf_release(((((result).val.ok).next_cursor).val).ptr, ((((result).val.ok).next_cursor).val).len * sizeof(*((((result).val.ok).next_cursor).val).ptr)); ((((result).val.ok).next_cursor).val).ptr = NULL; ((((result).val.ok).next_cursor).val).len = 0;
}
}
break; }
case 12: {
latent_state_key_value_borrow_page_t arg0 = {0};
uint64_t local_403 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_403;
lsf_finish(&input);
latent_state_key_value_result_option_entry_state_error_t result = {0};
latent_state_key_value_page_next(arg0, &result);
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).is_some), 1);
if (((result).val.ok).is_some) {
lsf_require(((((result).val.ok).val).key).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).val).key).len, 4);
for (size_t local_412 = 0; local_412 < ((((result).val.ok).val).key).len; local_412++) {
lsf_put(&output, (uint64_t)(((((result).val.ok).val).key).ptr[local_412]), 1);
}
lsf_require(((((((result).val.ok).val).value).value).bytes).len <= LSF_MAX_BYTES); lsf_put(&output, ((((((result).val.ok).val).value).value).bytes).len, 4);
for (size_t local_416 = 0; local_416 < ((((((result).val.ok).val).value).value).bytes).len; local_416++) {
lsf_put(&output, (uint64_t)(((((((result).val.ok).val).value).value).bytes).ptr[local_416]), 1);
}
lsf_require(((((((result).val.ok).val).value).value).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, ((((((result).val.ok).val).value).value).media_type).len, 4);
for (size_t local_418 = 0; local_418 < ((((((result).val.ok).val).value).value).media_type).len; local_418++) lsf_put(&output, ((((((result).val.ok).val).value).value).media_type).ptr[local_418], 1);
lsf_require(((((((result).val.ok).val).value).value).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, ((((((result).val.ok).val).value).value).metadata).len, 4);
for (size_t local_419 = 0; local_419 < ((((((result).val.ok).val).value).value).metadata).len; local_419++) {
lsf_require(((((((((result).val.ok).val).value).value).metadata).ptr[local_419]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, ((((((((result).val.ok).val).value).value).metadata).ptr[local_419]).f0).len, 4);
for (size_t local_421 = 0; local_421 < ((((((((result).val.ok).val).value).value).metadata).ptr[local_419]).f0).len; local_421++) lsf_put(&output, ((((((((result).val.ok).val).value).value).metadata).ptr[local_419]).f0).ptr[local_421], 1);
lsf_require(((((((((result).val.ok).val).value).value).metadata).ptr[local_419]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, ((((((((result).val.ok).val).value).value).metadata).ptr[local_419]).f1).len, 4);
for (size_t local_422 = 0; local_422 < ((((((((result).val.ok).val).value).value).metadata).ptr[local_419]).f1).len; local_422++) lsf_put(&output, ((((((((result).val.ok).val).value).value).metadata).ptr[local_419]).f1).ptr[local_422], 1);
}
lsf_require((((((result).val.ok).val).value).version).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).val).value).version).len, 4);
for (size_t local_423 = 0; local_423 < (((((result).val.ok).val).value).version).len; local_423++) {
lsf_put(&output, (uint64_t)((((((result).val.ok).val).value).version).ptr[local_423]), 1);
}
}
}
if ((result).is_err) {
} else {
if (((result).val.ok).is_some) {
for (size_t local_431 = 0; local_431 < ((((result).val.ok).val).key).len; local_431++) {
}
lsf_release(((((result).val.ok).val).key).ptr, ((((result).val.ok).val).key).len * sizeof(*((((result).val.ok).val).key).ptr)); ((((result).val.ok).val).key).ptr = NULL; ((((result).val.ok).val).key).len = 0;
for (size_t local_435 = 0; local_435 < ((((((result).val.ok).val).value).value).bytes).len; local_435++) {
}
lsf_release(((((((result).val.ok).val).value).value).bytes).ptr, ((((((result).val.ok).val).value).value).bytes).len * sizeof(*((((((result).val.ok).val).value).value).bytes).ptr)); ((((((result).val.ok).val).value).value).bytes).ptr = NULL; ((((((result).val.ok).val).value).value).bytes).len = 0;
lsf_release(((((((result).val.ok).val).value).value).media_type).ptr, ((((((result).val.ok).val).value).value).media_type).len); ((((((result).val.ok).val).value).value).media_type).ptr = NULL; ((((((result).val.ok).val).value).value).media_type).len = 0;
for (size_t local_438 = 0; local_438 < ((((((result).val.ok).val).value).value).metadata).len; local_438++) {
lsf_release(((((((((result).val.ok).val).value).value).metadata).ptr[local_438]).f0).ptr, ((((((((result).val.ok).val).value).value).metadata).ptr[local_438]).f0).len); ((((((((result).val.ok).val).value).value).metadata).ptr[local_438]).f0).ptr = NULL; ((((((((result).val.ok).val).value).value).metadata).ptr[local_438]).f0).len = 0;
lsf_release(((((((((result).val.ok).val).value).value).metadata).ptr[local_438]).f1).ptr, ((((((((result).val.ok).val).value).value).metadata).ptr[local_438]).f1).len); ((((((((result).val.ok).val).value).value).metadata).ptr[local_438]).f1).ptr = NULL; ((((((((result).val.ok).val).value).value).metadata).ptr[local_438]).f1).len = 0;
}
lsf_release(((((((result).val.ok).val).value).value).metadata).ptr, ((((((result).val.ok).val).value).value).metadata).len * sizeof(*((((((result).val.ok).val).value).value).metadata).ptr)); ((((((result).val.ok).val).value).value).metadata).ptr = NULL; ((((((result).val.ok).val).value).value).metadata).len = 0;
for (size_t local_442 = 0; local_442 < (((((result).val.ok).val).value).version).len; local_442++) {
}
lsf_release((((((result).val.ok).val).value).version).ptr, (((((result).val.ok).val).value).version).len * sizeof(*(((((result).val.ok).val).value).version).ptr)); (((((result).val.ok).val).value).version).ptr = NULL; (((((result).val.ok).val).value).version).len = 0;
}
}
break; }
case 13: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_445 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_445;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_446 = 0; local_446 < (arg1).len; local_446++) {
uint64_t local_447 = lsf_get(&input, 1);  ((arg1).ptr[local_446]) = (__typeof__(((arg1).ptr[local_446])))local_447;
}
latent_state_key_value_value_t arg2 = {0};
((arg2).bytes).len = (size_t)lsf_get(&input, 4); lsf_require(((arg2).bytes).len <= LSF_MAX_BYTES);
((arg2).bytes).ptr = lsf_allocate(((arg2).bytes).len, sizeof(*((arg2).bytes).ptr));
for (size_t local_449 = 0; local_449 < ((arg2).bytes).len; local_449++) {
uint64_t local_450 = lsf_get(&input, 1);  (((arg2).bytes).ptr[local_449]) = (__typeof__((((arg2).bytes).ptr[local_449])))local_450;
}
((arg2).media_type).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg2).media_type).len <= LSF_MAX_BYTES);
((arg2).media_type).ptr = lsf_allocate(((arg2).media_type).len, 1);
for (size_t local_451 = 0; local_451 < ((arg2).media_type).len; local_451++) ((arg2).media_type).ptr[local_451] = (uint8_t)lsf_get(&input, 1);
((arg2).metadata).len = lsf_count(&input); lsf_require(((arg2).metadata).len <= LSF_MAX_ITEMS);
((arg2).metadata).ptr = lsf_allocate(((arg2).metadata).len, sizeof(*((arg2).metadata).ptr));
for (size_t local_452 = 0; local_452 < ((arg2).metadata).len; local_452++) {
((((arg2).metadata).ptr[local_452]).f0).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg2).metadata).ptr[local_452]).f0).len <= LSF_MAX_BYTES);
((((arg2).metadata).ptr[local_452]).f0).ptr = lsf_allocate(((((arg2).metadata).ptr[local_452]).f0).len, 1);
for (size_t local_454 = 0; local_454 < ((((arg2).metadata).ptr[local_452]).f0).len; local_454++) ((((arg2).metadata).ptr[local_452]).f0).ptr[local_454] = (uint8_t)lsf_get(&input, 1);
((((arg2).metadata).ptr[local_452]).f1).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg2).metadata).ptr[local_452]).f1).len <= LSF_MAX_BYTES);
((((arg2).metadata).ptr[local_452]).f1).ptr = lsf_allocate(((((arg2).metadata).ptr[local_452]).f1).len, 1);
for (size_t local_455 = 0; local_455 < ((((arg2).metadata).ptr[local_452]).f1).len; local_455++) ((((arg2).metadata).ptr[local_452]).f1).ptr[local_455] = (uint8_t)lsf_get(&input, 1);
}
lsf_finish(&input);
latent_state_key_value_result_void_state_error_t result = {0};
latent_state_key_value_put(arg0, &arg1, &arg2, &result);
for (size_t local_457 = 0; local_457 < (arg1).len; local_457++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
for (size_t local_460 = 0; local_460 < ((arg2).bytes).len; local_460++) {
}
lsf_release(((arg2).bytes).ptr, ((arg2).bytes).len * sizeof(*((arg2).bytes).ptr)); ((arg2).bytes).ptr = NULL; ((arg2).bytes).len = 0;
lsf_release(((arg2).media_type).ptr, ((arg2).media_type).len); ((arg2).media_type).ptr = NULL; ((arg2).media_type).len = 0;
for (size_t local_463 = 0; local_463 < ((arg2).metadata).len; local_463++) {
lsf_release(((((arg2).metadata).ptr[local_463]).f0).ptr, ((((arg2).metadata).ptr[local_463]).f0).len); ((((arg2).metadata).ptr[local_463]).f0).ptr = NULL; ((((arg2).metadata).ptr[local_463]).f0).len = 0;
lsf_release(((((arg2).metadata).ptr[local_463]).f1).ptr, ((((arg2).metadata).ptr[local_463]).f1).len); ((((arg2).metadata).ptr[local_463]).f1).ptr = NULL; ((((arg2).metadata).ptr[local_463]).f1).len = 0;
}
lsf_release(((arg2).metadata).ptr, ((arg2).metadata).len * sizeof(*((arg2).metadata).ptr)); ((arg2).metadata).ptr = NULL; ((arg2).metadata).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
}
if ((result).is_err) {
} else {
}
break; }
case 14: {
latent_state_key_value_borrow_transaction_t arg0 = {0};
uint64_t local_477 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_477;
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_478 = 0; local_478 < (arg1).len; local_478++) {
uint64_t local_479 = lsf_get(&input, 1);  ((arg1).ptr[local_478]) = (__typeof__(((arg1).ptr[local_478])))local_479;
}
lsf_finish(&input);
latent_state_key_value_result_void_state_error_t result = {0};
latent_state_key_value_delete(arg0, &arg1, &result);
for (size_t local_481 = 0; local_481 < (arg1).len; local_481++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 15);
} else {
}
if ((result).is_err) {
} else {
}
break; }
case 15: {
latent_intents_staging_borrow_transaction_t arg0 = {0};
uint64_t local_493 = lsf_get(&input, 4);  ((arg0).__handle) = (__typeof__(((arg0).__handle)))local_493;
latent_intents_staging_intent_t arg1 = {0};
((arg1).binding).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg1).binding).len <= LSF_MAX_BYTES);
((arg1).binding).ptr = lsf_allocate(((arg1).binding).len, 1);
for (size_t local_495 = 0; local_495 < ((arg1).binding).len; local_495++) ((arg1).binding).ptr[local_495] = (uint8_t)lsf_get(&input, 1);
((arg1).operation).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg1).operation).len <= LSF_MAX_BYTES);
((arg1).operation).ptr = lsf_allocate(((arg1).operation).len, 1);
for (size_t local_496 = 0; local_496 < ((arg1).operation).len; local_496++) ((arg1).operation).ptr[local_496] = (uint8_t)lsf_get(&input, 1);
((((arg1).payload)).bytes).len = (size_t)lsf_get(&input, 4); lsf_require(((((arg1).payload)).bytes).len <= LSF_MAX_BYTES);
((((arg1).payload)).bytes).ptr = lsf_allocate(((((arg1).payload)).bytes).len, sizeof(*((((arg1).payload)).bytes).ptr));
for (size_t local_499 = 0; local_499 < ((((arg1).payload)).bytes).len; local_499++) {
uint64_t local_500 = lsf_get(&input, 1);  (((((arg1).payload)).bytes).ptr[local_499]) = (__typeof__((((((arg1).payload)).bytes).ptr[local_499])))local_500;
}
((((arg1).payload)).media_type).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg1).payload)).media_type).len <= LSF_MAX_BYTES);
((((arg1).payload)).media_type).ptr = lsf_allocate(((((arg1).payload)).media_type).len, 1);
for (size_t local_501 = 0; local_501 < ((((arg1).payload)).media_type).len; local_501++) ((((arg1).payload)).media_type).ptr[local_501] = (uint8_t)lsf_get(&input, 1);
((((arg1).payload)).metadata).len = lsf_count(&input); lsf_require(((((arg1).payload)).metadata).len <= LSF_MAX_ITEMS);
((((arg1).payload)).metadata).ptr = lsf_allocate(((((arg1).payload)).metadata).len, sizeof(*((((arg1).payload)).metadata).ptr));
for (size_t local_502 = 0; local_502 < ((((arg1).payload)).metadata).len; local_502++) {
((((((arg1).payload)).metadata).ptr[local_502]).f0).len = (size_t)lsf_get(&input, 4);
lsf_require(((((((arg1).payload)).metadata).ptr[local_502]).f0).len <= LSF_MAX_BYTES);
((((((arg1).payload)).metadata).ptr[local_502]).f0).ptr = lsf_allocate(((((((arg1).payload)).metadata).ptr[local_502]).f0).len, 1);
for (size_t local_504 = 0; local_504 < ((((((arg1).payload)).metadata).ptr[local_502]).f0).len; local_504++) ((((((arg1).payload)).metadata).ptr[local_502]).f0).ptr[local_504] = (uint8_t)lsf_get(&input, 1);
((((((arg1).payload)).metadata).ptr[local_502]).f1).len = (size_t)lsf_get(&input, 4);
lsf_require(((((((arg1).payload)).metadata).ptr[local_502]).f1).len <= LSF_MAX_BYTES);
((((((arg1).payload)).metadata).ptr[local_502]).f1).ptr = lsf_allocate(((((((arg1).payload)).metadata).ptr[local_502]).f1).len, 1);
for (size_t local_505 = 0; local_505 < ((((((arg1).payload)).metadata).ptr[local_502]).f1).len; local_505++) ((((((arg1).payload)).metadata).ptr[local_502]).f1).ptr[local_505] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_507 = lsf_get(&input, 1); lsf_require(local_507 <= 1); (((arg1).expires_at_unix_millis).is_some) = (__typeof__((((arg1).expires_at_unix_millis).is_some)))local_507;
if (((arg1).expires_at_unix_millis).is_some) {
uint64_t local_508 = lsf_get(&input, 8);  (((arg1).expires_at_unix_millis).val) = (__typeof__((((arg1).expires_at_unix_millis).val)))local_508;
}
lsf_finish(&input);
latent_intents_staging_result_staged_intent_intent_error_t result = {0};
latent_intents_staging_stage(arg0, &arg1, &result);
lsf_release(((arg1).binding).ptr, ((arg1).binding).len); ((arg1).binding).ptr = NULL; ((arg1).binding).len = 0;
lsf_release(((arg1).operation).ptr, ((arg1).operation).len); ((arg1).operation).ptr = NULL; ((arg1).operation).len = 0;
for (size_t local_515 = 0; local_515 < ((((arg1).payload)).bytes).len; local_515++) {
}
lsf_release(((((arg1).payload)).bytes).ptr, ((((arg1).payload)).bytes).len * sizeof(*((((arg1).payload)).bytes).ptr)); ((((arg1).payload)).bytes).ptr = NULL; ((((arg1).payload)).bytes).len = 0;
lsf_release(((((arg1).payload)).media_type).ptr, ((((arg1).payload)).media_type).len); ((((arg1).payload)).media_type).ptr = NULL; ((((arg1).payload)).media_type).len = 0;
for (size_t local_518 = 0; local_518 < ((((arg1).payload)).metadata).len; local_518++) {
lsf_release(((((((arg1).payload)).metadata).ptr[local_518]).f0).ptr, ((((((arg1).payload)).metadata).ptr[local_518]).f0).len); ((((((arg1).payload)).metadata).ptr[local_518]).f0).ptr = NULL; ((((((arg1).payload)).metadata).ptr[local_518]).f0).len = 0;
lsf_release(((((((arg1).payload)).metadata).ptr[local_518]).f1).ptr, ((((((arg1).payload)).metadata).ptr[local_518]).f1).len); ((((((arg1).payload)).metadata).ptr[local_518]).f1).ptr = NULL; ((((((arg1).payload)).metadata).ptr[local_518]).f1).len = 0;
}
lsf_release(((((arg1).payload)).metadata).ptr, ((((arg1).payload)).metadata).len * sizeof(*((((arg1).payload)).metadata).ptr)); ((((arg1).payload)).metadata).ptr = NULL; ((((arg1).payload)).metadata).len = 0;
if (((arg1).expires_at_unix_millis).is_some) {
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err)), 4);
lsf_require(((result).val.err) < 13);
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).sequence), 4);
}
if ((result).is_err) {
} else {
}
break; }
case -1: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_state_key_value_transaction_drop_own((latent_state_key_value_own_transaction_t){(int32_t)handle}); break; }
case -2: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_state_key_value_query_view_drop_own((latent_state_key_value_own_query_view_t){(int32_t)handle}); break; }
case -3: {
uint32_t handle = (uint32_t)lsf_get(&input, 4); lsf_finish(&input);
latent_state_key_value_page_drop_own((latent_state_key_value_own_page_t){(int32_t)handle}); break; }
default: __builtin_trap(); }
return lsf_result(&output);
}
