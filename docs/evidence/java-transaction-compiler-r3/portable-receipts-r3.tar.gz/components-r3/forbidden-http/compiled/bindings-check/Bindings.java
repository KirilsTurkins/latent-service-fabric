// Generated from authoritative WIT and maintained wit-bindgen C. DO NOT EDIT.
package dev.latent.generated;
import dev.latent.guest.*;
import org.teavm.interop.Address;
import org.teavm.interop.Export;
import org.teavm.interop.Function;
public final class Bindings {
private Bindings() { }
public enum LatentHttpClientMethod { Get, Head, Post, Put, Patch, Delete, Options }
public record LatentHttpClientHeader(String name, String value) { public LatentHttpClientHeader { java.util.Objects.requireNonNull(name); java.util.Objects.requireNonNull(value); } }
public record LatentHttpClientRequest(LatentHttpClientMethod method, String url, java.util.List<LatentHttpClientHeader> headers, Option<byte[]> body, Option<String> bodyMediaType, Option<String> idempotencyKey, Option<Unsigned64> timeoutMillis) { public LatentHttpClientRequest { java.util.Objects.requireNonNull(method); java.util.Objects.requireNonNull(url); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(body); java.util.Objects.requireNonNull(bodyMediaType); java.util.Objects.requireNonNull(idempotencyKey); java.util.Objects.requireNonNull(timeoutMillis); } }
public record LatentHttpClientResponse(Integer status, java.util.List<LatentHttpClientHeader> headers, byte[] body, Option<String> bodyMediaType) { public LatentHttpClientResponse { java.util.Objects.requireNonNull(status); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(body); java.util.Objects.requireNonNull(bodyMediaType); } }
public static final class LatentHttpClientHttpError {
private final int tag; private final Object value;
private LatentHttpClientHttpError(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentHttpClientHttpError invalidUrl() { return new LatentHttpClientHttpError(0, Unit.VALUE); }
public static LatentHttpClientHttpError invalidRequest() { return new LatentHttpClientHttpError(1, Unit.VALUE); }
public static LatentHttpClientHttpError permissionDenied() { return new LatentHttpClientHttpError(2, Unit.VALUE); }
public static LatentHttpClientHttpError requestTooLarge() { return new LatentHttpClientHttpError(3, Unit.VALUE); }
public static LatentHttpClientHttpError responseTooLarge() { return new LatentHttpClientHttpError(4, Unit.VALUE); }
public static LatentHttpClientHttpError deadlineExceeded() { return new LatentHttpClientHttpError(5, Unit.VALUE); }
public static LatentHttpClientHttpError cancelled() { return new LatentHttpClientHttpError(6, Unit.VALUE); }
public static LatentHttpClientHttpError budgetExhausted() { return new LatentHttpClientHttpError(7, Unit.VALUE); }
public static LatentHttpClientHttpError dnsFailed() { return new LatentHttpClientHttpError(8, Unit.VALUE); }
public static LatentHttpClientHttpError tlsFailed() { return new LatentHttpClientHttpError(9, Unit.VALUE); }
public static LatentHttpClientHttpError connectionFailed() { return new LatentHttpClientHttpError(10, Unit.VALUE); }
public static LatentHttpClientHttpError unavailable() { return new LatentHttpClientHttpError(11, Unit.VALUE); }
public static LatentHttpClientHttpError uncertain() { return new LatentHttpClientHttpError(12, Unit.VALUE); }
}
public static final class LatentStateKeyValueTransaction extends Resource { private LatentStateKeyValueTransaction(int handle) { super(handle, -1); } }
public static final class LatentStateKeyValueQueryView extends Resource { private LatentStateKeyValueQueryView(int handle) { super(handle, -2); } }
public static final class LatentStateKeyValuePage extends Resource { private LatentStateKeyValuePage(int handle) { super(handle, -3); } }
public record Value15(String f0, String f1) { public Value15 { java.util.Objects.requireNonNull(f0); java.util.Objects.requireNonNull(f1); } }
public record LatentStateKeyValueValue(byte[] bytes, String mediaType, java.util.List<Value15> metadata) { public LatentStateKeyValueValue { java.util.Objects.requireNonNull(bytes); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(metadata); } }
public record LatentStateKeyValueVersionedValue(LatentStateKeyValueValue value, byte[] version) { public LatentStateKeyValueVersionedValue { java.util.Objects.requireNonNull(value); java.util.Objects.requireNonNull(version); } }
public record LatentStateKeyValueEntry(byte[] key, LatentStateKeyValueVersionedValue value) { public LatentStateKeyValueEntry { java.util.Objects.requireNonNull(key); java.util.Objects.requireNonNull(value); } }
public record LatentStateKeyValueViewIdentity(String namespace, String incarnation, byte[] version, String stateSchema) { public LatentStateKeyValueViewIdentity { java.util.Objects.requireNonNull(namespace); java.util.Objects.requireNonNull(incarnation); java.util.Objects.requireNonNull(version); java.util.Objects.requireNonNull(stateSchema); } }
public record LatentStateKeyValueCommandInfo(LatentStateKeyValueViewIdentity view, String commandId, String attemptId, Option<String> entity) { public LatentStateKeyValueCommandInfo { java.util.Objects.requireNonNull(view); java.util.Objects.requireNonNull(commandId); java.util.Objects.requireNonNull(attemptId); java.util.Objects.requireNonNull(entity); } }
public record LatentStateKeyValuePageInfo(LatentStateKeyValueViewIdentity view, Long entryCount, Unsigned64 encodedBytes, Boolean hasMore, Option<byte[]> nextCursor) { public LatentStateKeyValuePageInfo { java.util.Objects.requireNonNull(view); java.util.Objects.requireNonNull(entryCount); java.util.Objects.requireNonNull(encodedBytes); java.util.Objects.requireNonNull(hasMore); java.util.Objects.requireNonNull(nextCursor); } }
public enum LatentStateKeyValueStateError { PermissionDenied, InvalidKey, InvalidValue, InvalidLimit, InvalidCursor, StaleInput, Conflict, ReadBudgetExhausted, WriteBudgetExhausted, HandleClosed, WrongActivation, WrongMode, UnsupportedVersion, Cancelled, Unavailable }
public record LatentIntentsStagingIntent(String binding, String operation, LatentStateKeyValueValue payload, Option<Unsigned64> expiresAtUnixMillis) { public LatentIntentsStagingIntent { java.util.Objects.requireNonNull(binding); java.util.Objects.requireNonNull(operation); java.util.Objects.requireNonNull(payload); java.util.Objects.requireNonNull(expiresAtUnixMillis); } }
public record LatentIntentsStagingStagedIntent(Long sequence) { public LatentIntentsStagingStagedIntent { java.util.Objects.requireNonNull(sequence); } }
public enum LatentIntentsStagingIntentError { PermissionDenied, InvalidBinding, InvalidOperation, InvalidPayload, InvalidExpiry, CountLimit, ByteLimit, HandleClosed, WrongActivation, WrongMode, UnsupportedProfile, Cancelled, Unavailable }
public record ExamplesTransactionalAggregateApiUpdateRequest(Long delta, Boolean reject) { public ExamplesTransactionalAggregateApiUpdateRequest { java.util.Objects.requireNonNull(delta); java.util.Objects.requireNonNull(reject); } }
public record ExamplesTransactionalAggregateApiAggregate(Unsigned64 count, byte[] viewVersion, Option<byte[]> keyVersion) { public ExamplesTransactionalAggregateApiAggregate { java.util.Objects.requireNonNull(count); java.util.Objects.requireNonNull(viewVersion); java.util.Objects.requireNonNull(keyVersion); } }
public record ExamplesTransactionalAggregateApiScanResult(Long count, Unsigned64 encodedBytes, byte[] viewVersion, Option<byte[]> nextCursor) { public ExamplesTransactionalAggregateApiScanResult { java.util.Objects.requireNonNull(count); java.util.Objects.requireNonNull(encodedBytes); java.util.Objects.requireNonNull(viewVersion); java.util.Objects.requireNonNull(nextCursor); } }
public enum ExamplesTransactionalAggregateApiBusinessError { Rejected, MalformedState, Overflow }
public interface Exports {
Result<ExamplesTransactionalAggregateApiAggregate, ExamplesTransactionalAggregateApiBusinessError> update(ExamplesTransactionalAggregateApiUpdateRequest arg0);
Result<ExamplesTransactionalAggregateApiAggregate, ExamplesTransactionalAggregateApiBusinessError> query();
Result<ExamplesTransactionalAggregateApiScanResult, ExamplesTransactionalAggregateApiBusinessError> scan(byte[] arg0, Long arg1, Option<byte[]> arg2);
}
public static final class LatentHttpClient { private LatentHttpClient() { }
public static Result<LatentHttpClientResponse, LatentHttpClientHttpError> send(LatentHttpClientRequest arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT7(arguments, arg0);
try (Wire.Reader input = arguments.call(0)) {
Result<LatentHttpClientResponse, LatentHttpClientHttpError> result = readT10(input);
input.finish(); return result;
} } }
}
public static final class LatentClockMonotonic { private LatentClockMonotonic() { }
public static Unsigned64 nowNanos() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(1)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentClockWall { private LatentClockWall() { }
public static Unsigned64 nowUnixMillis() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(2)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentStateKeyValue { private LatentStateKeyValue() { }
public static Result<LatentStateKeyValueTransaction, LatentStateKeyValueStateError> acquireCommand() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(3)) {
Result<LatentStateKeyValueTransaction, LatentStateKeyValueStateError> result = readT28(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValueQueryView, LatentStateKeyValueStateError> acquireQuery() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(4)) {
Result<LatentStateKeyValueQueryView, LatentStateKeyValueStateError> result = readT30(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValueCommandInfo, LatentStateKeyValueStateError> info(LatentStateKeyValueTransaction arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT31(arguments, arg0);
try (Wire.Reader input = arguments.call(5)) {
Result<LatentStateKeyValueCommandInfo, LatentStateKeyValueStateError> result = readT32(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValueViewIdentity, LatentStateKeyValueStateError> queryInfo(LatentStateKeyValueQueryView arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT33(arguments, arg0);
try (Wire.Reader input = arguments.call(6)) {
Result<LatentStateKeyValueViewIdentity, LatentStateKeyValueStateError> result = readT34(input);
input.finish(); return result;
} } }
public static Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> get(LatentStateKeyValueTransaction arg0, byte[] arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT31(arguments, arg0);
writeT14(arguments, arg1);
try (Wire.Reader input = arguments.call(7)) {
Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> result = readT36(input);
input.finish(); return result;
} } }
public static Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> getQuery(LatentStateKeyValueQueryView arg0, byte[] arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT33(arguments, arg0);
writeT14(arguments, arg1);
try (Wire.Reader input = arguments.call(8)) {
Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> result = readT36(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> scan(LatentStateKeyValueTransaction arg0, byte[] arg1, Long arg2, Option<byte[]> arg3) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT31(arguments, arg0);
writeT14(arguments, arg1);
writeU32(arguments, arg2);
writeT24(arguments, arg3);
try (Wire.Reader input = arguments.call(9)) {
Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> result = readT38(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> scanQuery(LatentStateKeyValueQueryView arg0, byte[] arg1, Long arg2, Option<byte[]> arg3) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT33(arguments, arg0);
writeT14(arguments, arg1);
writeU32(arguments, arg2);
writeT24(arguments, arg3);
try (Wire.Reader input = arguments.call(10)) {
Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> result = readT38(input);
input.finish(); return result;
} } }
public static Result<LatentStateKeyValuePageInfo, LatentStateKeyValueStateError> describePage(LatentStateKeyValuePage arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT39(arguments, arg0);
try (Wire.Reader input = arguments.call(11)) {
Result<LatentStateKeyValuePageInfo, LatentStateKeyValueStateError> result = readT40(input);
input.finish(); return result;
} } }
public static Result<Option<LatentStateKeyValueEntry>, LatentStateKeyValueStateError> pageNext(LatentStateKeyValuePage arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT39(arguments, arg0);
try (Wire.Reader input = arguments.call(12)) {
Result<Option<LatentStateKeyValueEntry>, LatentStateKeyValueStateError> result = readT42(input);
input.finish(); return result;
} } }
public static Result<Unit, LatentStateKeyValueStateError> put(LatentStateKeyValueTransaction arg0, byte[] arg1, LatentStateKeyValueValue arg2) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT31(arguments, arg0);
writeT14(arguments, arg1);
writeT17(arguments, arg2);
try (Wire.Reader input = arguments.call(13)) {
Result<Unit, LatentStateKeyValueStateError> result = readT43(input);
input.finish(); return result;
} } }
public static Result<Unit, LatentStateKeyValueStateError> delete(LatentStateKeyValueTransaction arg0, byte[] arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT31(arguments, arg0);
writeT14(arguments, arg1);
try (Wire.Reader input = arguments.call(14)) {
Result<Unit, LatentStateKeyValueStateError> result = readT43(input);
input.finish(); return result;
} } }
}
public static final class LatentIntentsStaging { private LatentIntentsStaging() { }
public static Result<LatentIntentsStagingStagedIntent, LatentIntentsStagingIntentError> stage(LatentStateKeyValueTransaction arg0, LatentIntentsStagingIntent arg1) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT50(arguments, arg0);
writeT47(arguments, arg1);
try (Wire.Reader input = arguments.call(15)) {
Result<LatentIntentsStagingStagedIntent, LatentIntentsStagingIntentError> result = readT51(input);
input.finish(); return result;
} } }
}
public abstract static class Dispatch extends Function { public abstract Address apply(int operation, Address data, int length); }
public static void main(String[] args) { Function.get(Dispatch.class, Bindings.class, "dispatch"); }
@Export(name = "lsf_java_dispatch") public static Address dispatch(int operation, Address data, int length) {
try (Wire.Reader input = Wire.Reader.copy(data, length); Wire.Writer output = new Wire.Writer()) {
switch (operation) {
case 0: {
ExamplesTransactionalAggregateApiUpdateRequest arg0 = readT52(input);
input.finish();
writeT58(output, new dev.latent.app.Capsule().update(arg0));
return output.nativeResult(); }
case 1: {
input.finish();
writeT58(output, new dev.latent.app.Capsule().query());
return output.nativeResult(); }
case 2: {
byte[] arg0 = readT53(input);
Long arg1 = readU32(input);
Option<byte[]> arg2 = readT54(input);
input.finish();
writeT59(output, new dev.latent.app.Capsule().scan(arg0, arg1, arg2));
return output.nativeResult(); }
default: throw new IllegalArgumentException("unknown Java export"); } } }
private static Unit readUnit(Wire.Reader input) { return Unit.VALUE; }
private static void writeUnit(Wire.Writer output, Unit value) { java.util.Objects.requireNonNull(value); }
private static Integer readCharValue(Wire.Reader input) { long value = input.integer(4); Wire.require(value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); return (int) value; }
private static Boolean readBool(Wire.Reader input) { return input.bool(); }
private static void writeBool(Wire.Writer output, Boolean value) { output.bool(value); }
private static Integer readChar(Wire.Reader input) { return readCharValue(input); }
private static void writeChar(Wire.Writer output, Integer value) { Wire.require(value >= 0 && value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); output.unsigned(value, 4); }
private static Float readF32(Wire.Reader input) { return Float.intBitsToFloat((int) input.integer(4)); }
private static void writeF32(Wire.Writer output, Float value) { output.integer(Float.floatToRawIntBits(value), 4); }
private static Double readF64(Wire.Reader input) { return Double.longBitsToDouble(input.integer(8)); }
private static void writeF64(Wire.Writer output, Double value) { output.integer(Double.doubleToRawLongBits(value), 8); }
private static Short readS16(Wire.Reader input) { return (short) input.integer(2); }
private static void writeS16(Wire.Writer output, Short value) { output.integer(value, 2); }
private static Integer readS32(Wire.Reader input) { return (int) input.integer(4); }
private static void writeS32(Wire.Writer output, Integer value) { output.integer(value, 4); }
private static Long readS64(Wire.Reader input) { return (long) input.integer(8); }
private static void writeS64(Wire.Writer output, Long value) { output.integer(value, 8); }
private static Byte readS8(Wire.Reader input) { return (byte) input.integer(1); }
private static void writeS8(Wire.Writer output, Byte value) { output.integer(value, 1); }
private static String readString(Wire.Reader input) { return input.string(); }
private static void writeString(Wire.Writer output, String value) { output.string(value); }
private static Integer readU16(Wire.Reader input) { return (int) input.integer(2); }
private static void writeU16(Wire.Writer output, Integer value) { output.unsigned(value, 2); }
private static Long readU32(Wire.Reader input) { return (long) input.integer(4); }
private static void writeU32(Wire.Writer output, Long value) { output.unsigned(value, 4); }
private static Unsigned64 readU64(Wire.Reader input) { return new Unsigned64(input.integer(8)); }
private static void writeU64(Wire.Writer output, Unsigned64 value) { output.integer(value.bits(), 8); }
private static Short readU8(Wire.Reader input) { return (short) input.integer(1); }
private static void writeU8(Wire.Writer output, Short value) { output.unsigned(value, 1); }
private static void writeT0(Wire.Writer output, LatentHttpClientMethod value) {
output.integer(value.ordinal(), 4);
}
private static LatentHttpClientMethod readT0(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 7);
return LatentHttpClientMethod.values()[(int) tag];
}
private static void writeT1(Wire.Writer output, LatentHttpClientHeader value) {
writeString(output, value.name());
writeString(output, value.value());
}
private static LatentHttpClientHeader readT1(Wire.Reader input) {
return new LatentHttpClientHeader(readString(input), readString(input));
}
private static void writeT2(Wire.Writer output, java.util.List<LatentHttpClientHeader> value) {
output.count(value.size());
for (LatentHttpClientHeader item : value) { writeT1(output, item); }
}
private static java.util.List<LatentHttpClientHeader> readT2(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<LatentHttpClientHeader> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT1(input));
return values;
}
private static void writeT3(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT3(Wire.Reader input) {
return input.bytes();
}
private static void writeT4(Wire.Writer output, Option<byte[]> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT3(output, value.value()); }
}
private static Option<byte[]> readT4(Wire.Reader input) {
return input.bool() ? Option.some(readT3(input)) : Option.none();
}
private static void writeT5(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT5(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT6(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT6(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT7(Wire.Writer output, LatentHttpClientRequest value) {
writeT0(output, value.method());
writeString(output, value.url());
writeT2(output, value.headers());
writeT4(output, value.body());
writeT5(output, value.bodyMediaType());
writeT5(output, value.idempotencyKey());
writeT6(output, value.timeoutMillis());
}
private static LatentHttpClientRequest readT7(Wire.Reader input) {
return new LatentHttpClientRequest(readT0(input), readString(input), readT2(input), readT4(input), readT5(input), readT5(input), readT6(input));
}
private static void writeT8(Wire.Writer output, LatentHttpClientResponse value) {
writeU16(output, value.status());
writeT2(output, value.headers());
writeT3(output, value.body());
writeT5(output, value.bodyMediaType());
}
private static LatentHttpClientResponse readT8(Wire.Reader input) {
return new LatentHttpClientResponse(readU16(input), readT2(input), readT3(input), readT5(input));
}
private static void writeT9(Wire.Writer output, LatentHttpClientHttpError value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0:  break;
case 1:  break;
case 2:  break;
case 3:  break;
case 4:  break;
case 5:  break;
case 6:  break;
case 7:  break;
case 8:  break;
case 9:  break;
case 10:  break;
case 11:  break;
case 12:  break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentHttpClientHttpError readT9(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentHttpClientHttpError.invalidUrl();
case 1: return LatentHttpClientHttpError.invalidRequest();
case 2: return LatentHttpClientHttpError.permissionDenied();
case 3: return LatentHttpClientHttpError.requestTooLarge();
case 4: return LatentHttpClientHttpError.responseTooLarge();
case 5: return LatentHttpClientHttpError.deadlineExceeded();
case 6: return LatentHttpClientHttpError.cancelled();
case 7: return LatentHttpClientHttpError.budgetExhausted();
case 8: return LatentHttpClientHttpError.dnsFailed();
case 9: return LatentHttpClientHttpError.tlsFailed();
case 10: return LatentHttpClientHttpError.connectionFailed();
case 11: return LatentHttpClientHttpError.unavailable();
case 12: return LatentHttpClientHttpError.uncertain();
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT10(Wire.Writer output, Result<LatentHttpClientResponse, LatentHttpClientHttpError> value) {
output.bool(value.isError()); if (value.isError()) { writeT9(output, value.error()); } else { writeT8(output, value.value()); }
}
private static Result<LatentHttpClientResponse, LatentHttpClientHttpError> readT10(Wire.Reader input) {
return input.bool() ? Result.err(readT9(input)) : Result.ok(readT8(input));
}
private static void writeT14(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT14(Wire.Reader input) {
return input.bytes();
}
private static void writeT15(Wire.Writer output, Value15 value) {
writeString(output, value.f0());
writeString(output, value.f1());
}
private static Value15 readT15(Wire.Reader input) {
return new Value15(readString(input), readString(input));
}
private static void writeT16(Wire.Writer output, java.util.List<Value15> value) {
output.count(value.size());
for (Value15 item : value) { writeT15(output, item); }
}
private static java.util.List<Value15> readT16(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<Value15> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT15(input));
return values;
}
private static void writeT17(Wire.Writer output, LatentStateKeyValueValue value) {
writeT14(output, value.bytes());
writeString(output, value.mediaType());
writeT16(output, value.metadata());
}
private static LatentStateKeyValueValue readT17(Wire.Reader input) {
return new LatentStateKeyValueValue(readT14(input), readString(input), readT16(input));
}
private static void writeT18(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT18(Wire.Reader input) {
return input.bytes();
}
private static void writeT19(Wire.Writer output, LatentStateKeyValueVersionedValue value) {
writeT17(output, value.value());
writeT18(output, value.version());
}
private static LatentStateKeyValueVersionedValue readT19(Wire.Reader input) {
return new LatentStateKeyValueVersionedValue(readT17(input), readT18(input));
}
private static void writeT20(Wire.Writer output, LatentStateKeyValueEntry value) {
writeT14(output, value.key());
writeT19(output, value.value());
}
private static LatentStateKeyValueEntry readT20(Wire.Reader input) {
return new LatentStateKeyValueEntry(readT14(input), readT19(input));
}
private static void writeT21(Wire.Writer output, LatentStateKeyValueViewIdentity value) {
writeString(output, value.namespace());
writeString(output, value.incarnation());
writeT18(output, value.version());
writeString(output, value.stateSchema());
}
private static LatentStateKeyValueViewIdentity readT21(Wire.Reader input) {
return new LatentStateKeyValueViewIdentity(readString(input), readString(input), readT18(input), readString(input));
}
private static void writeT22(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT22(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT23(Wire.Writer output, LatentStateKeyValueCommandInfo value) {
writeT21(output, value.view());
writeString(output, value.commandId());
writeString(output, value.attemptId());
writeT22(output, value.entity());
}
private static LatentStateKeyValueCommandInfo readT23(Wire.Reader input) {
return new LatentStateKeyValueCommandInfo(readT21(input), readString(input), readString(input), readT22(input));
}
private static void writeT24(Wire.Writer output, Option<byte[]> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT14(output, value.value()); }
}
private static Option<byte[]> readT24(Wire.Reader input) {
return input.bool() ? Option.some(readT14(input)) : Option.none();
}
private static void writeT25(Wire.Writer output, LatentStateKeyValuePageInfo value) {
writeT21(output, value.view());
writeU32(output, value.entryCount());
writeU64(output, value.encodedBytes());
writeBool(output, value.hasMore());
writeT24(output, value.nextCursor());
}
private static LatentStateKeyValuePageInfo readT25(Wire.Reader input) {
return new LatentStateKeyValuePageInfo(readT21(input), readU32(input), readU64(input), readBool(input), readT24(input));
}
private static void writeT26(Wire.Writer output, LatentStateKeyValueStateError value) {
output.integer(value.ordinal(), 4);
}
private static LatentStateKeyValueStateError readT26(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 15);
return LatentStateKeyValueStateError.values()[(int) tag];
}
private static void writeT27(Wire.Writer output, LatentStateKeyValueTransaction value) {
output.resource(value, true);
}
private static LatentStateKeyValueTransaction readT27(Wire.Reader input) {
return new LatentStateKeyValueTransaction((int) input.integer(4));
}
private static void writeT28(Wire.Writer output, Result<LatentStateKeyValueTransaction, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT26(output, value.error()); } else { writeT27(output, value.value()); }
}
private static Result<LatentStateKeyValueTransaction, LatentStateKeyValueStateError> readT28(Wire.Reader input) {
return input.bool() ? Result.err(readT26(input)) : Result.ok(readT27(input));
}
private static void writeT29(Wire.Writer output, LatentStateKeyValueQueryView value) {
output.resource(value, true);
}
private static LatentStateKeyValueQueryView readT29(Wire.Reader input) {
return new LatentStateKeyValueQueryView((int) input.integer(4));
}
private static void writeT30(Wire.Writer output, Result<LatentStateKeyValueQueryView, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT26(output, value.error()); } else { writeT29(output, value.value()); }
}
private static Result<LatentStateKeyValueQueryView, LatentStateKeyValueStateError> readT30(Wire.Reader input) {
return input.bool() ? Result.err(readT26(input)) : Result.ok(readT29(input));
}
private static void writeT31(Wire.Writer output, LatentStateKeyValueTransaction value) {
output.resource(value, false);
}
private static LatentStateKeyValueTransaction readT31(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT32(Wire.Writer output, Result<LatentStateKeyValueCommandInfo, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT26(output, value.error()); } else { writeT23(output, value.value()); }
}
private static Result<LatentStateKeyValueCommandInfo, LatentStateKeyValueStateError> readT32(Wire.Reader input) {
return input.bool() ? Result.err(readT26(input)) : Result.ok(readT23(input));
}
private static void writeT33(Wire.Writer output, LatentStateKeyValueQueryView value) {
output.resource(value, false);
}
private static LatentStateKeyValueQueryView readT33(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT34(Wire.Writer output, Result<LatentStateKeyValueViewIdentity, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT26(output, value.error()); } else { writeT21(output, value.value()); }
}
private static Result<LatentStateKeyValueViewIdentity, LatentStateKeyValueStateError> readT34(Wire.Reader input) {
return input.bool() ? Result.err(readT26(input)) : Result.ok(readT21(input));
}
private static void writeT35(Wire.Writer output, Option<LatentStateKeyValueVersionedValue> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT19(output, value.value()); }
}
private static Option<LatentStateKeyValueVersionedValue> readT35(Wire.Reader input) {
return input.bool() ? Option.some(readT19(input)) : Option.none();
}
private static void writeT36(Wire.Writer output, Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT26(output, value.error()); } else { writeT35(output, value.value()); }
}
private static Result<Option<LatentStateKeyValueVersionedValue>, LatentStateKeyValueStateError> readT36(Wire.Reader input) {
return input.bool() ? Result.err(readT26(input)) : Result.ok(readT35(input));
}
private static void writeT37(Wire.Writer output, LatentStateKeyValuePage value) {
output.resource(value, true);
}
private static LatentStateKeyValuePage readT37(Wire.Reader input) {
return new LatentStateKeyValuePage((int) input.integer(4));
}
private static void writeT38(Wire.Writer output, Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT26(output, value.error()); } else { writeT37(output, value.value()); }
}
private static Result<LatentStateKeyValuePage, LatentStateKeyValueStateError> readT38(Wire.Reader input) {
return input.bool() ? Result.err(readT26(input)) : Result.ok(readT37(input));
}
private static void writeT39(Wire.Writer output, LatentStateKeyValuePage value) {
output.resource(value, false);
}
private static LatentStateKeyValuePage readT39(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT40(Wire.Writer output, Result<LatentStateKeyValuePageInfo, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT26(output, value.error()); } else { writeT25(output, value.value()); }
}
private static Result<LatentStateKeyValuePageInfo, LatentStateKeyValueStateError> readT40(Wire.Reader input) {
return input.bool() ? Result.err(readT26(input)) : Result.ok(readT25(input));
}
private static void writeT41(Wire.Writer output, Option<LatentStateKeyValueEntry> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT20(output, value.value()); }
}
private static Option<LatentStateKeyValueEntry> readT41(Wire.Reader input) {
return input.bool() ? Option.some(readT20(input)) : Option.none();
}
private static void writeT42(Wire.Writer output, Result<Option<LatentStateKeyValueEntry>, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT26(output, value.error()); } else { writeT41(output, value.value()); }
}
private static Result<Option<LatentStateKeyValueEntry>, LatentStateKeyValueStateError> readT42(Wire.Reader input) {
return input.bool() ? Result.err(readT26(input)) : Result.ok(readT41(input));
}
private static void writeT43(Wire.Writer output, Result<Unit, LatentStateKeyValueStateError> value) {
output.bool(value.isError()); if (value.isError()) { writeT26(output, value.error()); } else { writeUnit(output, value.value()); }
}
private static Result<Unit, LatentStateKeyValueStateError> readT43(Wire.Reader input) {
return input.bool() ? Result.err(readT26(input)) : Result.ok(readUnit(input));
}
private static void writeT45(Wire.Writer output, LatentStateKeyValueValue value) {
writeT17(output, value);
}
private static LatentStateKeyValueValue readT45(Wire.Reader input) {
return readT17(input);
}
private static void writeT46(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT46(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT47(Wire.Writer output, LatentIntentsStagingIntent value) {
writeString(output, value.binding());
writeString(output, value.operation());
writeT45(output, value.payload());
writeT46(output, value.expiresAtUnixMillis());
}
private static LatentIntentsStagingIntent readT47(Wire.Reader input) {
return new LatentIntentsStagingIntent(readString(input), readString(input), readT45(input), readT46(input));
}
private static void writeT48(Wire.Writer output, LatentIntentsStagingStagedIntent value) {
writeU32(output, value.sequence());
}
private static LatentIntentsStagingStagedIntent readT48(Wire.Reader input) {
return new LatentIntentsStagingStagedIntent(readU32(input));
}
private static void writeT49(Wire.Writer output, LatentIntentsStagingIntentError value) {
output.integer(value.ordinal(), 4);
}
private static LatentIntentsStagingIntentError readT49(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 13);
return LatentIntentsStagingIntentError.values()[(int) tag];
}
private static void writeT50(Wire.Writer output, LatentStateKeyValueTransaction value) {
output.resource(value, false);
}
private static LatentStateKeyValueTransaction readT50(Wire.Reader input) {
throw new IllegalArgumentException("borrowed resource exports are unsupported");
}
private static void writeT51(Wire.Writer output, Result<LatentIntentsStagingStagedIntent, LatentIntentsStagingIntentError> value) {
output.bool(value.isError()); if (value.isError()) { writeT49(output, value.error()); } else { writeT48(output, value.value()); }
}
private static Result<LatentIntentsStagingStagedIntent, LatentIntentsStagingIntentError> readT51(Wire.Reader input) {
return input.bool() ? Result.err(readT49(input)) : Result.ok(readT48(input));
}
private static void writeT52(Wire.Writer output, ExamplesTransactionalAggregateApiUpdateRequest value) {
writeU32(output, value.delta());
writeBool(output, value.reject());
}
private static ExamplesTransactionalAggregateApiUpdateRequest readT52(Wire.Reader input) {
return new ExamplesTransactionalAggregateApiUpdateRequest(readU32(input), readBool(input));
}
private static void writeT53(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT53(Wire.Reader input) {
return input.bytes();
}
private static void writeT54(Wire.Writer output, Option<byte[]> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT53(output, value.value()); }
}
private static Option<byte[]> readT54(Wire.Reader input) {
return input.bool() ? Option.some(readT53(input)) : Option.none();
}
private static void writeT55(Wire.Writer output, ExamplesTransactionalAggregateApiAggregate value) {
writeU64(output, value.count());
writeT53(output, value.viewVersion());
writeT54(output, value.keyVersion());
}
private static ExamplesTransactionalAggregateApiAggregate readT55(Wire.Reader input) {
return new ExamplesTransactionalAggregateApiAggregate(readU64(input), readT53(input), readT54(input));
}
private static void writeT56(Wire.Writer output, ExamplesTransactionalAggregateApiScanResult value) {
writeU32(output, value.count());
writeU64(output, value.encodedBytes());
writeT53(output, value.viewVersion());
writeT54(output, value.nextCursor());
}
private static ExamplesTransactionalAggregateApiScanResult readT56(Wire.Reader input) {
return new ExamplesTransactionalAggregateApiScanResult(readU32(input), readU64(input), readT53(input), readT54(input));
}
private static void writeT57(Wire.Writer output, ExamplesTransactionalAggregateApiBusinessError value) {
output.integer(value.ordinal(), 4);
}
private static ExamplesTransactionalAggregateApiBusinessError readT57(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 3);
return ExamplesTransactionalAggregateApiBusinessError.values()[(int) tag];
}
private static void writeT58(Wire.Writer output, Result<ExamplesTransactionalAggregateApiAggregate, ExamplesTransactionalAggregateApiBusinessError> value) {
output.bool(value.isError()); if (value.isError()) { writeT57(output, value.error()); } else { writeT55(output, value.value()); }
}
private static Result<ExamplesTransactionalAggregateApiAggregate, ExamplesTransactionalAggregateApiBusinessError> readT58(Wire.Reader input) {
return input.bool() ? Result.err(readT57(input)) : Result.ok(readT55(input));
}
private static void writeT59(Wire.Writer output, Result<ExamplesTransactionalAggregateApiScanResult, ExamplesTransactionalAggregateApiBusinessError> value) {
output.bool(value.isError()); if (value.isError()) { writeT57(output, value.error()); } else { writeT56(output, value.value()); }
}
private static Result<ExamplesTransactionalAggregateApiScanResult, ExamplesTransactionalAggregateApiBusinessError> readT59(Wire.Reader input) {
return input.bool() ? Result.err(readT57(input)) : Result.ok(readT56(input));
}
}
