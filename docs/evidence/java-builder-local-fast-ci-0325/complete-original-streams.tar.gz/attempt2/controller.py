from pathlib import Path
import json,os,subprocess,sys,time
SOURCE='0325b746ce89f6268d3b441257715adc96c35740'
root=Path('/tmp/local-fast785-0325-r2');root.mkdir(mode=0o700);home=root/'home';home.mkdir(mode=0o700);source=root/'source';out=Path('/output');started=time.monotonic();stages=[]
assert os.geteuid()==23001 and sys.version_info[:3]==(3,13,5)
for directory in ['cargo','target','runner-temp']:(root/directory).mkdir()
os.environ.update(HOME=str(home),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',CI='true',GITHUB_ACTIONS='true',GITHUB_SHA=SOURCE,RUNNER_TEMP=str(out),GITHUB_WORKSPACE=str(source),RUSTUP_TOOLCHAIN='1.97.1',CARGO_HOME=str(root/'cargo'),CARGO_TARGET_DIR=str(source/'target'),CARGO_BUILD_JOBS='2')
config=root/'gitconfig';config.write_text('[safe]\n\tdirectory = /repository\n\tdirectory = /repository/.git\n');os.environ['GIT_CONFIG_GLOBAL']=str(config)
record={'schemaVersion':'latent.local-ci.workflow-job.v1','sourceHead':SOURCE,'job':'fast','profile':'full','jobTimeoutSeconds':1200,'allSelectedRunBlocksPassed':False,'fullRepositoryCiPassed':False,'sharedCargoCacheUsed':False,'sourceTrackedFilesUnchanged':False,'stages':stages}
def save():
 record['seconds']=round(time.monotonic()-started,6);(out/'controller-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
def run(stage,args,cwd=None):
 remaining=1200-(time.monotonic()-started);assert remaining>0,'original-job-deadline-exhausted'
 mark=time.monotonic();result=subprocess.run(args,cwd=cwd,capture_output=True,timeout=remaining)
 assert len(result.stdout)+len(result.stderr)<=32*1024*1024
 for suffix,data in [('stdout',result.stdout),('stderr',result.stderr)]:(out/(stage+'.'+suffix+'.txt')).write_bytes(data)
 stages.append({'stage':stage,'command':args,'exitCode':result.returncode,'seconds':round(time.monotonic()-mark,6)});save();print(stage+' exit='+str(result.returncode),flush=True)
 assert result.returncode==0,(stage,result.stderr.decode(errors='replace')[-2500:])
try:
 run('source-clone',['git','clone','--shared','--no-checkout','/repository',str(source)])
 run('source-checkout',['git','checkout','--detach',SOURCE],source)
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD']).decode().strip()==SOURCE
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
 os.chdir(source);sys.path.insert(0,str(source))
 from tools import ci_suite_inventory as registry
 from tools.ci_fast import selected_packages
 from tools.ci_profile import classify_paths
 plan=json.loads(Path('/controller/prelaunch-selection.json').read_bytes());data=registry.load();packages=selected_packages(json.dumps(plan['packages']),data)
 deps=registry.closure(registry.workspace(registry.ROOT),set(packages));assert sorted(deps)==plan['workspaceDependencyClosure']
 decision=classify_paths(['crates/latent-state/src/lib.rs']);assert decision.profile=='fast' and list(decision.fast_packages)==plan['narrowPackages']
 record['workspaceDependencies']=sorted(deps);record['heavyweightDependenciesAbsent']=True;record['osRelease']=Path('/etc/os-release').read_text()
 import yaml
 workflow=yaml.safe_load((source/'.github/workflows/ci.yml').read_text())
 job=workflow['jobs']['fast'];assert job['name']=='Fast host correctness' and job['timeout-minutes']==20
 blocks=[{'name':step.get('name'),'if':step.get('if'),'run':step['run']} for step in job['steps'] if 'run' in step]
 assert len(blocks)==2 and blocks[1]['if']=="needs.profile.outputs.profile == 'full'"
 (out/'original-run-blocks.json').write_text(json.dumps(blocks,indent=2)+'\n')
 os.environ['CI_FAST_PACKAGES']=json.dumps(packages)
 run('original-affected-command',['bash','-e','-o','pipefail','-c',blocks[0]['run']],source)
 run('original-narrow-command',['bash','-e','-o','pipefail','-c',blocks[1]['run']],source)
 record.update(allSelectedRunBlocksPassed=True,sourceTrackedFilesUnchanged=not bool(subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no'])))
 assert record['sourceTrackedFilesUnchanged']
except BaseException as error:record['failedReason']=str(error);raise
finally:save()
print(json.dumps(record),flush=True)
