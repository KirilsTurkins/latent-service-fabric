from pathlib import Path
import json,hashlib,subprocess,time,sys
root=Path(__file__).resolve().parent;out=root/'output';assert not out.exists();out.mkdir();image='sha256:c19db1b2bb887c214b87d05aa7f15a6d2108758fa4f2cf04d09bddce8a627502'
inspect=subprocess.run(['docker','image','inspect',image],capture_output=True);(root/'actual-image-inspect.json').write_bytes(inspect.stdout);assert inspect.returncode==0 and json.loads(inspect.stdout)[0]['Id']==image
args=['docker','run','--name','latent-local-fast785-0325-linux-r2','--label','latent.owner=java-http','--label','latent.purpose=exact-785-fast-host-ci','--user','23001:23001','--cpus','2','--memory','4g','--pids-limit','256','--mount','type=bind,source=C:/Users/turkins/Desktop/latent-fabric,target=/repository,readonly','--mount','type=bind,source='+str(root)+',target=/controller,readonly','--mount','type=bind,source='+str(out)+',target=/output','--entrypoint','/usr/local/bin/python3',image,'-B','/controller/controller.py']
(root/'controller-command.json').write_text(json.dumps({'command':args,'actualImage':image,'controllerSha256':'sha256:'+hashlib.sha256((root/'controller.py').read_bytes()).hexdigest()},indent=2)+'\n');start=time.monotonic();print('Exact7850325 Fast host CI started;17 workspace dependencies, no heavyweight engine dependencies.',flush=True)
with (root/'controller.stdout.txt').open('wb') as stdout,(root/'controller.stderr.txt').open('wb') as stderr:result=subprocess.run(args,stdout=stdout,stderr=stderr,timeout=1230)
record={'exitCode':result.returncode,'seconds':round(time.monotonic()-start,6),'actualImage':image};(root/'controller-process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
if result.returncode:print((root/'controller.stderr.txt').read_text(errors='replace')[-4000:],flush=True)
sys.exit(result.returncode)
