// Generated from authoritative WIT and maintained wit-bindgen C. DO NOT EDIT.
package dev.latent.generated;
import dev.latent.guest.*;
import org.teavm.interop.Address;
import org.teavm.interop.Export;
import org.teavm.interop.Function;
public final class Bindings {
private Bindings() { }
public record LatentServiceInvokeTarget(Option<String> tenant, String service, String contract, String function, Option<String> route) { public LatentServiceInvokeTarget { java.util.Objects.requireNonNull(tenant); java.util.Objects.requireNonNull(service); java.util.Objects.requireNonNull(contract); java.util.Objects.requireNonNull(function); java.util.Objects.requireNonNull(route); } }
public record Value3(String f0, String f1) { public Value3 { java.util.Objects.requireNonNull(f0); java.util.Objects.requireNonNull(f1); } }
public record LatentServiceInvokeCallOptions(Option<Unsigned64> deadlineUnixMillis, Short priority, Option<String> idempotencyKey, java.util.List<Value3> metadata) { public LatentServiceInvokeCallOptions { java.util.Objects.requireNonNull(deadlineUnixMillis); java.util.Objects.requireNonNull(priority); java.util.Objects.requireNonNull(idempotencyKey); java.util.Objects.requireNonNull(metadata); } }
public record LatentServiceInvokeInvocationResult(byte[] payload, String mediaType, java.util.List<Value3> metadata) { public LatentServiceInvokeInvocationResult { java.util.Objects.requireNonNull(payload); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(metadata); } }
public record LatentServiceInvokeErrorDetail(String kind, java.util.List<Value3> fields) { public LatentServiceInvokeErrorDetail { java.util.Objects.requireNonNull(kind); java.util.Objects.requireNonNull(fields); } }
public enum LatentServiceInvokePlatformErrorCode { Unavailable, DeadlineExceeded, Cancelled, ResourceExhausted, PermissionDenied, Unauthenticated, InvalidArgument, NotFound, AlreadyExists, IncompatibleContract, StateConflict, DependencyFailed, GuestTrap, CorruptArtifact, RouteUnavailable, AdmissionRejected, Internal }
public record LatentServiceInvokePlatformError(LatentServiceInvokePlatformErrorCode code, String message, Boolean retryable, java.util.List<LatentServiceInvokeErrorDetail> details) { public LatentServiceInvokePlatformError { java.util.Objects.requireNonNull(code); java.util.Objects.requireNonNull(message); java.util.Objects.requireNonNull(retryable); java.util.Objects.requireNonNull(details); } }
public record LatentServiceInvokeDeclaredError(String code, String message, byte[] payload, String mediaType, java.util.List<Value3> metadata) { public LatentServiceInvokeDeclaredError { java.util.Objects.requireNonNull(code); java.util.Objects.requireNonNull(message); java.util.Objects.requireNonNull(payload); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(metadata); } }
public static final class LatentServiceInvokeInvocationOutcome {
private final int tag; private final Object value;
private LatentServiceInvokeInvocationOutcome(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentServiceInvokeInvocationOutcome success(LatentServiceInvokeInvocationResult value) { return new LatentServiceInvokeInvocationOutcome(0, java.util.Objects.requireNonNull(value)); }
@SuppressWarnings("unchecked") public LatentServiceInvokeInvocationResult successValue() { Wire.require(tag == 0); return (LatentServiceInvokeInvocationResult) value; }
public static LatentServiceInvokeInvocationOutcome declaredError(LatentServiceInvokeDeclaredError value) { return new LatentServiceInvokeInvocationOutcome(1, java.util.Objects.requireNonNull(value)); }
@SuppressWarnings("unchecked") public LatentServiceInvokeDeclaredError declaredErrorValue() { Wire.require(tag == 1); return (LatentServiceInvokeDeclaredError) value; }
public static LatentServiceInvokeInvocationOutcome platformFailure(LatentServiceInvokePlatformError value) { return new LatentServiceInvokeInvocationOutcome(2, java.util.Objects.requireNonNull(value)); }
@SuppressWarnings("unchecked") public LatentServiceInvokePlatformError platformFailureValue() { Wire.require(tag == 2); return (LatentServiceInvokePlatformError) value; }
}
public enum LatentWebApplicationProfile { BufferedV1 }
public enum LatentWebApplicationMethod { Get, Head, Post, Put, Patch, Delete, Options }
public enum LatentWebApplicationScheme { Http, Https }
public record LatentWebApplicationHeader(String name, byte[] value) { public LatentWebApplicationHeader { java.util.Objects.requireNonNull(name); java.util.Objects.requireNonNull(value); } }
public record LatentWebApplicationRequest(LatentWebApplicationProfile profile, LatentWebApplicationMethod method, LatentWebApplicationScheme scheme, String authority, String path, Option<String> query, java.util.List<LatentWebApplicationHeader> headers, Option<String> mediaType, String bodyBase64) { public LatentWebApplicationRequest { java.util.Objects.requireNonNull(profile); java.util.Objects.requireNonNull(method); java.util.Objects.requireNonNull(scheme); java.util.Objects.requireNonNull(authority); java.util.Objects.requireNonNull(path); java.util.Objects.requireNonNull(query); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(bodyBase64); } }
public record LatentWebApplicationResponse(LatentWebApplicationProfile profile, Integer status, java.util.List<LatentWebApplicationHeader> headers, Option<String> mediaType, Option<Unsigned64> representationLength, String bodyBase64) { public LatentWebApplicationResponse { java.util.Objects.requireNonNull(profile); java.util.Objects.requireNonNull(status); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(mediaType); java.util.Objects.requireNonNull(representationLength); java.util.Objects.requireNonNull(bodyBase64); } }
public interface Exports {
LatentWebApplicationResponse handle(LatentWebApplicationRequest arg0);
}
public static final class LatentClockMonotonic { private LatentClockMonotonic() { }
public static Unsigned64 nowNanos() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(0)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentClockWall { private LatentClockWall() { }
public static Unsigned64 nowUnixMillis() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(1)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentServiceInvoke { private LatentServiceInvoke() { }
public static LatentServiceInvokeInvocationOutcome call(LatentServiceInvokeTarget arg0, byte[] arg1, String arg2, LatentServiceInvokeCallOptions arg3) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT1(arguments, arg0);
writeT6(arguments, arg1);
writeString(arguments, arg2);
writeT5(arguments, arg3);
try (Wire.Reader input = arguments.call(2)) {
LatentServiceInvokeInvocationOutcome result = readT13(input);
input.finish(); return result;
} } }
}
public abstract static class Dispatch extends Function { public abstract Address apply(int operation, Address data, int length); }
public static void main(String[] args) { Function.get(Dispatch.class, Bindings.class, "dispatch"); }
@Export(name = "lsf_java_dispatch") public static Address dispatch(int operation, Address data, int length) {
try (Wire.Reader input = Wire.Reader.copy(data, length); Wire.Writer output = new Wire.Writer()) {
switch (operation) {
case 0: {
LatentWebApplicationRequest arg0 = readT28(input);
input.finish();
writeT30(output, new dev.latent.app.Capsule().handle(arg0));
return output.nativeResult(); }
default: throw new IllegalArgumentException("unknown Java export"); } } }
private static Unit readUnit(Wire.Reader input) { return Unit.VALUE; }
private static void writeUnit(Wire.Writer output, Unit value) { java.util.Objects.requireNonNull(value); }
private static Integer readCharValue(Wire.Reader input) { long value = input.integer(4); Wire.require(value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); return (int) value; }
private static Boolean readBool(Wire.Reader input) { return input.bool(); }
private static void writeBool(Wire.Writer output, Boolean value) { output.bool(value); }
private static Integer readChar(Wire.Reader input) { return readCharValue(input); }
private static void writeChar(Wire.Writer output, Integer value) { Wire.require(value >= 0 && value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); output.unsigned(value, 4); }
private static Float readF32(Wire.Reader input) { return Float.intBitsToFloat((int) input.integer(4)); }
private static void writeF32(Wire.Writer output, Float value) { output.integer(Float.floatToRawIntBits(value), 4); }
private static Double readF64(Wire.Reader input) { return Double.longBitsToDouble(input.integer(8)); }
private static void writeF64(Wire.Writer output, Double value) { output.integer(Double.doubleToRawLongBits(value), 8); }
private static Short readS16(Wire.Reader input) { return (short) input.integer(2); }
private static void writeS16(Wire.Writer output, Short value) { output.integer(value, 2); }
private static Integer readS32(Wire.Reader input) { return (int) input.integer(4); }
private static void writeS32(Wire.Writer output, Integer value) { output.integer(value, 4); }
private static Long readS64(Wire.Reader input) { return (long) input.integer(8); }
private static void writeS64(Wire.Writer output, Long value) { output.integer(value, 8); }
private static Byte readS8(Wire.Reader input) { return (byte) input.integer(1); }
private static void writeS8(Wire.Writer output, Byte value) { output.integer(value, 1); }
private static String readString(Wire.Reader input) { return input.string(); }
private static void writeString(Wire.Writer output, String value) { output.string(value); }
private static Integer readU16(Wire.Reader input) { return (int) input.integer(2); }
private static void writeU16(Wire.Writer output, Integer value) { output.unsigned(value, 2); }
private static Long readU32(Wire.Reader input) { return (long) input.integer(4); }
private static void writeU32(Wire.Writer output, Long value) { output.unsigned(value, 4); }
private static Unsigned64 readU64(Wire.Reader input) { return new Unsigned64(input.integer(8)); }
private static void writeU64(Wire.Writer output, Unsigned64 value) { output.integer(value.bits(), 8); }
private static Short readU8(Wire.Reader input) { return (short) input.integer(1); }
private static void writeU8(Wire.Writer output, Short value) { output.unsigned(value, 1); }
private static void writeT0(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT0(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT1(Wire.Writer output, LatentServiceInvokeTarget value) {
writeT0(output, value.tenant());
writeString(output, value.service());
writeString(output, value.contract());
writeString(output, value.function());
writeT0(output, value.route());
}
private static LatentServiceInvokeTarget readT1(Wire.Reader input) {
return new LatentServiceInvokeTarget(readT0(input), readString(input), readString(input), readString(input), readT0(input));
}
private static void writeT2(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT2(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT3(Wire.Writer output, Value3 value) {
writeString(output, value.f0());
writeString(output, value.f1());
}
private static Value3 readT3(Wire.Reader input) {
return new Value3(readString(input), readString(input));
}
private static void writeT4(Wire.Writer output, java.util.List<Value3> value) {
output.count(value.size());
for (Value3 item : value) { writeT3(output, item); }
}
private static java.util.List<Value3> readT4(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<Value3> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT3(input));
return values;
}
private static void writeT5(Wire.Writer output, LatentServiceInvokeCallOptions value) {
writeT2(output, value.deadlineUnixMillis());
writeU8(output, value.priority());
writeT0(output, value.idempotencyKey());
writeT4(output, value.metadata());
}
private static LatentServiceInvokeCallOptions readT5(Wire.Reader input) {
return new LatentServiceInvokeCallOptions(readT2(input), readU8(input), readT0(input), readT4(input));
}
private static void writeT6(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT6(Wire.Reader input) {
return input.bytes();
}
private static void writeT7(Wire.Writer output, LatentServiceInvokeInvocationResult value) {
writeT6(output, value.payload());
writeString(output, value.mediaType());
writeT4(output, value.metadata());
}
private static LatentServiceInvokeInvocationResult readT7(Wire.Reader input) {
return new LatentServiceInvokeInvocationResult(readT6(input), readString(input), readT4(input));
}
private static void writeT8(Wire.Writer output, LatentServiceInvokeErrorDetail value) {
writeString(output, value.kind());
writeT4(output, value.fields());
}
private static LatentServiceInvokeErrorDetail readT8(Wire.Reader input) {
return new LatentServiceInvokeErrorDetail(readString(input), readT4(input));
}
private static void writeT9(Wire.Writer output, LatentServiceInvokePlatformErrorCode value) {
output.integer(value.ordinal(), 4);
}
private static LatentServiceInvokePlatformErrorCode readT9(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 17);
return LatentServiceInvokePlatformErrorCode.values()[(int) tag];
}
private static void writeT10(Wire.Writer output, java.util.List<LatentServiceInvokeErrorDetail> value) {
output.count(value.size());
for (LatentServiceInvokeErrorDetail item : value) { writeT8(output, item); }
}
private static java.util.List<LatentServiceInvokeErrorDetail> readT10(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<LatentServiceInvokeErrorDetail> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT8(input));
return values;
}
private static void writeT11(Wire.Writer output, LatentServiceInvokePlatformError value) {
writeT9(output, value.code());
writeString(output, value.message());
writeBool(output, value.retryable());
writeT10(output, value.details());
}
private static LatentServiceInvokePlatformError readT11(Wire.Reader input) {
return new LatentServiceInvokePlatformError(readT9(input), readString(input), readBool(input), readT10(input));
}
private static void writeT12(Wire.Writer output, LatentServiceInvokeDeclaredError value) {
writeString(output, value.code());
writeString(output, value.message());
writeT6(output, value.payload());
writeString(output, value.mediaType());
writeT4(output, value.metadata());
}
private static LatentServiceInvokeDeclaredError readT12(Wire.Reader input) {
return new LatentServiceInvokeDeclaredError(readString(input), readString(input), readT6(input), readString(input), readT4(input));
}
private static void writeT13(Wire.Writer output, LatentServiceInvokeInvocationOutcome value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0: writeT7(output, value.successValue()); break;
case 1: writeT12(output, value.declaredErrorValue()); break;
case 2: writeT11(output, value.platformFailureValue()); break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentServiceInvokeInvocationOutcome readT13(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentServiceInvokeInvocationOutcome.success(readT7(input));
case 1: return LatentServiceInvokeInvocationOutcome.declaredError(readT12(input));
case 2: return LatentServiceInvokeInvocationOutcome.platformFailure(readT11(input));
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT21(Wire.Writer output, LatentWebApplicationProfile value) {
output.integer(value.ordinal(), 4);
}
private static LatentWebApplicationProfile readT21(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 1);
return LatentWebApplicationProfile.values()[(int) tag];
}
private static void writeT22(Wire.Writer output, LatentWebApplicationMethod value) {
output.integer(value.ordinal(), 4);
}
private static LatentWebApplicationMethod readT22(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 7);
return LatentWebApplicationMethod.values()[(int) tag];
}
private static void writeT23(Wire.Writer output, LatentWebApplicationScheme value) {
output.integer(value.ordinal(), 4);
}
private static LatentWebApplicationScheme readT23(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 2);
return LatentWebApplicationScheme.values()[(int) tag];
}
private static void writeT24(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT24(Wire.Reader input) {
return input.bytes();
}
private static void writeT25(Wire.Writer output, LatentWebApplicationHeader value) {
writeString(output, value.name());
writeT24(output, value.value());
}
private static LatentWebApplicationHeader readT25(Wire.Reader input) {
return new LatentWebApplicationHeader(readString(input), readT24(input));
}
private static void writeT26(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT26(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT27(Wire.Writer output, java.util.List<LatentWebApplicationHeader> value) {
output.count(value.size());
for (LatentWebApplicationHeader item : value) { writeT25(output, item); }
}
private static java.util.List<LatentWebApplicationHeader> readT27(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<LatentWebApplicationHeader> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT25(input));
return values;
}
private static void writeT28(Wire.Writer output, LatentWebApplicationRequest value) {
writeT21(output, value.profile());
writeT22(output, value.method());
writeT23(output, value.scheme());
writeString(output, value.authority());
writeString(output, value.path());
writeT26(output, value.query());
writeT27(output, value.headers());
writeT26(output, value.mediaType());
writeString(output, value.bodyBase64());
}
private static LatentWebApplicationRequest readT28(Wire.Reader input) {
return new LatentWebApplicationRequest(readT21(input), readT22(input), readT23(input), readString(input), readString(input), readT26(input), readT27(input), readT26(input), readString(input));
}
private static void writeT29(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT29(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT30(Wire.Writer output, LatentWebApplicationResponse value) {
writeT21(output, value.profile());
writeU16(output, value.status());
writeT27(output, value.headers());
writeT26(output, value.mediaType());
writeT29(output, value.representationLength());
writeString(output, value.bodyBase64());
}
private static LatentWebApplicationResponse readT30(Wire.Reader input) {
return new LatentWebApplicationResponse(readT21(input), readU16(input), readT27(input), readT26(input), readT29(input), readString(input));
}
}
