// Generated from authoritative WIT and maintained wit-bindgen C. DO NOT EDIT.
package dev.latent.generated;
import dev.latent.guest.*;
import org.teavm.interop.Address;
import org.teavm.interop.Export;
import org.teavm.interop.Function;
public final class Bindings {
private Bindings() { }
public enum LatentHttpClientMethod { Get, Head, Post, Put, Patch, Delete, Options }
public record LatentHttpClientHeader(String name, String value) { public LatentHttpClientHeader { java.util.Objects.requireNonNull(name); java.util.Objects.requireNonNull(value); } }
public record LatentHttpClientRequest(LatentHttpClientMethod method, String url, java.util.List<LatentHttpClientHeader> headers, Option<byte[]> body, Option<String> bodyMediaType, Option<String> idempotencyKey, Option<Unsigned64> timeoutMillis) { public LatentHttpClientRequest { java.util.Objects.requireNonNull(method); java.util.Objects.requireNonNull(url); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(body); java.util.Objects.requireNonNull(bodyMediaType); java.util.Objects.requireNonNull(idempotencyKey); java.util.Objects.requireNonNull(timeoutMillis); } }
public record LatentHttpClientResponse(Integer status, java.util.List<LatentHttpClientHeader> headers, byte[] body, Option<String> bodyMediaType) { public LatentHttpClientResponse { java.util.Objects.requireNonNull(status); java.util.Objects.requireNonNull(headers); java.util.Objects.requireNonNull(body); java.util.Objects.requireNonNull(bodyMediaType); } }
public static final class LatentHttpClientHttpError {
private final int tag; private final Object value;
private LatentHttpClientHttpError(int tag, Object value) { this.tag = tag; this.value = value; }
public int tag() { return tag; }
public static LatentHttpClientHttpError invalidUrl() { return new LatentHttpClientHttpError(0, Unit.VALUE); }
public static LatentHttpClientHttpError invalidRequest() { return new LatentHttpClientHttpError(1, Unit.VALUE); }
public static LatentHttpClientHttpError permissionDenied() { return new LatentHttpClientHttpError(2, Unit.VALUE); }
public static LatentHttpClientHttpError requestTooLarge() { return new LatentHttpClientHttpError(3, Unit.VALUE); }
public static LatentHttpClientHttpError responseTooLarge() { return new LatentHttpClientHttpError(4, Unit.VALUE); }
public static LatentHttpClientHttpError deadlineExceeded() { return new LatentHttpClientHttpError(5, Unit.VALUE); }
public static LatentHttpClientHttpError cancelled() { return new LatentHttpClientHttpError(6, Unit.VALUE); }
public static LatentHttpClientHttpError budgetExhausted() { return new LatentHttpClientHttpError(7, Unit.VALUE); }
public static LatentHttpClientHttpError dnsFailed() { return new LatentHttpClientHttpError(8, Unit.VALUE); }
public static LatentHttpClientHttpError tlsFailed() { return new LatentHttpClientHttpError(9, Unit.VALUE); }
public static LatentHttpClientHttpError connectionFailed() { return new LatentHttpClientHttpError(10, Unit.VALUE); }
public static LatentHttpClientHttpError unavailable() { return new LatentHttpClientHttpError(11, Unit.VALUE); }
public static LatentHttpClientHttpError uncertain() { return new LatentHttpClientHttpError(12, Unit.VALUE); }
}
public record ExamplesJavaHttpDomainTypesWide(String a, String b, String c, String d, String e, String f, String g, String h, String i, String j, String k, String l, Unsigned64 sequence) { public ExamplesJavaHttpDomainTypesWide { java.util.Objects.requireNonNull(a); java.util.Objects.requireNonNull(b); java.util.Objects.requireNonNull(c); java.util.Objects.requireNonNull(d); java.util.Objects.requireNonNull(e); java.util.Objects.requireNonNull(f); java.util.Objects.requireNonNull(g); java.util.Objects.requireNonNull(h); java.util.Objects.requireNonNull(i); java.util.Objects.requireNonNull(j); java.util.Objects.requireNonNull(k); java.util.Objects.requireNonNull(l); java.util.Objects.requireNonNull(sequence); } }
public record ExamplesJavaHttpDomainTypesNested(ExamplesJavaHttpDomainTypesWide value, Option<ExamplesJavaHttpDomainTypesWide> optional, java.util.List<String> labels) { public ExamplesJavaHttpDomainTypesNested { java.util.Objects.requireNonNull(value); java.util.Objects.requireNonNull(optional); java.util.Objects.requireNonNull(labels); } }
public interface Exports {
java.util.List<ExamplesJavaHttpDomainTypesWide> status();
ExamplesJavaHttpDomainTypesWide echo(ExamplesJavaHttpDomainTypesWide arg0);
ExamplesJavaHttpDomainTypesNested echoNested(ExamplesJavaHttpDomainTypesNested arg0);
String text(String arg0);
java.util.List<String> items(java.util.List<String> arg0);
Result<String, String> fail();
String throwError();
Long spin();
String privateAdmin();
String publishing();
String providerEvent();
}
public static final class LatentHttpClient { private LatentHttpClient() { }
public static Result<LatentHttpClientResponse, LatentHttpClientHttpError> send(LatentHttpClientRequest arg0) {
try (Wire.Writer arguments = new Wire.Writer()) {
writeT7(arguments, arg0);
try (Wire.Reader input = arguments.call(0)) {
Result<LatentHttpClientResponse, LatentHttpClientHttpError> result = readT10(input);
input.finish(); return result;
} } }
}
public static final class LatentClockMonotonic { private LatentClockMonotonic() { }
public static Unsigned64 nowNanos() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(1)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentClockWall { private LatentClockWall() { }
public static Unsigned64 nowUnixMillis() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(2)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public abstract static class Dispatch extends Function { public abstract Address apply(int operation, Address data, int length); }
public static void main(String[] args) { Function.get(Dispatch.class, Bindings.class, "dispatch"); }
@Export(name = "lsf_java_dispatch") public static Address dispatch(int operation, Address data, int length) {
try (Wire.Reader input = Wire.Reader.copy(data, length); Wire.Writer output = new Wire.Writer()) {
switch (operation) {
case 0: {
input.finish();
writeT18(output, new dev.latent.app.Capsule().status());
return output.nativeResult(); }
case 1: {
ExamplesJavaHttpDomainTypesWide arg0 = readT16(input);
input.finish();
writeT16(output, new dev.latent.app.Capsule().echo(arg0));
return output.nativeResult(); }
case 2: {
ExamplesJavaHttpDomainTypesNested arg0 = readT17(input);
input.finish();
writeT17(output, new dev.latent.app.Capsule().echoNested(arg0));
return output.nativeResult(); }
case 3: {
String arg0 = readString(input);
input.finish();
writeString(output, new dev.latent.app.Capsule().text(arg0));
return output.nativeResult(); }
case 4: {
java.util.List<String> arg0 = readT14(input);
input.finish();
writeT14(output, new dev.latent.app.Capsule().items(arg0));
return output.nativeResult(); }
case 5: {
input.finish();
writeT19(output, new dev.latent.app.Capsule().fail());
return output.nativeResult(); }
case 6: {
input.finish();
writeString(output, new dev.latent.app.Capsule().throwError());
return output.nativeResult(); }
case 7: {
input.finish();
writeU32(output, new dev.latent.app.Capsule().spin());
return output.nativeResult(); }
case 8: {
input.finish();
writeString(output, new dev.latent.app.Capsule().privateAdmin());
return output.nativeResult(); }
case 9: {
input.finish();
writeString(output, new dev.latent.app.Capsule().publishing());
return output.nativeResult(); }
case 10: {
input.finish();
writeString(output, new dev.latent.app.Capsule().providerEvent());
return output.nativeResult(); }
default: throw new IllegalArgumentException("unknown Java export"); } } }
private static Unit readUnit(Wire.Reader input) { return Unit.VALUE; }
private static void writeUnit(Wire.Writer output, Unit value) { java.util.Objects.requireNonNull(value); }
private static Integer readCharValue(Wire.Reader input) { long value = input.integer(4); Wire.require(value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); return (int) value; }
private static Boolean readBool(Wire.Reader input) { return input.bool(); }
private static void writeBool(Wire.Writer output, Boolean value) { output.bool(value); }
private static Integer readChar(Wire.Reader input) { return readCharValue(input); }
private static void writeChar(Wire.Writer output, Integer value) { Wire.require(value >= 0 && value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); output.unsigned(value, 4); }
private static Float readF32(Wire.Reader input) { return Float.intBitsToFloat((int) input.integer(4)); }
private static void writeF32(Wire.Writer output, Float value) { output.integer(Float.floatToRawIntBits(value), 4); }
private static Double readF64(Wire.Reader input) { return Double.longBitsToDouble(input.integer(8)); }
private static void writeF64(Wire.Writer output, Double value) { output.integer(Double.doubleToRawLongBits(value), 8); }
private static Short readS16(Wire.Reader input) { return (short) input.integer(2); }
private static void writeS16(Wire.Writer output, Short value) { output.integer(value, 2); }
private static Integer readS32(Wire.Reader input) { return (int) input.integer(4); }
private static void writeS32(Wire.Writer output, Integer value) { output.integer(value, 4); }
private static Long readS64(Wire.Reader input) { return (long) input.integer(8); }
private static void writeS64(Wire.Writer output, Long value) { output.integer(value, 8); }
private static Byte readS8(Wire.Reader input) { return (byte) input.integer(1); }
private static void writeS8(Wire.Writer output, Byte value) { output.integer(value, 1); }
private static String readString(Wire.Reader input) { return input.string(); }
private static void writeString(Wire.Writer output, String value) { output.string(value); }
private static Integer readU16(Wire.Reader input) { return (int) input.integer(2); }
private static void writeU16(Wire.Writer output, Integer value) { output.unsigned(value, 2); }
private static Long readU32(Wire.Reader input) { return (long) input.integer(4); }
private static void writeU32(Wire.Writer output, Long value) { output.unsigned(value, 4); }
private static Unsigned64 readU64(Wire.Reader input) { return new Unsigned64(input.integer(8)); }
private static void writeU64(Wire.Writer output, Unsigned64 value) { output.integer(value.bits(), 8); }
private static Short readU8(Wire.Reader input) { return (short) input.integer(1); }
private static void writeU8(Wire.Writer output, Short value) { output.unsigned(value, 1); }
private static void writeT0(Wire.Writer output, LatentHttpClientMethod value) {
output.integer(value.ordinal(), 4);
}
private static LatentHttpClientMethod readT0(Wire.Reader input) {
long tag = input.integer(4);
Wire.require(tag < 7);
return LatentHttpClientMethod.values()[(int) tag];
}
private static void writeT1(Wire.Writer output, LatentHttpClientHeader value) {
writeString(output, value.name());
writeString(output, value.value());
}
private static LatentHttpClientHeader readT1(Wire.Reader input) {
return new LatentHttpClientHeader(readString(input), readString(input));
}
private static void writeT2(Wire.Writer output, java.util.List<LatentHttpClientHeader> value) {
output.count(value.size());
for (LatentHttpClientHeader item : value) { writeT1(output, item); }
}
private static java.util.List<LatentHttpClientHeader> readT2(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<LatentHttpClientHeader> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT1(input));
return values;
}
private static void writeT3(Wire.Writer output, byte[] value) {
output.bytes(value);
}
private static byte[] readT3(Wire.Reader input) {
return input.bytes();
}
private static void writeT4(Wire.Writer output, Option<byte[]> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT3(output, value.value()); }
}
private static Option<byte[]> readT4(Wire.Reader input) {
return input.bool() ? Option.some(readT3(input)) : Option.none();
}
private static void writeT5(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT5(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT6(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT6(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT7(Wire.Writer output, LatentHttpClientRequest value) {
writeT0(output, value.method());
writeString(output, value.url());
writeT2(output, value.headers());
writeT4(output, value.body());
writeT5(output, value.bodyMediaType());
writeT5(output, value.idempotencyKey());
writeT6(output, value.timeoutMillis());
}
private static LatentHttpClientRequest readT7(Wire.Reader input) {
return new LatentHttpClientRequest(readT0(input), readString(input), readT2(input), readT4(input), readT5(input), readT5(input), readT6(input));
}
private static void writeT8(Wire.Writer output, LatentHttpClientResponse value) {
writeU16(output, value.status());
writeT2(output, value.headers());
writeT3(output, value.body());
writeT5(output, value.bodyMediaType());
}
private static LatentHttpClientResponse readT8(Wire.Reader input) {
return new LatentHttpClientResponse(readU16(input), readT2(input), readT3(input), readT5(input));
}
private static void writeT9(Wire.Writer output, LatentHttpClientHttpError value) {
output.integer(value.tag(), 4); switch (value.tag()) {
case 0:  break;
case 1:  break;
case 2:  break;
case 3:  break;
case 4:  break;
case 5:  break;
case 6:  break;
case 7:  break;
case 8:  break;
case 9:  break;
case 10:  break;
case 11:  break;
case 12:  break;
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static LatentHttpClientHttpError readT9(Wire.Reader input) {
switch ((int) input.integer(4)) {
case 0: return LatentHttpClientHttpError.invalidUrl();
case 1: return LatentHttpClientHttpError.invalidRequest();
case 2: return LatentHttpClientHttpError.permissionDenied();
case 3: return LatentHttpClientHttpError.requestTooLarge();
case 4: return LatentHttpClientHttpError.responseTooLarge();
case 5: return LatentHttpClientHttpError.deadlineExceeded();
case 6: return LatentHttpClientHttpError.cancelled();
case 7: return LatentHttpClientHttpError.budgetExhausted();
case 8: return LatentHttpClientHttpError.dnsFailed();
case 9: return LatentHttpClientHttpError.tlsFailed();
case 10: return LatentHttpClientHttpError.connectionFailed();
case 11: return LatentHttpClientHttpError.unavailable();
case 12: return LatentHttpClientHttpError.uncertain();
default: throw new IllegalArgumentException("invalid variant tag"); }
}
private static void writeT10(Wire.Writer output, Result<LatentHttpClientResponse, LatentHttpClientHttpError> value) {
output.bool(value.isError()); if (value.isError()) { writeT9(output, value.error()); } else { writeT8(output, value.value()); }
}
private static Result<LatentHttpClientResponse, LatentHttpClientHttpError> readT10(Wire.Reader input) {
return input.bool() ? Result.err(readT9(input)) : Result.ok(readT8(input));
}
private static void writeT11(Wire.Writer output, Unsigned64 value) {
writeU64(output, value);
}
private static Unsigned64 readT11(Wire.Reader input) {
return readU64(input);
}
private static void writeT12(Wire.Writer output, ExamplesJavaHttpDomainTypesWide value) {
writeString(output, value.a());
writeString(output, value.b());
writeString(output, value.c());
writeString(output, value.d());
writeString(output, value.e());
writeString(output, value.f());
writeString(output, value.g());
writeString(output, value.h());
writeString(output, value.i());
writeString(output, value.j());
writeString(output, value.k());
writeString(output, value.l());
writeT11(output, value.sequence());
}
private static ExamplesJavaHttpDomainTypesWide readT12(Wire.Reader input) {
return new ExamplesJavaHttpDomainTypesWide(readString(input), readString(input), readString(input), readString(input), readString(input), readString(input), readString(input), readString(input), readString(input), readString(input), readString(input), readString(input), readT11(input));
}
private static void writeT13(Wire.Writer output, Option<ExamplesJavaHttpDomainTypesWide> value) {
output.bool(value.isSome()); if (value.isSome()) { writeT12(output, value.value()); }
}
private static Option<ExamplesJavaHttpDomainTypesWide> readT13(Wire.Reader input) {
return input.bool() ? Option.some(readT12(input)) : Option.none();
}
private static void writeT14(Wire.Writer output, java.util.List<String> value) {
output.count(value.size());
for (String item : value) { writeString(output, item); }
}
private static java.util.List<String> readT14(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<String> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readString(input));
return values;
}
private static void writeT15(Wire.Writer output, ExamplesJavaHttpDomainTypesNested value) {
writeT12(output, value.value());
writeT13(output, value.optional());
writeT14(output, value.labels());
}
private static ExamplesJavaHttpDomainTypesNested readT15(Wire.Reader input) {
return new ExamplesJavaHttpDomainTypesNested(readT12(input), readT13(input), readT14(input));
}
private static void writeT16(Wire.Writer output, ExamplesJavaHttpDomainTypesWide value) {
writeT12(output, value);
}
private static ExamplesJavaHttpDomainTypesWide readT16(Wire.Reader input) {
return readT12(input);
}
private static void writeT17(Wire.Writer output, ExamplesJavaHttpDomainTypesNested value) {
writeT15(output, value);
}
private static ExamplesJavaHttpDomainTypesNested readT17(Wire.Reader input) {
return readT15(input);
}
private static void writeT18(Wire.Writer output, java.util.List<ExamplesJavaHttpDomainTypesWide> value) {
output.count(value.size());
for (ExamplesJavaHttpDomainTypesWide item : value) { writeT16(output, item); }
}
private static java.util.List<ExamplesJavaHttpDomainTypesWide> readT18(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<ExamplesJavaHttpDomainTypesWide> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT16(input));
return values;
}
private static void writeT19(Wire.Writer output, Result<String, String> value) {
output.bool(value.isError()); if (value.isError()) { writeString(output, value.error()); } else { writeString(output, value.value()); }
}
private static Result<String, String> readT19(Wire.Reader input) {
return input.bool() ? Result.err(readString(input)) : Result.ok(readString(input));
}
}
