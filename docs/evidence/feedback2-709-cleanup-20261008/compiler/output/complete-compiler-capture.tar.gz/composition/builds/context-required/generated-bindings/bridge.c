/* Generated from authoritative WIT. DO NOT EDIT. */
#include "bridge.h"
void exports_examples_java_http_context_required_api_status(probe_string_t *arg0) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(0, &output, &owned);
(*arg0).len = (size_t)lsf_get(&input, 4);
lsf_require((*arg0).len <= LSF_MAX_BYTES);
(*arg0).ptr = lsf_allocate((*arg0).len, 1);
for (size_t local_1 = 0; local_1 < (*arg0).len; local_1++) (*arg0).ptr[local_1] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input); lsf_java_free(owned);
}
void *lsf_java_host(int32_t operation, void *bytes, int32_t length) {
lsf_require(length >= 0 && (uint32_t)length <= LSF_MAX_BYTES);
lsf_wire input = {bytes, (size_t)length, 0, (size_t)length}; lsf_wire output = {0};
switch (operation) {
case 0: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_monotonic_now_nanos();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 1: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_wall_now_unix_millis();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 2: {
lsf_finish(&input);
probe_string_t result = {0};
latent_context_context_activation_id(&result);
lsf_require((result).len <= LSF_MAX_BYTES); lsf_put(&output, (result).len, 4);
for (size_t local_6 = 0; local_6 < (result).len; local_6++) lsf_put(&output, (result).ptr[local_6], 1);
lsf_release((result).ptr, (result).len); (result).ptr = NULL; (result).len = 0;
break; }
case 3: {
lsf_finish(&input);
probe_string_t result = {0};
latent_context_context_root_activation_id(&result);
lsf_require((result).len <= LSF_MAX_BYTES); lsf_put(&output, (result).len, 4);
for (size_t local_8 = 0; local_8 < (result).len; local_8++) lsf_put(&output, (result).ptr[local_8], 1);
lsf_release((result).ptr, (result).len); (result).ptr = NULL; (result).len = 0;
break; }
case 4: {
lsf_finish(&input);
probe_option_string_t result = {0};
latent_context_context_parent_activation_id(&result);
lsf_put(&output, (uint64_t)((result).is_some), 1);
if ((result).is_some) {
lsf_require(((result).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((result).val).len, 4);
for (size_t local_12 = 0; local_12 < ((result).val).len; local_12++) lsf_put(&output, ((result).val).ptr[local_12], 1);
}
if ((result).is_some) {
lsf_release(((result).val).ptr, ((result).val).len); ((result).val).ptr = NULL; ((result).val).len = 0;
}
break; }
case 5: {
lsf_finish(&input);
latent_context_context_invocation_principal_t result = {0};
latent_context_context_principal(&result);
lsf_require(((result).subject).len <= LSF_MAX_BYTES); lsf_put(&output, ((result).subject).len, 4);
for (size_t local_17 = 0; local_17 < ((result).subject).len; local_17++) lsf_put(&output, ((result).subject).ptr[local_17], 1);
lsf_require(((result).kind).len <= LSF_MAX_BYTES); lsf_put(&output, ((result).kind).len, 4);
for (size_t local_18 = 0; local_18 < ((result).kind).len; local_18++) lsf_put(&output, ((result).kind).ptr[local_18], 1);
lsf_put(&output, (uint64_t)(((result).tenant).is_some), 1);
if (((result).tenant).is_some) {
lsf_require((((result).tenant).val).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).tenant).val).len, 4);
for (size_t local_21 = 0; local_21 < (((result).tenant).val).len; local_21++) lsf_put(&output, (((result).tenant).val).ptr[local_21], 1);
}
lsf_put(&output, (uint64_t)(((result).service).is_some), 1);
if (((result).service).is_some) {
lsf_require((((result).service).val).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).service).val).len, 4);
for (size_t local_24 = 0; local_24 < (((result).service).val).len; local_24++) lsf_put(&output, (((result).service).val).ptr[local_24], 1);
}
lsf_require(((result).claims).len <= LSF_MAX_ITEMS); lsf_put(&output, ((result).claims).len, 4);
for (size_t local_25 = 0; local_25 < ((result).claims).len; local_25++) {
lsf_require(((((result).claims).ptr[local_25]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).claims).ptr[local_25]).f0).len, 4);
for (size_t local_27 = 0; local_27 < ((((result).claims).ptr[local_25]).f0).len; local_27++) lsf_put(&output, ((((result).claims).ptr[local_25]).f0).ptr[local_27], 1);
lsf_require(((((result).claims).ptr[local_25]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).claims).ptr[local_25]).f1).len, 4);
for (size_t local_28 = 0; local_28 < ((((result).claims).ptr[local_25]).f1).len; local_28++) lsf_put(&output, ((((result).claims).ptr[local_25]).f1).ptr[local_28], 1);
}
lsf_release(((result).subject).ptr, ((result).subject).len); ((result).subject).ptr = NULL; ((result).subject).len = 0;
lsf_release(((result).kind).ptr, ((result).kind).len); ((result).kind).ptr = NULL; ((result).kind).len = 0;
if (((result).tenant).is_some) {
lsf_release((((result).tenant).val).ptr, (((result).tenant).val).len); (((result).tenant).val).ptr = NULL; (((result).tenant).val).len = 0;
}
if (((result).service).is_some) {
lsf_release((((result).service).val).ptr, (((result).service).val).len); (((result).service).val).ptr = NULL; (((result).service).val).len = 0;
}
for (size_t local_38 = 0; local_38 < ((result).claims).len; local_38++) {
lsf_release(((((result).claims).ptr[local_38]).f0).ptr, ((((result).claims).ptr[local_38]).f0).len); ((((result).claims).ptr[local_38]).f0).ptr = NULL; ((((result).claims).ptr[local_38]).f0).len = 0;
lsf_release(((((result).claims).ptr[local_38]).f1).ptr, ((((result).claims).ptr[local_38]).f1).len); ((((result).claims).ptr[local_38]).f1).ptr = NULL; ((((result).claims).ptr[local_38]).f1).len = 0;
}
lsf_release(((result).claims).ptr, ((result).claims).len * sizeof(*((result).claims).ptr)); ((result).claims).ptr = NULL; ((result).claims).len = 0;
break; }
case 6: {
lsf_finish(&input);
latent_context_context_trace_context_t result = {0};
latent_context_context_trace(&result);
lsf_require(((result).trace_id).len <= LSF_MAX_BYTES); lsf_put(&output, ((result).trace_id).len, 4);
for (size_t local_43 = 0; local_43 < ((result).trace_id).len; local_43++) lsf_put(&output, ((result).trace_id).ptr[local_43], 1);
lsf_require(((result).span_id).len <= LSF_MAX_BYTES); lsf_put(&output, ((result).span_id).len, 4);
for (size_t local_44 = 0; local_44 < ((result).span_id).len; local_44++) lsf_put(&output, ((result).span_id).ptr[local_44], 1);
lsf_put(&output, (uint64_t)((result).trace_flags), 1);
lsf_require(((result).baggage).len <= LSF_MAX_ITEMS); lsf_put(&output, ((result).baggage).len, 4);
for (size_t local_46 = 0; local_46 < ((result).baggage).len; local_46++) {
lsf_require(((((result).baggage).ptr[local_46]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).baggage).ptr[local_46]).f0).len, 4);
for (size_t local_48 = 0; local_48 < ((((result).baggage).ptr[local_46]).f0).len; local_48++) lsf_put(&output, ((((result).baggage).ptr[local_46]).f0).ptr[local_48], 1);
lsf_require(((((result).baggage).ptr[local_46]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).baggage).ptr[local_46]).f1).len, 4);
for (size_t local_49 = 0; local_49 < ((((result).baggage).ptr[local_46]).f1).len; local_49++) lsf_put(&output, ((((result).baggage).ptr[local_46]).f1).ptr[local_49], 1);
}
lsf_release(((result).trace_id).ptr, ((result).trace_id).len); ((result).trace_id).ptr = NULL; ((result).trace_id).len = 0;
lsf_release(((result).span_id).ptr, ((result).span_id).len); ((result).span_id).ptr = NULL; ((result).span_id).len = 0;
for (size_t local_54 = 0; local_54 < ((result).baggage).len; local_54++) {
lsf_release(((((result).baggage).ptr[local_54]).f0).ptr, ((((result).baggage).ptr[local_54]).f0).len); ((((result).baggage).ptr[local_54]).f0).ptr = NULL; ((((result).baggage).ptr[local_54]).f0).len = 0;
lsf_release(((((result).baggage).ptr[local_54]).f1).ptr, ((((result).baggage).ptr[local_54]).f1).len); ((((result).baggage).ptr[local_54]).f1).ptr = NULL; ((((result).baggage).ptr[local_54]).f1).len = 0;
}
lsf_release(((result).baggage).ptr, ((result).baggage).len * sizeof(*((result).baggage).ptr)); ((result).baggage).ptr = NULL; ((result).baggage).len = 0;
break; }
case 7: {
lsf_finish(&input);
probe_option_u64_t result = {0};
latent_context_context_deadline_unix_millis(&result);
lsf_put(&output, (uint64_t)((result).is_some), 1);
if ((result).is_some) {
lsf_put(&output, (uint64_t)((result).val), 8);
}
if ((result).is_some) {
}
break; }
case 8: {
lsf_finish(&input);
latent_context_context_resource_budget_t result = {0};
latent_context_context_remaining_budget(&result);
lsf_put(&output, (uint64_t)((result).cpu_fuel), 8);
lsf_put(&output, (uint64_t)((result).memory_bytes), 8);
lsf_put(&output, (uint64_t)(((result).wall_time_limit_millis).is_some), 1);
if (((result).wall_time_limit_millis).is_some) {
lsf_put(&output, (uint64_t)(((result).wall_time_limit_millis).val), 8);
}
lsf_put(&output, (uint64_t)((result).child_calls), 4);
lsf_put(&output, (uint64_t)((result).outbound_requests), 4);
lsf_put(&output, (uint64_t)((result).state_read_bytes), 8);
lsf_put(&output, (uint64_t)((result).state_write_bytes), 8);
lsf_put(&output, (uint64_t)((result).blob_read_bytes), 8);
lsf_put(&output, (uint64_t)((result).blob_write_bytes), 8);
lsf_put(&output, (uint64_t)((result).log_bytes), 8);
lsf_put(&output, (uint64_t)((result).effect_count), 4);
if (((result).wall_time_limit_millis).is_some) {
}
break; }
case 9: {
lsf_finish(&input);
probe_list_tuple2_string_string_t result = {0};
latent_context_context_metadata(&result);
lsf_require((result).len <= LSF_MAX_ITEMS); lsf_put(&output, (result).len, 4);
for (size_t local_92 = 0; local_92 < (result).len; local_92++) {
lsf_require((((result).ptr[local_92]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).ptr[local_92]).f0).len, 4);
for (size_t local_94 = 0; local_94 < (((result).ptr[local_92]).f0).len; local_94++) lsf_put(&output, (((result).ptr[local_92]).f0).ptr[local_94], 1);
lsf_require((((result).ptr[local_92]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).ptr[local_92]).f1).len, 4);
for (size_t local_95 = 0; local_95 < (((result).ptr[local_92]).f1).len; local_95++) lsf_put(&output, (((result).ptr[local_92]).f1).ptr[local_95], 1);
}
for (size_t local_96 = 0; local_96 < (result).len; local_96++) {
lsf_release((((result).ptr[local_96]).f0).ptr, (((result).ptr[local_96]).f0).len); (((result).ptr[local_96]).f0).ptr = NULL; (((result).ptr[local_96]).f0).len = 0;
lsf_release((((result).ptr[local_96]).f1).ptr, (((result).ptr[local_96]).f1).len); (((result).ptr[local_96]).f1).ptr = NULL; (((result).ptr[local_96]).f1).len = 0;
}
lsf_release((result).ptr, (result).len * sizeof(*(result).ptr)); (result).ptr = NULL; (result).len = 0;
break; }
default: __builtin_trap(); }
return lsf_result(&output);
}
