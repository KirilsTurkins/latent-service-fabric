/* Generated from authoritative WIT. DO NOT EDIT. */
#include "bridge.h"
void exports_examples_java_http_domain_api_status(exports_examples_java_http_domain_api_list_wide_t *arg0) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(0, &output, &owned);
(*arg0).len = lsf_count(&input); lsf_require((*arg0).len <= LSF_MAX_ITEMS);
(*arg0).ptr = lsf_allocate((*arg0).len, sizeof(*(*arg0).ptr));
for (size_t local_1 = 0; local_1 < (*arg0).len; local_1++) {
((((*arg0).ptr[local_1])).a).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).a).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).a).ptr = lsf_allocate(((((*arg0).ptr[local_1])).a).len, 1);
for (size_t local_4 = 0; local_4 < ((((*arg0).ptr[local_1])).a).len; local_4++) ((((*arg0).ptr[local_1])).a).ptr[local_4] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).b).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).b).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).b).ptr = lsf_allocate(((((*arg0).ptr[local_1])).b).len, 1);
for (size_t local_5 = 0; local_5 < ((((*arg0).ptr[local_1])).b).len; local_5++) ((((*arg0).ptr[local_1])).b).ptr[local_5] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).c).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).c).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).c).ptr = lsf_allocate(((((*arg0).ptr[local_1])).c).len, 1);
for (size_t local_6 = 0; local_6 < ((((*arg0).ptr[local_1])).c).len; local_6++) ((((*arg0).ptr[local_1])).c).ptr[local_6] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).d).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).d).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).d).ptr = lsf_allocate(((((*arg0).ptr[local_1])).d).len, 1);
for (size_t local_7 = 0; local_7 < ((((*arg0).ptr[local_1])).d).len; local_7++) ((((*arg0).ptr[local_1])).d).ptr[local_7] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).e).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).e).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).e).ptr = lsf_allocate(((((*arg0).ptr[local_1])).e).len, 1);
for (size_t local_8 = 0; local_8 < ((((*arg0).ptr[local_1])).e).len; local_8++) ((((*arg0).ptr[local_1])).e).ptr[local_8] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).f).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).f).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).f).ptr = lsf_allocate(((((*arg0).ptr[local_1])).f).len, 1);
for (size_t local_9 = 0; local_9 < ((((*arg0).ptr[local_1])).f).len; local_9++) ((((*arg0).ptr[local_1])).f).ptr[local_9] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).g).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).g).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).g).ptr = lsf_allocate(((((*arg0).ptr[local_1])).g).len, 1);
for (size_t local_10 = 0; local_10 < ((((*arg0).ptr[local_1])).g).len; local_10++) ((((*arg0).ptr[local_1])).g).ptr[local_10] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).h).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).h).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).h).ptr = lsf_allocate(((((*arg0).ptr[local_1])).h).len, 1);
for (size_t local_11 = 0; local_11 < ((((*arg0).ptr[local_1])).h).len; local_11++) ((((*arg0).ptr[local_1])).h).ptr[local_11] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).i).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).i).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).i).ptr = lsf_allocate(((((*arg0).ptr[local_1])).i).len, 1);
for (size_t local_12 = 0; local_12 < ((((*arg0).ptr[local_1])).i).len; local_12++) ((((*arg0).ptr[local_1])).i).ptr[local_12] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).j).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).j).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).j).ptr = lsf_allocate(((((*arg0).ptr[local_1])).j).len, 1);
for (size_t local_13 = 0; local_13 < ((((*arg0).ptr[local_1])).j).len; local_13++) ((((*arg0).ptr[local_1])).j).ptr[local_13] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).k).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).k).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).k).ptr = lsf_allocate(((((*arg0).ptr[local_1])).k).len, 1);
for (size_t local_14 = 0; local_14 < ((((*arg0).ptr[local_1])).k).len; local_14++) ((((*arg0).ptr[local_1])).k).ptr[local_14] = (uint8_t)lsf_get(&input, 1);
((((*arg0).ptr[local_1])).l).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg0).ptr[local_1])).l).len <= LSF_MAX_BYTES);
((((*arg0).ptr[local_1])).l).ptr = lsf_allocate(((((*arg0).ptr[local_1])).l).len, 1);
for (size_t local_15 = 0; local_15 < ((((*arg0).ptr[local_1])).l).len; local_15++) ((((*arg0).ptr[local_1])).l).ptr[local_15] = (uint8_t)lsf_get(&input, 1);
uint64_t local_17 = lsf_get(&input, 8);  (((((*arg0).ptr[local_1])).sequence)) = (__typeof__((((((*arg0).ptr[local_1])).sequence))))local_17;
}
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_java_http_domain_api_echo(exports_examples_java_http_domain_api_wide_t *arg0, exports_examples_java_http_domain_api_wide_t *arg1) {
lsf_wire output = {0};
lsf_require((((*arg0)).a).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).a).len, 4);
for (size_t local_20 = 0; local_20 < (((*arg0)).a).len; local_20++) lsf_put(&output, (((*arg0)).a).ptr[local_20], 1);
lsf_require((((*arg0)).b).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).b).len, 4);
for (size_t local_21 = 0; local_21 < (((*arg0)).b).len; local_21++) lsf_put(&output, (((*arg0)).b).ptr[local_21], 1);
lsf_require((((*arg0)).c).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).c).len, 4);
for (size_t local_22 = 0; local_22 < (((*arg0)).c).len; local_22++) lsf_put(&output, (((*arg0)).c).ptr[local_22], 1);
lsf_require((((*arg0)).d).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).d).len, 4);
for (size_t local_23 = 0; local_23 < (((*arg0)).d).len; local_23++) lsf_put(&output, (((*arg0)).d).ptr[local_23], 1);
lsf_require((((*arg0)).e).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).e).len, 4);
for (size_t local_24 = 0; local_24 < (((*arg0)).e).len; local_24++) lsf_put(&output, (((*arg0)).e).ptr[local_24], 1);
lsf_require((((*arg0)).f).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).f).len, 4);
for (size_t local_25 = 0; local_25 < (((*arg0)).f).len; local_25++) lsf_put(&output, (((*arg0)).f).ptr[local_25], 1);
lsf_require((((*arg0)).g).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).g).len, 4);
for (size_t local_26 = 0; local_26 < (((*arg0)).g).len; local_26++) lsf_put(&output, (((*arg0)).g).ptr[local_26], 1);
lsf_require((((*arg0)).h).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).h).len, 4);
for (size_t local_27 = 0; local_27 < (((*arg0)).h).len; local_27++) lsf_put(&output, (((*arg0)).h).ptr[local_27], 1);
lsf_require((((*arg0)).i).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).i).len, 4);
for (size_t local_28 = 0; local_28 < (((*arg0)).i).len; local_28++) lsf_put(&output, (((*arg0)).i).ptr[local_28], 1);
lsf_require((((*arg0)).j).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).j).len, 4);
for (size_t local_29 = 0; local_29 < (((*arg0)).j).len; local_29++) lsf_put(&output, (((*arg0)).j).ptr[local_29], 1);
lsf_require((((*arg0)).k).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).k).len, 4);
for (size_t local_30 = 0; local_30 < (((*arg0)).k).len; local_30++) lsf_put(&output, (((*arg0)).k).ptr[local_30], 1);
lsf_require((((*arg0)).l).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0)).l).len, 4);
for (size_t local_31 = 0; local_31 < (((*arg0)).l).len; local_31++) lsf_put(&output, (((*arg0)).l).ptr[local_31], 1);
lsf_put(&output, (uint64_t)((((*arg0)).sequence)), 8);
lsf_release((((*arg0)).a).ptr, (((*arg0)).a).len); (((*arg0)).a).ptr = NULL; (((*arg0)).a).len = 0;
lsf_release((((*arg0)).b).ptr, (((*arg0)).b).len); (((*arg0)).b).ptr = NULL; (((*arg0)).b).len = 0;
lsf_release((((*arg0)).c).ptr, (((*arg0)).c).len); (((*arg0)).c).ptr = NULL; (((*arg0)).c).len = 0;
lsf_release((((*arg0)).d).ptr, (((*arg0)).d).len); (((*arg0)).d).ptr = NULL; (((*arg0)).d).len = 0;
lsf_release((((*arg0)).e).ptr, (((*arg0)).e).len); (((*arg0)).e).ptr = NULL; (((*arg0)).e).len = 0;
lsf_release((((*arg0)).f).ptr, (((*arg0)).f).len); (((*arg0)).f).ptr = NULL; (((*arg0)).f).len = 0;
lsf_release((((*arg0)).g).ptr, (((*arg0)).g).len); (((*arg0)).g).ptr = NULL; (((*arg0)).g).len = 0;
lsf_release((((*arg0)).h).ptr, (((*arg0)).h).len); (((*arg0)).h).ptr = NULL; (((*arg0)).h).len = 0;
lsf_release((((*arg0)).i).ptr, (((*arg0)).i).len); (((*arg0)).i).ptr = NULL; (((*arg0)).i).len = 0;
lsf_release((((*arg0)).j).ptr, (((*arg0)).j).len); (((*arg0)).j).ptr = NULL; (((*arg0)).j).len = 0;
lsf_release((((*arg0)).k).ptr, (((*arg0)).k).len); (((*arg0)).k).ptr = NULL; (((*arg0)).k).len = 0;
lsf_release((((*arg0)).l).ptr, (((*arg0)).l).len); (((*arg0)).l).ptr = NULL; (((*arg0)).l).len = 0;
void *owned; lsf_wire input = lsf_invoke(1, &output, &owned);
(((*arg1)).a).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).a).len <= LSF_MAX_BYTES);
(((*arg1)).a).ptr = lsf_allocate((((*arg1)).a).len, 1);
for (size_t local_52 = 0; local_52 < (((*arg1)).a).len; local_52++) (((*arg1)).a).ptr[local_52] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).b).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).b).len <= LSF_MAX_BYTES);
(((*arg1)).b).ptr = lsf_allocate((((*arg1)).b).len, 1);
for (size_t local_53 = 0; local_53 < (((*arg1)).b).len; local_53++) (((*arg1)).b).ptr[local_53] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).c).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).c).len <= LSF_MAX_BYTES);
(((*arg1)).c).ptr = lsf_allocate((((*arg1)).c).len, 1);
for (size_t local_54 = 0; local_54 < (((*arg1)).c).len; local_54++) (((*arg1)).c).ptr[local_54] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).d).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).d).len <= LSF_MAX_BYTES);
(((*arg1)).d).ptr = lsf_allocate((((*arg1)).d).len, 1);
for (size_t local_55 = 0; local_55 < (((*arg1)).d).len; local_55++) (((*arg1)).d).ptr[local_55] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).e).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).e).len <= LSF_MAX_BYTES);
(((*arg1)).e).ptr = lsf_allocate((((*arg1)).e).len, 1);
for (size_t local_56 = 0; local_56 < (((*arg1)).e).len; local_56++) (((*arg1)).e).ptr[local_56] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).f).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).f).len <= LSF_MAX_BYTES);
(((*arg1)).f).ptr = lsf_allocate((((*arg1)).f).len, 1);
for (size_t local_57 = 0; local_57 < (((*arg1)).f).len; local_57++) (((*arg1)).f).ptr[local_57] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).g).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).g).len <= LSF_MAX_BYTES);
(((*arg1)).g).ptr = lsf_allocate((((*arg1)).g).len, 1);
for (size_t local_58 = 0; local_58 < (((*arg1)).g).len; local_58++) (((*arg1)).g).ptr[local_58] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).h).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).h).len <= LSF_MAX_BYTES);
(((*arg1)).h).ptr = lsf_allocate((((*arg1)).h).len, 1);
for (size_t local_59 = 0; local_59 < (((*arg1)).h).len; local_59++) (((*arg1)).h).ptr[local_59] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).i).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).i).len <= LSF_MAX_BYTES);
(((*arg1)).i).ptr = lsf_allocate((((*arg1)).i).len, 1);
for (size_t local_60 = 0; local_60 < (((*arg1)).i).len; local_60++) (((*arg1)).i).ptr[local_60] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).j).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).j).len <= LSF_MAX_BYTES);
(((*arg1)).j).ptr = lsf_allocate((((*arg1)).j).len, 1);
for (size_t local_61 = 0; local_61 < (((*arg1)).j).len; local_61++) (((*arg1)).j).ptr[local_61] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).k).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).k).len <= LSF_MAX_BYTES);
(((*arg1)).k).ptr = lsf_allocate((((*arg1)).k).len, 1);
for (size_t local_62 = 0; local_62 < (((*arg1)).k).len; local_62++) (((*arg1)).k).ptr[local_62] = (uint8_t)lsf_get(&input, 1);
(((*arg1)).l).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1)).l).len <= LSF_MAX_BYTES);
(((*arg1)).l).ptr = lsf_allocate((((*arg1)).l).len, 1);
for (size_t local_63 = 0; local_63 < (((*arg1)).l).len; local_63++) (((*arg1)).l).ptr[local_63] = (uint8_t)lsf_get(&input, 1);
uint64_t local_65 = lsf_get(&input, 8);  ((((*arg1)).sequence)) = (__typeof__(((((*arg1)).sequence))))local_65;
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_java_http_domain_api_echo_nested(exports_examples_java_http_domain_api_nested_t *arg0, exports_examples_java_http_domain_api_nested_t *arg1) {
lsf_wire output = {0};
lsf_require(((((*arg0)).value).a).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).a).len, 4);
for (size_t local_69 = 0; local_69 < ((((*arg0)).value).a).len; local_69++) lsf_put(&output, ((((*arg0)).value).a).ptr[local_69], 1);
lsf_require(((((*arg0)).value).b).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).b).len, 4);
for (size_t local_70 = 0; local_70 < ((((*arg0)).value).b).len; local_70++) lsf_put(&output, ((((*arg0)).value).b).ptr[local_70], 1);
lsf_require(((((*arg0)).value).c).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).c).len, 4);
for (size_t local_71 = 0; local_71 < ((((*arg0)).value).c).len; local_71++) lsf_put(&output, ((((*arg0)).value).c).ptr[local_71], 1);
lsf_require(((((*arg0)).value).d).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).d).len, 4);
for (size_t local_72 = 0; local_72 < ((((*arg0)).value).d).len; local_72++) lsf_put(&output, ((((*arg0)).value).d).ptr[local_72], 1);
lsf_require(((((*arg0)).value).e).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).e).len, 4);
for (size_t local_73 = 0; local_73 < ((((*arg0)).value).e).len; local_73++) lsf_put(&output, ((((*arg0)).value).e).ptr[local_73], 1);
lsf_require(((((*arg0)).value).f).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).f).len, 4);
for (size_t local_74 = 0; local_74 < ((((*arg0)).value).f).len; local_74++) lsf_put(&output, ((((*arg0)).value).f).ptr[local_74], 1);
lsf_require(((((*arg0)).value).g).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).g).len, 4);
for (size_t local_75 = 0; local_75 < ((((*arg0)).value).g).len; local_75++) lsf_put(&output, ((((*arg0)).value).g).ptr[local_75], 1);
lsf_require(((((*arg0)).value).h).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).h).len, 4);
for (size_t local_76 = 0; local_76 < ((((*arg0)).value).h).len; local_76++) lsf_put(&output, ((((*arg0)).value).h).ptr[local_76], 1);
lsf_require(((((*arg0)).value).i).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).i).len, 4);
for (size_t local_77 = 0; local_77 < ((((*arg0)).value).i).len; local_77++) lsf_put(&output, ((((*arg0)).value).i).ptr[local_77], 1);
lsf_require(((((*arg0)).value).j).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).j).len, 4);
for (size_t local_78 = 0; local_78 < ((((*arg0)).value).j).len; local_78++) lsf_put(&output, ((((*arg0)).value).j).ptr[local_78], 1);
lsf_require(((((*arg0)).value).k).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).k).len, 4);
for (size_t local_79 = 0; local_79 < ((((*arg0)).value).k).len; local_79++) lsf_put(&output, ((((*arg0)).value).k).ptr[local_79], 1);
lsf_require(((((*arg0)).value).l).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).value).l).len, 4);
for (size_t local_80 = 0; local_80 < ((((*arg0)).value).l).len; local_80++) lsf_put(&output, ((((*arg0)).value).l).ptr[local_80], 1);
lsf_put(&output, (uint64_t)(((((*arg0)).value).sequence)), 8);
lsf_put(&output, (uint64_t)((((*arg0)).optional).is_some), 1);
if ((((*arg0)).optional).is_some) {
lsf_require((((((*arg0)).optional).val).a).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).a).len, 4);
for (size_t local_86 = 0; local_86 < (((((*arg0)).optional).val).a).len; local_86++) lsf_put(&output, (((((*arg0)).optional).val).a).ptr[local_86], 1);
lsf_require((((((*arg0)).optional).val).b).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).b).len, 4);
for (size_t local_87 = 0; local_87 < (((((*arg0)).optional).val).b).len; local_87++) lsf_put(&output, (((((*arg0)).optional).val).b).ptr[local_87], 1);
lsf_require((((((*arg0)).optional).val).c).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).c).len, 4);
for (size_t local_88 = 0; local_88 < (((((*arg0)).optional).val).c).len; local_88++) lsf_put(&output, (((((*arg0)).optional).val).c).ptr[local_88], 1);
lsf_require((((((*arg0)).optional).val).d).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).d).len, 4);
for (size_t local_89 = 0; local_89 < (((((*arg0)).optional).val).d).len; local_89++) lsf_put(&output, (((((*arg0)).optional).val).d).ptr[local_89], 1);
lsf_require((((((*arg0)).optional).val).e).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).e).len, 4);
for (size_t local_90 = 0; local_90 < (((((*arg0)).optional).val).e).len; local_90++) lsf_put(&output, (((((*arg0)).optional).val).e).ptr[local_90], 1);
lsf_require((((((*arg0)).optional).val).f).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).f).len, 4);
for (size_t local_91 = 0; local_91 < (((((*arg0)).optional).val).f).len; local_91++) lsf_put(&output, (((((*arg0)).optional).val).f).ptr[local_91], 1);
lsf_require((((((*arg0)).optional).val).g).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).g).len, 4);
for (size_t local_92 = 0; local_92 < (((((*arg0)).optional).val).g).len; local_92++) lsf_put(&output, (((((*arg0)).optional).val).g).ptr[local_92], 1);
lsf_require((((((*arg0)).optional).val).h).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).h).len, 4);
for (size_t local_93 = 0; local_93 < (((((*arg0)).optional).val).h).len; local_93++) lsf_put(&output, (((((*arg0)).optional).val).h).ptr[local_93], 1);
lsf_require((((((*arg0)).optional).val).i).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).i).len, 4);
for (size_t local_94 = 0; local_94 < (((((*arg0)).optional).val).i).len; local_94++) lsf_put(&output, (((((*arg0)).optional).val).i).ptr[local_94], 1);
lsf_require((((((*arg0)).optional).val).j).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).j).len, 4);
for (size_t local_95 = 0; local_95 < (((((*arg0)).optional).val).j).len; local_95++) lsf_put(&output, (((((*arg0)).optional).val).j).ptr[local_95], 1);
lsf_require((((((*arg0)).optional).val).k).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).k).len, 4);
for (size_t local_96 = 0; local_96 < (((((*arg0)).optional).val).k).len; local_96++) lsf_put(&output, (((((*arg0)).optional).val).k).ptr[local_96], 1);
lsf_require((((((*arg0)).optional).val).l).len <= LSF_MAX_BYTES); lsf_put(&output, (((((*arg0)).optional).val).l).len, 4);
for (size_t local_97 = 0; local_97 < (((((*arg0)).optional).val).l).len; local_97++) lsf_put(&output, (((((*arg0)).optional).val).l).ptr[local_97], 1);
lsf_put(&output, (uint64_t)((((((*arg0)).optional).val).sequence)), 8);
}
lsf_require((((*arg0)).labels).len <= LSF_MAX_ITEMS); lsf_put(&output, (((*arg0)).labels).len, 4);
for (size_t local_100 = 0; local_100 < (((*arg0)).labels).len; local_100++) {
lsf_require(((((*arg0)).labels).ptr[local_100]).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0)).labels).ptr[local_100]).len, 4);
for (size_t local_101 = 0; local_101 < ((((*arg0)).labels).ptr[local_100]).len; local_101++) lsf_put(&output, ((((*arg0)).labels).ptr[local_100]).ptr[local_101], 1);
}
lsf_release(((((*arg0)).value).a).ptr, ((((*arg0)).value).a).len); ((((*arg0)).value).a).ptr = NULL; ((((*arg0)).value).a).len = 0;
lsf_release(((((*arg0)).value).b).ptr, ((((*arg0)).value).b).len); ((((*arg0)).value).b).ptr = NULL; ((((*arg0)).value).b).len = 0;
lsf_release(((((*arg0)).value).c).ptr, ((((*arg0)).value).c).len); ((((*arg0)).value).c).ptr = NULL; ((((*arg0)).value).c).len = 0;
lsf_release(((((*arg0)).value).d).ptr, ((((*arg0)).value).d).len); ((((*arg0)).value).d).ptr = NULL; ((((*arg0)).value).d).len = 0;
lsf_release(((((*arg0)).value).e).ptr, ((((*arg0)).value).e).len); ((((*arg0)).value).e).ptr = NULL; ((((*arg0)).value).e).len = 0;
lsf_release(((((*arg0)).value).f).ptr, ((((*arg0)).value).f).len); ((((*arg0)).value).f).ptr = NULL; ((((*arg0)).value).f).len = 0;
lsf_release(((((*arg0)).value).g).ptr, ((((*arg0)).value).g).len); ((((*arg0)).value).g).ptr = NULL; ((((*arg0)).value).g).len = 0;
lsf_release(((((*arg0)).value).h).ptr, ((((*arg0)).value).h).len); ((((*arg0)).value).h).ptr = NULL; ((((*arg0)).value).h).len = 0;
lsf_release(((((*arg0)).value).i).ptr, ((((*arg0)).value).i).len); ((((*arg0)).value).i).ptr = NULL; ((((*arg0)).value).i).len = 0;
lsf_release(((((*arg0)).value).j).ptr, ((((*arg0)).value).j).len); ((((*arg0)).value).j).ptr = NULL; ((((*arg0)).value).j).len = 0;
lsf_release(((((*arg0)).value).k).ptr, ((((*arg0)).value).k).len); ((((*arg0)).value).k).ptr = NULL; ((((*arg0)).value).k).len = 0;
lsf_release(((((*arg0)).value).l).ptr, ((((*arg0)).value).l).len); ((((*arg0)).value).l).ptr = NULL; ((((*arg0)).value).l).len = 0;
if ((((*arg0)).optional).is_some) {
lsf_release((((((*arg0)).optional).val).a).ptr, (((((*arg0)).optional).val).a).len); (((((*arg0)).optional).val).a).ptr = NULL; (((((*arg0)).optional).val).a).len = 0;
lsf_release((((((*arg0)).optional).val).b).ptr, (((((*arg0)).optional).val).b).len); (((((*arg0)).optional).val).b).ptr = NULL; (((((*arg0)).optional).val).b).len = 0;
lsf_release((((((*arg0)).optional).val).c).ptr, (((((*arg0)).optional).val).c).len); (((((*arg0)).optional).val).c).ptr = NULL; (((((*arg0)).optional).val).c).len = 0;
lsf_release((((((*arg0)).optional).val).d).ptr, (((((*arg0)).optional).val).d).len); (((((*arg0)).optional).val).d).ptr = NULL; (((((*arg0)).optional).val).d).len = 0;
lsf_release((((((*arg0)).optional).val).e).ptr, (((((*arg0)).optional).val).e).len); (((((*arg0)).optional).val).e).ptr = NULL; (((((*arg0)).optional).val).e).len = 0;
lsf_release((((((*arg0)).optional).val).f).ptr, (((((*arg0)).optional).val).f).len); (((((*arg0)).optional).val).f).ptr = NULL; (((((*arg0)).optional).val).f).len = 0;
lsf_release((((((*arg0)).optional).val).g).ptr, (((((*arg0)).optional).val).g).len); (((((*arg0)).optional).val).g).ptr = NULL; (((((*arg0)).optional).val).g).len = 0;
lsf_release((((((*arg0)).optional).val).h).ptr, (((((*arg0)).optional).val).h).len); (((((*arg0)).optional).val).h).ptr = NULL; (((((*arg0)).optional).val).h).len = 0;
lsf_release((((((*arg0)).optional).val).i).ptr, (((((*arg0)).optional).val).i).len); (((((*arg0)).optional).val).i).ptr = NULL; (((((*arg0)).optional).val).i).len = 0;
lsf_release((((((*arg0)).optional).val).j).ptr, (((((*arg0)).optional).val).j).len); (((((*arg0)).optional).val).j).ptr = NULL; (((((*arg0)).optional).val).j).len = 0;
lsf_release((((((*arg0)).optional).val).k).ptr, (((((*arg0)).optional).val).k).len); (((((*arg0)).optional).val).k).ptr = NULL; (((((*arg0)).optional).val).k).len = 0;
lsf_release((((((*arg0)).optional).val).l).ptr, (((((*arg0)).optional).val).l).len); (((((*arg0)).optional).val).l).ptr = NULL; (((((*arg0)).optional).val).l).len = 0;
}
for (size_t local_136 = 0; local_136 < (((*arg0)).labels).len; local_136++) {
lsf_release(((((*arg0)).labels).ptr[local_136]).ptr, ((((*arg0)).labels).ptr[local_136]).len); ((((*arg0)).labels).ptr[local_136]).ptr = NULL; ((((*arg0)).labels).ptr[local_136]).len = 0;
}
lsf_release((((*arg0)).labels).ptr, (((*arg0)).labels).len * sizeof(*(((*arg0)).labels).ptr)); (((*arg0)).labels).ptr = NULL; (((*arg0)).labels).len = 0;
void *owned; lsf_wire input = lsf_invoke(2, &output, &owned);
((((*arg1)).value).a).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).a).len <= LSF_MAX_BYTES);
((((*arg1)).value).a).ptr = lsf_allocate(((((*arg1)).value).a).len, 1);
for (size_t local_141 = 0; local_141 < ((((*arg1)).value).a).len; local_141++) ((((*arg1)).value).a).ptr[local_141] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).b).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).b).len <= LSF_MAX_BYTES);
((((*arg1)).value).b).ptr = lsf_allocate(((((*arg1)).value).b).len, 1);
for (size_t local_142 = 0; local_142 < ((((*arg1)).value).b).len; local_142++) ((((*arg1)).value).b).ptr[local_142] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).c).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).c).len <= LSF_MAX_BYTES);
((((*arg1)).value).c).ptr = lsf_allocate(((((*arg1)).value).c).len, 1);
for (size_t local_143 = 0; local_143 < ((((*arg1)).value).c).len; local_143++) ((((*arg1)).value).c).ptr[local_143] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).d).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).d).len <= LSF_MAX_BYTES);
((((*arg1)).value).d).ptr = lsf_allocate(((((*arg1)).value).d).len, 1);
for (size_t local_144 = 0; local_144 < ((((*arg1)).value).d).len; local_144++) ((((*arg1)).value).d).ptr[local_144] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).e).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).e).len <= LSF_MAX_BYTES);
((((*arg1)).value).e).ptr = lsf_allocate(((((*arg1)).value).e).len, 1);
for (size_t local_145 = 0; local_145 < ((((*arg1)).value).e).len; local_145++) ((((*arg1)).value).e).ptr[local_145] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).f).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).f).len <= LSF_MAX_BYTES);
((((*arg1)).value).f).ptr = lsf_allocate(((((*arg1)).value).f).len, 1);
for (size_t local_146 = 0; local_146 < ((((*arg1)).value).f).len; local_146++) ((((*arg1)).value).f).ptr[local_146] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).g).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).g).len <= LSF_MAX_BYTES);
((((*arg1)).value).g).ptr = lsf_allocate(((((*arg1)).value).g).len, 1);
for (size_t local_147 = 0; local_147 < ((((*arg1)).value).g).len; local_147++) ((((*arg1)).value).g).ptr[local_147] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).h).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).h).len <= LSF_MAX_BYTES);
((((*arg1)).value).h).ptr = lsf_allocate(((((*arg1)).value).h).len, 1);
for (size_t local_148 = 0; local_148 < ((((*arg1)).value).h).len; local_148++) ((((*arg1)).value).h).ptr[local_148] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).i).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).i).len <= LSF_MAX_BYTES);
((((*arg1)).value).i).ptr = lsf_allocate(((((*arg1)).value).i).len, 1);
for (size_t local_149 = 0; local_149 < ((((*arg1)).value).i).len; local_149++) ((((*arg1)).value).i).ptr[local_149] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).j).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).j).len <= LSF_MAX_BYTES);
((((*arg1)).value).j).ptr = lsf_allocate(((((*arg1)).value).j).len, 1);
for (size_t local_150 = 0; local_150 < ((((*arg1)).value).j).len; local_150++) ((((*arg1)).value).j).ptr[local_150] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).k).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).k).len <= LSF_MAX_BYTES);
((((*arg1)).value).k).ptr = lsf_allocate(((((*arg1)).value).k).len, 1);
for (size_t local_151 = 0; local_151 < ((((*arg1)).value).k).len; local_151++) ((((*arg1)).value).k).ptr[local_151] = (uint8_t)lsf_get(&input, 1);
((((*arg1)).value).l).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).value).l).len <= LSF_MAX_BYTES);
((((*arg1)).value).l).ptr = lsf_allocate(((((*arg1)).value).l).len, 1);
for (size_t local_152 = 0; local_152 < ((((*arg1)).value).l).len; local_152++) ((((*arg1)).value).l).ptr[local_152] = (uint8_t)lsf_get(&input, 1);
uint64_t local_154 = lsf_get(&input, 8);  (((((*arg1)).value).sequence)) = (__typeof__((((((*arg1)).value).sequence))))local_154;
uint64_t local_156 = lsf_get(&input, 1); lsf_require(local_156 <= 1); ((((*arg1)).optional).is_some) = (__typeof__(((((*arg1)).optional).is_some)))local_156;
if ((((*arg1)).optional).is_some) {
(((((*arg1)).optional).val).a).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).a).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).a).ptr = lsf_allocate((((((*arg1)).optional).val).a).len, 1);
for (size_t local_158 = 0; local_158 < (((((*arg1)).optional).val).a).len; local_158++) (((((*arg1)).optional).val).a).ptr[local_158] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).b).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).b).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).b).ptr = lsf_allocate((((((*arg1)).optional).val).b).len, 1);
for (size_t local_159 = 0; local_159 < (((((*arg1)).optional).val).b).len; local_159++) (((((*arg1)).optional).val).b).ptr[local_159] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).c).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).c).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).c).ptr = lsf_allocate((((((*arg1)).optional).val).c).len, 1);
for (size_t local_160 = 0; local_160 < (((((*arg1)).optional).val).c).len; local_160++) (((((*arg1)).optional).val).c).ptr[local_160] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).d).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).d).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).d).ptr = lsf_allocate((((((*arg1)).optional).val).d).len, 1);
for (size_t local_161 = 0; local_161 < (((((*arg1)).optional).val).d).len; local_161++) (((((*arg1)).optional).val).d).ptr[local_161] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).e).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).e).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).e).ptr = lsf_allocate((((((*arg1)).optional).val).e).len, 1);
for (size_t local_162 = 0; local_162 < (((((*arg1)).optional).val).e).len; local_162++) (((((*arg1)).optional).val).e).ptr[local_162] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).f).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).f).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).f).ptr = lsf_allocate((((((*arg1)).optional).val).f).len, 1);
for (size_t local_163 = 0; local_163 < (((((*arg1)).optional).val).f).len; local_163++) (((((*arg1)).optional).val).f).ptr[local_163] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).g).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).g).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).g).ptr = lsf_allocate((((((*arg1)).optional).val).g).len, 1);
for (size_t local_164 = 0; local_164 < (((((*arg1)).optional).val).g).len; local_164++) (((((*arg1)).optional).val).g).ptr[local_164] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).h).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).h).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).h).ptr = lsf_allocate((((((*arg1)).optional).val).h).len, 1);
for (size_t local_165 = 0; local_165 < (((((*arg1)).optional).val).h).len; local_165++) (((((*arg1)).optional).val).h).ptr[local_165] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).i).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).i).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).i).ptr = lsf_allocate((((((*arg1)).optional).val).i).len, 1);
for (size_t local_166 = 0; local_166 < (((((*arg1)).optional).val).i).len; local_166++) (((((*arg1)).optional).val).i).ptr[local_166] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).j).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).j).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).j).ptr = lsf_allocate((((((*arg1)).optional).val).j).len, 1);
for (size_t local_167 = 0; local_167 < (((((*arg1)).optional).val).j).len; local_167++) (((((*arg1)).optional).val).j).ptr[local_167] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).k).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).k).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).k).ptr = lsf_allocate((((((*arg1)).optional).val).k).len, 1);
for (size_t local_168 = 0; local_168 < (((((*arg1)).optional).val).k).len; local_168++) (((((*arg1)).optional).val).k).ptr[local_168] = (uint8_t)lsf_get(&input, 1);
(((((*arg1)).optional).val).l).len = (size_t)lsf_get(&input, 4);
lsf_require((((((*arg1)).optional).val).l).len <= LSF_MAX_BYTES);
(((((*arg1)).optional).val).l).ptr = lsf_allocate((((((*arg1)).optional).val).l).len, 1);
for (size_t local_169 = 0; local_169 < (((((*arg1)).optional).val).l).len; local_169++) (((((*arg1)).optional).val).l).ptr[local_169] = (uint8_t)lsf_get(&input, 1);
uint64_t local_171 = lsf_get(&input, 8);  ((((((*arg1)).optional).val).sequence)) = (__typeof__(((((((*arg1)).optional).val).sequence))))local_171;
}
(((*arg1)).labels).len = lsf_count(&input); lsf_require((((*arg1)).labels).len <= LSF_MAX_ITEMS);
(((*arg1)).labels).ptr = lsf_allocate((((*arg1)).labels).len, sizeof(*(((*arg1)).labels).ptr));
for (size_t local_172 = 0; local_172 < (((*arg1)).labels).len; local_172++) {
((((*arg1)).labels).ptr[local_172]).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1)).labels).ptr[local_172]).len <= LSF_MAX_BYTES);
((((*arg1)).labels).ptr[local_172]).ptr = lsf_allocate(((((*arg1)).labels).ptr[local_172]).len, 1);
for (size_t local_173 = 0; local_173 < ((((*arg1)).labels).ptr[local_172]).len; local_173++) ((((*arg1)).labels).ptr[local_172]).ptr[local_173] = (uint8_t)lsf_get(&input, 1);
}
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_java_http_domain_api_text(probe_string_t *arg0, probe_string_t *arg1) {
lsf_wire output = {0};
lsf_require((*arg0).len <= LSF_MAX_BYTES); lsf_put(&output, (*arg0).len, 4);
for (size_t local_174 = 0; local_174 < (*arg0).len; local_174++) lsf_put(&output, (*arg0).ptr[local_174], 1);
lsf_release((*arg0).ptr, (*arg0).len); (*arg0).ptr = NULL; (*arg0).len = 0;
void *owned; lsf_wire input = lsf_invoke(3, &output, &owned);
(*arg1).len = (size_t)lsf_get(&input, 4);
lsf_require((*arg1).len <= LSF_MAX_BYTES);
(*arg1).ptr = lsf_allocate((*arg1).len, 1);
for (size_t local_176 = 0; local_176 < (*arg1).len; local_176++) (*arg1).ptr[local_176] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_java_http_domain_api_items(probe_list_string_t *arg0, probe_list_string_t *arg1) {
lsf_wire output = {0};
lsf_require((*arg0).len <= LSF_MAX_ITEMS); lsf_put(&output, (*arg0).len, 4);
for (size_t local_177 = 0; local_177 < (*arg0).len; local_177++) {
lsf_require(((*arg0).ptr[local_177]).len <= LSF_MAX_BYTES); lsf_put(&output, ((*arg0).ptr[local_177]).len, 4);
for (size_t local_178 = 0; local_178 < ((*arg0).ptr[local_177]).len; local_178++) lsf_put(&output, ((*arg0).ptr[local_177]).ptr[local_178], 1);
}
for (size_t local_179 = 0; local_179 < (*arg0).len; local_179++) {
lsf_release(((*arg0).ptr[local_179]).ptr, ((*arg0).ptr[local_179]).len); ((*arg0).ptr[local_179]).ptr = NULL; ((*arg0).ptr[local_179]).len = 0;
}
lsf_release((*arg0).ptr, (*arg0).len * sizeof(*(*arg0).ptr)); (*arg0).ptr = NULL; (*arg0).len = 0;
void *owned; lsf_wire input = lsf_invoke(4, &output, &owned);
(*arg1).len = lsf_count(&input); lsf_require((*arg1).len <= LSF_MAX_ITEMS);
(*arg1).ptr = lsf_allocate((*arg1).len, sizeof(*(*arg1).ptr));
for (size_t local_181 = 0; local_181 < (*arg1).len; local_181++) {
((*arg1).ptr[local_181]).len = (size_t)lsf_get(&input, 4);
lsf_require(((*arg1).ptr[local_181]).len <= LSF_MAX_BYTES);
((*arg1).ptr[local_181]).ptr = lsf_allocate(((*arg1).ptr[local_181]).len, 1);
for (size_t local_182 = 0; local_182 < ((*arg1).ptr[local_181]).len; local_182++) ((*arg1).ptr[local_181]).ptr[local_182] = (uint8_t)lsf_get(&input, 1);
}
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_java_http_domain_api_fail(exports_examples_java_http_domain_api_result_string_string_t *arg0) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(5, &output, &owned);
uint64_t local_184 = lsf_get(&input, 1); lsf_require(local_184 <= 1); ((*arg0).is_err) = (__typeof__(((*arg0).is_err)))local_184;
if ((*arg0).is_err) {
((*arg0).val.err).len = (size_t)lsf_get(&input, 4);
lsf_require(((*arg0).val.err).len <= LSF_MAX_BYTES);
((*arg0).val.err).ptr = lsf_allocate(((*arg0).val.err).len, 1);
for (size_t local_185 = 0; local_185 < ((*arg0).val.err).len; local_185++) ((*arg0).val.err).ptr[local_185] = (uint8_t)lsf_get(&input, 1);
} else {
((*arg0).val.ok).len = (size_t)lsf_get(&input, 4);
lsf_require(((*arg0).val.ok).len <= LSF_MAX_BYTES);
((*arg0).val.ok).ptr = lsf_allocate(((*arg0).val.ok).len, 1);
for (size_t local_186 = 0; local_186 < ((*arg0).val.ok).len; local_186++) ((*arg0).val.ok).ptr[local_186] = (uint8_t)lsf_get(&input, 1);
}
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_java_http_domain_api_throw_error(probe_string_t *arg0) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(6, &output, &owned);
(*arg0).len = (size_t)lsf_get(&input, 4);
lsf_require((*arg0).len <= LSF_MAX_BYTES);
(*arg0).ptr = lsf_allocate((*arg0).len, 1);
for (size_t local_187 = 0; local_187 < (*arg0).len; local_187++) (*arg0).ptr[local_187] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input); lsf_java_free(owned);
}
uint32_t exports_examples_java_http_domain_api_spin(void) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(7, &output, &owned);
uint32_t result = {0};
uint64_t local_188 = lsf_get(&input, 4);  (result) = (__typeof__((result)))local_188;
lsf_finish(&input); lsf_java_free(owned);
return result;
}
void exports_examples_java_http_domain_api_private_admin(probe_string_t *arg0) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(8, &output, &owned);
(*arg0).len = (size_t)lsf_get(&input, 4);
lsf_require((*arg0).len <= LSF_MAX_BYTES);
(*arg0).ptr = lsf_allocate((*arg0).len, 1);
for (size_t local_189 = 0; local_189 < (*arg0).len; local_189++) (*arg0).ptr[local_189] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_java_http_domain_api_publishing(probe_string_t *arg0) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(9, &output, &owned);
(*arg0).len = (size_t)lsf_get(&input, 4);
lsf_require((*arg0).len <= LSF_MAX_BYTES);
(*arg0).ptr = lsf_allocate((*arg0).len, 1);
for (size_t local_190 = 0; local_190 < (*arg0).len; local_190++) (*arg0).ptr[local_190] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input); lsf_java_free(owned);
}
void exports_examples_java_http_domain_api_provider_event(probe_string_t *arg0) {
lsf_wire output = {0};
void *owned; lsf_wire input = lsf_invoke(10, &output, &owned);
(*arg0).len = (size_t)lsf_get(&input, 4);
lsf_require((*arg0).len <= LSF_MAX_BYTES);
(*arg0).ptr = lsf_allocate((*arg0).len, 1);
for (size_t local_191 = 0; local_191 < (*arg0).len; local_191++) (*arg0).ptr[local_191] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input); lsf_java_free(owned);
}
void *lsf_java_host(int32_t operation, void *bytes, int32_t length) {
lsf_require(length >= 0 && (uint32_t)length <= LSF_MAX_BYTES);
lsf_wire input = {bytes, (size_t)length, 0, (size_t)length}; lsf_wire output = {0};
switch (operation) {
case 0: {
latent_http_client_request_t arg0 = {0};
uint64_t local_193 = lsf_get(&input, 4); lsf_require(local_193 < 7);
((arg0).method) = (__typeof__(((arg0).method)))local_193;
lsf_require(((arg0).method) < 7);
((arg0).url).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).url).len <= LSF_MAX_BYTES);
((arg0).url).ptr = lsf_allocate(((arg0).url).len, 1);
for (size_t local_194 = 0; local_194 < ((arg0).url).len; local_194++) ((arg0).url).ptr[local_194] = (uint8_t)lsf_get(&input, 1);
((arg0).headers).len = lsf_count(&input); lsf_require(((arg0).headers).len <= LSF_MAX_ITEMS);
((arg0).headers).ptr = lsf_allocate(((arg0).headers).len, sizeof(*((arg0).headers).ptr));
for (size_t local_195 = 0; local_195 < ((arg0).headers).len; local_195++) {
((((arg0).headers).ptr[local_195]).name).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).headers).ptr[local_195]).name).len <= LSF_MAX_BYTES);
((((arg0).headers).ptr[local_195]).name).ptr = lsf_allocate(((((arg0).headers).ptr[local_195]).name).len, 1);
for (size_t local_197 = 0; local_197 < ((((arg0).headers).ptr[local_195]).name).len; local_197++) ((((arg0).headers).ptr[local_195]).name).ptr[local_197] = (uint8_t)lsf_get(&input, 1);
((((arg0).headers).ptr[local_195]).value).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg0).headers).ptr[local_195]).value).len <= LSF_MAX_BYTES);
((((arg0).headers).ptr[local_195]).value).ptr = lsf_allocate(((((arg0).headers).ptr[local_195]).value).len, 1);
for (size_t local_198 = 0; local_198 < ((((arg0).headers).ptr[local_195]).value).len; local_198++) ((((arg0).headers).ptr[local_195]).value).ptr[local_198] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_200 = lsf_get(&input, 1); lsf_require(local_200 <= 1); (((arg0).body).is_some) = (__typeof__((((arg0).body).is_some)))local_200;
if (((arg0).body).is_some) {
(((arg0).body).val).len = (size_t)lsf_get(&input, 4); lsf_require((((arg0).body).val).len <= LSF_MAX_BYTES);
(((arg0).body).val).ptr = lsf_allocate((((arg0).body).val).len, sizeof(*(((arg0).body).val).ptr));
for (size_t local_201 = 0; local_201 < (((arg0).body).val).len; local_201++) {
uint64_t local_202 = lsf_get(&input, 1);  ((((arg0).body).val).ptr[local_201]) = (__typeof__(((((arg0).body).val).ptr[local_201])))local_202;
}
}
uint64_t local_204 = lsf_get(&input, 1); lsf_require(local_204 <= 1); (((arg0).body_media_type).is_some) = (__typeof__((((arg0).body_media_type).is_some)))local_204;
if (((arg0).body_media_type).is_some) {
(((arg0).body_media_type).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).body_media_type).val).len <= LSF_MAX_BYTES);
(((arg0).body_media_type).val).ptr = lsf_allocate((((arg0).body_media_type).val).len, 1);
for (size_t local_205 = 0; local_205 < (((arg0).body_media_type).val).len; local_205++) (((arg0).body_media_type).val).ptr[local_205] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_207 = lsf_get(&input, 1); lsf_require(local_207 <= 1); (((arg0).idempotency_key).is_some) = (__typeof__((((arg0).idempotency_key).is_some)))local_207;
if (((arg0).idempotency_key).is_some) {
(((arg0).idempotency_key).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).idempotency_key).val).len <= LSF_MAX_BYTES);
(((arg0).idempotency_key).val).ptr = lsf_allocate((((arg0).idempotency_key).val).len, 1);
for (size_t local_208 = 0; local_208 < (((arg0).idempotency_key).val).len; local_208++) (((arg0).idempotency_key).val).ptr[local_208] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_210 = lsf_get(&input, 1); lsf_require(local_210 <= 1); (((arg0).timeout_millis).is_some) = (__typeof__((((arg0).timeout_millis).is_some)))local_210;
if (((arg0).timeout_millis).is_some) {
uint64_t local_211 = lsf_get(&input, 8);  (((arg0).timeout_millis).val) = (__typeof__((((arg0).timeout_millis).val)))local_211;
}
lsf_finish(&input);
latent_http_client_result_response_http_error_t result = {0};
latent_http_client_send(&arg0, &result);
lsf_release(((arg0).url).ptr, ((arg0).url).len); ((arg0).url).ptr = NULL; ((arg0).url).len = 0;
for (size_t local_215 = 0; local_215 < ((arg0).headers).len; local_215++) {
lsf_release(((((arg0).headers).ptr[local_215]).name).ptr, ((((arg0).headers).ptr[local_215]).name).len); ((((arg0).headers).ptr[local_215]).name).ptr = NULL; ((((arg0).headers).ptr[local_215]).name).len = 0;
lsf_release(((((arg0).headers).ptr[local_215]).value).ptr, ((((arg0).headers).ptr[local_215]).value).len); ((((arg0).headers).ptr[local_215]).value).ptr = NULL; ((((arg0).headers).ptr[local_215]).value).len = 0;
}
lsf_release(((arg0).headers).ptr, ((arg0).headers).len * sizeof(*((arg0).headers).ptr)); ((arg0).headers).ptr = NULL; ((arg0).headers).len = 0;
if (((arg0).body).is_some) {
for (size_t local_221 = 0; local_221 < (((arg0).body).val).len; local_221++) {
}
lsf_release((((arg0).body).val).ptr, (((arg0).body).val).len * sizeof(*(((arg0).body).val).ptr)); (((arg0).body).val).ptr = NULL; (((arg0).body).val).len = 0;
}
if (((arg0).body_media_type).is_some) {
lsf_release((((arg0).body_media_type).val).ptr, (((arg0).body_media_type).val).len); (((arg0).body_media_type).val).ptr = NULL; (((arg0).body_media_type).val).len = 0;
}
if (((arg0).idempotency_key).is_some) {
lsf_release((((arg0).idempotency_key).val).ptr, (((arg0).idempotency_key).val).len); (((arg0).idempotency_key).val).ptr = NULL; (((arg0).idempotency_key).val).len = 0;
}
if (((arg0).timeout_millis).is_some) {
}
lsf_put(&output, (uint64_t)((result).is_err), 1);
if ((result).is_err) {
lsf_put(&output, (uint64_t)(((result).val.err).tag), 4);
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
default: __builtin_trap(); }
} else {
lsf_put(&output, (uint64_t)(((result).val.ok).status), 2);
lsf_require((((result).val.ok).headers).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.ok).headers).len, 4);
for (size_t local_251 = 0; local_251 < (((result).val.ok).headers).len; local_251++) {
lsf_require((((((result).val.ok).headers).ptr[local_251]).name).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).headers).ptr[local_251]).name).len, 4);
for (size_t local_253 = 0; local_253 < (((((result).val.ok).headers).ptr[local_251]).name).len; local_253++) lsf_put(&output, (((((result).val.ok).headers).ptr[local_251]).name).ptr[local_253], 1);
lsf_require((((((result).val.ok).headers).ptr[local_251]).value).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.ok).headers).ptr[local_251]).value).len, 4);
for (size_t local_254 = 0; local_254 < (((((result).val.ok).headers).ptr[local_251]).value).len; local_254++) lsf_put(&output, (((((result).val.ok).headers).ptr[local_251]).value).ptr[local_254], 1);
}
lsf_require((((result).val.ok).body).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.ok).body).len, 4);
for (size_t local_255 = 0; local_255 < (((result).val.ok).body).len; local_255++) {
lsf_put(&output, (uint64_t)((((result).val.ok).body).ptr[local_255]), 1);
}
lsf_put(&output, (uint64_t)((((result).val.ok).body_media_type).is_some), 1);
if ((((result).val.ok).body_media_type).is_some) {
lsf_require(((((result).val.ok).body_media_type).val).len <= LSF_MAX_BYTES); lsf_put(&output, ((((result).val.ok).body_media_type).val).len, 4);
for (size_t local_259 = 0; local_259 < ((((result).val.ok).body_media_type).val).len; local_259++) lsf_put(&output, ((((result).val.ok).body_media_type).val).ptr[local_259], 1);
}
}
if ((result).is_err) {
switch (((result).val.err).tag) {
case 0: {
break; }
case 1: {
break; }
case 2: {
break; }
case 3: {
break; }
case 4: {
break; }
case 5: {
break; }
case 6: {
break; }
case 7: {
break; }
case 8: {
break; }
case 9: {
break; }
case 10: {
break; }
case 11: {
break; }
case 12: {
break; }
default: __builtin_trap(); }
} else {
for (size_t local_278 = 0; local_278 < (((result).val.ok).headers).len; local_278++) {
lsf_release((((((result).val.ok).headers).ptr[local_278]).name).ptr, (((((result).val.ok).headers).ptr[local_278]).name).len); (((((result).val.ok).headers).ptr[local_278]).name).ptr = NULL; (((((result).val.ok).headers).ptr[local_278]).name).len = 0;
lsf_release((((((result).val.ok).headers).ptr[local_278]).value).ptr, (((((result).val.ok).headers).ptr[local_278]).value).len); (((((result).val.ok).headers).ptr[local_278]).value).ptr = NULL; (((((result).val.ok).headers).ptr[local_278]).value).len = 0;
}
lsf_release((((result).val.ok).headers).ptr, (((result).val.ok).headers).len * sizeof(*(((result).val.ok).headers).ptr)); (((result).val.ok).headers).ptr = NULL; (((result).val.ok).headers).len = 0;
for (size_t local_282 = 0; local_282 < (((result).val.ok).body).len; local_282++) {
}
lsf_release((((result).val.ok).body).ptr, (((result).val.ok).body).len * sizeof(*(((result).val.ok).body).ptr)); (((result).val.ok).body).ptr = NULL; (((result).val.ok).body).len = 0;
if ((((result).val.ok).body_media_type).is_some) {
lsf_release(((((result).val.ok).body_media_type).val).ptr, ((((result).val.ok).body_media_type).val).len); ((((result).val.ok).body_media_type).val).ptr = NULL; ((((result).val.ok).body_media_type).val).len = 0;
}
}
break; }
case 1: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_monotonic_now_nanos();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 2: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_wall_now_unix_millis();
lsf_put(&output, (uint64_t)(result), 8);
break; }
default: __builtin_trap(); }
return lsf_result(&output);
}
