/* Generated from authoritative WIT. DO NOT EDIT. */
#include "bridge.h"
void exports_latent_web_application_handle(exports_latent_web_application_request_t *arg0, exports_latent_web_application_response_t *arg1) {
lsf_wire output = {0};
lsf_put(&output, (uint64_t)(((*arg0).profile)), 4);
lsf_require(((*arg0).profile) < 1);
lsf_put(&output, (uint64_t)(((*arg0).method)), 4);
lsf_require(((*arg0).method) < 7);
lsf_put(&output, (uint64_t)(((*arg0).scheme)), 4);
lsf_require(((*arg0).scheme) < 2);
lsf_require(((*arg0).authority).len <= LSF_MAX_BYTES); lsf_put(&output, ((*arg0).authority).len, 4);
for (size_t local_8 = 0; local_8 < ((*arg0).authority).len; local_8++) lsf_put(&output, ((*arg0).authority).ptr[local_8], 1);
lsf_require(((*arg0).path).len <= LSF_MAX_BYTES); lsf_put(&output, ((*arg0).path).len, 4);
for (size_t local_9 = 0; local_9 < ((*arg0).path).len; local_9++) lsf_put(&output, ((*arg0).path).ptr[local_9], 1);
lsf_put(&output, (uint64_t)(((*arg0).query).is_some), 1);
if (((*arg0).query).is_some) {
lsf_require((((*arg0).query).val).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0).query).val).len, 4);
for (size_t local_12 = 0; local_12 < (((*arg0).query).val).len; local_12++) lsf_put(&output, (((*arg0).query).val).ptr[local_12], 1);
}
lsf_require(((*arg0).headers).len <= LSF_MAX_ITEMS); lsf_put(&output, ((*arg0).headers).len, 4);
for (size_t local_13 = 0; local_13 < ((*arg0).headers).len; local_13++) {
lsf_require(((((*arg0).headers).ptr[local_13]).name).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0).headers).ptr[local_13]).name).len, 4);
for (size_t local_15 = 0; local_15 < ((((*arg0).headers).ptr[local_13]).name).len; local_15++) lsf_put(&output, ((((*arg0).headers).ptr[local_13]).name).ptr[local_15], 1);
lsf_require(((((*arg0).headers).ptr[local_13]).value).len <= LSF_MAX_BYTES); lsf_put(&output, ((((*arg0).headers).ptr[local_13]).value).len, 4);
for (size_t local_16 = 0; local_16 < ((((*arg0).headers).ptr[local_13]).value).len; local_16++) {
lsf_put(&output, (uint64_t)(((((*arg0).headers).ptr[local_13]).value).ptr[local_16]), 1);
}
}
lsf_put(&output, (uint64_t)(((*arg0).media_type).is_some), 1);
if (((*arg0).media_type).is_some) {
lsf_require((((*arg0).media_type).val).len <= LSF_MAX_BYTES); lsf_put(&output, (((*arg0).media_type).val).len, 4);
for (size_t local_20 = 0; local_20 < (((*arg0).media_type).val).len; local_20++) lsf_put(&output, (((*arg0).media_type).val).ptr[local_20], 1);
}
lsf_require(((*arg0).body_base64).len <= LSF_MAX_BYTES); lsf_put(&output, ((*arg0).body_base64).len, 4);
for (size_t local_21 = 0; local_21 < ((*arg0).body_base64).len; local_21++) lsf_put(&output, ((*arg0).body_base64).ptr[local_21], 1);
lsf_release(((*arg0).authority).ptr, ((*arg0).authority).len); ((*arg0).authority).ptr = NULL; ((*arg0).authority).len = 0;
lsf_release(((*arg0).path).ptr, ((*arg0).path).len); ((*arg0).path).ptr = NULL; ((*arg0).path).len = 0;
if (((*arg0).query).is_some) {
lsf_release((((*arg0).query).val).ptr, (((*arg0).query).val).len); (((*arg0).query).val).ptr = NULL; (((*arg0).query).val).len = 0;
}
for (size_t local_31 = 0; local_31 < ((*arg0).headers).len; local_31++) {
lsf_release(((((*arg0).headers).ptr[local_31]).name).ptr, ((((*arg0).headers).ptr[local_31]).name).len); ((((*arg0).headers).ptr[local_31]).name).ptr = NULL; ((((*arg0).headers).ptr[local_31]).name).len = 0;
for (size_t local_34 = 0; local_34 < ((((*arg0).headers).ptr[local_31]).value).len; local_34++) {
}
lsf_release(((((*arg0).headers).ptr[local_31]).value).ptr, ((((*arg0).headers).ptr[local_31]).value).len * sizeof(*((((*arg0).headers).ptr[local_31]).value).ptr)); ((((*arg0).headers).ptr[local_31]).value).ptr = NULL; ((((*arg0).headers).ptr[local_31]).value).len = 0;
}
lsf_release(((*arg0).headers).ptr, ((*arg0).headers).len * sizeof(*((*arg0).headers).ptr)); ((*arg0).headers).ptr = NULL; ((*arg0).headers).len = 0;
if (((*arg0).media_type).is_some) {
lsf_release((((*arg0).media_type).val).ptr, (((*arg0).media_type).val).len); (((*arg0).media_type).val).ptr = NULL; (((*arg0).media_type).val).len = 0;
}
lsf_release(((*arg0).body_base64).ptr, ((*arg0).body_base64).len); ((*arg0).body_base64).ptr = NULL; ((*arg0).body_base64).len = 0;
void *owned; lsf_wire input = lsf_invoke(0, &output, &owned);
uint64_t local_41 = lsf_get(&input, 4); lsf_require(local_41 < 1);
((*arg1).profile) = (__typeof__(((*arg1).profile)))local_41;
lsf_require(((*arg1).profile) < 1);
uint64_t local_42 = lsf_get(&input, 2);  ((*arg1).status) = (__typeof__(((*arg1).status)))local_42;
((*arg1).headers).len = lsf_count(&input); lsf_require(((*arg1).headers).len <= LSF_MAX_ITEMS);
((*arg1).headers).ptr = lsf_allocate(((*arg1).headers).len, sizeof(*((*arg1).headers).ptr));
for (size_t local_43 = 0; local_43 < ((*arg1).headers).len; local_43++) {
((((*arg1).headers).ptr[local_43]).name).len = (size_t)lsf_get(&input, 4);
lsf_require(((((*arg1).headers).ptr[local_43]).name).len <= LSF_MAX_BYTES);
((((*arg1).headers).ptr[local_43]).name).ptr = lsf_allocate(((((*arg1).headers).ptr[local_43]).name).len, 1);
for (size_t local_45 = 0; local_45 < ((((*arg1).headers).ptr[local_43]).name).len; local_45++) ((((*arg1).headers).ptr[local_43]).name).ptr[local_45] = (uint8_t)lsf_get(&input, 1);
((((*arg1).headers).ptr[local_43]).value).len = (size_t)lsf_get(&input, 4); lsf_require(((((*arg1).headers).ptr[local_43]).value).len <= LSF_MAX_BYTES);
((((*arg1).headers).ptr[local_43]).value).ptr = lsf_allocate(((((*arg1).headers).ptr[local_43]).value).len, sizeof(*((((*arg1).headers).ptr[local_43]).value).ptr));
for (size_t local_46 = 0; local_46 < ((((*arg1).headers).ptr[local_43]).value).len; local_46++) {
uint64_t local_47 = lsf_get(&input, 1);  (((((*arg1).headers).ptr[local_43]).value).ptr[local_46]) = (__typeof__((((((*arg1).headers).ptr[local_43]).value).ptr[local_46])))local_47;
}
}
uint64_t local_49 = lsf_get(&input, 1); lsf_require(local_49 <= 1); (((*arg1).media_type).is_some) = (__typeof__((((*arg1).media_type).is_some)))local_49;
if (((*arg1).media_type).is_some) {
(((*arg1).media_type).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((*arg1).media_type).val).len <= LSF_MAX_BYTES);
(((*arg1).media_type).val).ptr = lsf_allocate((((*arg1).media_type).val).len, 1);
for (size_t local_50 = 0; local_50 < (((*arg1).media_type).val).len; local_50++) (((*arg1).media_type).val).ptr[local_50] = (uint8_t)lsf_get(&input, 1);
}
uint64_t local_52 = lsf_get(&input, 1); lsf_require(local_52 <= 1); (((*arg1).representation_length).is_some) = (__typeof__((((*arg1).representation_length).is_some)))local_52;
if (((*arg1).representation_length).is_some) {
uint64_t local_53 = lsf_get(&input, 8);  (((*arg1).representation_length).val) = (__typeof__((((*arg1).representation_length).val)))local_53;
}
((*arg1).body_base64).len = (size_t)lsf_get(&input, 4);
lsf_require(((*arg1).body_base64).len <= LSF_MAX_BYTES);
((*arg1).body_base64).ptr = lsf_allocate(((*arg1).body_base64).len, 1);
for (size_t local_54 = 0; local_54 < ((*arg1).body_base64).len; local_54++) ((*arg1).body_base64).ptr[local_54] = (uint8_t)lsf_get(&input, 1);
lsf_finish(&input); lsf_java_free(owned);
}
void *lsf_java_host(int32_t operation, void *bytes, int32_t length) {
lsf_require(length >= 0 && (uint32_t)length <= LSF_MAX_BYTES);
lsf_wire input = {bytes, (size_t)length, 0, (size_t)length}; lsf_wire output = {0};
switch (operation) {
case 0: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_monotonic_now_nanos();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 1: {
lsf_finish(&input);
uint64_t result = {0};
result = latent_clock_wall_now_unix_millis();
lsf_put(&output, (uint64_t)(result), 8);
break; }
case 2: {
latent_service_invoke_target_t arg0 = {0};
uint64_t local_61 = lsf_get(&input, 1); lsf_require(local_61 <= 1); (((arg0).tenant).is_some) = (__typeof__((((arg0).tenant).is_some)))local_61;
if (((arg0).tenant).is_some) {
(((arg0).tenant).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).tenant).val).len <= LSF_MAX_BYTES);
(((arg0).tenant).val).ptr = lsf_allocate((((arg0).tenant).val).len, 1);
for (size_t local_62 = 0; local_62 < (((arg0).tenant).val).len; local_62++) (((arg0).tenant).val).ptr[local_62] = (uint8_t)lsf_get(&input, 1);
}
((arg0).service).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).service).len <= LSF_MAX_BYTES);
((arg0).service).ptr = lsf_allocate(((arg0).service).len, 1);
for (size_t local_63 = 0; local_63 < ((arg0).service).len; local_63++) ((arg0).service).ptr[local_63] = (uint8_t)lsf_get(&input, 1);
((arg0).contract).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).contract).len <= LSF_MAX_BYTES);
((arg0).contract).ptr = lsf_allocate(((arg0).contract).len, 1);
for (size_t local_64 = 0; local_64 < ((arg0).contract).len; local_64++) ((arg0).contract).ptr[local_64] = (uint8_t)lsf_get(&input, 1);
((arg0).function).len = (size_t)lsf_get(&input, 4);
lsf_require(((arg0).function).len <= LSF_MAX_BYTES);
((arg0).function).ptr = lsf_allocate(((arg0).function).len, 1);
for (size_t local_65 = 0; local_65 < ((arg0).function).len; local_65++) ((arg0).function).ptr[local_65] = (uint8_t)lsf_get(&input, 1);
uint64_t local_67 = lsf_get(&input, 1); lsf_require(local_67 <= 1); (((arg0).route).is_some) = (__typeof__((((arg0).route).is_some)))local_67;
if (((arg0).route).is_some) {
(((arg0).route).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg0).route).val).len <= LSF_MAX_BYTES);
(((arg0).route).val).ptr = lsf_allocate((((arg0).route).val).len, 1);
for (size_t local_68 = 0; local_68 < (((arg0).route).val).len; local_68++) (((arg0).route).val).ptr[local_68] = (uint8_t)lsf_get(&input, 1);
}
probe_list_u8_t arg1 = {0};
(arg1).len = (size_t)lsf_get(&input, 4); lsf_require((arg1).len <= LSF_MAX_BYTES);
(arg1).ptr = lsf_allocate((arg1).len, sizeof(*(arg1).ptr));
for (size_t local_69 = 0; local_69 < (arg1).len; local_69++) {
uint64_t local_70 = lsf_get(&input, 1);  ((arg1).ptr[local_69]) = (__typeof__(((arg1).ptr[local_69])))local_70;
}
probe_string_t arg2 = {0};
(arg2).len = (size_t)lsf_get(&input, 4);
lsf_require((arg2).len <= LSF_MAX_BYTES);
(arg2).ptr = lsf_allocate((arg2).len, 1);
for (size_t local_71 = 0; local_71 < (arg2).len; local_71++) (arg2).ptr[local_71] = (uint8_t)lsf_get(&input, 1);
latent_service_invoke_call_options_t arg3 = {0};
uint64_t local_74 = lsf_get(&input, 1); lsf_require(local_74 <= 1); (((arg3).deadline_unix_millis).is_some) = (__typeof__((((arg3).deadline_unix_millis).is_some)))local_74;
if (((arg3).deadline_unix_millis).is_some) {
uint64_t local_75 = lsf_get(&input, 8);  (((arg3).deadline_unix_millis).val) = (__typeof__((((arg3).deadline_unix_millis).val)))local_75;
}
uint64_t local_76 = lsf_get(&input, 1);  ((arg3).priority) = (__typeof__(((arg3).priority)))local_76;
uint64_t local_78 = lsf_get(&input, 1); lsf_require(local_78 <= 1); (((arg3).idempotency_key).is_some) = (__typeof__((((arg3).idempotency_key).is_some)))local_78;
if (((arg3).idempotency_key).is_some) {
(((arg3).idempotency_key).val).len = (size_t)lsf_get(&input, 4);
lsf_require((((arg3).idempotency_key).val).len <= LSF_MAX_BYTES);
(((arg3).idempotency_key).val).ptr = lsf_allocate((((arg3).idempotency_key).val).len, 1);
for (size_t local_79 = 0; local_79 < (((arg3).idempotency_key).val).len; local_79++) (((arg3).idempotency_key).val).ptr[local_79] = (uint8_t)lsf_get(&input, 1);
}
((arg3).metadata).len = lsf_count(&input); lsf_require(((arg3).metadata).len <= LSF_MAX_ITEMS);
((arg3).metadata).ptr = lsf_allocate(((arg3).metadata).len, sizeof(*((arg3).metadata).ptr));
for (size_t local_80 = 0; local_80 < ((arg3).metadata).len; local_80++) {
((((arg3).metadata).ptr[local_80]).f0).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg3).metadata).ptr[local_80]).f0).len <= LSF_MAX_BYTES);
((((arg3).metadata).ptr[local_80]).f0).ptr = lsf_allocate(((((arg3).metadata).ptr[local_80]).f0).len, 1);
for (size_t local_82 = 0; local_82 < ((((arg3).metadata).ptr[local_80]).f0).len; local_82++) ((((arg3).metadata).ptr[local_80]).f0).ptr[local_82] = (uint8_t)lsf_get(&input, 1);
((((arg3).metadata).ptr[local_80]).f1).len = (size_t)lsf_get(&input, 4);
lsf_require(((((arg3).metadata).ptr[local_80]).f1).len <= LSF_MAX_BYTES);
((((arg3).metadata).ptr[local_80]).f1).ptr = lsf_allocate(((((arg3).metadata).ptr[local_80]).f1).len, 1);
for (size_t local_83 = 0; local_83 < ((((arg3).metadata).ptr[local_80]).f1).len; local_83++) ((((arg3).metadata).ptr[local_80]).f1).ptr[local_83] = (uint8_t)lsf_get(&input, 1);
}
lsf_finish(&input);
latent_service_invoke_invocation_outcome_t result = {0};
latent_service_invoke_call(&arg0, &arg1, &arg2, &arg3, &result);
if (((arg0).tenant).is_some) {
lsf_release((((arg0).tenant).val).ptr, (((arg0).tenant).val).len); (((arg0).tenant).val).ptr = NULL; (((arg0).tenant).val).len = 0;
}
lsf_release(((arg0).service).ptr, ((arg0).service).len); ((arg0).service).ptr = NULL; ((arg0).service).len = 0;
lsf_release(((arg0).contract).ptr, ((arg0).contract).len); ((arg0).contract).ptr = NULL; ((arg0).contract).len = 0;
lsf_release(((arg0).function).ptr, ((arg0).function).len); ((arg0).function).ptr = NULL; ((arg0).function).len = 0;
if (((arg0).route).is_some) {
lsf_release((((arg0).route).val).ptr, (((arg0).route).val).len); (((arg0).route).val).ptr = NULL; (((arg0).route).val).len = 0;
}
for (size_t local_94 = 0; local_94 < (arg1).len; local_94++) {
}
lsf_release((arg1).ptr, (arg1).len * sizeof(*(arg1).ptr)); (arg1).ptr = NULL; (arg1).len = 0;
lsf_release((arg2).ptr, (arg2).len); (arg2).ptr = NULL; (arg2).len = 0;
if (((arg3).deadline_unix_millis).is_some) {
}
if (((arg3).idempotency_key).is_some) {
lsf_release((((arg3).idempotency_key).val).ptr, (((arg3).idempotency_key).val).len); (((arg3).idempotency_key).val).ptr = NULL; (((arg3).idempotency_key).val).len = 0;
}
for (size_t local_105 = 0; local_105 < ((arg3).metadata).len; local_105++) {
lsf_release(((((arg3).metadata).ptr[local_105]).f0).ptr, ((((arg3).metadata).ptr[local_105]).f0).len); ((((arg3).metadata).ptr[local_105]).f0).ptr = NULL; ((((arg3).metadata).ptr[local_105]).f0).len = 0;
lsf_release(((((arg3).metadata).ptr[local_105]).f1).ptr, ((((arg3).metadata).ptr[local_105]).f1).len); ((((arg3).metadata).ptr[local_105]).f1).ptr = NULL; ((((arg3).metadata).ptr[local_105]).f1).len = 0;
}
lsf_release(((arg3).metadata).ptr, ((arg3).metadata).len * sizeof(*((arg3).metadata).ptr)); ((arg3).metadata).ptr = NULL; ((arg3).metadata).len = 0;
lsf_put(&output, (uint64_t)((result).tag), 4);
switch ((result).tag) {
case 0: {
lsf_require((((result).val.success).payload).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.success).payload).len, 4);
for (size_t local_112 = 0; local_112 < (((result).val.success).payload).len; local_112++) {
lsf_put(&output, (uint64_t)((((result).val.success).payload).ptr[local_112]), 1);
}
lsf_require((((result).val.success).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.success).media_type).len, 4);
for (size_t local_114 = 0; local_114 < (((result).val.success).media_type).len; local_114++) lsf_put(&output, (((result).val.success).media_type).ptr[local_114], 1);
lsf_require((((result).val.success).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.success).metadata).len, 4);
for (size_t local_115 = 0; local_115 < (((result).val.success).metadata).len; local_115++) {
lsf_require((((((result).val.success).metadata).ptr[local_115]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.success).metadata).ptr[local_115]).f0).len, 4);
for (size_t local_117 = 0; local_117 < (((((result).val.success).metadata).ptr[local_115]).f0).len; local_117++) lsf_put(&output, (((((result).val.success).metadata).ptr[local_115]).f0).ptr[local_117], 1);
lsf_require((((((result).val.success).metadata).ptr[local_115]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.success).metadata).ptr[local_115]).f1).len, 4);
for (size_t local_118 = 0; local_118 < (((((result).val.success).metadata).ptr[local_115]).f1).len; local_118++) lsf_put(&output, (((((result).val.success).metadata).ptr[local_115]).f1).ptr[local_118], 1);
}
break; }
case 1: {
lsf_require((((result).val.declared_error).code).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.declared_error).code).len, 4);
for (size_t local_120 = 0; local_120 < (((result).val.declared_error).code).len; local_120++) lsf_put(&output, (((result).val.declared_error).code).ptr[local_120], 1);
lsf_require((((result).val.declared_error).message).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.declared_error).message).len, 4);
for (size_t local_121 = 0; local_121 < (((result).val.declared_error).message).len; local_121++) lsf_put(&output, (((result).val.declared_error).message).ptr[local_121], 1);
lsf_require((((result).val.declared_error).payload).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.declared_error).payload).len, 4);
for (size_t local_122 = 0; local_122 < (((result).val.declared_error).payload).len; local_122++) {
lsf_put(&output, (uint64_t)((((result).val.declared_error).payload).ptr[local_122]), 1);
}
lsf_require((((result).val.declared_error).media_type).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.declared_error).media_type).len, 4);
for (size_t local_124 = 0; local_124 < (((result).val.declared_error).media_type).len; local_124++) lsf_put(&output, (((result).val.declared_error).media_type).ptr[local_124], 1);
lsf_require((((result).val.declared_error).metadata).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.declared_error).metadata).len, 4);
for (size_t local_125 = 0; local_125 < (((result).val.declared_error).metadata).len; local_125++) {
lsf_require((((((result).val.declared_error).metadata).ptr[local_125]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.declared_error).metadata).ptr[local_125]).f0).len, 4);
for (size_t local_127 = 0; local_127 < (((((result).val.declared_error).metadata).ptr[local_125]).f0).len; local_127++) lsf_put(&output, (((((result).val.declared_error).metadata).ptr[local_125]).f0).ptr[local_127], 1);
lsf_require((((((result).val.declared_error).metadata).ptr[local_125]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.declared_error).metadata).ptr[local_125]).f1).len, 4);
for (size_t local_128 = 0; local_128 < (((((result).val.declared_error).metadata).ptr[local_125]).f1).len; local_128++) lsf_put(&output, (((((result).val.declared_error).metadata).ptr[local_125]).f1).ptr[local_128], 1);
}
break; }
case 2: {
lsf_put(&output, (uint64_t)((((result).val.platform_failure).code)), 4);
lsf_require((((result).val.platform_failure).code) < 17);
lsf_require((((result).val.platform_failure).message).len <= LSF_MAX_BYTES); lsf_put(&output, (((result).val.platform_failure).message).len, 4);
for (size_t local_132 = 0; local_132 < (((result).val.platform_failure).message).len; local_132++) lsf_put(&output, (((result).val.platform_failure).message).ptr[local_132], 1);
lsf_put(&output, (uint64_t)(((result).val.platform_failure).retryable), 1);
lsf_require((((result).val.platform_failure).details).len <= LSF_MAX_ITEMS); lsf_put(&output, (((result).val.platform_failure).details).len, 4);
for (size_t local_134 = 0; local_134 < (((result).val.platform_failure).details).len; local_134++) {
lsf_require((((((result).val.platform_failure).details).ptr[local_134]).kind).len <= LSF_MAX_BYTES); lsf_put(&output, (((((result).val.platform_failure).details).ptr[local_134]).kind).len, 4);
for (size_t local_136 = 0; local_136 < (((((result).val.platform_failure).details).ptr[local_134]).kind).len; local_136++) lsf_put(&output, (((((result).val.platform_failure).details).ptr[local_134]).kind).ptr[local_136], 1);
lsf_require((((((result).val.platform_failure).details).ptr[local_134]).fields).len <= LSF_MAX_ITEMS); lsf_put(&output, (((((result).val.platform_failure).details).ptr[local_134]).fields).len, 4);
for (size_t local_137 = 0; local_137 < (((((result).val.platform_failure).details).ptr[local_134]).fields).len; local_137++) {
lsf_require((((((((result).val.platform_failure).details).ptr[local_134]).fields).ptr[local_137]).f0).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.platform_failure).details).ptr[local_134]).fields).ptr[local_137]).f0).len, 4);
for (size_t local_139 = 0; local_139 < (((((((result).val.platform_failure).details).ptr[local_134]).fields).ptr[local_137]).f0).len; local_139++) lsf_put(&output, (((((((result).val.platform_failure).details).ptr[local_134]).fields).ptr[local_137]).f0).ptr[local_139], 1);
lsf_require((((((((result).val.platform_failure).details).ptr[local_134]).fields).ptr[local_137]).f1).len <= LSF_MAX_BYTES); lsf_put(&output, (((((((result).val.platform_failure).details).ptr[local_134]).fields).ptr[local_137]).f1).len, 4);
for (size_t local_140 = 0; local_140 < (((((((result).val.platform_failure).details).ptr[local_134]).fields).ptr[local_137]).f1).len; local_140++) lsf_put(&output, (((((((result).val.platform_failure).details).ptr[local_134]).fields).ptr[local_137]).f1).ptr[local_140], 1);
}
}
break; }
default: __builtin_trap(); }
switch ((result).tag) {
case 0: {
for (size_t local_143 = 0; local_143 < (((result).val.success).payload).len; local_143++) {
}
lsf_release((((result).val.success).payload).ptr, (((result).val.success).payload).len * sizeof(*(((result).val.success).payload).ptr)); (((result).val.success).payload).ptr = NULL; (((result).val.success).payload).len = 0;
lsf_release((((result).val.success).media_type).ptr, (((result).val.success).media_type).len); (((result).val.success).media_type).ptr = NULL; (((result).val.success).media_type).len = 0;
for (size_t local_146 = 0; local_146 < (((result).val.success).metadata).len; local_146++) {
lsf_release((((((result).val.success).metadata).ptr[local_146]).f0).ptr, (((((result).val.success).metadata).ptr[local_146]).f0).len); (((((result).val.success).metadata).ptr[local_146]).f0).ptr = NULL; (((((result).val.success).metadata).ptr[local_146]).f0).len = 0;
lsf_release((((((result).val.success).metadata).ptr[local_146]).f1).ptr, (((((result).val.success).metadata).ptr[local_146]).f1).len); (((((result).val.success).metadata).ptr[local_146]).f1).ptr = NULL; (((((result).val.success).metadata).ptr[local_146]).f1).len = 0;
}
lsf_release((((result).val.success).metadata).ptr, (((result).val.success).metadata).len * sizeof(*(((result).val.success).metadata).ptr)); (((result).val.success).metadata).ptr = NULL; (((result).val.success).metadata).len = 0;
break; }
case 1: {
lsf_release((((result).val.declared_error).code).ptr, (((result).val.declared_error).code).len); (((result).val.declared_error).code).ptr = NULL; (((result).val.declared_error).code).len = 0;
lsf_release((((result).val.declared_error).message).ptr, (((result).val.declared_error).message).len); (((result).val.declared_error).message).ptr = NULL; (((result).val.declared_error).message).len = 0;
for (size_t local_153 = 0; local_153 < (((result).val.declared_error).payload).len; local_153++) {
}
lsf_release((((result).val.declared_error).payload).ptr, (((result).val.declared_error).payload).len * sizeof(*(((result).val.declared_error).payload).ptr)); (((result).val.declared_error).payload).ptr = NULL; (((result).val.declared_error).payload).len = 0;
lsf_release((((result).val.declared_error).media_type).ptr, (((result).val.declared_error).media_type).len); (((result).val.declared_error).media_type).ptr = NULL; (((result).val.declared_error).media_type).len = 0;
for (size_t local_156 = 0; local_156 < (((result).val.declared_error).metadata).len; local_156++) {
lsf_release((((((result).val.declared_error).metadata).ptr[local_156]).f0).ptr, (((((result).val.declared_error).metadata).ptr[local_156]).f0).len); (((((result).val.declared_error).metadata).ptr[local_156]).f0).ptr = NULL; (((((result).val.declared_error).metadata).ptr[local_156]).f0).len = 0;
lsf_release((((((result).val.declared_error).metadata).ptr[local_156]).f1).ptr, (((((result).val.declared_error).metadata).ptr[local_156]).f1).len); (((((result).val.declared_error).metadata).ptr[local_156]).f1).ptr = NULL; (((((result).val.declared_error).metadata).ptr[local_156]).f1).len = 0;
}
lsf_release((((result).val.declared_error).metadata).ptr, (((result).val.declared_error).metadata).len * sizeof(*(((result).val.declared_error).metadata).ptr)); (((result).val.declared_error).metadata).ptr = NULL; (((result).val.declared_error).metadata).len = 0;
break; }
case 2: {
lsf_release((((result).val.platform_failure).message).ptr, (((result).val.platform_failure).message).len); (((result).val.platform_failure).message).ptr = NULL; (((result).val.platform_failure).message).len = 0;
for (size_t local_164 = 0; local_164 < (((result).val.platform_failure).details).len; local_164++) {
lsf_release((((((result).val.platform_failure).details).ptr[local_164]).kind).ptr, (((((result).val.platform_failure).details).ptr[local_164]).kind).len); (((((result).val.platform_failure).details).ptr[local_164]).kind).ptr = NULL; (((((result).val.platform_failure).details).ptr[local_164]).kind).len = 0;
for (size_t local_167 = 0; local_167 < (((((result).val.platform_failure).details).ptr[local_164]).fields).len; local_167++) {
lsf_release((((((((result).val.platform_failure).details).ptr[local_164]).fields).ptr[local_167]).f0).ptr, (((((((result).val.platform_failure).details).ptr[local_164]).fields).ptr[local_167]).f0).len); (((((((result).val.platform_failure).details).ptr[local_164]).fields).ptr[local_167]).f0).ptr = NULL; (((((((result).val.platform_failure).details).ptr[local_164]).fields).ptr[local_167]).f0).len = 0;
lsf_release((((((((result).val.platform_failure).details).ptr[local_164]).fields).ptr[local_167]).f1).ptr, (((((((result).val.platform_failure).details).ptr[local_164]).fields).ptr[local_167]).f1).len); (((((((result).val.platform_failure).details).ptr[local_164]).fields).ptr[local_167]).f1).ptr = NULL; (((((((result).val.platform_failure).details).ptr[local_164]).fields).ptr[local_167]).f1).len = 0;
}
lsf_release((((((result).val.platform_failure).details).ptr[local_164]).fields).ptr, (((((result).val.platform_failure).details).ptr[local_164]).fields).len * sizeof(*(((((result).val.platform_failure).details).ptr[local_164]).fields).ptr)); (((((result).val.platform_failure).details).ptr[local_164]).fields).ptr = NULL; (((((result).val.platform_failure).details).ptr[local_164]).fields).len = 0;
}
lsf_release((((result).val.platform_failure).details).ptr, (((result).val.platform_failure).details).len * sizeof(*(((result).val.platform_failure).details).ptr)); (((result).val.platform_failure).details).ptr = NULL; (((result).val.platform_failure).details).len = 0;
break; }
default: __builtin_trap(); }
break; }
default: __builtin_trap(); }
return lsf_result(&output);
}
