// Generated from authoritative WIT and maintained wit-bindgen C. DO NOT EDIT.
package dev.latent.generated;
import dev.latent.guest.*;
import org.teavm.interop.Address;
import org.teavm.interop.Export;
import org.teavm.interop.Function;
public final class Bindings {
private Bindings() { }
public record Value1(String f0, String f1) { public Value1 { java.util.Objects.requireNonNull(f0); java.util.Objects.requireNonNull(f1); } }
public record LatentContextContextInvocationPrincipal(String subject, String kind, Option<String> tenant, Option<String> service, java.util.List<Value1> claims) { public LatentContextContextInvocationPrincipal { java.util.Objects.requireNonNull(subject); java.util.Objects.requireNonNull(kind); java.util.Objects.requireNonNull(tenant); java.util.Objects.requireNonNull(service); java.util.Objects.requireNonNull(claims); } }
public record LatentContextContextTraceContext(String traceId, String spanId, Short traceFlags, java.util.List<Value1> baggage) { public LatentContextContextTraceContext { java.util.Objects.requireNonNull(traceId); java.util.Objects.requireNonNull(spanId); java.util.Objects.requireNonNull(traceFlags); java.util.Objects.requireNonNull(baggage); } }
public record LatentContextContextResourceBudget(Unsigned64 cpuFuel, Unsigned64 memoryBytes, Option<Unsigned64> wallTimeLimitMillis, Long childCalls, Long outboundRequests, Unsigned64 stateReadBytes, Unsigned64 stateWriteBytes, Unsigned64 blobReadBytes, Unsigned64 blobWriteBytes, Unsigned64 logBytes, Long effectCount) { public LatentContextContextResourceBudget { java.util.Objects.requireNonNull(cpuFuel); java.util.Objects.requireNonNull(memoryBytes); java.util.Objects.requireNonNull(wallTimeLimitMillis); java.util.Objects.requireNonNull(childCalls); java.util.Objects.requireNonNull(outboundRequests); java.util.Objects.requireNonNull(stateReadBytes); java.util.Objects.requireNonNull(stateWriteBytes); java.util.Objects.requireNonNull(blobReadBytes); java.util.Objects.requireNonNull(blobWriteBytes); java.util.Objects.requireNonNull(logBytes); java.util.Objects.requireNonNull(effectCount); } }
public interface Exports {
String status();
}
public static final class LatentClockMonotonic { private LatentClockMonotonic() { }
public static Unsigned64 nowNanos() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(0)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentClockWall { private LatentClockWall() { }
public static Unsigned64 nowUnixMillis() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(1)) {
Unsigned64 result = readU64(input);
input.finish(); return result;
} } }
}
public static final class LatentContextContext { private LatentContextContext() { }
public static String activationId() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(2)) {
String result = readString(input);
input.finish(); return result;
} } }
public static String rootActivationId() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(3)) {
String result = readString(input);
input.finish(); return result;
} } }
public static Option<String> parentActivationId() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(4)) {
Option<String> result = readT0(input);
input.finish(); return result;
} } }
public static LatentContextContextInvocationPrincipal principal() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(5)) {
LatentContextContextInvocationPrincipal result = readT3(input);
input.finish(); return result;
} } }
public static LatentContextContextTraceContext trace() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(6)) {
LatentContextContextTraceContext result = readT4(input);
input.finish(); return result;
} } }
public static Option<Unsigned64> deadlineUnixMillis() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(7)) {
Option<Unsigned64> result = readT5(input);
input.finish(); return result;
} } }
public static LatentContextContextResourceBudget remainingBudget() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(8)) {
LatentContextContextResourceBudget result = readT6(input);
input.finish(); return result;
} } }
public static java.util.List<Value1> metadata() {
try (Wire.Writer arguments = new Wire.Writer()) {
try (Wire.Reader input = arguments.call(9)) {
java.util.List<Value1> result = readT2(input);
input.finish(); return result;
} } }
}
public abstract static class Dispatch extends Function { public abstract Address apply(int operation, Address data, int length); }
public static void main(String[] args) { Function.get(Dispatch.class, Bindings.class, "dispatch"); }
@Export(name = "lsf_java_dispatch") public static Address dispatch(int operation, Address data, int length) {
try (Wire.Reader input = Wire.Reader.copy(data, length); Wire.Writer output = new Wire.Writer()) {
switch (operation) {
case 0: {
input.finish();
writeString(output, new dev.latent.app.Capsule().status());
return output.nativeResult(); }
default: throw new IllegalArgumentException("unknown Java export"); } } }
private static Unit readUnit(Wire.Reader input) { return Unit.VALUE; }
private static void writeUnit(Wire.Writer output, Unit value) { java.util.Objects.requireNonNull(value); }
private static Integer readCharValue(Wire.Reader input) { long value = input.integer(4); Wire.require(value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); return (int) value; }
private static Boolean readBool(Wire.Reader input) { return input.bool(); }
private static void writeBool(Wire.Writer output, Boolean value) { output.bool(value); }
private static Integer readChar(Wire.Reader input) { return readCharValue(input); }
private static void writeChar(Wire.Writer output, Integer value) { Wire.require(value >= 0 && value <= 0x10ffff && !(value >= 0xd800 && value <= 0xdfff)); output.unsigned(value, 4); }
private static Float readF32(Wire.Reader input) { return Float.intBitsToFloat((int) input.integer(4)); }
private static void writeF32(Wire.Writer output, Float value) { output.integer(Float.floatToRawIntBits(value), 4); }
private static Double readF64(Wire.Reader input) { return Double.longBitsToDouble(input.integer(8)); }
private static void writeF64(Wire.Writer output, Double value) { output.integer(Double.doubleToRawLongBits(value), 8); }
private static Short readS16(Wire.Reader input) { return (short) input.integer(2); }
private static void writeS16(Wire.Writer output, Short value) { output.integer(value, 2); }
private static Integer readS32(Wire.Reader input) { return (int) input.integer(4); }
private static void writeS32(Wire.Writer output, Integer value) { output.integer(value, 4); }
private static Long readS64(Wire.Reader input) { return (long) input.integer(8); }
private static void writeS64(Wire.Writer output, Long value) { output.integer(value, 8); }
private static Byte readS8(Wire.Reader input) { return (byte) input.integer(1); }
private static void writeS8(Wire.Writer output, Byte value) { output.integer(value, 1); }
private static String readString(Wire.Reader input) { return input.string(); }
private static void writeString(Wire.Writer output, String value) { output.string(value); }
private static Integer readU16(Wire.Reader input) { return (int) input.integer(2); }
private static void writeU16(Wire.Writer output, Integer value) { output.unsigned(value, 2); }
private static Long readU32(Wire.Reader input) { return (long) input.integer(4); }
private static void writeU32(Wire.Writer output, Long value) { output.unsigned(value, 4); }
private static Unsigned64 readU64(Wire.Reader input) { return new Unsigned64(input.integer(8)); }
private static void writeU64(Wire.Writer output, Unsigned64 value) { output.integer(value.bits(), 8); }
private static Short readU8(Wire.Reader input) { return (short) input.integer(1); }
private static void writeU8(Wire.Writer output, Short value) { output.unsigned(value, 1); }
private static void writeT0(Wire.Writer output, Option<String> value) {
output.bool(value.isSome()); if (value.isSome()) { writeString(output, value.value()); }
}
private static Option<String> readT0(Wire.Reader input) {
return input.bool() ? Option.some(readString(input)) : Option.none();
}
private static void writeT1(Wire.Writer output, Value1 value) {
writeString(output, value.f0());
writeString(output, value.f1());
}
private static Value1 readT1(Wire.Reader input) {
return new Value1(readString(input), readString(input));
}
private static void writeT2(Wire.Writer output, java.util.List<Value1> value) {
output.count(value.size());
for (Value1 item : value) { writeT1(output, item); }
}
private static java.util.List<Value1> readT2(Wire.Reader input) {
int count = input.count();
java.util.ArrayList<Value1> values = new java.util.ArrayList<>(count);
for (int i = 0; i < count; i++) values.add(readT1(input));
return values;
}
private static void writeT3(Wire.Writer output, LatentContextContextInvocationPrincipal value) {
writeString(output, value.subject());
writeString(output, value.kind());
writeT0(output, value.tenant());
writeT0(output, value.service());
writeT2(output, value.claims());
}
private static LatentContextContextInvocationPrincipal readT3(Wire.Reader input) {
return new LatentContextContextInvocationPrincipal(readString(input), readString(input), readT0(input), readT0(input), readT2(input));
}
private static void writeT4(Wire.Writer output, LatentContextContextTraceContext value) {
writeString(output, value.traceId());
writeString(output, value.spanId());
writeU8(output, value.traceFlags());
writeT2(output, value.baggage());
}
private static LatentContextContextTraceContext readT4(Wire.Reader input) {
return new LatentContextContextTraceContext(readString(input), readString(input), readU8(input), readT2(input));
}
private static void writeT5(Wire.Writer output, Option<Unsigned64> value) {
output.bool(value.isSome()); if (value.isSome()) { writeU64(output, value.value()); }
}
private static Option<Unsigned64> readT5(Wire.Reader input) {
return input.bool() ? Option.some(readU64(input)) : Option.none();
}
private static void writeT6(Wire.Writer output, LatentContextContextResourceBudget value) {
writeU64(output, value.cpuFuel());
writeU64(output, value.memoryBytes());
writeT5(output, value.wallTimeLimitMillis());
writeU32(output, value.childCalls());
writeU32(output, value.outboundRequests());
writeU64(output, value.stateReadBytes());
writeU64(output, value.stateWriteBytes());
writeU64(output, value.blobReadBytes());
writeU64(output, value.blobWriteBytes());
writeU64(output, value.logBytes());
writeU32(output, value.effectCount());
}
private static LatentContextContextResourceBudget readT6(Wire.Reader input) {
return new LatentContextContextResourceBudget(readU64(input), readU64(input), readT5(input), readU32(input), readU32(input), readU64(input), readU64(input), readU64(input), readU64(input), readU64(input), readU32(input));
}
}
