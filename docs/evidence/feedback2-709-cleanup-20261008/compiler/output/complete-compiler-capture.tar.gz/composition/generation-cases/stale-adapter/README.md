# java-http-adapter

Generated from an authoritative typed Java domain and explicit routes.
Regenerate through `tools/java_http_adapter.py`; run `check` before building.
The node requires explicit clock grants, local-service binding/grant and pinned HTTP trigger.
The additional local-service hop remains part of this profile. No latency change is measured.
