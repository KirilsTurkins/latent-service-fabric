# Compatible Java HTTP adapter revision

This independently compiled revision changes the bounded body for unselected routes.
It preserves the parent's exact WIT and service identity, with a new package name/version
and one less CPU fuel. Build, sign and admit it independently before canary or rollback.
